/*
**  SCCS Info :  "@(#)MainUI.java	1.17    05/03/24"
*/
/*
 * MainUI.java
 *
 * Created on April 18, 2000, 11:51 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class MainUI {



  public static void main(java.lang.String[] args) {

	Constants.uiThreads = new ThreadGroup("IDS Application threads");
	
	boolean showMem = false;

	String version = System.getProperty("version");
	if (version!=null)
	{
		System.out.println("RELEASE NOTES   :\n"+Release.RELEASE_NOTES);
		System.out.print("COMPILED ON "+Release.HOSTNAME);
		System.out.println("/"+Release.COMPILE_DATE);
		System.out.println("FILE VERSIONS   :\n"+Release.FILE_VERSIONS);
		System.out.println("FILES CHECKED OUT :\n"+Release.EDIT_FILES);
		System.exit(0);
	}


	String local = System.getProperty("local");
	if ((local==null) || !local.equalsIgnoreCase("true")) {
		javax.swing.RepaintManager.currentManager(null).setDoubleBufferingEnabled(false);
		System.out.println("Double Buffering turned OFF.");
	}



	String debug = System.getProperty("debug");
	if ((debug!=null) && debug.equalsIgnoreCase("true"))
				Constants.DEBUG = true;


	String ckpt_status_str = System.getProperty("ckptfromdsp");
	if ( (ckpt_status_str == null)
	     || ((ckpt_status_str!=null) && debug.equalsIgnoreCase("true")) )
	    Constants.checkpointStatusFromDSP = true;
	else
	    Constants.checkpointStatusFromDSP = false;
	
	String ports = System.getProperty("ports");
	if ((ports!=null) && ports.equalsIgnoreCase("true"))
				Constants.SHOW_PORTS_BUTTON = true;

	String verbose = System.getProperty("verbose");
	if (verbose!=null) {
		try {
			Constants.Verbose = Integer.parseInt(verbose);
		} catch (NumberFormatException nfe) {}
	}


	/*
	****************************************************************
	* IGNORE COMMAND LINE ACCESS LEVEL
	String mode = System.getProperty("mode");
	if ((mode!=null) && mode.equalsIgnoreCase("restricted"))
		AccessLevel.MENU_ACCESS_LEVEL = 1;

	String level = System.getProperty("accesslevel");
	if (level!=null) {
		try {
			AccessLevel.MENU_ACCESS_LEVEL = Integer.parseInt(level);
		} catch (NumberFormatException nfe) {
			System.out.println("Error in parsing access level.\n Defaulting to restricted.");
			AccessLevel.MENU_ACCESS_LEVEL = 2;
		}
	}

	*
	****************************************************************
	*/



	try {
		String laf = System.getProperty("laf");
		
		if (laf!=null) {
			if (laf.equalsIgnoreCase("motif")) {
				javax.swing.UIManager.setLookAndFeel(
						"com.sun.java.swing.plaf.motif.MotifLookAndFeel");
			} else if (laf.equalsIgnoreCase("windows")) {
				javax.swing.UIManager.setLookAndFeel(
						"com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			} else if (laf.equalsIgnoreCase("macintosh")) {
				javax.swing.UIManager.setLookAndFeel(
						"com.sun.java.swing.plaf.mac.MacLookAndFeel");
			} else if (laf.equalsIgnoreCase("system")) {
				javax.swing.UIManager.setLookAndFeel(
					javax.swing.UIManager.getSystemLookAndFeelClassName());
			} else {
	    		javax.swing.UIManager.setLookAndFeel(
					javax.swing.UIManager.getCrossPlatformLookAndFeelClassName());
			}
		}
	} catch (Exception exc) {
	    System.out.println("Error loading L&F: " + exc);
	}

	int width = -1;
	int height = -1;

	String s = System.getProperty("width");
	if (s!=null) {
		try {
			width = Integer.parseInt(s);
		} catch (NumberFormatException nfe) {
		}
	}

	s = System.getProperty("height");
	if (s!=null) {
		try {
			height = Integer.parseInt(s);
		} catch (NumberFormatException nfe) {
		}
	}

	s = System.getProperty("showmem");
	if ((s!=null) && s.equalsIgnoreCase("true"))
				showMem = true;
  

    javax.swing.JFrame frame 
= new javax.swing.JFrame(Release.PLATFORM_STRING + " User Interface "+Release.VERSION_STRING);

    frame.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	final javax.swing.JFrame f = frame;

    frame.addWindowListener(new java.awt.event.WindowAdapter()
        {
          public void windowClosing(java.awt.event.WindowEvent evt){
              
            int resp = javax.swing.JOptionPane.showConfirmDialog(f,
											"Confirm exit  ??");
    
            if (resp==javax.swing.JOptionPane.YES_OPTION){
              
			  f.setVisible(false);
              f.dispose();
			  System.exit(0);
            }
            return;
          }    
        });



    javax.swing.JOptionPane.setRootFrame(frame);


	frame.getContentPane().setLayout(new java.awt.BorderLayout());
	MainScreenPanel mainPanel = new MainScreenPanel(frame);
	frame.getContentPane().add(mainPanel, 
                                   java.awt.BorderLayout.CENTER);


	

        if ( (width != -1) && (height != -1) )
                frame.setSize(width, height);


	frame.validate();
	frame.pack();

        width = frame.getWidth();
        height = frame.getHeight();

        java.awt.Dimension screenSize
                = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
	int x = screenSize.width/2 - width/2;
	int y = screenSize.height/2 - height/2;

	frame.setLocation(x,y);



        
	
	mainPanel.requestDefaultFocus();




	frame.show();

        
        if (showMem) {
		MemoryView mv = new MemoryView ();
		mv.setLocation (0, 0);
		mv.setVisible (true);
	}
  }


}




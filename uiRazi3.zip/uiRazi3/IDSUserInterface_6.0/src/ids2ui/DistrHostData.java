/*
**  SCCS Info :  "@(#)DistrHostData.java	1.1    04/04/14"
*/


package ids2ui;

public class DistrHostData {
	public String dc1Host;
	public String dc2Host;
	public StringBuffer distrList;
	public DistrHostData(String h1, String h2, String id)
	{
	    dc1Host = new String(h1);
	    dc2Host = new String(h2);
	    distrList = new StringBuffer(id);
	    distrList.append(" ");
	}
	public void addDistr(String id) 
	{
	    if (distrList!=null)
		distrList.append(id).append(" ");
	}

    }

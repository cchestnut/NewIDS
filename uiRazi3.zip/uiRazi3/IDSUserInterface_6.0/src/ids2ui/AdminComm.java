/*
**  SCCS Info :  "@(#)AdminComm.java	1.12    05/08/18"
*/
/*
 * AdminComm.java
 *
 * Created on May 15, 2000, 2:51 PM
 */
 
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;


/** 
 *
 * @author  srz
 * @version 
 */
public class AdminComm extends Object {

  /* ********* ADMINSERVER ****/
  static final int              ADMIN_MESSAGE            = 0;
  static final int 	        EXEC_COMMAND            = 1;
  static final int 	        DYNAMIC_MESSAGE         = 2;
  static final int 	        PROXY_MESSAGE           = 3;

  static final int 	        LINE_HANDLER=1;
  static final int 	        MESSAGE_MANAGER=2;
  static final int 	        READER=3;
  static final int 	        RETRANSMISSION=4;
  static final int 	        DELETE_DISTRIBUTOR_CACHE=5;
  static final int 	        CONFIGSERVER=6;
  
  static final int 	        LIST_IDS2_PROC_BY_KEY   = 2;
  static final int 	        LIST_IDS2_PROC_BY_NAME  = 3;
  static final int 	        START_IDS2_PROC         = 4;  
  static final int 	        STOP_IDS2_PROC          = 5;  
  static final int 	        RUN_COMMAND          	= 6;  
  static final int	INSTALL_X25_CONFIGURATION_FILE  = 7;  
  static final int	RETRIEVE_X25_CONFIGURATION_FILE = 8;  
  static final int	RETRIEVE_DEFAULT_X25_CONFIGURATION_FILE = 9;  

    static final int 	        ADD_PRODUCT=200;
    static final int 	        MODIFY_PRODUCT=201;
    static final int 	        DELETE_PRODUCT=202;
    static final int 	        SET_FILTERING_CODES=203;
    static final int 	        GET_FILTERING_CODES=204;
    static final int 	        CHANGE_MODE = 300;
    static final int 	        CHANGE_DISTRIBUTOR=504;


  static private String   userName="USER-NAME";
  static private String           testServer = "dist-c1d2";

  
  /** Creates new AdminComm */
  public AdminComm() {
  }
  
 
  
  private static byte[] getResponse(Socket server) 
      throws IOException, DBException, DBModeException
  {

    InputStream din = server.getInputStream();

    byte[] hdrb = new byte[Constants.MIN_HEADER_BYTES];

    din.read(hdrb,0,Constants.MIN_HEADER_BYTES);
    String hdr = new String(hdrb);
    StringBuffer sep =  new StringBuffer();
    sep.append(ConfigComm.CONF_FS).append(ConfigComm.CONF_SOH);
    java.util.StringTokenizer tok = 
              new java.util.StringTokenizer(hdr,sep.toString());

    //System.out.println("Response "+hdr+ " "+hdr.length());
    int len=0;

    if (tok.hasMoreTokens()) {
      String token = tok.nextToken();
      
      try {
        len = Integer.parseInt(token);
      } catch (Exception e) {
        Log.getInstance().log_error("AdminComm:Error in parsing length of response",e);
        len = 0;
      }
    }

    if (len == 0) throw new IOException("Error in parsing length of response");

    int rlen = len - Constants.MIN_HEADER_BYTES;
    
    byte[] b = new byte[len];
    int nleft=rlen,nread=0,offset=Constants.MIN_HEADER_BYTES;
    while (nleft > 0) {
      nread = din.read(b,offset,nleft);
      if (nread <= 0) break;
      nleft -= nread;
      offset += nread;
    }
    
    if (offset != len) throw new IOException("Error in reading server response");   
    
    System.arraycopy(hdrb,0,b,0,Constants.MIN_HEADER_BYTES);

    server.close();


    
    return b;
  }

   

  private static Socket connectToOPServer(String serverName) throws IOException
  {
      /*
      Socket sock =  new Socket(serverName, Constants.ADMIN_SERVER_PORT);
      */
      Socket sock = TimeoutSocket.Connect(serverName, 
					  Constants.ADMIN_SERVER_PORT,
					  Constants.ConnectTimeout);

 	/* Set timeout */
      //sock.setSoTimeout(Constants.NetworkTimeout);
      sock.setTcpNoDelay(true);

      return sock;
  }

  private static void sendRequest(Socket server,StringBuffer buf, 
				  boolean insertHeader) throws IOException
  {
    BufferedOutputStream dout;
    StringBuffer b = new StringBuffer();;
    int len=buf.length()+Constants.MIN_HEADER_BYTES;
    long checksum=55555;
    
    dout = new BufferedOutputStream( server.getOutputStream() );

    if (insertHeader) {
      b.append(ConfigComm.CONF_SOH).append(Integer.toString(len))
            .append(ConfigComm.CONF_FS)
            .append(Long.toString(checksum));
      b.append("                  ");
      b.setLength(Constants.MIN_HEADER_BYTES);
      buf.insert(0,b);
    }
    
    if (Constants.DEBUG && Constants.Verbose>1)
      System.out.println("Buffer " + buf.toString() );

    dout.write(buf.toString().getBytes(),0,buf.length()); 
    dout.flush();
    //System.out.println("Written " + buf.length() + " bytes");
  }


  
  
  private static byte[] configRequest(String SL, StringBuffer buf) throws IOException, DBException
  {
    byte[] b=null;
    boolean done=false;
    int ntries =Constants.NUM_CONNECTION_TRIES;
    boolean insertHeader = true;
      

    String serverList = ConfigComm.getServerList();

    StringBuffer rbuf = new StringBuffer();

	if (SL.equals(serverList)) {
		rbuf.append(buf);
    		if (Constants.DEBUG && Constants.Verbose>1)
	    		System.out.println("Sending admin request directly to "+serverList);

	} else {

    		if (Constants.DEBUG && Constants.Verbose>1)
	    		System.out.println("Routing "+SL+" request thru "+serverList);




	    StringBuffer rbf = new StringBuffer();
	    int len = buf.length()+Constants.MIN_HEADER_BYTES;
	    long checksum=55555;

	    rbf.append(ConfigComm.CONF_SOH)
		    .append(Integer.toString(len))
		    .append(ConfigComm.CONF_FS)
		    .append(Long.toString(checksum));
	    rbf.append("                  ");
	    rbf.setLength(Constants.MIN_HEADER_BYTES);

	    buf.insert(0,rbf);

	    ConfigComm.createHeader(rbuf,PROXY_MESSAGE,1,0);
	    rbuf.append(SL)
		    .append(ConfigComm.CONF_GS)
		    .append(buf);
	}



    java.util.StringTokenizer tok = new java.util.StringTokenizer(serverList,",");

    String serverName;

	if (tok.hasMoreTokens())
		serverName = tok.nextToken();
	else
		throw new DBException("Could not get admin server list");

    Socket server=null;
    while ( !done ) {
      if (Constants.DEBUG && Constants.Verbose>2)
        System.out.println("Connecting to host: "+serverName);
      
      try {
        server = connectToOPServer(serverName);
        sendRequest(server,rbuf,insertHeader);
	if (Constants.DEBUG && Constants.Verbose>1  && insertHeader)
    			System.out.println("Request with header: "+rbuf.toString());
		
      } catch (UnknownHostException uhe) {
	  Log.getInstance().log_warning("AdminComm:Unknown host: "
					+serverName+".",uhe);
	  
	  ntries=Constants.NUM_CONNECTION_TRIES;
	  if (tok.hasMoreTokens()) {
              serverName = tok.nextToken();
              Log.getInstance().log_warning(
			     "AdminComm:Could not connect. Trying "
			     +serverName,
			     uhe);
              continue;
	  } else
              throw new DBException("Could not connect to adminserver on "
				    +serverName);
	  
      } catch (Exception ioEx) {
        ntries--;
        
	  	Log.getInstance().log_warning("AdminComm:IO Exception : "+serverName
								+".",ioEx);
        if (ntries>0) {
            Log.getInstance().log_warning("AdminComm:Communication error: Retrying .. "
                        +serverName+".",ioEx);
            continue;
        } else { 
            ntries=Constants.NUM_CONNECTION_TRIES;
            if (tok.hasMoreTokens()) {
              serverName = tok.nextToken();
              Log.getInstance().log_warning(
                  "AdminComm:Could not connect. Trying "+serverName,
                  ioEx);
              continue;
            } else
              throw new DBException("Could not connect to adminserver on "+serverName);
        }
        
      }
      
      insertHeader=false;
      try {
        b = getResponse(server);
        done=true;
        
      }  catch (IOException ioEx) {
        ntries--;
        if (ntries>0) {
            Log.getInstance().log_warning("AdminComm:Communication error: "+serverName+" .Retrying ",null);
            continue;
          } else {
        	if (tok.hasMoreTokens()) {
          		ntries=Constants.NUM_CONNECTION_TRIES;
          		serverName = tok.nextToken();
          		Log.getInstance().log_warning(
                  "AdminComm:Trying "+serverName,
                  ioEx);
	        } else 
            throw new DBException("Error in retrieving configuration from server "+serverName);
		}
      }
    }
    
    server.close();
    server = null;
    String s = new String (b) ;

    if (Constants.DEBUG && Constants.Verbose>1)
    	System.out.println("Response: "+s);


    Utils.RequestHeader hdr = new Utils.RequestHeader(s);
    if (hdr.error_number == 146) 
	throw new java.io.IOException("Connection refused");
    if (hdr.error_number == 148) 
	throw new java.io.IOException("Can't connect to host");
    return b;
    
  }


  public static int processAction(int option,String host,String cmdline,StringBuffer response) {
    StringBuffer reqbuf = new StringBuffer();
    
    if ((option != START_IDS2_PROC) 
          && (option != STOP_IDS2_PROC))
    {
      Log.getInstance().log_error("AdminComm:Invalid option passed: "+option,null);
      return -1;
    }


    if ((cmdline == null)|| (cmdline.length()==0)) {
     Log.getInstance().log_error("AdminComm:Required parameter 'cmdline' is null or zero length: ",null);
    return -1;
    }
    
    
    ConfigComm.createHeader(reqbuf,EXEC_COMMAND,option,0);

    
	reqbuf.append(cmdline);

    try {
		byte[] b;
		java.util.StringTokenizer tok = null;
		StringBuffer sep =  new StringBuffer();
		sep.append(ConfigComm.CONF_FS).append(ConfigComm.CONF_SOH);

		b = configRequest(host,reqbuf);


		String respbuf = new String(b);
		
		if (Constants.DEBUG && Constants.Verbose>4) {			  
		    //System.out.println("Response: "+respbuf);
		    Log.getInstance().log_message("Admin server log: "
						  +respbuf,null);
		}
		

		  tok =  new java.util.StringTokenizer(respbuf,sep.toString());

		  for (int i = 0; i < Constants.NUM_HEADER_FIELDS-2; i++) {
			  if (tok.hasMoreTokens()) {
				  String s1 = tok.nextToken();
			  } else {
				  Log.getInstance().log_message("Error in parsing header information",null);
				  return -1;
			  }
		  }
		  
		  int errno = -2;
		  String token = tok.nextToken();
		  try {
			  errno = Integer.parseInt(token);
		  } catch (Exception e) { }
		  
		  
		  if (errno == -2) 
			  Log.getInstance().log_error("AdminComm:Error in parsing status from server response", null);
		  
		  if (errno != 0) {
			  int index = respbuf.indexOf(ConfigComm.CONF_STX) +1;
			  response.append(respbuf.substring(index));
			  return errno;
		  }
				


    } catch (Exception e) {
	if (response.length()==0) 
		  response.append(e.getMessage());
	Log.getInstance().log_error("AdminComm:Error while handling request",e);
    	return -1;
    }
	
    return 0;
  }
  

  public static int sendDynamicMessage(int option,String host,String buffer, 
								StringBuffer response) {
	  StringBuffer reqbuf = new StringBuffer();
    
  

	  if ((buffer == null)|| (buffer.length()==0)) {
		  Log.getInstance().log_error("AdminComm:Required parameter 'buffer' is null or zero length: ",null);
		  return -1;
	  }
	  
	  
	  
	  
	  ConfigComm.createHeader(reqbuf,DYNAMIC_MESSAGE,option,0);
	  
	  /*tmp = new StringBuffer("0001TEST0300 1 HOT");
	  */
	  
	  
	  reqbuf.append(buffer);
	  
	  try {
		  byte[] b;
		  java.util.StringTokenizer tok = null;
		  StringBuffer sep =  new StringBuffer();
		  sep.append(ConfigComm.CONF_FS).append(ConfigComm.CONF_SOH);

		  b = configRequest(host,reqbuf);

		  String respbuf = new String(b);	

		  if (Constants.DEBUG && Constants.Verbose>2) {			  
			  System.out.println("Response: "+respbuf);
			  Log.getInstance().log_message("Admin server log: "
							+respbuf,null);
		  }

		  tok =  new java.util.StringTokenizer(respbuf,sep.toString());

		  for (int i = 0; i < Constants.NUM_HEADER_FIELDS-2; i++) {
			  if (tok.hasMoreTokens()) {
				  String s1 = tok.nextToken();
			  } else {
				  Log.getInstance().log_message("Error in parsing header information",null);
				  return -1;
			  }
		  }
		  
		  int errno = -2;
		  String token = tok.nextToken();
		  try {
			  errno = Integer.parseInt(token);
		  } catch (Exception e) { }
		  
		  
		  if (errno == -2) 
			  Log.getInstance().log_error("AdminComm:Error in parsing status from server response", null);
		  
		  if (errno != 0) {
			  Log.getInstance().log_error("AdminComm:Service error:"+errno,null);
			  int index = respbuf.indexOf(ConfigComm.CONF_STX) +1;
			  response.append(respbuf.substring(index));
			  return errno;
		  }
							  

		  
	  } catch (Exception e) {
	      if (response.length()==0) 
		  response.append(e.getMessage());
	      Log.getInstance().log_error("AdminComm:Error while handling request",e);
	      return -1;
	  }
	  
	  return 0;
  }
	

    
    
  public static byte[] serviceRequest(String host,int major,int minor,String args) 
			throws IOException, DBException, DBModeException 
   { 
    StringBuffer reqbuf = new StringBuffer();

    ConfigComm.createHeader(reqbuf,major,minor,0);
    reqbuf.append(args);
  
    return configRequest(host,reqbuf);  
    
  }
   

    

    static int 
    checkProcesses(javax.swing.JFrame parent,
		   String serverList,
		   String proglist) 
    {



	java.util.StringTokenizer st;


	String datastr = null;
	boolean exc=false;
	byte[] respb;
	String response;
	int index;
	
	/* Get list of processes from host */
	try {
	    respb = AdminComm.serviceRequest(serverList,
					     AdminComm.EXEC_COMMAND,
					     AdminComm.LIST_IDS2_PROC_BY_NAME,
					     proglist);
	    
	    response = new String(respb);
	    
	    index = response.indexOf(ConfigComm.CONF_STX)+1;
	    
	    if (index>0) 
		datastr = response.substring(index);
	    
	} catch (Exception e) {
	    exc=true;
	    Log.getInstance().log_warning(
			"Error retrieving process list from : "
			+serverList,
			e);
	}
	
	
	if (exc) 
	    return -1;
	
	String separator = new String("\n");
	String fldsep    = new String(" ");
	
	/* 
	** Parse the response from admin servers and
	** update the UI
	*/
	
	boolean found = false;
	
	/* Parse process list */
	if (datastr != null) {
	    st = new java.util.StringTokenizer(datastr,
					       separator);
		    
	    while (st.hasMoreTokens()){
		String s = st.nextToken();
		int i = s.indexOf(fldsep);
		if (i>0) s = s.substring(0,i);
		if (Constants.findPattern(proglist,s)) {
		    found=true;
		    break;
		}
	    }
	} /* if (datastr1 != null) */
	
	    
	
	if (found)
		return 1;

    return 0;
    
  } /* End of checkProcesses() */
  
  
}

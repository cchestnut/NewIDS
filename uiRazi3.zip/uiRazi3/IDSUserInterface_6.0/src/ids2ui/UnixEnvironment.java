/*
**  SCCS Info :  "@(#)UnixEnvironment.java	1.1    00/11/16"
*/



package ids2ui;
import java.util.*;
import java.io.*;


class UnixEnvironment extends Hashtable {
  static private UnixEnvironment _instance = null;
  
  private UnixEnvironment(){}
  
  public static UnixEnvironment getInstance() {
    if (_instance == null) {
      synchronized(UnixEnvironment.class) {
        if (_instance == null) {
          _instance = new UnixEnvironment();
          initialize();
          
        }
      }      
    }
    return _instance;
  }
    

  private static void initialize() {
    // this is unix specific
  String[] cmd = {"/bin/sh", "-c", "set"};
    try {
      Process proc = Runtime.getRuntime().exec(cmd);
      BufferedReader inp = new BufferedReader(new InputStreamReader(proc.getInputStream()));
      String LINE = inp.readLine();
      while (LINE != null) {
        int eqPos = LINE.indexOf("=");
        if (eqPos >= 0) {
          String name = LINE.substring(0, eqPos);
          String value = LINE.substring(eqPos + 1);
          _instance.put(name.toUpperCase(), value);
        }
        LINE = inp.readLine();
      }
      inp.close();
    } catch (IOException e) {
      System.out.println("I/O error");
    }
  } 
  public synchronized Object get(Object name) {
    // this case-desensitizes the name, overriding Hashtable.get()
    String theName = name.toString().toUpperCase();
    return super.get(theName);
  }
  public synchronized Object put(Object name, Object value) {
    String theName = name.toString().toUpperCase();
    String theValue = value.toString();
    Object result = super.get(theName);
    // this is Unix specific
  String[] cmd = {"/bin/sh", "-c", "set " + theName + "=" + theValue};
    try {
      Process proc = Runtime.getRuntime().exec(cmd);
      BufferedReader inp = new BufferedReader(new InputStreamReader(proc.getInputStream()));
      String LINE = inp.readLine();
    while (LINE != null) {}
      super.put(name.toString().toUpperCase(), value.toString());
      return result;
    } catch (IOException e) {
      System.out.println("I/O error");
      return null;
    }
  }
}


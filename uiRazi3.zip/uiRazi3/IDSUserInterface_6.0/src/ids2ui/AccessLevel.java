/* SCCS Info: @(#)Makefile	1.40 07/12/14 */ 
package ids2ui;
 public class AccessLevel { 
	public static int MENU_ACCESS_LEVEL=Constants.ACCESS_LEVEL_ADMIN;
}


/*
**  SCCS Info :  "@(#)DistrProductDialog.java	1.11    04/12/03"
*/
/*
 * DistrProductDialog.java
 *
 * Created on March 22, 2000, 2:04 PM
 */
 
package ids2ui;

import java.awt.event.ActionEvent;
import model.DistributorProductFlagOptions;
import model.PremiumCodesList;
import refactor.ui.forms.CodeTableDialog;
import refactor.ui.model.DistributorPremiumCodesListTableModel;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistrProductDialog extends javax.swing.JDialog {
  private javax.swing.DefaultComboBoxModel productComboModel;
  private javax.swing.DefaultComboBoxModel formatComboModel = new javax.swing.DefaultComboBoxModel() ;
  private javax.swing.DefaultComboBoxModel derivedDataComboModel = new javax.swing.DefaultComboBoxModel(DistributorProductFlagOptions.DerivedDataOptions) ;
  private javax.swing.DefaultComboBoxModel derivedDataDictComboModel = new javax.swing.DefaultComboBoxModel(ConfigComm.getDerivedDataDictionaries()) ;
  private javax.swing.DefaultComboBoxModel languageComboModel = new javax.swing.DefaultComboBoxModel(Constants.OutputLanguageOptions);  
  private javax.swing.DefaultComboBoxModel encodingComboModel = new javax.swing.DefaultComboBoxModel(Constants.OutputEncodingOptions) ;  
  private javax.swing.DefaultComboBoxModel templateComboModel;
  private DistrProductStructure[]     distrProductStruct1 = null;
  
  private String SELECT_STRING = "Select";
  
  private DistrProductTableModel tableModel1;
  private DistrProductTableModel tableModel2;
  
  private javax.swing.DefaultComboBoxModel  productModel;
  
  private int actionType;
  
  private int lhType = Constants.DCM_LINEHANDLER;

    java.util.HashSet newSet1 = new java.util.HashSet();
    java.util.HashSet newSet2 = new java.util.HashSet();
    java.util.HashSet commonSet = new java.util.HashSet();
    private String distrid;

  
    /** Creates new form DistrProductDialog */
    public DistrProductDialog(java.awt.Frame parent,
                              boolean modal, 
			      DistrProductTableModel tabModel1,
			      DistrProductTableModel tabModel2,
			      javax.swing.DefaultComboBoxModel pModel, 
			      int type,
			      int defaultScope) 
    {
            
	super (parent, modal);

	if (parent != null)
	    setLocationRelativeTo(parent);


	tableModel1        = tabModel1;
	tableModel2        = tabModel2;
	productModel = pModel;
	lhType = type;

	TemplateListModel tModel = new TemplateListModel(this);
	templateComboModel = new javax.swing.DefaultComboBoxModel(tModel.toArray());
	for (int i = 0; i < templateComboModel.getSize(); i++) {
	    Object o = templateComboModel.getElementAt(i);
	    if (((String)o).equals(Constants.FILTER_CODES_NONE)) {
		templateComboModel.setSelectedItem(o);
		break;
	    }
	}   
	productComboModel = new javax.swing.DefaultComboBoxModel();
    
	initComponents ();

    premiumTextField.setEditable(false);
	actionType=0;

     
	allProductsCB.setEnabled(true);


	int nrows1 = tableModel1.getRowCount();
	int nrows2 = tableModel2.getRowCount();
	
	java.util.HashSet currSet1 = new java.util.HashSet();
	java.util.HashSet currSet2 = new java.util.HashSet();
	java.util.HashSet prodSet = new java.util.HashSet();

	
	for (int i = 0; i < nrows1 ; i++)
	    currSet1.add((String)tableModel1.getValueAt(i,0));

	for (int i = 0; i < nrows2; i++)
	    currSet2.add((String)tableModel2.getValueAt(i,0));

	int nsize = pModel.getSize();
	for (int i = 0; i < nsize; i++)
	    prodSet.add((String)pModel.getElementAt(i));

	newSet1.addAll(prodSet);
	newSet2.addAll(prodSet);
	

	newSet1.removeAll(currSet1);
	newSet2.removeAll(currSet2);

	commonSet.addAll(newSet1);
	commonSet.retainAll(newSet2);
	  
	
	if (commonSet.isEmpty()
	    && newSet1.isEmpty()
	    && newSet2.isEmpty()) {
	    //All products added
	    Log.getInstance().show_error(this,"Error",
					 "All products are already added",null);
	    okButton.setEnabled(false);
	}
	
	
        
	java.util.HashSet set  = null;
	java.awt.event.ActionEvent evt = null;

	if (!commonSet.isEmpty()) {
	    set = commonSet;
	    bothRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "Both");
	    
	} else if (!newSet1.isEmpty()) {
	    set = newSet1;
	    oneRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "One");
	    
	} else if (!newSet2.isEmpty()) {
	    set = newSet2;
	    twoRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "Two");
	    
	}

	

	String prods[] = (String[])set.toArray(new String[1]);
	java.util.Arrays.sort(prods);
	productComboModel = new javax.swing.DefaultComboBoxModel(prods);
	
	productCombo.setModel(productComboModel);

	javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();

	if (commonSet.isEmpty()) {
	    bothRB.setEnabled(false);
	}
	if (newSet1.isEmpty()) {
	    oneRB.setEnabled(false);
	    group.add(twoRB);
	}
	if (newSet2.isEmpty()) {
	    twoRB.setEnabled(false);
	    group.add(oneRB);
	}


	scopeRBHandler(evt);
	    	
        encodingComboBox.setEditable(true);

	String item = (String)productCombo.getSelectedItem();    
	formatCombo.removeAllItems();

	java.util.Vector v = ConfigComm.getCSCSparseMatrixModel().getProductFormats(item);

	if (lhType == Constants.DSP_LINEHANDLER) {
	    try {
		v = new DSPSparseMatrixModel(ConfigComm.getCSCProductsModel(),1).getProductFormats(item);
	    } catch (Exception e) {
		v = ConfigComm.getIDSProductFormatList();
	    }
	} else if (lhType == Constants.DJNEWS_LINEHANDLER) {
	    v = new java.util.Vector(1);
	    v.add(Constants.GLB_IDS_FORMAT);
	    //jLabel3.setVisible(false);
	    //delayTextF.setVisible(false);
	    jLabel4.setVisible(false);
	    freewheelCB.setVisible(false);
	    //jLabel41.setVisible(false);
	    //newsplusOffCB.setVisible(false);
	    jLabel42.setVisible(false);
	    derivedDataComboBox.setVisible(false);
	    derivedDataDictComboBox.setVisible(false);
		//jLabel6.setVisible(false);
	    //languageComboBox.setVisible(false);
		//jLabel7.setVisible(false);
	    //encodingComboBox.setVisible(false);
	    jLabel2.setVisible(false);
	    formatCombo.setVisible(false);
	    allProductsCB.setVisible(false);
            sigAboutCB.setVisible(false);
	}

	formatCombo.setModel(new javax.swing.DefaultComboBoxModel(v));  
	
	String fmt = (String)formatCombo.getSelectedItem();
	allProductsCB.setText("Add all "+fmt+" products");  
        
	validate();
   	pack ();
    
    }

  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
    private void initComponents () {//GEN-BEGIN:initComponents
      jPanel1 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      productCombo = new javax.swing.JComboBox(productComboModel);

      jLabel2 = new javax.swing.JLabel ();
      formatCombo = new javax.swing.JComboBox(formatComboModel);
      jLabel3 = new javax.swing.JLabel ();
      delayTextF = new ids2ui.IntTextField ();
      jLabel4 = new javax.swing.JLabel ();
      freewheelCB = new javax.swing.JCheckBox ();
      jLabel41 = new javax.swing.JLabel ();
      newsplusOffCB = new javax.swing.JCheckBox ();
      jLabel42 = new javax.swing.JLabel ();
	  derivedDataComboBox = new javax.swing.JComboBox(derivedDataComboModel);
      jLabel43 = new javax.swing.JLabel ();
	  derivedDataDictComboBox = new javax.swing.JComboBox(derivedDataDictComboModel);
      jLabel5 = new javax.swing.JLabel ();
      templateCombo = new javax.swing.JComboBox((javax.swing.ComboBoxModel)templateComboModel);
      jLabel6 = new javax.swing.JLabel ();
	  languageComboBox= new javax.swing.JComboBox(languageComboModel);
      jLabel7 = new javax.swing.JLabel ();
      encodingComboBox= new javax.swing.JComboBox(encodingComboModel);
      
      jLabel8 = new javax.swing.JLabel ();
      premiumTextField = new javax.swing.JTextField ();
      jButton2 = new javax.swing.JButton ();
      
       jLabel9 = new javax.swing.JLabel ();
      sigAboutCB = new javax.swing.JCheckBox ();
      
      jButton1 = new javax.swing.JButton ();
      allProductsCB = new javax.swing.JCheckBox ();
      jPanel2 = new javax.swing.JPanel ();
      okButton = new javax.swing.JButton ();
      jButton3 = new javax.swing.JButton ();
      javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();

      jPanel3 = new javax.swing.JPanel ();
      bothRB = new javax.swing.JRadioButton ();
      group.add(bothRB);
      bothRB.setSelected(true);
      oneRB = new javax.swing.JRadioButton ();
      group.add(oneRB);
      twoRB = new javax.swing.JRadioButton ();
      group.add(twoRB);
      setTitle ("Distributor product configuration");
      addWindowListener (new java.awt.event.WindowAdapter () {
        public void windowClosing (java.awt.event.WindowEvent evt) {
          closeDialog (evt);
        }
      }
      );

      jPanel1.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;
      jPanel1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 10, 10)));

        jLabel1.setText ("Product");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel1, gridBagConstraints1);
  
        productCombo.setActionCommand ("Product");
        productCombo.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            comboAction (evt);
          }
        }
        );
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (productCombo, gridBagConstraints1);
  
        jLabel2.setText ("Format");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 1;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel2, gridBagConstraints1);
  
        formatCombo.setActionCommand ("Format");
        formatCombo.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            comboAction (evt);
          }
        }
        );
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 1;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (formatCombo, gridBagConstraints1);
  
        jLabel3.setText ("Delay (mins.)");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 2;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel3, gridBagConstraints1);
  
        delayTextF.setColumns (10);
        delayTextF.setText ("0");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 2;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (delayTextF, gridBagConstraints1);
  
        jLabel4.setText ("Free Wheel");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 3;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel4, gridBagConstraints1);
  
        freewheelCB.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
        freewheelCB.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 3;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (freewheelCB, gridBagConstraints1);


        jLabel41.setText ("WSJ Links Off");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 4;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel41, gridBagConstraints1);
  
        newsplusOffCB.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
        newsplusOffCB.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);

        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 4;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (newsplusOffCB, gridBagConstraints1);



        jLabel42.setText ("Derived Data");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 5;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel42, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 5;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (derivedDataComboBox, gridBagConstraints1);
  

        jLabel43.setText ("Derived Data Dictionary");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 6;
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel43, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 6;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (derivedDataDictComboBox, gridBagConstraints1);


        jLabel5.setText ("Filter codes");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 7;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel5, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 7;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (templateCombo, gridBagConstraints1);
  


        jButton1.setText ("Edit");
        jButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            editCodes (evt);
          }
        }
        );
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 2;
        gridBagConstraints1.gridy = 7;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jButton1, gridBagConstraints1);
  
        allProductsCB.setText ("Add all products");
        allProductsCB.setEnabled (false);
        allProductsCB.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            allProductsSelected (evt);
          }
        }
        );
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 2;
        gridBagConstraints1.gridy = 1;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
        jPanel1.add (allProductsCB, gridBagConstraints1);


        jLabel6.setText ("Language");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 8;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel6, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 8;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (languageComboBox, gridBagConstraints1);
  
        jLabel7.setText ("Encoding");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 9;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel7, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 9;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (encodingComboBox, gridBagConstraints1);

        
        /***/
        
        jLabel8.setText ("Premium codes");
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 10;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel8, gridBagConstraints1);
  
        premiumTextField.setColumns(20);
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 10;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (premiumTextField, gridBagConstraints1);
  


        jButton2.setText ("Edit");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            editPremiumCodes (evt);
          }

            
        }
        );
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 2;
        gridBagConstraints1.gridy = 10;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jButton2, gridBagConstraints1);
        
        
        jLabel9.setText ("Sig/About");
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 11;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (jLabel9, gridBagConstraints1);
        
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 1;
        gridBagConstraints1.gridy = 11;
        gridBagConstraints1.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (sigAboutCB, gridBagConstraints1);
        
        
        /***/
        
      getContentPane ().add (jPanel1, java.awt.BorderLayout.CENTER);

      jPanel2.setLayout (new java.awt.FlowLayout (1, 15, 5));

        okButton.setText ("OK");
        okButton.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            dialogAction (evt);
          }
        }
        );
  
        jPanel2.add (okButton);
  
        jButton3.setText ("Cancel");
        jButton3.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            dialogAction (evt);
          }
        }
        );
  
        jPanel2.add (jButton3);
  

      getContentPane ().add (jPanel2, java.awt.BorderLayout.SOUTH);

      jPanel3.setLayout (new javax.swing.BoxLayout (jPanel3, 0));
      jPanel3.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.LineBorder(java.awt.Color.black)));

        bothRB.setText ("Both");
        bothRB.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            scopeRBHandler (evt);
          }
        }
        );
  
        jPanel3.add (bothRB);
  
        oneRB.setText ("Data center - I only");
        oneRB.setActionCommand ("One");
        oneRB.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            scopeRBHandler (evt);
          }
        }
        );
  
        jPanel3.add (oneRB);
  
        twoRB.setText ("Data center - II only");
        twoRB.setActionCommand ("Two");
        twoRB.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            scopeRBHandler (evt);
          }
        }
        );
  
        jPanel3.add (twoRB);
  

      getContentPane ().add (jPanel3, java.awt.BorderLayout.NORTH);

    }//GEN-END:initComponents

private void editCodes (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editCodes
// Add your handling code here:
  
    String name = (String)templateCombo.getSelectedItem();
    if (name.equals("NONE")) {
      java.awt.Toolkit.getDefaultToolkit().beep();
      return;
    }
    
    javax.swing.JDialog f = 
        (javax.swing.JDialog)WindowEventAdapter.getInstance()
          .findWindow(Constants.CONFIGURATION_FILTERCODE_PREFIX+name);
    if (f==null)
		f = new FilterCodesConfigForm(this,true,name,false);
    
    f.show();

  }//GEN-LAST:event_editCodes


    private void editPremiumCodes(ActionEvent evt) {
        
        PremiumCodesList pcl = ConfigComm.getPremiumCodesList();
                    
              
        String s = premiumTextField.getText();
        CodeTableDialog dlg = new CodeTableDialog(this, true, pcl, s);   
        StringBuilder title = new StringBuilder("Edit premium codes");
        if (distrid != null)
            title.append(":").append(distrid);
        dlg.setTitle(title.toString());
        dlg.setVisible(true);
        
        DistributorPremiumCodesListTableModel pcltm = dlg.getModel();
        if (pcltm != null)
        {
            premiumTextField.setText(pcltm.toString());
        }

    }

private void allProductsSelected (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allProductsSelected
// Add your handling code here:
  
    if (allProductsCB.isSelected())
      productCombo.setEnabled(false);
    else
      productCombo.setEnabled(true);
  
  }//GEN-LAST:event_allProductsSelected

private void scopeRBHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scopeRBHandler
  // Add your handling code here:


    if (evt == null) return;
    
  String action = evt.getActionCommand();
  //System.out.println("Radio Button action :"+action);

  if (actionType==1) return;
  
  /* setup products  */
    
    String selectedItem = (String)productCombo.getSelectedItem();
    
    java.util.HashSet set  = null;
    if (action.equals("Both")){
	set = commonSet;
    } else if (action.equals("One")) {
	set = newSet1;
    } else if (action.equals("Two")) {
	set = newSet2;
    }
    
    String prods[] = (String[])set.toArray(new String[1]);
    java.util.Arrays.sort(prods);
    productComboModel = new javax.swing.DefaultComboBoxModel(prods);
	    
    productCombo.setModel(productComboModel);
    
    if (selectedItem != null) productCombo.setSelectedItem(selectedItem);
    
  
  }//GEN-LAST:event_scopeRBHandler

private void comboAction (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboAction
// Add your handling code here:
  String action = evt.getActionCommand();
  
  if (action.equals("Product")) {
    String item = (String)productCombo.getSelectedItem();    
    formatCombo.removeAllItems();
    java.util.Vector v = ConfigComm.getCSCSparseMatrixModel().getProductFormats(item);

    if (lhType == Constants.DSP_LINEHANDLER) {
	try {
	    v = new DSPSparseMatrixModel(ConfigComm.getCSCProductsModel(),1).getProductFormats(item);
	} catch (Exception e){
	    v = ConfigComm.getIDSProductFormatList();
	}
    } else if (lhType == Constants.DJNEWS_LINEHANDLER) {
	    v = new java.util.Vector(1);
	    v.add(Constants.GLB_IDS_FORMAT);
    }
    formatCombo.setModel(new javax.swing.DefaultComboBoxModel(v));    


    String default_codes = Constants.getDefaultPremiumEntitlement(item);
    premiumTextField.setText(default_codes);
    
    
  }
  
  
    String fmt = (String)formatCombo.getSelectedItem();
    allProductsCB.setText("All "+fmt+" products");
    return ;
  
   
    
  }//GEN-LAST:event_comboAction


private void dialogAction (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dialogAction
// Add your handling code here:
    String action = evt.getActionCommand();
    
    distrProductStruct1 = null;
    
    if (action.equals("OK")) {

if (lhType != Constants.DSP_LINEHANDLER) {
	int opt = DistributorProductFlagOptions.getDerivedDataOptionFlag((String)derivedDataComboBox.getSelectedItem());
	String s =  (String)derivedDataDictComboBox.getSelectedItem();
System.out.println("OPT="+opt+" "+(String)derivedDataComboBox.getSelectedItem() +" "+ s);
	if ( (opt > 0) && ( (s==null) || s.equalsIgnoreCase("NONE") ) )
	{
          distrProductStruct1= null;
          javax.swing.JOptionPane.showMessageDialog(this,"Please select a dictionary","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;

	}
	if ( (opt < 1) && (s!=null) && !s.equalsIgnoreCase("NONE") )
	{
          distrProductStruct1= null;
          javax.swing.JOptionPane.showMessageDialog(this,"Cannot select dictionary without derived data ","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;
	}

}

      try {
        int delay = Integer.parseInt(delayTextF.getText());
      
        if (allProductsCB.isSelected()) {
          String format = (String) formatCombo.getSelectedItem();
          java.util.Vector v = ConfigComm.getCSCSparseMatrixModel().getFormatProducts(format);
          
	  if (lhType == Constants.DSP_LINEHANDLER) {
	      try {
		  v = new DSPSparseMatrixModel(ConfigComm.getCSCProductsModel(),1).getFormatProducts(format);
	      } catch (Exception e){
		  v = ConfigComm.getIDSProductFormatList();
	      }
	  }

          int numprods = v.size();
        


          distrProductStruct1 = new DistrProductStructure[numprods];
            for (int i = 0; i < numprods; i++) {
                distrProductStruct1[i] = new DistrProductStructure(
                        (String) v.get(i),
                        format,
                        delay, freewheelCB.isSelected(),
                        newsplusOffCB.isSelected(),
                        DistributorProductFlagOptions.getDerivedDataOptionFlag((String) derivedDataComboBox.getSelectedItem()), (String) derivedDataDictComboBox.getSelectedItem(),
                        (String) templateCombo.getSelectedItem(),
                        languageComboBox.getSelectedItem().toString(),
                        encodingComboBox.getSelectedItem().toString(),
                        premiumTextField.getText(),
                        sigAboutCB.isSelected());
            }
        } else {
          distrProductStruct1 = new DistrProductStructure[1];
          distrProductStruct1[0] = new DistrProductStructure(
                    (String) productCombo.getSelectedItem(),
                    (String) formatCombo.getSelectedItem(),
                    delay, freewheelCB.isSelected(),
                    newsplusOffCB.isSelected(),
                    DistributorProductFlagOptions.getDerivedDataOptionFlag((String) derivedDataComboBox.getSelectedItem()),
                    (String) derivedDataDictComboBox.getSelectedItem(),
                    (String) templateCombo.getSelectedItem(),
                    languageComboBox.getSelectedItem().toString(),
                    encodingComboBox.getSelectedItem().toString(),
                  premiumTextField.getText(),
                  
                        sigAboutCB.isSelected());
        }

        
      } catch (NumberFormatException e) {
          distrProductStruct1= null;
          javax.swing.JOptionPane.showMessageDialog(this,"Error in parsing delay ","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;
      }
      
    }
  
    closeDialog(null);
  }//GEN-LAST:event_dialogAction

  public DistrProductStructure[] getDistrProduct1() {
    return distrProductStruct1;
  }

 
  
  public int getScope() {
    if (bothRB.isSelected()) return 0;
    if (oneRB.isSelected()) return 1;
    if (twoRB.isSelected()) return 2;
    return 0;
  }
  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
    setVisible (false);
    dispose ();
  }//GEN-LAST:event_closeDialog

  /**
  * @param args the command line arguments
  */
  public static void main (String args[]) {
    //new DistrProductDialog (new javax.swing.JFrame (), true).show ();
  }


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel1;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JComboBox productCombo;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JComboBox formatCombo;
  private javax.swing.JLabel jLabel3;
  private ids2ui.IntTextField delayTextF;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JCheckBox freewheelCB;
  private javax.swing.JLabel jLabel41;
  private javax.swing.JCheckBox newsplusOffCB;
  private javax.swing.JLabel jLabel42;
  private javax.swing.JLabel jLabel43;
  private javax.swing.JComboBox derivedDataComboBox;
  private javax.swing.JComboBox derivedDataDictComboBox;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JComboBox templateCombo;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JComboBox languageComboBox;
  private javax.swing.JLabel jLabel7;
  private javax.swing.JComboBox encodingComboBox;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JTextField premiumTextField;  
  private javax.swing.JLabel jLabel9;
  private javax.swing.JCheckBox sigAboutCB;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton1;
  private javax.swing.JCheckBox allProductsCB;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton okButton;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JRadioButton bothRB;
  private javax.swing.JRadioButton oneRB;
  private javax.swing.JRadioButton twoRB;
  // End of variables declaration//GEN-END:variables

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ids2ui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * SVN  Info :  "$Id$"
 * SCCS Info :  "%W%    %E%"
 * @author srz
 */
public class BatchFilterUpdate1 {
    
    public static void main(String[] args)
    {
        
        class Row {
            int sno;
            String id;
            String description;
            String codes;
            boolean exactMatch;
            
            String ncodes;
            boolean validate;
            String feeds;
            int nfeeds;
            
            boolean error;
            private Exception exception;
            Row(){
                description="";
                feeds="";
                ncodes="";
                sno=0;
                nfeeds=0;
            }
            
        }
        
        List<Row> report = new ArrayList<Row>();
        
        try {
            ConfigComm.initLoginLite("BatchFilterUpdate",
                    "distpc1,distpc2",
                    //"distc1d1,distc2d1",
                    //"sbkdistqc1,distqc2",
                    "/ids2");
        } catch (Exception ex) {
            Logger.getLogger(BatchFilterUpdate1.class.getName()).log(Level.SEVERE, null, ex);
        }


        StringBuffer reqbuf = new StringBuffer();
        String respbuf, databuf;
        byte[] b = null;


        ConfigComm.getTagKey(reqbuf, ConfigComm.GET_ALL_FILTERCODES_INFO);
        try {
            b = ConfigComm.configRequest(reqbuf);
        } catch (Exception e) {


            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo() == -11001) {
                    return;
                }
            }
            System.out.println("Error in retrieving Filter codes list"+e);
            System.exit(1);

        }
        
        respbuf = new String(b);
        int index = respbuf.indexOf(ConfigComm.CONF_STX) + 1;
        databuf = respbuf.substring(index);


        if (Constants.DEBUG && Constants.Verbose > 2) {
            System.out.println("Response: " + databuf);
        }


        java.util.StringTokenizer rowTokenizer, colTokenizer;

        StringBuffer rowSeparator, colSeparator;
        rowSeparator = new StringBuffer();
        colSeparator = new StringBuffer();

        rowSeparator.append(ConfigComm.CONF_STX).
                append(ConfigComm.CONF_ETX).
                append(ConfigComm.CONF_FS);

        colSeparator.append(ConfigComm.CONF_ETX).
                append(ConfigComm.CONF_RS);

        rowTokenizer = new java.util.StringTokenizer(databuf, rowSeparator.toString());


        String key = null, value = null;
        int row=0;
        java.util.HashMap map = null;
        while (rowTokenizer.hasMoreTokens()) {
            //String [] rowData = new String[m_columnsCount];
            rowTokenizer.nextToken(); // Skip "key"
            String fstr = rowTokenizer.nextToken();
            colTokenizer =
                    new java.util.StringTokenizer(fstr,
                    colSeparator.toString());

            map = new java.util.HashMap(4);
            while (colTokenizer.hasMoreTokens()) {
                key = colTokenizer.nextToken();
                if (colTokenizer.hasMoreTokens()) {
                    value = colTokenizer.nextToken();
                    //                        System.out.println("Key: "+key+" Value:"+value);
                } else {
                    continue;
                }
                if (key.length() > 0) {
                    map.put(key, value);
                }
            }

            String id = (String) map.get("ID");
            String desc = (String) map.get("DESCRIPTION");
            if (desc == null) {
                desc = "";
            }
            
            java.util.HashMap cmap = null;
            try {
                cmap = ConfigComm.getHashMapDirect(Constants.GLB_TAG_FILTERCODE_PREFIX + id);
            } catch (IOException ex) {                
                Logger.getLogger(BatchFilterUpdate1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DBException ex) {
                Logger.getLogger(BatchFilterUpdate1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DBModeException ex) {
                Logger.getLogger(BatchFilterUpdate1.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (cmap == null) continue;
            
            String ocodes = (String) cmap.get("CODES");

                
            String codes = ocodes.replace('\n', '$').trim();
            String magic_str = "&! (P/FXEX & P/FXTR)";
            int inx = codes.indexOf(magic_str);
            if (inx < 0)
                continue;
            Row line = new Row();
            line.sno = ++row;
            line.id = id;
            line.description = desc;
            line.codes = codes;
            line.error = false;
            report.add(line);
            if (codes.endsWith(magic_str)) {
                line.exactMatch = true;
                System.out.println("ID:" + id + " Desc: " + desc
                        + " Codes: " + codes);
                int len = codes.length();
                int nlen = len - magic_str.length();
                StringBuilder sb = new StringBuilder(codes);
                sb.setLength(nlen);

                System.out.println("ID: " + id + " New Filter: " + sb.toString());

                line.ncodes = sb.toString();
                line.validate = false;
                StringBuffer reqbuf1 = new StringBuffer();
                ConfigComm.getServKey(reqbuf1, ConfigComm.VALIDATE_FILTER_STRING,
                        line.ncodes);
                try {
                    byte [] b0 = ConfigComm.configRequest(reqbuf1);	
                    String rbuf = new String(b0);
                    int index1 = rbuf.indexOf(ConfigComm.CONF_STX) +1;
                    StringBuffer separator = new StringBuffer();

                    String databuf1 = rbuf.substring(index1);
                    separator.append(ConfigComm.CONF_ETX)
                        .append(ConfigComm.CONF_US)
                        .append(ConfigComm.CONF_FS);

                    java.util.StringTokenizer st =
                        new java.util.StringTokenizer(databuf1,
                                                      separator.toString());
                    int ret = -1;
                    if (st.hasMoreTokens()) {
                        String s = st.nextToken();
                        try {
                            ret = Integer.parseInt(s);
                        } catch (Exception e){}
                    }
                    if (ret != 0) {
                        String errStr = null;
                        if (st.hasMoreTokens()) 
                            errStr =  st.nextToken();
                        System.out.println("Syntax error: \n"+errStr);
                        continue;
                    }

                } catch (Exception e) {
                    line.error = true;
                    line.exception = e;
                    System.out.println("Error in validating filter syntax:"
                                            +id +" "+e.toString());
                    continue;

                }
                line.validate = true;
                /* Get the list of distributors&products
                ** using the template and update dynamically
                */
                    
                
                
                
                StringBuffer reqbuf2 = new StringBuffer();
                ConfigComm.getServKey(reqbuf2,
                                      ConfigComm.GET_DISTRPRODS_USING_FILTER,
                                      id);

                StringBuilder dlist = new StringBuilder();
                
                try {
                    byte[] b1 = ConfigComm.configRequest(reqbuf2);

                    /*
                    ** Format:
                    ** |ID;host11,host12;p1,p2;host21,host22;p1,p2;|
                    ** |ID;host11,host12;p1,p2;host21,host22;p1,p2;|
                    **
                    */

                    String rbuf = new String(b1);
                    int index2 = rbuf.indexOf(ConfigComm.CONF_STX) +1;
                    StringBuilder rowsep = new StringBuilder("|");
                    rowsep.append(ConfigComm.CONF_FS)
                        .append(ConfigComm.CONF_ETX);
                    StringBuilder colsep = new StringBuilder(";");

                    String databuf2 = rbuf.substring(index2);

                    java.util.StringTokenizer rt =
                        new java.util.StringTokenizer(databuf2,
                                                      rowsep.toString());
                    
                    while (rt.hasMoreTokens()) {
                        String [] datastr = null;

                        String s = rt.nextToken();
                        java.util.StringTokenizer ct =
                            new java.util.StringTokenizer(s,
                                                          colsep.toString());
                        datastr = new String[5];

                        datastr[0] = null;
                        datastr[1] = null;
                        datastr[2] = null;
                        datastr[3] = null;
                        datastr[4] = null;
                        if (ct.hasMoreTokens())
                            datastr[0] = ct.nextToken();
                        if (ct.hasMoreTokens())
                            datastr[1] = ct.nextToken();
                        if (ct.hasMoreTokens())
                            datastr[2] = ct.nextToken();
                        if (ct.hasMoreTokens())
                            datastr[3] = ct.nextToken();
                        if (ct.hasMoreTokens())
                            datastr[4] = ct.nextToken();

                        dlist.append(datastr[0]).append(" ");
                        
                    }

                    
                    System.out.println("FEEDS using "+id+" :"+dlist.toString());

                    line.feeds = dlist.toString();
                } catch (Exception e) {
                    if (e instanceof DBException) {
                                                
                        if (((DBException) e).getErrorNo() == -11001) {
                            System.out.println("No distributors "
                            + "using filter : " + id);
                            continue;
                        }
                    }
                    line.error = true;
                    line.exception = e;
                    System.out.println("Error in retrieving list"
                            + " of distributors "
                            + "using filter : " + id
                            + " " + e.toString()+" ");
                    continue;
                }



                //                    StringBuffer buf = new StringBuffer();
                //                    ConfigComm.addFilterCode(buf, id, desc, codes, false);
                //
                //                    b = ConfigComm.configRequest(buf);

                } else if (inx >= 0)
                {
                    line.exactMatch = false;                                    
                    System.out.println("FX not at the end for "+id);
                }
            }
        try {
            FileOutputStream fos = new FileOutputStream("/tmp/FX_entitlement_report.csv");
            PrintStream rptps = new PrintStream(fos);
            rptps.println("No"+","+"ID"+","+"Description"+","+"Feeds"+","+"Existing codes"
                        +","+"Pattern match"+","+"Proposed codes"+","+"Valid syntax");
            for (Row line:report) {
                rptps.println(line.sno+","+line.id+","+line.description+","+line.feeds+","+line.codes
                        +","+line.exactMatch+","+line.ncodes+","+((line.exactMatch)?line.validate:""));
            }
            rptps.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BatchFilterUpdate1.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        
       System.exit(0);
    }

}

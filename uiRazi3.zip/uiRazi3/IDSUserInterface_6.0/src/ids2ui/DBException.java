/*
**  SCCS Info :  "@(#)DBException.java	1.3    04/04/01"
*/
/*
 * DBException.java
 *
 * Created on May 1, 2000, 1:41 PM
 */

package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DBException extends RuntimeException {

  /**
   * Constructs an <code>DBException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public DBException(String msg) {
    super(msg);
    errno = -1;
  }
  
    public DBException(String msg, int eno) {
      super(msg);
      errno = eno;
  }

  public DBException(String msg, int eno, byte[] sb) {
      super(msg);
      errno = eno;
	  serverBytes = sb;
  }
      
  public String getMessage()
  {
      return super.getMessage() ;   
  }
  
  public int getErrorNo()
  {
    return errno;
  }

  public byte[] getServerBytes() {
	return serverBytes;
  }

  private int errno=-1;
  private byte[] serverBytes=null;
    
  };
  

/*
**  SCCS Info :  "@(#)DBModeException.java	1.1    00/11/16"
*/
/*
 * DBModeException.java
 *
 * Created on May 10, 2000, 4:52 PM
 */

package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DBModeException extends RuntimeException {

  /**
   * Creates new <code>DBModeException</code> without detail message.
   */
  public DBModeException() {
  }
  

  /**
   * Constructs an <code>DBModeException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public DBModeException(String msg) {
    super(msg);
  }
}


/*
**  SCCS Info :  "@(#)ReadWriteLock.java	1.2    01/07/10"
*/
/*
  File: ReadWriteLock.java

*/

package ids2ui;



public interface ReadWriteLock {
  /** get the readLock **/
  Sync readLock();

  /** get the writeLock **/
  Sync writeLock();
}


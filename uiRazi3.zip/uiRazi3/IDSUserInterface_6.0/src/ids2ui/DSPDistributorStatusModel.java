/*
**  SCCS Info :  "@(#)DSPDistributorStatusModel.java	1.4    07/12/14"
*/
/*
 * DSPDistributorStatusModel.java
 *
 * Created on May 24, 2000, 5:08 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

public class DSPDistributorStatusModel 
    extends javax.swing.table.AbstractTableModel
    implements Utils.UpdateModel
{
  
      
    DistrHostData 		distrHostData = null;
    protected int     		m_sortCol = 0;
    protected boolean 		m_sortAsc = true;
    protected java.util.Vector 	m_vector = null;

    protected int 			m_columnsCount = 
	Constants.DSPDistributorStatusTableColumnNames.length;

    

    private class DistrHostData {
	public String dc1Host;
	public String dc2Host;
	public String dc1PHost;
	public String dc2PHost;
	public StringBuffer distrList;

	public DistrHostData(String h1, String ph1, String h2,
			     String ph2, String id)
	{
	    dc1Host = new String(h1);
	    dc2Host = new String(h2);
	    dc1PHost = new String(ph1);
	    dc2PHost = new String(ph2);
	    distrList = new StringBuffer(id);
	    distrList.append(" ");
	}
	public void addDistr(String id) 
	{
	    if (distrList!=null)
		distrList.append(id).append(" ");
	}

    }


    public DSPDistributorStatusModel()
    {
	m_vector = new java.util.Vector(10);
    }

  




    public String getHost1(int r) {
	return distrHostData.dc1Host;
    }

    public String getHost2(int r) {
	return distrHostData.dc2Host;
    }



    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){}
    }



    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int col) {
      	String str = Constants.DSPDistributorStatusTableColumnNames[col];
        
        if  ((col==2) && (distrHostData!=null)
             && (distrHostData.dc1PHost!=null) ) 
                str = distrHostData.dc1PHost;


        if  ((col==3) && (distrHostData!=null)
             && (distrHostData.dc2PHost!=null) ) 
                str = distrHostData.dc2PHost;
        
            
	if (col==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
        
	return str;
    }
 

    public Object getValueAt(int nRow, int nCol) {
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }


    private void _setValueAt(Object o, int r, int c) {

	Object[] s = (Object[])m_vector.get(r);

	s[c] = o;
	m_vector.setElementAt(s,r);
		
    }


    public void setValueAt(Object o, int r, int c) {

	Object[] s = (Object[])m_vector.get(r);

	s[c] = o;
	m_vector.setElementAt(s,r);
		

	java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	fireTableDataChanged();


    }

    public void addRow(Object[] o) {
	m_vector.add(o);

	java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	fireTableDataChanged();

    }
	
    public void removeRow(int r) {
	m_vector.remove(r);

	fireTableDataChanged();

    }

    public java.util.Vector getDataVector(){
	return m_vector;
    }

   


    public void Update() 
	throws Exception 
    {

	
	int oldRows = m_vector.size();
	int numRows = 0;
	int sColumn = 1;
	

            //if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DSPDistributorStatusModel: Updating..");

	distrHostData = null;

	try {
	    
	    String       respbuf, databuf;
	    byte         [] b;

	    java.util.StringTokenizer rowTokenizer, colTokenizer;

	    /*
	    **	Get List of DSP distributor IDs from configserver
	    */
	    StringBuffer reqbuf = new StringBuffer();
	    ConfigComm.getServKey(reqbuf,ConfigComm.GET_DSP_DIST_ALL_INFO,
				  null);
	    b = ConfigComm.configRequest(reqbuf);
	    respbuf = new String(b);
	    b = null;

	    int index = respbuf.indexOf(ConfigComm.CONF_STX) + 1;

	    databuf = respbuf.substring(index);

	    StringBuffer rowSeparator = new StringBuffer();
	    StringBuffer colSeparator = new StringBuffer();

	    rowSeparator.append(ConfigComm.CONF_STX).
		append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_FS);

	    colSeparator.append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_RS);

	    rowTokenizer = new
		java.util.StringTokenizer(databuf,rowSeparator.toString());

	    
	    
	  
	    
	    

	    int numTokens = rowTokenizer.countTokens();
	    
	    while (rowTokenizer.hasMoreTokens()) {

		String [] rowData = new String [m_columnsCount];
		

		rowTokenizer.nextToken(); // Skip "key"
		String fstr = rowTokenizer.nextToken();

		colTokenizer = new
		    java.util.StringTokenizer(fstr, colSeparator.toString());

		rowData[0] = colTokenizer.nextToken();

		String dsptag = (String) colTokenizer.nextToken();
		
        
		if (colTokenizer.hasMoreTokens())
		    rowData[sColumn] = colTokenizer.nextToken();
		else
		    rowData[sColumn] = null;

		rowData[sColumn+1] = Constants.ERROR_STATUS;
		rowData[sColumn+2] = Constants.ERROR_STATUS;

		String host1 = (String)colTokenizer.nextToken();
		String host2 = (String)colTokenizer.nextToken();
		String phost1 = (String)colTokenizer.nextToken();
		String phost2 = (String)colTokenizer.nextToken();
		
		
		String did = (String)rowData[0];
		

		if (distrHostData == null) {
		    distrHostData = new DistrHostData(host1,phost1,
						      host2,phost2,
						      did);
		} else {
		    distrHostData.distrList.append(did).append(" ");
		}
		    
	

		if (numRows >= oldRows) {
		    m_vector.add(rowData);
		} else {
		    m_vector.setElementAt(rowData,numRows);
		}
		numRows++;

		host1 = null;
		host2 = null;
		phost1 = null;
		phost2=null;
		dsptag = null;
		fstr = null;

	    } /* while rowTokenizer() */


	    m_vector.setSize(numRows);

	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("DSPDistributorStatusModel: Num rows: "+numRows);

	    respbuf = null;
	    reqbuf = null;
	    databuf = null;
	   
	    if ( numRows==0) {
		m_vector.removeAllElements();
		fireTableDataChanged();
		return;
	    }	

	} catch (Exception e) {
	    m_vector.removeAllElements();
	    fireTableDataChanged();
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND)
		    return;
	    }
	    Log.getInstance().log_error("Error in retrieving DSP list",e);
	    return;
	}	
      

 
	


	
	StringBuffer hostQuery = new StringBuffer();
	
	hostQuery.append(distrHostData.dc1Host)
	    .append(" ").append(distrHostData.dc1PHost)
	    .append(" ").append(distrHostData.dc2Host)
	    .append(" ").append(distrHostData.dc2PHost);
        
	
	/*
	** Use ' ' for hostname separator for status query
	*/
	for (int i = 0; i < hostQuery.length(); i++) 
	    if (hostQuery.charAt(i)==',')
		hostQuery.setCharAt(i,' ');
	
	
	
	StringBuffer query = new StringBuffer("#4 ");

	query.append(hostQuery)
	    .append(",dsp_linehand,");
	
	query.append(distrHostData.distrList);
	query.append('\0');
	
	Utils.StatusQueryThread queryThread = 
	    new Utils.StatusQueryThread(query.toString());
	
	
	queryThread.start();
	
	
	Utils.QueryData queryData = (Utils.QueryData) queryThread.get();
	
	if (queryData.error != null) {
	    Log.getInstance().log_error("Error in retrieving status",
					queryData.error);
	}	

	String statusBuffer = queryData.result;

	if (statusBuffer == null) {
	    
	    java.util.Collections.sort(m_vector, new
			       StatusComparator(m_sortCol, m_sortAsc));
	    fireTableDataChanged();

	    Log.getInstance().log_error("Error in retrieving DSP Line handlers status: status buffer is null",null);
	    return;
	}


	java.util.StringTokenizer recordTokenizer 
		= new java.util.StringTokenizer(statusBuffer,"\n");

	int numRecords = recordTokenizer.countTokens();

	    
        int status_match1[] = new int[numRows];
        int status_match2[] = new int[numRows];
        for (int i = 0; i< numRows; i++){
            status_match1[i] = 0;
            status_match2[i] = 0;
        }
        
        
	for (int n = 0; n < numRecords; n++) {

		String record = recordTokenizer.nextToken();
		java.util.StringTokenizer fieldTokenizer 
		    = new java.util.StringTokenizer(record,",");

		if (fieldTokenizer.countTokens()>=6) {

		    String timestamp = fieldTokenizer.nextToken();
		    String status = fieldTokenizer.nextToken().trim();
		    String host = fieldTokenizer.nextToken().trim();
		    String progname = fieldTokenizer.nextToken();
		    String id = fieldTokenizer.nextToken().trim();
		    String lhmode = Constants.NO_STATUS;

		    

		    for (int i = 0; i< numRows; i++) {
			String did = (String)getValueAt(i,0);
			String host1 = distrHostData.dc1Host+" "
			                    +distrHostData.dc1PHost;
			String host2 = distrHostData.dc2Host+" "
			                    +distrHostData.dc2PHost;

			if (did.equals(id)) {

			    if (status.equals("status")) {

				lhmode = fieldTokenizer.nextToken();

				if (Constants.matchPattern(host1,", ",host)) {
				    _setValueAt(lhmode,i,sColumn+1);
                                    status_match1[i] = 1;
				} else if (Constants.matchPattern(host2,", ",host)) {
				    _setValueAt(lhmode,i,sColumn+2);
                                    status_match2[i] = 1;
				} else {
				    Log.getInstance().log_error("Could not "
					    +"match status host names:"+id+" ["
					    +host+"] : <"+host1+"> <"
					    +host2+">", null);
				}

			    } else {
				String es = fieldTokenizer.nextToken();
				if (host1.replace(',',' ').trim().equals(host)) {
				    _setValueAt(lhmode,i,sColumn+1);
                                    status_match1[i] = 1;
				}
                                else if (host2.replace(',',' ').trim().equals(host)) {
				    _setValueAt(lhmode,i,sColumn+2);
                                    status_match2[i] = 1;
				} else {
				    Log.getInstance().log_error("Could not "
					    +"match status host names:"+id+" ["
					    +host+"] : <"+host1+"> <"
					    +host2+">", null);
				}

			    }

			} /* if did == id */


		    } /* for i < numRows */

		    
		} else {
		    Log.getInstance().log_error("Malformed status record ("
			      +fieldTokenizer.countTokens()+") : "+record, null);
		}


	    } /* For n < numRecords */
	  
        for (int i = 0; i< numRows; i++){
            if (status_match1[i] == 0)
                _setValueAt(Constants.NO_STATUS,i,sColumn+1);
            if ( status_match2[i] == 0)
                _setValueAt(Constants.NO_STATUS,i,sColumn+2);
        }

	java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	
	IDS_SwingUtils.fireTableChanged(this, oldRows, numRows);

    

	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DSPDistributorStatusModel: Update done.");


    }





    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel 
		= m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }


	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;


	   

	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }
	    m_table.getTableHeader().repaint();  

	    synchronized (DSPDistributorStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
				       StatusComparator(modelIndex, m_sortAsc));
	    }
	  
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DSPDistributorStatusModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release();
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;

	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

	public boolean equals(Object obj) {
	    return false;
	}
    }

  


}



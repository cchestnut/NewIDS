/*
**  SCCS Info :  "@(#)IDS_SwingUtils.java	1.5    04/05/10"
*/
/*
 * IDS_SwingUtils.java
 *
 * Created on Nov 6, 2001, 4:12 PM
 */
 
package ids2ui;

 
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.util.*;
import javax.swing.event.*;

import java.awt.Component;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
/** 
 *
 * @author  srz
 * @version 
 */

public class IDS_SwingUtils {

   

    final public static Object[][] DefaultServiceCellColorMap = {
	{"Running", java.awt.Color.blue },
	{"ACTIVE", java.awt.Color.blue },
	{"DORMANT", java.awt.Color.blue },
	{"Not Configured", java.awt.Color.orange },
	{null, java.awt.Color.red }
    };

    final public static Object[][] DefaultDistrStateCellColorMap = {
	{"UP", java.awt.Color.blue },
	{null, java.awt.Color.red }

    };
    final public static Object[][] DefaultDistrSummaryCellColorMap = {
	{"UP", java.awt.Color.green.darker().darker() },
	{"DOWN", java.awt.Color.red },
	{"ACTIVE", java.awt.Color.blue },
	{"DORMANT", java.awt.Color.blue },
	{null, java.awt.Color.pink }

    };
	final public static int INTEGERS = 2;
	final public static int UPPER_CASE = 4;
	final public static int LOWER_CASE = 8;
	final public static int LIMIT_CHARS = 16;

	public static class LimitCharsDocument 
		extends javax.swing.text.PlainDocument 
	{
		int numChars = 1024;
		public LimitCharsDocument(int max) {
			super();
			numChars = max;
		}

	    public void insertString(int offs, String str, 	
					javax.swing.text.AttributeSet a) 
	    throws javax.swing.text.BadLocationException 
	    {

		if ( (str == null) 
			|| (str.length()==0) )
			return;

		int curLength = getLength();
		int insertLength = str.length();
		int newLength = curLength + insertLength;

		if (   (curLength == numChars)
			|| (offs >= numChars) )
		{
			java.awt.Toolkit.getDefaultToolkit().beep();
			return;
		}


		String s = new String(str);
		if (newLength > numChars)  {
			int n = newLength - numChars + 1;
			s = s.substring(0,n+1);
		}
	      	super.insertString(offs, s, a);
	    }
	}


    static public class IDS_CellRenderer 
	extends JLabel
	implements TableCellRenderer 
    {
	protected static Border noFocusBorder = new EmptyBorder(1, 2, 1, 2); 


	java.util.HashMap color_map = new java.util.HashMap();
 
	public IDS_CellRenderer(Object[][] cmap) 
	throws Exception
	{
	    setOpaque(true);
	    setBorder(noFocusBorder);

	    for (int i = 0; i < cmap.length; i++)
		color_map.put((String)cmap[i][0], (java.awt.Color)cmap[i][1]);
	}
	
	public Component getTableCellRendererComponent(JTable table, 
						       Object value,
						       boolean isSelected, 
						       boolean hasFocus,
						       int row, int column) 
	{
	    Color foreground = null;
	    Color background = null;
	    Font font = null;
	    
	    String s = (String)table.getValueAt(row,column);

	    
	    foreground = (java.awt.Color) color_map.get(s);
	    if (foreground == null)
		foreground = (java.awt.Color) color_map.get(null);

	    
	    setFont(table.getFont());
	    
	    if (isSelected) {
		setForeground((foreground != null) ? foreground
			      : table.getSelectionForeground());
		setBackground(table.getSelectionBackground());
	    } else {
		setForeground((foreground != null) ? foreground 
			      : table.getForeground());
		setBackground((background != null) ? background 
			      : table.getBackground());
	    }
	    
	    if (hasFocus) {
		setBorder( UIManager.getBorder("Table.focusCellHighlightBorder") );
		if (table.isCellEditable(row, column)) {
		    setForeground((foreground != null) ? foreground
				  : UIManager.getColor("Table.focusCellForeground") );
		    setBackground( UIManager.getColor("Table.focusCellBackground") );
		}
	    } else {
		setBorder(noFocusBorder);
	    }
	    setValue(value);        
	    return this;
	}
	
	protected void setValue(Object value) {
	    setText((value == null) ? "" : value.toString());
	}
    }




    


    
    public static class IntegerEditor 
	extends DefaultCellEditor
    {

	public IntegerEditor() {
	    super(new JTextField(new IntDocument(8),"",8));
	}

	public IntegerEditor(int maxlength) {
	    super(new JTextField(new IntDocument(maxlength),"",maxlength));
	}
    }


 

    

    public static class IntegerCellEditor 
	extends JTextField 
	implements TableCellEditor 
    {

	protected transient JTextField editor = null;
	protected transient Vector listeners;
	protected transient int originalValue=-1;
	protected int numChars=1024;

	public IntegerCellEditor() {
	    this(1024);
	}

	public IntegerCellEditor(int nc) {
	    super();
	    numChars = nc;
	    

	    listeners = new Vector();
	    
	    final IntegerCellEditor me = this;

	    javax.swing.text.PlainDocument intDoc = 
		new javax.swing.text.PlainDocument() {
		
		public void insertString(int offs, String str, 
					 javax.swing.text.AttributeSet a) 
		    throws javax.swing.text.BadLocationException {
		    
		    if ((str == null) || (str.length()==0))
			return;

		    char[] old_chars = str.toCharArray();
		    char[] new_chars;

		    if ((str.length() > numChars )
			|| (offs >= numChars) ) {
			me.cancelCellEditing();
			java.awt.Toolkit.getDefaultToolkit().beep();
			return;
		    }
		    
		    int l=0;
		    for (int i = 0; i < old_chars.length; i++) {
			if (Character.isDigit(old_chars[i])
			    ||((l==0)&&(old_chars[i] == '-'))
			    ||((l==0)&&(old_chars[i] == '+'))  ) {
			    old_chars[l++] = old_chars[i];
			} else {
			    me.cancelCellEditing();
			    java.awt.Toolkit.getDefaultToolkit().beep();
			}
		    }

		    new_chars = new char [l];
		    System.arraycopy(old_chars, 0, new_chars, 0, l);
		    super.insertString(offs, new String(new_chars), a);
		    
		}
		
	    };
	    setDocument(intDoc);
	}

	public Component getTableCellEditorComponent(JTable table,Object value,
						     boolean isSelected,
						     int row,int column) {
	    if (value == null) {
		return this;
	    }
	    if (value instanceof Integer) {
		setText(((Integer)value).toString());
	    }
	    


	    table.setRowSelectionInterval(row, row);
	    table.setColumnSelectionInterval(column, column);
	    try {
		originalValue = Integer.parseInt(getText());
	    } catch (NumberFormatException nfe) {};


	    return this;
	}

	// CellEditor methods
	public void cancelCellEditing() {fireEditingCanceled();}

	public Object getCellEditorValue() {
	    try {
		return new Integer(Integer.parseInt(getText()));
	    } catch (NumberFormatException nfe) {}
	    return new Integer(-1);
	}


	public boolean isCellEditable(EventObject eo) {return true;}
  
	public boolean shouldSelectCell(EventObject eo) {
	    return true;
	}

	public boolean stopCellEditing() {
	    fireEditingStopped();
	    return true;
	}

	public void addCellEditorListener(CellEditorListener cel) {
	    listeners.addElement(cel);
	}
  
	public void removeCellEditorListener(CellEditorListener cel) {
	    listeners.removeElement(cel);
	}

	protected void fireEditingCanceled() {
	    if (originalValue!=-1)
		setText(Integer.toString(originalValue));
	    ChangeEvent ce = new ChangeEvent(this);
	    for (int i = listeners.size() - 1; i >= 0; i--) {
		((CellEditorListener)listeners.elementAt(i)).editingCanceled(ce);
	    }
	}

	protected void fireEditingStopped() {
	    ChangeEvent ce = new ChangeEvent(this);
	    for (int i = listeners.size() - 1; i >= 0; i--) {
		((CellEditorListener)listeners.elementAt(i)).editingStopped(ce);
	    }
	}
    }


    public static class MultilineHeader
	extends javax.swing.JTextArea
    {
	public MultilineHeader(String s) {
	    super(s);
	    setLineWrap(true);
	    setWrapStyleWord(true);
	    setHighlighter(null);
	    setEditable(false);
	}


	public void updateUI() {
	    super.updateUI();

	    //setLineWrap(true);
	    //setWrapStyleWord(true);
	    //setHighlighter(null);
	    //setEditable(false);

	    LookAndFeel.installColorsAndFont(this,"TableHeader.background",
					     "TableHeader.foreground",
					     "TableHeader.font");

	    LookAndFeel.installBorder(this,"TableHeader.cellBorder");
	}

    }



    public static class MultilineHeaderRenderer
	implements TableCellRenderer
    {
	MultilineHeader mlh;
	JScrollPane scrollPane;


	public MultilineHeaderRenderer(String title) {
	    mlh = new MultilineHeader(title);
	    scrollPane = new javax.swing.JScrollPane(mlh);
	    
	    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);


	    scrollPane.setBorder(null);
	}


	public Component getTableCellRendererComponent(JTable table,
						       Object value, 
						       boolean isSelected,
						       boolean hasFocus, int row,
						       int col)
	{
	    mlh.setText((String)value);
	    return scrollPane;
	}
    }

    





/** Returns an ImageIcon, or null if the path was invalid. */
        protected static ImageIcon createImageIcon(String path,
                                                   String description) {
                java.net.URL imgURL = IDS_SwingUtils.class.getResource(path);
                if (imgURL != null) {
                        return new ImageIcon(imgURL, description);
                } else {
                        System.err.println("Couldn't find file: " + path);
                        return null;
                }
        }
        

        
        public static class LocationComboBoxRenderer extends JLabel
                implements ListCellRenderer {
                
                public LocationComboBoxRenderer() {
                        setOpaque(true);
                            //setHorizontalAlignment(CENTER);
                        setVerticalAlignment(CENTER);
                }
                
                
                
                    
                public Component getListCellRendererComponent(
                        JList list,
                        Object value,
                        int index,
                        boolean isSelected,
                        boolean cellHasFocus) {
                            //Get the selected index. (The index param isn't
                            //always valid, so just use the value.)

                        String item = value.toString();
                        
                        if (isSelected) {
                                setBackground(list.getSelectionBackground());
                        } else {
                                setBackground(list.getBackground());
                        }

                        if (item.equals("HOME")
                            || item.equals("Location-I")) 
                                setForeground(java.awt.Color.blue);
                        else if (item.equals("AWAY")
                                 || item.equals("Location-II")) 
                                setForeground(java.awt.Color.red);
                        else
                                setForeground(list.getSelectionForeground());
                        
                        setText(item);
                        
                        return this;
                }
                    
        } 





        public static void
        fireTableChanged(javax.swing.table.AbstractTableModel model,
                         int oldRows, int newRows) 
        {
                
                
                
                if (newRows == oldRows) {
                        javax.swing.event.TableModelEvent tme
                                = new javax.swing.event.TableModelEvent(model,
                                                                        0, newRows,
                                                                        javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                        javax.swing.event.TableModelEvent.UPDATE);
                        model.fireTableChanged(tme);
                } else if ((oldRows==0) && (newRows>0)) {
                        javax.swing.event.TableModelEvent tme
                                = new javax.swing.event.TableModelEvent(model,
                                                                        0, newRows,
                                                                        javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                        javax.swing.event.TableModelEvent.INSERT);
                        model.fireTableChanged(tme);

                } else if ((oldRows>0) && (newRows==0)) {
                        javax.swing.event.TableModelEvent tme
                                = new javax.swing.event.TableModelEvent(model,
                                                                        0, newRows,
                                                                        javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                        javax.swing.event.TableModelEvent.DELETE);
                        model.fireTableChanged(tme);
                } else if (oldRows > newRows) {
                        javax.swing.event.TableModelEvent tme
                                = new javax.swing.event.TableModelEvent(model,
                                                                        0, newRows,
                                                                        javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                        javax.swing.event.TableModelEvent.UPDATE);
                        model.fireTableChanged(tme);

                        tme = new javax.swing.event.TableModelEvent(model,
                                                                    newRows+1, oldRows,
                                                                    javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                    javax.swing.event.TableModelEvent.DELETE);
                        model.fireTableChanged(tme);
                } else if (oldRows < newRows) {
                        javax.swing.event.TableModelEvent tme
                                = new javax.swing.event.TableModelEvent(model,
                                                                        0, oldRows,
                                                                        javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                        javax.swing.event.TableModelEvent.UPDATE);
                        model.fireTableChanged(tme);

                        tme = new javax.swing.event.TableModelEvent(model,
                                                                    oldRows+1, newRows,
                                                                    javax.swing.event.TableModelEvent.ALL_COLUMNS,
                                                                    javax.swing.event.TableModelEvent.INSERT);
                        model.fireTableChanged(tme);
                }

        }
        
                        
} // End of IDS_SwingUtils

/*
**  SCCS Info :  "@(#)DistributorStatusForm.java	1.12    04/04/01"
*/
/*
 * DistributorStatusForm.java
 *
 * Created on October 19, 2000, 6:00 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistributorStatusForm 
    extends javax.swing.JFrame 
    implements TaskListener 
{

    DistributorStatusModel statusModel = null;
    javax.swing.JTable statusTable=null;

    javax.swing.JFrame myFrame;

    private javax.swing.table.TableCellRenderer stateCellRenderer = null;


    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();

    private volatile boolean isExiting = false;


  
    /** Creates new form DistributorStatusForm */
    public DistributorStatusForm(int type, int which, String name) 
	throws Exception 
    {
	myFrame = this;

	try {
		stateCellRenderer = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultDistrStateCellColorMap);
	
	} catch (Exception e) {
		Log.getInstance().log_error("DistributorStatusForm:Error in "
			+"creating cell renderer.",e);
	}

	StringBuffer key = new StringBuffer(Constants.STATUS_DISTRIBUTOR_PREFIX);
    
	if ((type!=Constants.DSP_BROADCASTER)
	    && (type!=Constants.DCM_LINEHANDLER)) {
	    setVisible(false);
	    dispose();
	    throw new Exception("Status request for invalid LH type"
				+type);
	}
    
	if (type==Constants.DSP_BROADCASTER) {
	    setTitle("DSP Line handler status");
	    key.append(Constants.GLB_TAG_DSP);
	} else if (type==Constants.DCM_LINEHANDLER) {
	    setTitle("DCM Line handler status");
	}
    
	key.append("_");
    
	if (name!=null)
	    key.append(name);
    
	key.append("_").append(which);
	
	javax.swing.JFrame f 
	    = (javax.swing.JFrame)WindowEventAdapter.getInstance()
	    .findWindow(key.toString());
	if (f!=null) {
	    f.show();
	    setVisible(false);
	    dispose();
	    throw new Utils.DuplicateWindowException();
	}


	initComponents ();
	myInitComponents(type,which,name);

	pack ();

	WindowEventAdapter.getInstance().registerWindow(key.toString(),
							this);

	updateTimer.start();


    }





    public void Refresh () 
    {

	if (statusModel==null) return;

	taskStarted(new java.util.EventObject(this));
	try {
	    rwLock.writeLock().acquire();
	} catch (Exception e){
		taskEnded();
		return;
	}
	statusModel.Refresh();

   	rwLock.writeLock().release();     
	taskEnded();

    }//GEN-LAST:event_refresh




    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }

    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 
	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}

    }




    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(final String s) {
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);
	    else
		statusPanel.clear();

	    repaint();
	}

    }



    public void taskEnded(final java.util.EventObject evt) {	

	
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(evt);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {

	    if (evt instanceof DistributorStatusEvent ) {
		DistributorStatusEvent e = (DistributorStatusEvent)evt;
		if (e.getStatus()==0) {
		    idLabel.setText(": "+e.getName());
		    hostLabel.setText(": "+e.getHost());
		    timeLabel.setText(": "+e.getTimeStamp());
		    String mode = e.getMode();
		    if (mode.startsWith("ACTIVE")) 
			modeLabel.setForeground(java.awt.Color.blue);
		    else
			modeLabel.setForeground(statusTable.getForeground());
		    modeLabel.setText(": "+mode);

		    String ckpt = e.getCheckpoint();
		    if (ckpt==null) {
			jLabel7.setText ("");
			ckptLabel.setText("");
		    } else {
			jLabel7.setText ("Checkpoint link");
			if (ckpt.startsWith("UP")
				|| ckpt.equals("-"))
			    ckptLabel.setForeground(statusTable.getForeground());
			else
			    ckptLabel.setForeground(java.awt.Color.red);
			ckptLabel.setText(": "+ckpt);
				
		    }
		    protocolLabel.setText(": "+e.getProtocol());
		    timeLabel.setText(": "+e.getTimeStamp());
		    keepaliveLabel.setText(": "+e.getKeepalive());
		    statisticsLabel.setText(": "+e.getStatistics());

		    taskEnded("Status updated @ "+new java.util.Date().toString());
		} else  {
                        if (e.getStatus()==-2) {
                                idLabel.setText(": "+e.getName());
                                hostLabel.setText(": "+e.getHost());
                        } else {
                                timeLabel.setText(": ?");
                        }
                        
                        modeLabel.setForeground(statusTable.getForeground());
                        modeLabel.setText(": ?");

                        jLabel7.setText ("");
                        ckptLabel.setText("");
                        protocolLabel.setText(": ?");
                        timeLabel.setText(": ?");
                        keepaliveLabel.setText(": ?");
                        statisticsLabel.setText(": ?");
                        taskEnded(e.getError());
		}
	    } else {
		taskEnded("Status updated.");
	    }
	}
    }



     private void myInitComponents(int type, int which, String name) 
	throws Exception
    {

	try {
	    statusModel = new DistributorStatusModel(type,which, name);
      	} catch (Exception e) { 
	    //Log.getInstance().show_error(this,"Error",e.getMessage(),e);
	    Log.getInstance().log_error(e.getMessage(),e);
	    setVisible(false);
	    dispose();
	    throw e;
	}
    
	
      
	statusTable = new javax.swing.JTable(statusModel) {
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row, int column) {
		if ( (stateCellRenderer!=null)
			&& (column==4) ) return stateCellRenderer;
		return super.getCellRenderer(row,column);
	    }
	};

	statusTable.setPreferredScrollableViewportSize(new java.awt.Dimension(500,350));
	
	statusTable.getColumnModel().getColumn(0).sizeWidthToFit();
	statusTable.getColumnModel().getColumn(1).sizeWidthToFit();
	statusTable.getColumnModel().getColumn(2).sizeWidthToFit();

	int w = statusTable.getFontMetrics(statusTable.getFont()).
	    stringWidth(" YYYYMMDD###### ");

	java.awt.Insets insets
	    = ((javax.swing.JComponent)statusTable.getCellRenderer(0 ,3)).getInsets();

	w+= (insets.left+insets.right);

	statusTable.getColumnModel().getColumn(3).setMinWidth(w );
	statusTable.getColumnModel().getColumn(3).setPreferredWidth(w );

	w = statusTable.getFontMetrics(statusTable.getFont()).stringWidth(" HHMM ");
	w+= (insets.left+insets.right);

	statusTable.getColumnModel().getColumn(5).setMinWidth(w );
	statusTable.getColumnModel().getColumn(5).setPreferredWidth(w );


	javax.swing.JScrollPane jScrollPane1 = 
	    new javax.swing.JScrollPane(statusTable);


	jPanel1.add (jScrollPane1, java.awt.BorderLayout.CENTER);


	javax.swing.table.JTableHeader header = statusTable.getTableHeader();
	header.addMouseListener(statusModel.new ColumnListener(statusTable,
							       rwLock));


    
	idLabel.setForeground(statusTable.getForeground());
	hostLabel.setForeground(statusTable.getForeground());
	protocolLabel.setForeground(statusTable.getForeground());
	timeLabel.setForeground(statusTable.getForeground());
	keepaliveLabel.setForeground(statusTable.getForeground());
	statisticsLabel.setForeground(statusTable.getForeground());

	Utils.UpdateEventListener updater 
	    = new Utils.UpdateEventListener(rwLock, this,
					    statusModel);

	updateTimer = 
	    new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, 
				  updater);

    }




    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents () {//GEN-BEGIN:initComponents
	jPanel1 = new javax.swing.JPanel ();
	jPanel3 = new javax.swing.JPanel ();
	jLabel1 = new javax.swing.JLabel ();
	idLabel = new javax.swing.JLabel ();
	jLabel3 = new javax.swing.JLabel ();
	hostLabel = new javax.swing.JLabel ();
	jLabel5 = new javax.swing.JLabel ();
	modeLabel = new javax.swing.JLabel ();
	jLabel7 = new javax.swing.JLabel ();
	ckptLabel = new javax.swing.JLabel ();
	jLabel9 = new javax.swing.JLabel ();
	protocolLabel = new javax.swing.JLabel ();
	jLabel11 = new javax.swing.JLabel ();
	timeLabel = new javax.swing.JLabel ();
	jLabel13 = new javax.swing.JLabel ();
	keepaliveLabel = new javax.swing.JLabel ();
	jLabel15 = new javax.swing.JLabel ();
	statisticsLabel = new javax.swing.JLabel ();
	jPanel4 = new javax.swing.JPanel ();
	jPanel2 = new javax.swing.JPanel ();
	jButton1 = new javax.swing.JButton ();
	jButton2 = new javax.swing.JButton ();
	statusPanel = new ids2ui.StatusPanel ();
	getContentPane ().setLayout (new java.awt.GridBagLayout ());
	java.awt.GridBagConstraints gridBagConstraints1;
	addWindowListener (new java.awt.event.WindowAdapter () {
	    public void windowClosing (java.awt.event.WindowEvent evt) {
		exitForm (evt);
	    }
	}
			   );

	jPanel1.setLayout (new java.awt.BorderLayout ());

        jPanel3.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints2;
        jPanel3.setBorder (new javax.swing.border.TitledBorder(""));
  
	jLabel1.setText ("ID");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel1, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (idLabel, gridBagConstraints2);
    
	jLabel3.setText ("Host");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel3, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (hostLabel, gridBagConstraints2);
    
	jLabel5.setText ("Mode");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 0;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel5, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 1;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (modeLabel, gridBagConstraints2);
    
	jLabel7.setText ("Checkpoint link");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 0;
	gridBagConstraints2.gridy = 4;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel7, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 1;
	gridBagConstraints2.gridy = 4;
	gridBagConstraints2.gridwidth = 3;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (ckptLabel, gridBagConstraints2);
    
	jLabel9.setText ("Line protocol");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 0;
	gridBagConstraints2.gridy = 3;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel9, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 1;
	gridBagConstraints2.gridy = 3;
	gridBagConstraints2.gridwidth = 3;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (protocolLabel, gridBagConstraints2);
    
	jLabel11.setText ("Time");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 2;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel11, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 3;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (timeLabel, gridBagConstraints2);
    
	jLabel13.setText ("Keep alive");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 0;
	gridBagConstraints2.gridy = 2;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel13, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 1;
	gridBagConstraints2.gridy = 2;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (keepaliveLabel, gridBagConstraints2);
    
	jLabel15.setText ("Statistics");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 2;
	gridBagConstraints2.gridy = 2;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 0, 10);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	jPanel3.add (jLabel15, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 3;
	gridBagConstraints2.gridy = 2;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
	gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
	gridBagConstraints2.weightx = 0.5;
	jPanel3.add (statisticsLabel, gridBagConstraints2);
    
        jPanel1.add (jPanel3, java.awt.BorderLayout.NORTH);
  
  
        jPanel1.add (jPanel4, java.awt.BorderLayout.SOUTH);
  

	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
	gridBagConstraints1.weightx = 1.0;
	gridBagConstraints1.weighty = 1.0;
	getContentPane ().add (jPanel1, gridBagConstraints1);

	jPanel2.setLayout (new java.awt.FlowLayout (1, 25, 5));

        jButton1.setText ("Refresh");
        jButton1.addActionListener (new java.awt.event.ActionListener () {
	    public void actionPerformed (java.awt.event.ActionEvent evt) {
		refresh (evt);
	    }
        }
				    );
  
        jPanel2.add (jButton1);
  
        jButton2.setText ("Close");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
	    public void actionPerformed (java.awt.event.ActionEvent evt) {
		closeForm (evt);
	    }
        }
				    );
  
        jPanel2.add (jButton2);
  

	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.gridx = 0;
	gridBagConstraints1.gridy = 1;
	gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints1.weightx = 1.0;
	getContentPane ().add (jPanel2, gridBagConstraints1);



	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.gridx = 0;
	gridBagConstraints1.gridy = 2;
	gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints1.weightx = 1.0;
	getContentPane ().add (statusPanel, gridBagConstraints1);

    }//GEN-END:initComponents

    private void closeForm (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeForm
	// Add your handling code here:
	exitForm(null);
    }//GEN-LAST:event_closeForm

    private void refresh (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		Refresh();
		return null;
	    }

	    public void finished(){
		if (cmdButton!=null) cmdButton.setEnabled(true);
	    }
	};

	sw.start();
    }//GEN-LAST:event_refresh




    /** Exit the Application */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm


	if (isExiting) return;

	isExiting = true;

	if (updateTimer!=null)
	    updateTimer.stop();

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final DistributorStatusForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();
		    //model.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();

    }//GEN-LAST:event_exitForm

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel hostLabel;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel modeLabel;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel ckptLabel;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel protocolLabel;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel keepaliveLabel;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel statisticsLabel;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private ids2ui.StatusPanel statusPanel;
    // End of variables declaration//GEN-END:variables

}

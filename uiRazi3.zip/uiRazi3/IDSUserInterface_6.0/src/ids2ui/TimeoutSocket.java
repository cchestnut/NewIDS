/*
**  SCCS Info :  "@(#)TimeoutSocket.java	1.5    02/11/18"
*/
/*
 * TimeoutSocket.java
 *
 * Created on May 15, 2000, 2:51 PM
 */
 

package ids2ui;



import java.net.*;
import java.io.*;
import java.util.*;

public class TimeoutSocket
{
   
    public static Socket Connect ( InetAddress addr, int port, int delay) 
	throws InterruptedIOException, IOException
    {
	
	SocketThread st = new SocketThread( addr, port );
	st.start();

	int timer = 0;
	Socket sock = null;

	for (;;) {
		if (Constants.DEBUG && Constants.Verbose>3)
			System.out.println("Trying connection .. "+addr+":"+port);

	    // Check to see if a connection is established
	    if (st.isConnected())  {
				// Yes ...  assign to sock variable, and break out of loop
		sock = st.getSocket();
		if (Constants.DEBUG && Constants.Verbose>2)
			System.out.println("Connected to "+addr+":"+port+" after "+timer+" msecs.");
		break;
	    } else {
				// Check to see if an error occurred
		if (st.isError()) {
				// No connection could be established
		    throw (st.getException());
		}

		try {
				// Sleep for a short period of time
		    Thread.sleep ( POLL_DELAY );
		} catch (InterruptedException ie) {}
				// Increment timer
		timer += POLL_DELAY;
		if (Constants.isExiting)
			timer = delay+1;
		
				// Check to see if time limit exceeded
		if (timer > delay)   {
		    st.interrupt();
		    try {
			st.join();
		    } catch (InterruptedException e){}
		    if (st.isConnected() ) {
			sock = st.getSocket();
			break;
		    }
				// Can't connect to server
		    throw new InterruptedIOException("Could not connect for "
						     + delay/1000 + " seconds");
		}
	    }
	}
	
	return sock;
    }

 
    public static Socket Connect ( String host, int port, int delay) 
	throws InterruptedIOException, IOException, UnknownHostException
    {
	InetAddress inetAddr = InetAddress.getByName (host);
	
	return Connect ( inetAddr, port, delay );
    }
    
    

    static class SocketThread extends Thread  {

	volatile private Socket m_connection = null;
	private String m_host       = null;
	private InetAddress m_inet  = null;
	private int    m_port       = 0;
	private IOException m_exception = null;
	
	// Connect to the specified host and port number
	public SocketThread ( String host, int port){
	    // Assign to member variables
	    m_host = host;
	    m_port = port;
	}
	
	// Connect to the specified host IP and port number
	public SocketThread ( InetAddress inetAddr, int port )
	{
	    // Assign to member variables
	    m_inet = inetAddr;
	    m_port = port;
	}
	
	public void run() {
	    // Socket used for establishing a connection
	    Socket sock = null;
	    
	    try	{
				// Was a string or an inet specified
		if (m_host != null)			{
		    // Connect to a remote host - BLOCKING I/O
		    sock = new Socket (m_host, m_port);
		} else {
		    // Connect to a remote host - BLOCKING I/O
		    sock = new Socket (m_inet, m_port);
		}
	    }   catch (IOException ioe)		{
				// Assign to our exception member variable
		m_exception = ioe;
		return;
	    }
	    
	    // If socket constructor returned without error,
	    // then connection finished
	    m_connection = sock;
	}
	
	// Are we connected?
	public boolean isConnected(){
	    if (m_connection == null)
		return false;
	    else
		return true;
	}
	
	// Did an error occur?
	public boolean isError(){
	    if (m_exception == null)
		return false;
	    else
		return true;
	}

	// Get socket
	public Socket getSocket()	{
	    return m_connection;
	}

	// Get exception
	public IOException getException()
	{
	    return m_exception;
	}
    }
    
    // Polling delay for socket checks (in milliseconds)
    private static final int POLL_DELAY = 100;
}

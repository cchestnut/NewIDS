/*
**  SCCS Info :  "@(#)StatusHandler.java	1.6    08/12/05"
*/
/*
 * StatusHandler.java
 *
 * Created on June 15, 2000, 9:50 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class StatusHandler extends Object {
        private static StatusHandler _instance = null;
  
            /** Creates new StatusHandler */
        private StatusHandler() {
        }
  
        public static StatusHandler getInstance() {
                if (_instance == null) {
                        synchronized(StatusHandler.class) {
                                if (_instance == null) {
                                        _instance  = new StatusHandler();
                                }
                        }
                }
                return _instance;
        }
  
        public int 
        displayStatus(java.awt.Component parent, int type, 
		      int which, String host, String tag, String name )
                throws Exception
        {
                        

                javax.swing.JFrame status_win = null;
                
                
                switch (type) {
                    case Constants.DSP_READER:
                    case Constants.DCM_READER:
                    case Constants.MSGMGR:
                            try {
                                    status_win    = new ReaderStatusForm(type,which,tag, name);
                            } catch (Utils.DuplicateWindowException dwe) {
                            } 
                            break;
                    case Constants.DSP_BROADCASTER:
                    case Constants.DCM_LINEHANDLER:
                            try {
                                    status_win    = new DistributorStatusForm(type,which,name);
                            } catch (Utils.DuplicateWindowException dwe) {
                            } 
                            break;
                    default:
                            Log.getInstance().show_error(parent,"Error",
                                                         "Request to display status"
                                                         +"of unknown type:"+type,
                                                         null);
                }


                if (status_win!=null)
                        status_win.show();


                return 0;             
        }
  
}

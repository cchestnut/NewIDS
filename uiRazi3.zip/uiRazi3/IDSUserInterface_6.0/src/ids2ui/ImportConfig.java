
    /*
    **  SCCS Info :  "@(#)ImportConfig.java	1.1    05/03/31"
    */

/*
 * ImportConfig.java
 *
 * Created on March 31, 2005, 10:21 AM
 */


package ids2ui;
import java.io.*;


public class ImportConfig {

	public ImportConfig(){}


	static public java.util.HashMap loadConfig(boolean resource, String name)
	throws Exception
	{
		java.util.HashMap map = null;

		if (resource)
			map = Utils.getHashMap(ImportConfig.class.getResourceAsStream("config/"
							+ platform +"/" + name));
		else
			map = Utils.getHashMap(new FileInputStream(name));


		return map;
	}

	static public InputStream getStream(boolean resource, String name)
	throws Exception
	{

		if (resource)
			return ImportConfig.class.getResourceAsStream("config/"
							+ platform +"/" + name );
		else
			return new FileInputStream(name);

	}

	static public void ImportProducts(boolean resource, String products_file, String sparse_matrix_file)
	throws Exception
	{

		CSCProductsModel pmodel 
		    = new CSCProductsModel( getStream(resource, products_file) );

                CSCSparseMatrixModel smodel
		    = new CSCSparseMatrixModel(pmodel, getStream(resource, sparse_matrix_file));


		StringBuffer reqbuf = new StringBuffer();


		System.out.print("Saving products...");
		ConfigComm.saveProducts(reqbuf,Constants.GLB_PRODUCT_LIST,
				pmodel.toString());


		/* Send request to save products*/
		byte[] b = ConfigComm.configRequest(reqbuf);

		System.out.println("... done.");

                reqbuf.setLength(0);
                

		ConfigComm.saveKeyValue(reqbuf,
				Constants.GLB_DCM_PRODUCT_CONVERSION_TABLE,
				smodel.toString());

		System.out.print("Saving sparse matrix.");
		b = ConfigComm.configRequest(reqbuf);

		System.out.println("... done.");

	}

        


	static public void ImportDSP(boolean resource, String dsp_file)
	throws Exception
	{

		java.util.HashMap map = loadConfig(resource, dsp_file);


		System.out.print("Saving DSP configuration....");

                // Save
		StringBuffer reqbuf = new StringBuffer();
		
                ConfigComm.convertHashMap(reqbuf, 
                                  Constants.GLB_TAG_DSP,
                                  ConfigComm.SAVE_DSP_KEY,
                                  map, null, true);
		

		byte[] b = ConfigComm.configRequest(reqbuf);

		System.out.println("... done.");
	}

	static public void ImportDCM(boolean resource, String dcm_file)
	throws Exception
	{

		java.util.HashMap map = loadConfig(resource, dcm_file);

		String id = (String)map.get("ID");

		if (id == null) 
			throw new Exception("ID field missing in configuration file "+dcm_file);
		System.out.print("Saving DCM "+id+" configuration....");

		// Save
		StringBuffer reqbuf = new StringBuffer();
                 int r = ConfigComm.SAVE_DCM_KEY;
            
            
            ConfigComm.convertHashMap(reqbuf,
                                      Constants.GLB_TAG_DCM_PREFIX+id,
                                      r, map, null, true);
            
          
		byte[] b = ConfigComm.configRequest(reqbuf);

		System.out.println("... done.");
	}

	static public void ImportLinehandler(boolean resource, String dlh_file)
	throws Exception
	{

		java.util.HashMap map = loadConfig(resource, dlh_file);


		String id = (String)map.get("ID");
 		int db_req = ConfigComm.SAVE_DISTRIBUTOR_KEY;

		StringBuffer reqbuf = new StringBuffer();
		System.out.print("Saving distributor "+id+" configuration....");
 		ConfigComm.convertHashMap(reqbuf, Constants.GLB_TAG_DISTR_PREFIX+id,
					   db_req, map, null, true);

		byte[] b = ConfigComm.configRequest(reqbuf);
		System.out.println("... done.");

	}



	static public void ImportKV(boolean resource, String kv_file)
		throws Exception
	{


        java.io.LineNumberReader fileReader
		= new java.io.LineNumberReader( 
			new java.io.InputStreamReader(getStream(resource, kv_file)));


		
		char	COMMENT = '#';
		String line = null;
		StringBuffer reqbuf = new StringBuffer();
		byte [] b;

		while ( (line = fileReader.readLine()) != null) {
			
			if ( (line.trim().length()==0)
				|| (line.charAt(0)==COMMENT) )
				continue;

			int index = line.indexOf("\t");

			if (index > 0) {

				String key = line.substring(0,index).trim();
				String value = line.substring(index+1);

				reqbuf.setLength(0);

		    		ConfigComm.saveKeyValue(reqbuf,key,value);
				b = ConfigComm.configRequest(reqbuf);

			}
		}
	}

	
	private static void Usage()
	{
		System.out.println("Usage: java -jar ImportConfig.jar dsp_host_list  PRODUCTS product_config_file sparse_matrix_config_file");
		System.out.println("Usage: java -jar ImportConfig.jar dsp_host_list  [DSP|DCM|LINEHANDLER|KV ] file1 file2 ..");
		System.exit(1);
	}

	static String platform = null;

	static String PRODUCTS_ARG = "PRODUCTS";
	static String DSP_ARG = "DSP";
	static String DCM_ARG = "DCM";
	static String LINEHANDLER_ARG = "LINEHANDLER";
	static String KV_ARG = "KV";

        
	public static void main(String[] args)
	{

		boolean resource = false;
		try {
			StringBuffer userName = new StringBuffer();
			StringBuffer hostList = new StringBuffer();
			StringBuffer idsDir   = new StringBuffer();
		    
			if ( 
				   (args.length < 3) 
                                   || ( !args[1].equals(DSP_ARG) 
					&& !args[1].equals(DCM_ARG)
					&& !args[1].equals(PRODUCTS_ARG) 
					&& !args[1].equals(LINEHANDLER_ARG) 
					&& !args[1].equals(KV_ARG) )  
			   ) 
			{
				Usage();
			}

		    
			userName.append("ids2adm");
			idsDir.append("/ids2");
			hostList.append(args[0]);

			
			System.out.println("Configuration host list: "
						+hostList.toString());

			ConfigComm.initLoginLite(userName.toString(),
						 hostList.toString(),
						 idsDir.toString());

			

		
			if (args[1].equals(PRODUCTS_ARG)) {
				if (args.length != 4)
					Usage();
				ImportProducts(resource,
					args[2], args[3] );
			}
					
                    
		    	if (args[1].equals(DSP_ARG)) {
				if (args.length != 3)
					Usage();
				ImportDSP(resource, args[2]);
			}

			if (args[1].equals(DCM_ARG)) {
				if (args.length != 3)
					Usage();
				for (int i = 2; i < args.length; i++)
					ImportDCM(resource, args[i]);
                        }
                        

			if (args[1].equals(KV_ARG)) {
				if (args.length != 3)
					Usage();
				for (int i = 2; i < args.length; i++)
					ImportKV(resource, args[i]);
                        }
                        
                    

			if (args[1].equals(LINEHANDLER_ARG)) {
				if (args.length != 3)
					Usage();
				for (int i = 2; i < args.length; i++)
					ImportLinehandler(resource, args[i]);
                        }
                        

		}
		catch (Exception e) {
		    e.printStackTrace();
		}
		
		System.exit(0);


	}


}



/*
 **  SCCS Info :  "@(#)NBConnect.java	1.1    05/03/29"
 */
/*
 * TimeoutSocket.java
 *
 * Created on May 15, 2000, 2:51 PM
 */


package ids2ui;



import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Non-blocking connect:
 * Use a separate thread to make TCP connections
 * making it easier to break out 
 */

public class NBConnect {
    
    public static Socket Connect( InetAddress addr, int port, int delay)
    throws InterruptedIOException, IOException 
    {
        
        ConnectThread ct = new ConnectThread( addr, port );
        
        ct.start();
        
        int timer = 0;
        Socket sock = null;
        
        /*
         ** Wait for connection to complete or timeout
         */
         
        for (;;) 
        {
            
            if (Constants.DEBUG && Constants.Verbose>3)
                System.out.println("Trying connection .. "+addr+":"+port);
            
            
            if (ct.isConnected())  
            {
                sock = ct.getConnection();
                
                if (Constants.DEBUG && Constants.Verbose>2)
                    System.out.println("Connected to "+addr+":"
                    +port+" after "+timer+" msecs.");
                
                break;
                
            } 
            else 
            {
                
                if (ct.isError()) {                    
                    throw (ct.getException());
                }
                
                try {                    
                    Thread.sleep( POLL_DELAY );
                } 
                catch (InterruptedException ie) {}
                
                timer += POLL_DELAY;
                if (Constants.isExiting)
                    timer = delay+1;
                
                
                if (timer > delay)   
                {
                    ct.interrupt();
                    
                    try {
                        ct.join();
                    } 
                    catch (InterruptedException e){}
                    
                    if (ct.isConnected() ) 
                    {
                        sock = ct.getConnection();
                        break;
                    }
                    
                    throw new InterruptedIOException("Could not connect for "
                                        + delay/1000 + " seconds");
                }
            }
        }
        
        ct = null;
        return sock;
    }
    
    
    public static Socket Connect( String host, int port, int delay)
    throws InterruptedIOException, IOException, UnknownHostException {
        
        InetAddress inetAddr = InetAddress.getByName(host);
        
        return Connect( inetAddr, port, delay );
    }
    
    
    
    static class ConnectThread extends Thread  {
        
        volatile private Socket conn  = null;        
        private InetAddress addr      = null;
        private int         port      = 0;
        private IOException exception = null;
        
        
        
        public ConnectThread( InetAddress a, int p ) 
        {            
            this.addr = a;
            this.port = p;
        }
        
        public void run() 
        {
            
            Socket s = null;
            
            try	
            {
                
                if (addr != null)
                {                    
                    s = new Socket(addr, port);
                }
                else
                {
                    exception = new IOException("Destination address not specified.");
                    return;
                }
            }   
            catch (IOException ioe)	
            {                                
                exception = ioe;
                return;
            }
            
            
            conn = s;
        }
        
        
        public boolean isConnected()
        {
            if (conn == null)
                return false;
            else
                return true;
        }
        
        
        public boolean isError()
        {
            return (exception != null);                
        }
        
        
        public Socket getConnection()
        {
            return conn;
        }
        
        
        public IOException getException() 
        {
            return exception;
        }
    }
    
    // Polling delay for socket checks (in milliseconds)
    private static final int POLL_DELAY = 500;
}

/*
 **  SCCS Info :  "%W%    %E%"
 */
/*
 * DistributorConfigurationForm.java
 *
 * Created on March 2, 2001, 4:15 PM
 */
package ids2ui;

import javax.swing.DefaultComboBoxModel;
import model.DistributorProductFlagOptions;
import model.PremiumCodesList;

/**
 *
 * @author srz
 * @version
 */
public class DistributorConfigurationForm
        extends javax.swing.JFrame {

    final static short CODES_ON = 1;
    final static short SUMMARY_ON = 4;
    
    public static int MAX_ENTRIES = Constants.MAX_TCP_ADDRESS;
    public static String ftpParamsColumnNames[] = {"Hostname", "Port",
        "Username", "Password",
        "Passive mode", "Transfer mode",
        "Statistics", "Remote dir.",
        "Rename file"
    };
    public static String DefaultFileExtention[] = {".xml", ".txt"};
    protected Class[] ftpParamsColumnClasses = {String.class, String.class,
        String.class, String.class,
        Boolean.class, String.class,
        Boolean.class, String.class,
        Boolean.class
    };
    private javax.swing.table.DefaultTableModel ftpParamsModel = new javax.swing.table.DefaultTableModel(ftpParamsColumnNames, 0) {

        public Class getColumnClass(int columnIndex) {
            return ftpParamsColumnClasses[columnIndex];
        }

        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private javax.swing.JTable ftpParamsTable =
            new javax.swing.JTable(ftpParamsModel);
    private String ckptPort = Constants.GLB_DCM_DISTR_CHECKPOINT_STRING;
    private int distrConfigType = -1;
    private String blank = "Select a DCM";
    private java.util.Vector transportList = null;
    private java.util.Vector statisticsList = null;
    private java.util.Vector formatList = null;
    private java.util.Vector formatList_AD = null;
    private java.util.Vector productList = null;
    private javax.swing.DefaultComboBoxModel formatComboBoxModel;
    private javax.swing.DefaultComboBoxModel productComboBoxModel;
    private TransportConfigPanel transportPanel = null;
    private javax.swing.JTable productTable1;
    private javax.swing.JTable productTable2;
    private boolean existsInDatabase = false;
    private String origDCMTag = null;
    private java.util.HashMap origConfig = null;
    private java.util.HashMap origHostConfig = null;
    private java.util.HashMap productMap1 = null;
    private java.util.HashMap productMap2 = null;
    private javax.swing.JFrame myFrame = null;
    private MutexLock mLock = new MutexLock();
    private volatile boolean isExiting = false;
    private boolean configModified = false;
    ReceivingDCMPanel recvDCMPanel = null;

    PremiumCodesList pcl = null;
    
    /**
     * Creates new form DistributorConfigurationForm
     */
    public DistributorConfigurationForm(String distrTag, String dcmTag,
            boolean copy)
            throws Exception {
        try {
            init(Constants.DCM_LINEHANDLER, distrTag, dcmTag, copy);
        } catch (Exception e) {
            Log.getInstance().log_error("DistributorConfigurationForm:"
                    + "Error", e);
            throw e;
        }

    }

    public DistributorConfigurationForm(int htype,
            String distrTag,
            String dcmTag,
            boolean copy)
            throws Exception {
        try {
            init(htype, distrTag, dcmTag, copy);
        } catch (Exception e) {
            Log.getInstance().log_error("DistributorConfigurationForm:"
                    + "Error", e);
            throw e;
        }
        //((DistrProductTableModel)productTable1.getModel()).setProductFilterView(productTable1);

    }

    private void initDJNEWSComponents() {

        javax.swing.DefaultComboBoxModel m = null;
        java.util.Vector deliveryTypes = ConfigComm.getDeliveryTypes();
        java.util.Vector conversionTypes = ConfigComm.getConversionTypes();
        java.util.Vector contentTypes = ConfigComm.getContentTypes();
        java.util.Vector encodingList = ConfigComm.getEncodingList();
        java.util.Vector deliveryMethods = ConfigComm.getDeliveryMethods();
        java.util.Vector takeTypes = ConfigComm.getTakeTypes();
        java.util.Vector fileGenTypes = ConfigComm.getFileGenerationTypes();

        m = new javax.swing.DefaultComboBoxModel(deliveryTypes);
        deliveryTypesComboBox.setModel(m);
        m = new javax.swing.DefaultComboBoxModel(conversionTypes);
        conversionTypesComboBox.setModel(m);
        m = new javax.swing.DefaultComboBoxModel(contentTypes);
        contentTypesComboBox.setModel(m);
        m = new javax.swing.DefaultComboBoxModel(encodingList);
        encodingTypesComboBox.setModel(m);

        m = new javax.swing.DefaultComboBoxModel(deliveryMethods);
        deliveryMethodsComboBox.setModel(m);

        m = new javax.swing.DefaultComboBoxModel(takeTypes);
        takeComboBox.setModel(m);
        m = new javax.swing.DefaultComboBoxModel(fileGenTypes);
        filenameGenerationComboBox.setModel(m);


        filenameGenerationComboBox.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        comboChanged(evt);
                    }
                });
        conversionTypesComboBox.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        comboChanged(evt);
                    }
                });

        javax.swing.JScrollPane sp = new javax.swing.JScrollPane(ftpParamsTable);

        ftpParamsTable.setAutoCreateColumnsFromModel(false);
        ftpParamsTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200, 100));
        ftpParamsTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

        ftpParamsPanel.add(sp);



        sendChangesCheckBox.setSelected(true);

        deliveryTypesComboBox.setSelectedIndex(0);
        conversionTypesComboBox.setSelectedIndex(0);
        contentTypesComboBox.setSelectedIndex(0);
        deliveryMethodsComboBox.setSelectedIndex(0);
    }

    private void init(int htype, String distrTag, String dcmTag, boolean copy)
            throws Exception {
        myFrame = this;

        pcl = ConfigComm.getPremiumCodesList();

        statisticsList = ConfigComm.getStatisticsList();
        formatList = ConfigComm.getProductFormatList();
        formatList_AD = ConfigComm.getCSCSparseMatrixModel().getProductFormats(Constants.ADMIN_PRODUCT_ID);

        transportList = ConfigComm.getTransportTypeList();

        distrConfigType = htype;

        initComponents();

        codeCheckBox.setSelected(false);
        codeTextField.setEnabled(false);
        jLabel25.setEnabled(false);

        jLabel27.setEnabled(false);
        newsplusOffCheckBox.setEnabled(false);

        initDJNEWSComponents();

        int inx = jTabbedPane1.indexOfTab("Delivery Rules");
        if (inx != -1) {
            jTabbedPane1.removeTabAt(inx);
        }
        //ftpContentPanel.setVisible(false);
        ftpTransportPanel.setVisible(false);

        idTextField.setDocument(new UCDocument(Constants.DISTRIBUTOR_ID_SIZE));
        locationComboBox1.addActionListener(locationComboListener);
        /*
         * Disable Delete button
         */
        jButton9.setEnabled(false);





        setTitle("Distributor Configuration Screen");


        int ret = 0;


        if (distrTag == null) {
            /*
             * Setup the form for a new distributor
             */

            if (distrConfigType == Constants.DSP_LINEHANDLER) {

                ret = initNewDSPScreen();
                loadLocations(null, Constants.GLB_TAG_DSP);
            } else if (distrConfigType == Constants.DSP_BROADCASTER) {

                ret = initNewDSPShortCutScreen();
                loadLocations(null, Constants.GLB_TAG_DSP);
            } else if ((distrConfigType == Constants.DCM_LINEHANDLER)
                    || (distrConfigType == Constants.DJNEWS_LINEHANDLER)) {
                //ftpContentPanel.setVisible(true);
                inx = jTabbedPane1.indexOfTab("Delivery Rules");
                if (inx == -1) {
                    jTabbedPane1.insertTab("Delivery Rules",
                            null, jPanel8, null, 1);
                }
                ftpTransportPanel.setVisible(true);
                ret = initNewDCMScreen();
                java.awt.CardLayout cl = (java.awt.CardLayout) cardsPanel.getLayout();
                cl.show(cardsPanel, "SELECT_DCM");
                if (dcmTag != null) {
                    dcmComboBox.setSelectedItem(dcmTag);
                }

            } else {
                ret = -1;
                Log.getInstance().show_error(this, "Error",
                        "Unsupported type."
                        + distrConfigType, null);
            }
        } else {
            /*
             * Setup the form for a new distributor
             */
            ret = loadConfig(distrTag, copy);
        }


        if (ret != 0) {
            setVisible(false);
            dispose();
            throw new Exception("Can't initialize ");
        }

        if (distrConfigType == Constants.DSP_BROADCASTER) {
            // Disable product modify
            jButton2.setVisible(false);

            // Disable keep alive label & text fields
            jLabel3.setVisible(false);
            jLabel4.setVisible(false);
            keepAliveTextField1.setVisible(false);
            keepAliveTextField2.setVisible(false);
        } else if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {
            // Disable keep alive label & text fields
            jLabel3.setVisible(false);
            jLabel4.setVisible(false);
            keepAliveTextField1.setVisible(false);
            keepAliveTextField2.setVisible(false);
        }

        if ((copy == false) && (distrTag != null)) {
            idTextField.setText(distrTag);
            idTextField.setEditable(false); // Don't allow changing ID
        }


        javax.swing.table.JTableHeader header = productTable1.getTableHeader();
        header.addMouseListener(((DistrProductTableModel) productTable1.getModel()).new ColumnListener(productTable1));

        header = productTable2.getTableHeader();
        header.addMouseListener(((DistrProductTableModel) productTable2.getModel()).new ColumnListener(productTable2));


        if (distrConfigType == Constants.DCM_LINEHANDLER) {
        } else {
        }




        if ((copy == false) && (distrTag != null)) {
            WindowEventAdapter.getInstance().registerWindow(
                    Constants.CONFIGURATION_DISTRIBUTOR_PREFIX
                    + distrTag, this);
        }


        pack();

    } // init

    public boolean setupTable(java.util.HashMap map,
            StringBuffer errmsg) {

        if ((map == null)
                || (map.size() == 0)) {
            return false;
        }

        int n = -1;

        String np = (String) map.get(Constants.FTP_NUM_ENTRIES);
        try {
            n = Integer.parseInt(np);
        } catch (Exception e) {
        }

        /*
         * ftpParamsModel.setRowCount(0); ftpParamsModel.setRowCount(n);
         */

        ftpParamsModel.setNumRows(0);
        ftpParamsModel.setNumRows(n);

        for (int i = 0; i < n; i++) {
            String hostname = (String) map.get(Constants.FTP_SERVER_PREFIX + i);
            String port = (String) map.get(Constants.FTP_PORT_PREFIX + i);
            String username = (String) map.get(Constants.FTP_USERNAME_PREFIX + i);
            String password = (String) map.get(Constants.FTP_PASSWORD_PREFIX + i);


            Boolean passiveMode = Boolean.valueOf((String) map.get(Constants.FTP_PASSIVE_MODE_PREFIX + i));
            String xfer_mode = (String) map.get(Constants.FTP_TRANSFER_MODE_PREFIX + i);
            Boolean statistics_file = Boolean.valueOf((String) map.get(Constants.FTP_STATISTICS_FILE_PREFIX + i));
            String remote_dir = (String) map.get(Constants.FTP_REMOTE_DIR_PREFIX + i);
            Boolean renameFile = Boolean.valueOf((String) map.get(Constants.FTP_RENAME_FILE_PREFIX + i));


            ftpParamsModel.setValueAt(new String(hostname), i, 0);
            ftpParamsModel.setValueAt(new String(port), i, 1);
            ftpParamsModel.setValueAt(new String(username), i, 2);
            if (password != null) {
                ftpParamsModel.setValueAt(new String(password), i, 3);
            } else {
                ftpParamsModel.setValueAt(new String(""), i, 3);
            }

            ftpParamsModel.setValueAt(new Boolean(passiveMode.booleanValue()), i, 4);

            if (xfer_mode != null) {
                ftpParamsModel.setValueAt(new String(xfer_mode), i, 5);
            }


            ftpParamsModel.setValueAt(new Boolean(statistics_file.booleanValue()), i, 6);

            if (remote_dir != null) {
                ftpParamsModel.setValueAt(new String(remote_dir), i, 7);
            }

            ftpParamsModel.setValueAt(new Boolean(renameFile.booleanValue()), i, 8);
        }


        if (errmsg != null) {
            return validateData(errmsg);
        }

        return true;

    }

    public java.util.HashMap getFTPParams() {



        int numRows = ftpParamsModel.getRowCount();

        java.util.HashMap map = new java.util.HashMap(5);

        int count = 0;
        for (int i = 0; i < numRows; i++) {
            String hostname = (String) ftpParamsModel.getValueAt(i, 0);
            String port = (String) ftpParamsModel.getValueAt(i, 1);



            if ((hostname == null) || (hostname.trim().length() == 0)) {
                continue;
            }

            String username = (String) ftpParamsModel.getValueAt(i, 2);
            String password = (String) ftpParamsModel.getValueAt(i, 3);

            Boolean b = (Boolean) ftpParamsModel.getValueAt(i, 4);
            String passive_mode = Boolean.FALSE.toString();
            if (b != null) {
                passive_mode = b.toString();
            }

            String xfer_mode = (String) ftpParamsModel.getValueAt(i, 5);

            b = (Boolean) ftpParamsModel.getValueAt(i, 6);
            String statistics = Boolean.FALSE.toString();
            if (b != null) {
                statistics = b.toString();
            }

            String remote_dir = (String) ftpParamsModel.getValueAt(i, 7);


            b = (Boolean) ftpParamsModel.getValueAt(i, 8);
            String rename_file = Boolean.FALSE.toString();
            if (b != null) {
                rename_file = b.toString();
            }



            map.put(Constants.FTP_SERVER_PREFIX + count, hostname);
            map.put(Constants.FTP_PORT_PREFIX + count, port);
            map.put(Constants.FTP_USERNAME_PREFIX + count, username);
            map.put(Constants.FTP_PASSWORD_PREFIX + count, password);
            map.put(Constants.FTP_PASSIVE_MODE_PREFIX + count, passive_mode);
            if ((xfer_mode != null)
                    && (xfer_mode.trim().length() > 0)) {
                map.put(Constants.FTP_TRANSFER_MODE_PREFIX + count, xfer_mode);
            }

            map.put(Constants.FTP_STATISTICS_FILE_PREFIX + count, statistics);

            if ((remote_dir != null)
                    && (remote_dir.trim().length() > 0)) {
                map.put(Constants.FTP_REMOTE_DIR_PREFIX + count, remote_dir);
            }

            map.put(Constants.FTP_RENAME_FILE_PREFIX + count, rename_file);

            count++;

        }

        if (count > 0) {
            map.put(Constants.FTP_NUM_ENTRIES, Integer.toString(count));
        }

        return map;
    }

    public boolean validateData(StringBuffer errmsg) {
        errmsg.setLength(0);
        errmsg.append("Enter valid FTP parameter values: \n");
        int numRows = ftpParamsModel.getRowCount();

        boolean err = false;
        int count = 0;

        for (int i = 0; i < numRows; i++) {

            String hostname = (String) ftpParamsModel.getValueAt(i, 0);
            String port = (String) ftpParamsModel.getValueAt(i, 1);
            String username = (String) ftpParamsModel.getValueAt(i, 2);
            String password = (String) ftpParamsModel.getValueAt(i, 3);
            String xfer_mode = (String) ftpParamsModel.getValueAt(i, 5);

            boolean hasRowData = false;
            boolean rowError = false;
            StringBuffer row_errmsg = new StringBuffer();
            if ((hostname == null) || (hostname.trim().length() == 0)) {
                rowError = true;
                row_errmsg.append("Host ");
            } else {
                hasRowData = true;
            }
            if ((port == null) || (port.trim().length() == 0)) {
                rowError = true;
                row_errmsg.append("Port ");
            } else {
                hasRowData = true;
            }
            if ((username == null) || (username.trim().length() == 0)) {
                rowError = true;
                row_errmsg.append("Username ");
            } else {
                hasRowData = true;
            }
            if ((password == null) || (password.trim().length() == 0)) {
                rowError = true;
                row_errmsg.append("Password ");
            } else {
                hasRowData = true;
            }

            if ((xfer_mode != null)
                    && (xfer_mode.trim().length() > 0)
                    && !(xfer_mode.equals("ascii")
                    || xfer_mode.equals("binary"))) {
                rowError = true;
                row_errmsg.append("Transfer mode is 'ascii' or 'binary'.");
            }


            if (hasRowData && rowError) {
                err = true;
                errmsg.append("Row " + (i + 1) + " :").append(row_errmsg).append("\n");
            } else if (hasRowData) {
                count++;
            }
        }

        if (count <= 0) {
            err = true;
            errmsg.append("Atleast one host has to be configured\n");
        }

        return err;
    }

    private void updateProducts() {

        boolean removeAD = false;

        String prodlist[] = null;

        if (distrConfigType == Constants.DCM_LINEHANDLER) {
            removeAD = false;
            prodlist = ConfigComm.getCSCProductsModel().getAllProducts();
        } else if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {
            removeAD = true;
            prodlist = ConfigComm.getCSCProductsModel().getContainerProducts();
        } else if (distrConfigType == Constants.DSP_BROADCASTER) {
            removeAD = true;
            prodlist = ConfigComm.getCSCProductsModel().getProducts();
        } else if (distrConfigType == Constants.DSP_LINEHANDLER) {
            removeAD = false;
            prodlist = ConfigComm.getCSCProductsModel().getProducts();
        }

        productList = new java.util.Vector(prodlist.length);
        for (int i = 0; i < prodlist.length; i++) {
            if (!removeAD
                    || (removeAD
                    && !prodlist[i].equals(Constants.ADMIN_PRODUCT_ID))) {
                productList.add(prodlist[i]);
            }
        }
        productComboBoxModel = new javax.swing.DefaultComboBoxModel(productList);
    }

    private javax.swing.JTable createProductTable() {

        boolean removeAD = false;

        String prodlist[] = null;

        if (distrConfigType == Constants.DCM_LINEHANDLER) {
            removeAD = false;
            prodlist = ConfigComm.getCSCProductsModel().getAllProducts();
        } else if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {
            removeAD = true;
            prodlist = ConfigComm.getCSCProductsModel().getContainerProducts();
        } else if (distrConfigType == Constants.DSP_BROADCASTER) {
            removeAD = true;
            prodlist = ConfigComm.getCSCProductsModel().getProducts();
        } else if (distrConfigType == Constants.DSP_LINEHANDLER) {
            removeAD = false;
            prodlist = ConfigComm.getCSCProductsModel().getProducts();
        }

        productList = new java.util.Vector(prodlist.length);
        for (int i = 0; i < prodlist.length; i++) {
            if (!removeAD
                    || (removeAD
                    && !prodlist[i].equals(Constants.ADMIN_PRODUCT_ID))) {
                productList.add(prodlist[i]);
            }
        }



        productComboBoxModel = new javax.swing.DefaultComboBoxModel(productList);




        javax.swing.JTable productTable = new javax.swing.JTable(new DistrProductTableModel(myFrame));

        productTable.setPreferredScrollableViewportSize(new java.awt.Dimension(225, 100));


        productTable.getColumnModel().getColumn(0).sizeWidthToFit();
        productTable.getColumnModel().getColumn(1).sizeWidthToFit();
        productTable.getColumnModel().getColumn(2).sizeWidthToFit();
        productTable.getColumnModel().getColumn(3).sizeWidthToFit();

        final IntTextField integerField = new IntTextField();
        final javax.swing.JFrame This = this;

        javax.swing.DefaultCellEditor integerEditor =
                new javax.swing.DefaultCellEditor(integerField) {

                    public Object getCellEditorValue() {
                        try {
                            return new Integer(Integer.parseInt(integerField.getText()));
                        } catch (Exception e) {
                            Log.getInstance().show_error(This, "Error",
                                    "Error in parsing delay.", e);
                            if (Constants.DEBUG && Constants.Verbose > 2) {
                                System.out.println("Error in parsing int");
                            }
                            return new Integer(0);
                        }
                    }
                };

        productTable.setDefaultEditor(Integer.class, integerEditor);


        return productTable;
    } /*
     * End of createProductTable()
     */


    private int initNewDSPShortCutScreen() {
        java.util.Vector dcmList = null;

        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DSP");

        recvDCMPanel = new ReceivingDCMPanel();
        transportBoxPanel.add(recvDCMPanel);

        recvDCMPanel.transportLabel.setText(Constants.GLB_IDS_TRANSPORT);

        /*
         * Retrieve List of DCM TAGS
         */
        try {

            dcmList = ConfigComm.getDCMList();

        } catch (Exception e) {
            StringBuffer errstr = new StringBuffer();
            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo()
                        == Constants.KEY_NOT_FOUND) {
                    errstr.append("Please define receiving DCM before adding ");
                    errstr.append("linehandler.\n");
                } else {
                    errstr.append("Error in retrieving DCM list.\n");
                }
            }

            Log.getInstance().show_error(this, "Error",
                    errstr.toString(), e);
            return -1;
        }

        int numDCMs = dcmList.size();

        recvDCMPanel.dcmComboBox.addItem(blank);
        recvDCMPanel.dcmComboBox.setSelectedItem(blank);

        for (int i = 0; i < numDCMs; i++) {
            recvDCMPanel.dcmComboBox.addItem((String) dcmList.get(i));
        }


        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);


        DistrProductTableModel m1 = (DistrProductTableModel) productTable1.getModel();
        DistrProductTableModel m2 = (DistrProductTableModel) productTable2.getModel();
        m1.setProductsOnlyView(true);
        m2.setProductsOnlyView(true);


        return 0;
    }

    private void loadLocations(java.util.HashMap map, String hostkey)
            throws Exception {

        java.util.HashMap config_map = null;

        if (map == null) {
            if (hostkey == null) {
                return;
            }
            config_map = ConfigComm.getHashMapDirect(hostkey);
        }

        String location1 = (String) config_map.get("LOCATION1");
        String location2 = (String) config_map.get("LOCATION2");

        DefaultComboBoxModel cm = new DefaultComboBoxModel();
        if (location1 != null && location1.trim().length() > 0) {
            cm.addElement(location1);
        }
        if (location2 != null && location2.trim().length() > 0) {
            cm.addElement(location2);
        }
        locationComboBox1.setModel(cm);
        locationComboBox1.setSelectedItem(null);
        locationComboBox2.setSelectedItem(null);
    }

    private int initNewDSPScreen() {


        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DSP");




        transportPanel = new TransportConfigPanel(this, "Receiving host transport protocol",
                transportList, null, null, null, null, true);

        transportBoxPanel.add(transportPanel);

        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);



        return 0;

    }
    private java.awt.event.ActionListener dcmComboListener = new java.awt.event.ActionListener() {

        public void actionPerformed(java.awt.event.ActionEvent evt) {
            String item = (String) dcmComboBox.getSelectedItem();
            if ((item == null) || item.equals(blank)) {
                item = null;
            }

            if (transportPanel != null) {
                transportPanel.dcmChanged(item);
            }

            java.awt.CardLayout cl = (java.awt.CardLayout) cardsPanel.getLayout();

            distrConfigType = Constants.DCM_LINEHANDLER;
            boolean vis = false;
            try {
                if ((item != null) && !item.equals(blank)) {
                    java.util.HashMap dcmConfig = ConfigComm.getHashMapDirect(Constants.GLB_TAG_DCM_PREFIX + item);
                    String dcmType = (String) dcmConfig.get("TYPE");
                    if (Utils.isDJNEWS_DCM(dcmType)) {
                        vis = true;
                        distrConfigType = Constants.DJNEWS_LINEHANDLER;
                    }

                    String location1 = (String) dcmConfig.get("LOCATION1");
                    String location2 = (String) dcmConfig.get("LOCATION2");

                    DefaultComboBoxModel cm = new DefaultComboBoxModel();
                    if (location1 != null && location1.trim().length() > 0) {
                        cm.addElement(location1);
                    }
                    if (location2 != null && location2.trim().length() > 0) {
                        cm.addElement(location2);
                    }
                    locationComboBox1.setModel(cm);
                    locationComboBox1.setSelectedItem(null);
                    locationComboBox2.setSelectedItem(null);
                    if (origDCMTag != null && origConfig != null
                            && item.equals(origDCMTag)) {
                        locationComboBox1.setSelectedItem((String) origHostConfig.get((String) origConfig.get("LOCATION1")));
                        locationComboBox2.removeAllItems();
                        String l2 = (String) origHostConfig.get((String) origConfig.get("LOCATION2"));
                        locationComboBox2.addItem(l2);
                        locationComboBox2.setSelectedItem(l2);
                    }


                }
            } catch (Exception e) {
            }

            boolean showFields = true;
            if (item == null) {
                showFields = false;
            }

            if (showFields) {
                cl.show(cardsPanel, "FIELDS_PANEL");
            } else {
                cl.show(cardsPanel, "SELECT_DCM");
            }

            updateProducts();
            //ftpContentPanel.setVisible(vis);
            if (vis) {
                int inx = jTabbedPane1.indexOfTab("Delivery Rules");
                if (inx == -1) {
                    jTabbedPane1.insertTab("Delivery Rules",
                            null, jPanel8, null, 1);
                }
            } else {
                int inx = jTabbedPane1.indexOfTab("Delivery Rules");
                if (inx != -1) {
                    jTabbedPane1.removeTabAt(inx);
                }
            }
            ftpTransportPanel.setVisible(vis);
            ftpTransportPanel.invalidate();
            jPanel21.invalidate();
            validate();
        }
    };
    private java.awt.event.ActionListener locationComboListener = new java.awt.event.ActionListener() {

        public void actionPerformed(java.awt.event.ActionEvent evt) {

            String other_location = "";

            int inx = locationComboBox1.getSelectedIndex();
            if (inx == 0) {
                other_location = (String) locationComboBox1.getItemAt(1);
            } else if (inx == 1) {
                other_location = (String) locationComboBox1.getItemAt(0);
            }


            locationComboBox2.removeAllItems();
            locationComboBox2.addItem(other_location);
            locationComboBox2.setSelectedItem(other_location);
        }
    };

    private int initNewDCMScreen() {

        java.util.Vector dcmList = null;

        /*
         * Retrieve List of DCM TAGS
         */
        try {

            dcmList = ConfigComm.getDCMList();

        } catch (Exception e) {
            StringBuffer errstr = new StringBuffer();
            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo()
                        == Constants.KEY_NOT_FOUND) {
                    errstr.append("Please define DCM(s) before adding ");
                    errstr.append("linehandlers.\n");
                } else {
                    errstr.append("Error in retrieving DCM list.\n");
                }
            }

            Log.getInstance().show_error(this, "Error",
                    errstr.toString(), e);
            return -1;
        }


        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DCM");


        int numDCMs = dcmList.size();

        dcmComboBox.addItem(blank);
        dcmComboBox.setSelectedItem(blank);

        for (int i = 0; i < numDCMs; i++) {
            dcmComboBox.addItem((String) dcmList.get(i));
        }


        dcmComboBox.addActionListener(dcmComboListener);


        transportPanel = new TransportConfigPanel(this, "Receiving host transport "
                + "protocol",
                transportList, null, null,
                null, null, true);

        transportBoxPanel.add(transportPanel);


        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);



        return 0;
    }

    java.util.HashMap _loadFullProductConfiguration(String prod_str,
            DistrProductTableModel model) {
        java.util.HashMap pmap = new java.util.HashMap(20);
        StringBuffer separator = new StringBuffer();

        separator.append(ConfigComm.CONF_US).append(ConfigComm.CONF_ETX);

        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(prod_str, separator.toString());

        while (tokenizer.hasMoreTokens()) {

            Object[] rowData = new Object[Constants.DistrProductColumnNames.length];

            rowData[0] = new String(tokenizer.nextToken());
            rowData[1] = new String(tokenizer.nextToken());
            rowData[2] = new Integer(Integer.parseInt(tokenizer.nextToken()));

            rowData[3] = new Boolean(false);
            rowData[4] = new Boolean(false);
            rowData[5] = new String(DistributorProductFlagOptions.getDerivedDataOption(0));

            rowData[7] = "Default";
            rowData[8] = "Default";
            rowData[9] = "NONE";
            rowData[10] = Boolean.FALSE;

            String nstr = tokenizer.nextToken();
            if (nstr.startsWith("Y") || nstr.startsWith("y")
                    || nstr.startsWith("T") || nstr.startsWith("t")) {
                if (nstr.equalsIgnoreCase("Y") || nstr.equalsIgnoreCase("true")) {
                    rowData[3] = new Boolean(true);
                }
            } else {
                try {
                    Long flags = Long.parseLong(nstr);
                    rowData[3] = new Boolean(DistributorProductFlagOptions.getFreewheel(flags));
                    rowData[4] = new Boolean(DistributorProductFlagOptions.getNewsplusOff(flags));
                    rowData[5] = new String(DistributorProductFlagOptions.getDerivedDataOption(flags));
                    rowData[10] = new Boolean(DistributorProductFlagOptions.getSigAbout(flags));
                    jLabel27.setVisible(false);
                    newsplusOffCheckBox.setVisible(false);
                } catch (NumberFormatException nfe) {
                }
            }

            rowData[6] = new String(tokenizer.nextToken());

            model.addRow(rowData);

            Object[] rowData1 = new Object[Constants.DistrProductColumnNames.length];
            rowData1[0] = new String((String) rowData[0]);
            rowData1[1] = new String((String) rowData[1]);
            rowData1[2] = new Integer(((Integer) rowData[2]).intValue());
            rowData1[3] = new Boolean(((Boolean) rowData[3]).booleanValue());
            rowData1[4] = new Boolean(((Boolean) rowData[4]).booleanValue());
            rowData1[5] = new String((String) rowData[5]);
            rowData1[6] = new String((String) rowData[5]);
            rowData1[7] = new String((String) rowData[5]);
            rowData1[8] = new String((String) rowData[5]);
            rowData1[10] = new Boolean(((Boolean) rowData[10]).booleanValue());

            pmap.put((String) rowData[0], rowData1);

        }

        return pmap;
    }

    java.util.HashMap loadFullProductConfiguration(String prod_str,
            DistrProductTableModel model) {

        if ((prod_str.indexOf("<") < 0)
                || (prod_str.indexOf("/>") < 0)) {
            return _loadFullProductConfiguration(prod_str, model);
        }

        java.util.HashMap pmap = new java.util.HashMap(20);
        StringBuffer separator = new StringBuffer();
        StringBuffer rowseparator = new StringBuffer("<");

        separator.append(ConfigComm.CONF_US).append(ConfigComm.CONF_ETX);

        java.util.StringTokenizer rowtokenizer = new java.util.StringTokenizer(prod_str, rowseparator.toString());

        System.out.println("PROD STR" + prod_str);

        while (rowtokenizer.hasMoreTokens()) {

            Object[] rowData = new Object[Constants.DistrProductColumnNames.length];


            String rowString = rowtokenizer.nextToken();
            System.out.println("ROW STR" + rowString);
            int inx = rowString.indexOf("/>");
            rowString = rowString.substring(0, inx);

            java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(rowString, separator.toString());

            rowData[0] = new String(tokenizer.nextToken());
            rowData[1] = new String(tokenizer.nextToken());
            rowData[2] = new Integer(Integer.parseInt(tokenizer.nextToken()));

            rowData[3] = new Boolean(false);
            rowData[4] = new Boolean(false);
            rowData[5] = new String(DistributorProductFlagOptions.getDerivedDataOption(0));

            String nstr = tokenizer.nextToken();
            if (nstr.startsWith("Y") || nstr.startsWith("y")
                    || nstr.startsWith("T") || nstr.startsWith("t")) {
                if (nstr.equalsIgnoreCase("Y") || nstr.equalsIgnoreCase("true")) {
                    rowData[3] = new Boolean(true);
                }
            } else {
                try {
                    Long flags = Long.parseLong(nstr);
                    rowData[3] = new Boolean(DistributorProductFlagOptions.getFreewheel(flags));
                    rowData[4] = new Boolean(DistributorProductFlagOptions.getNewsplusOff(flags));
                    rowData[5] = new String(DistributorProductFlagOptions.getDerivedDataOption(flags));
                    rowData[10] = new Boolean(DistributorProductFlagOptions.getSigAbout(flags));
                    jLabel27.setVisible(false);
                    newsplusOffCheckBox.setVisible(false);
                } catch (NumberFormatException nfe) {
                }
            }

            rowData[6] = new String(tokenizer.nextToken());
            if (tokenizer.hasMoreTokens()) {
                String dict = tokenizer.nextToken();
                StringBuffer sb = new StringBuffer((String) rowData[5]);
                sb.append("|").append(dict);
                rowData[5] = sb.toString();
            }
            if (tokenizer.hasMoreTokens()) {
                rowData[7] = new String(tokenizer.nextToken());
            }
            if (tokenizer.hasMoreTokens()) {
                rowData[8] = new String(tokenizer.nextToken());
            }
            if (tokenizer.hasMoreTokens()) {
                rowData[9] = new String(tokenizer.nextToken());
            }
            model.addRow(rowData);

            Object[] rowData1 = new Object[11];
            rowData1[0] = new String((String) rowData[0]);
            rowData1[1] = new String((String) rowData[1]);
            rowData1[2] = new Integer(((Integer) rowData[2]).intValue());
            rowData1[3] = new Boolean(((Boolean) rowData[3]).booleanValue());
            rowData1[4] = new Boolean(((Boolean) rowData[4]).booleanValue());
            rowData1[5] = new String((String) rowData[5]);

            rowData1[10] = new Boolean(((Boolean) rowData[10]).booleanValue());
            pmap.put((String) rowData[0], rowData1);

        }

        return pmap;
    }

    java.util.HashMap loadProductConfiguration(String prod_str,
            DistrProductTableModel model) {
        java.util.HashMap pmap = new java.util.HashMap(20);
        StringBuffer separator = new StringBuffer();

        separator.append(ConfigComm.CONF_US).append(ConfigComm.CONF_ETX);

        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(prod_str, separator.toString());

        while (tokenizer.hasMoreTokens()) {

            Object[] rowData = new Object[1];

            rowData[0] = new String(tokenizer.nextToken());

            model.addRow(rowData);

            Object[] rowData1 = new Object[1];
            rowData1[0] = new String((String) rowData[0]);

            pmap.put((String) rowData[0], rowData1);

        }

        return pmap;
    }

    void loadShared(java.util.HashMap map) {

        descTextField.setText((String) map.get("DESCRIPTION"));

        String autoFailStr = (String) map.get("AUTO_FAILOVER");
        boolean autoFail = true;
        if (autoFailStr != null) {
            autoFail = Boolean.valueOf(autoFailStr).booleanValue();
        }
        autoFailoverCheckBox.setSelected(autoFail);

        long options_flag = 0;
        codeTextField.setText("");
        String flagsStr = (String) map.get("OPTIONS_FLAG");
        if (flagsStr != null) {
            options_flag = Long.parseLong(flagsStr, 16);
            String codes = (String) map.get("CODES_STR");
            if (codes != null) {
                codeTextField.setText(codes);
            }


        }

        if ((options_flag & CODES_ON) > 0) {
            codeCheckBox.setSelected(true);
        } else {
            codeCheckBox.setSelected(false);
        }

        if ((options_flag & SUMMARY_ON) > 0) {
            summaryCheckBox.setSelected(true);
        } else {
            summaryCheckBox.setSelected(false);
        }
        
        codeTextField.setEnabled(codeCheckBox.isSelected());
        jLabel25.setEnabled(codeCheckBox.isSelected());



        String hiresTSStr = (String) map.get("HIGH_RESOLUTION_TIMESTAMPS");
        boolean hiresTS = false;
        if (hiresTSStr != null) {
            hiresTS = Boolean.valueOf(hiresTSStr).booleanValue();
        }
        highResolutionTimestampCheckBox.setSelected(hiresTS);

        String newsplusOffStr = (String) map.get("NEWSPLUS_OFF");
        boolean newsplusOff = false;
        if (newsplusOffStr != null) {
            newsplusOff = Boolean.valueOf(newsplusOffStr).booleanValue();
        }
        newsplusOffCheckBox.setSelected(newsplusOff);

        String rtkaStr = (String) map.get("REUTERS_KEEPALIVE_ACK");
        boolean rtka = false;
        if (rtkaStr != null) {
            rtka = Boolean.valueOf(rtkaStr).booleanValue();
        }
        reutersKeepAliveAckCheckBox.setSelected(rtka);

        String keepAliveStr1 = (String) map.get("KEEPALIVE_1");
        String keepAliveStr2 = (String) map.get("KEEPALIVE_2");

        if (!keepAliveStr1.equals("-")) {
            keepAliveTextField1.setText(keepAliveStr1);
        }
        if (!keepAliveStr2.equals("-")) {
            keepAliveTextField2.setText(keepAliveStr2);
        }

        statisticsComboBox1.setSelectedItem((String) map.get("STATISTICS_1"));
        statisticsComboBox2.setSelectedItem((String) map.get("STATISTICS_2"));

        try {

            java.util.HashMap hostmap = ConfigComm.getHashMapDirect((String) map.get("TAG"));
            String location1 = (String) hostmap.get("LOCATION1");
            String location2 = (String) hostmap.get("LOCATION2");
            String primary_location = (String) map.get("HOME_LOCATION");


            DefaultComboBoxModel cm = new DefaultComboBoxModel();
            if (location1 != null && location1.trim().length() > 0) {
                cm.addElement(location1);
            }
            if (location2 != null && location2.trim().length() > 0) {
                cm.addElement(location2);
            }
            locationComboBox1.setModel(cm);
            locationComboBox1.setSelectedItem(null);
            locationComboBox2.setSelectedItem(null);



            if (primary_location != null) {
                if (primary_location.equals("1")) {
                    locationComboBox1.setSelectedItem(location1);
                    locationComboBox2.removeAllItems();
                    locationComboBox2.addItem(location2);
                    locationComboBox2.setSelectedItem(location2);
                } else {
                    locationComboBox1.setSelectedItem(location2);
                    locationComboBox2.removeAllItems();
                    locationComboBox2.addItem(location1);
                    locationComboBox2.setSelectedItem(location1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }


    }

    private int loadConfig(String distrTag, boolean clone)
            throws Exception {
        java.util.HashMap map = null;



        try {
            map =
                    ConfigComm.getHashMapDirect(Constants.GLB_TAG_DISTR_PREFIX + distrTag);

        } catch (DBException dbe) {
            pack();
            show();
            if (!clone && (dbe.getErrorNo() == Constants.KEY_NOT_FOUND)) {
                int opt = Log.getInstance().show_confirm(this,
                        "Select on option",
                        distrTag
                        + ": Distributor configuration does not exist."
                        + " Create?");
                if (opt == javax.swing.JOptionPane.YES_OPTION) {
                    if (distrTag != null) {
                        idTextField.setText(distrTag);
                    }
                    return initNewDCMScreen();
                }
            }
            return -1;
        } catch (Exception e) {
            Log.getInstance().show_error(this, "Error",
                    "Error in retrieving distributor: "
                    + distrTag + " configuration", e);

            return -1;
        }


        String platform = (String) map.get("TAG");
        String config_type = (String) map.get("CONFIGURATION_TYPE");

        if (platform.equals(Constants.GLB_TAG_DSP)) {

            if ((config_type == null)
                    || config_type.equals(Constants.BROADCASTER_TEMPLATE)) {

                distrConfigType = Constants.DSP_BROADCASTER;
                return initDSPShortCutScreen(map, distrTag, clone);

            } else if (config_type.equals(Constants.FULL_CONFIGURATION)) {

                distrConfigType = Constants.DSP_LINEHANDLER;
                return initDSPScreen(map, distrTag, clone);

            } else {
            }


        } else if (platform.startsWith(Constants.GLB_TAG_DCM_PREFIX)) {

            
            
            
            
            

            if ((config_type != null) && config_type.startsWith("DJN")) {
                distrConfigType = Constants.DJNEWS_LINEHANDLER;
            } else {
                distrConfigType = Constants.DCM_LINEHANDLER;
            }
            return initDCMScreen(map, distrTag, clone);

        } else {
        }






        return -1;


    }

    private int initDSPShortCutScreen(java.util.HashMap map, String distrTag,
            boolean clone) {
        java.util.Vector dcmList = null;

        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DSP");

        recvDCMPanel = new ReceivingDCMPanel();
        transportBoxPanel.add(recvDCMPanel);


        recvDCMPanel.transportLabel.setText(Constants.GLB_IDS_TRANSPORT);


        /*
         * Retrieve List of DCM TAGS
         */
        try {

            dcmList = ConfigComm.getDCMList();

        } catch (Exception e) {
            StringBuffer errstr = new StringBuffer();
            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo()
                        == Constants.KEY_NOT_FOUND) {
                    errstr.append("Please define receving DCM before adding ");
                    errstr.append("linehandler.\n");
                } else {
                    errstr.append("Error in retrieving DCM list.\n");
                }
            }

            Log.getInstance().show_error(this, "Error",
                    errstr.toString(), e);
            return -1;
        }

        int numDCMs = dcmList.size();

        recvDCMPanel.dcmComboBox.addItem(blank);
        recvDCMPanel.dcmComboBox.setSelectedItem(blank);

        for (int i = 0; i < numDCMs; i++) {
            recvDCMPanel.dcmComboBox.addItem((String) dcmList.get(i));
        }


        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);


        DistrProductTableModel m1 = (DistrProductTableModel) productTable1.getModel();
        DistrProductTableModel m2 = (DistrProductTableModel) productTable2.getModel();
        m1.setProductsOnlyView(true);
        m2.setProductsOnlyView(true);



        origConfig = new java.util.HashMap(map);

        if (recvDCMPanel.transportLabel.getText().startsWith("TCP")) {
            String transport = (String) map.get("TRANSPORT");

            String dcm = transport.trim();

            for (int i = 0; i < recvDCMPanel.dcmComboBox.getItemCount(); i++) {
                if (dcm.equals((String) recvDCMPanel.dcmComboBox.getItemAt(i))) {
                    recvDCMPanel.dcmComboBox.setSelectedIndex(i);
                    break;
                }
            }
        }

        String s = (String) map.get("TAG");

        //dspID = "DSP";
        try {
            origHostConfig = ConfigComm.getHashMapDirect(Constants.GLB_TAG_DSP);
        } catch (Exception e) {
        }

        if (!clone) {
            ckptPort = (String) map.get("CHECKPOINT");
        }

        loadShared(map);

        String prod_str = (String) map.get("PRODUCTS_1");
        if (prod_str != null) {
            productMap1 = loadProductConfiguration(prod_str, m1);
        }

        prod_str = (String) map.get("PRODUCTS_2");
        if (prod_str != null) {
            productMap2 = loadProductConfiguration(prod_str, m2);
        }



        if (clone == false) {
            //confDelete.setEnabled(true);
            jButton9.setEnabled(true);
            existsInDatabase = true;
        }


        return 0;
    }

    private int initDCMScreen(java.util.HashMap map, String distrTag, boolean clone) {
        java.util.Vector dcmList = null;


        /*
         * Retrieve List of DCM TAGS
         */
        try {

            dcmList = ConfigComm.getDCMList();

        } catch (Exception e) {
            StringBuffer errstr = new StringBuffer();
            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo()
                        == Constants.KEY_NOT_FOUND) {
                    errstr.append("Please define receving DCM before adding ");
                    errstr.append("linehandler.\n");
                } else {
                    errstr.append("Error in retrieving DCM list.\n");
                }
            }

            Log.getInstance().show_error(this, "Error",
                    errstr.toString(), e);
            return -1;
        }


        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DCM");


        int numDCMs = dcmList.size();

        dcmComboBox.addItem(blank);
        dcmComboBox.setSelectedItem(blank);

        for (int i = 0; i < numDCMs; i++) {
            dcmComboBox.addItem((String) dcmList.get(i));
        }

        dcmComboBox.addActionListener(dcmComboListener);


        transportPanel = new TransportConfigPanel(this, "Receiving host transport "
                + "protocol", transportList,
                null, null, null, null, true);

        transportBoxPanel.add(transportPanel);


        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);


        DistrProductTableModel m1 = (DistrProductTableModel) productTable1.getModel();
        DistrProductTableModel m2 = (DistrProductTableModel) productTable2.getModel();


        origConfig = new java.util.HashMap(map);


        String s = (String) map.get("TAG");

        try {
            origHostConfig = ConfigComm.getHashMap(s);
        } catch (Exception e) {
        }

        s = s.substring(Constants.GLB_TAG_DCM_PREFIX.length());



        dcmComboBox.setSelectedItem(s);
        origDCMTag = new String(s);

        String transport1 = (String) map.get("TRANSPORT_1");
        String transport2 = (String) map.get("TRANSPORT_2");
        String transport = (String) map.get("TRANSPORT");



        if (transport1 == null) {
            transportPanel.setTransportConfig(distrTag, transport, transport, true);
        } else {
            transportPanel.setTransportConfig(distrTag, transport1, transport2, true);
        }



        if (!clone) {
            ckptPort = (String) map.get("CHECKPOINT");
        }

        loadShared(map);

        String prod_str = (String) map.get("PRODUCTS_1");
        if (prod_str != null) {
            productMap1 = loadFullProductConfiguration(prod_str, m1);
        }

        prod_str = (String) map.get("PRODUCTS_2");
        if (prod_str != null) {
            productMap2 = loadFullProductConfiguration(prod_str, m2);
        }



        if (clone == false) {
            //confDelete.setEnabled(true);
            jButton9.setEnabled(true);
            existsInDatabase = true;
        }

        if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {
            String lh = (String) map.get("DJNEWS_LWC_HEADER");

            if (lh == null) {
                lh = Boolean.TRUE.toString();
            }


            transportPanel.lwcHeaderCheckBox.setSelected(Boolean.valueOf(lh).booleanValue());

            sendChangesCheckBox.setSelected(Boolean.valueOf((String) map.get("DJNEWS_SEND_CHANGES")).booleanValue());

            contentTypesComboBox.setSelectedItem((String) Constants.label2KeyMap.get((String) map.get("DJNEWS_CONTENT_TYPE")));

            delayTextField.setText((String) map.get("DJNEWS_TIMER"));
            
            deliveryTypesComboBox.setSelectedItem((String) Constants.label2KeyMap.get((String) map.get("DJNEWS_DELIVERY_TYPE")));

            String formatType = (String) Constants.label2KeyMap.get((String) map.get("DJNEWS_FORMAT_TYPE"));
            conversionTypesComboBox.setSelectedItem(formatType);

            String deliveryMethod = (String) Constants.label2KeyMap.get((String) map.get("DJNEWS_DELIVERY_METHOD"));

            deliveryMethodsComboBox.setSelectedItem(deliveryMethod);

            takeComboBox.setSelectedItem((String) Constants.label2KeyMap.get((String) map.get("DJNEWS_TAKE_TYPE")));

            filenameGenerationComboBox.setSelectedItem((String) Constants.label2KeyMap.get((String) map.get("DJNEWS_FILE_GENERATION_TYPE")));

            extentionTextField.setText((String) map.get("DJNEWS_FILE_EXTENTION"));

            if (formatType.startsWith("XML")
                    || formatType.startsWith("NEWSML")
                    || formatType.startsWith("NewsML")
                    || formatType.startsWith("DISTDOC")) {
                encodingTypesComboBox.setSelectedItem((String) map.get("DJNEWS_FORMAT_ENCODING"));
            }



            String mixed_schema = (String) map.get("DJNEWS_MIXEDCASE_SCHEMA");
            if (mixed_schema == null) {
                mixedSchemaCheckBox.setSelected(true);
            } else {
                mixedSchemaCheckBox.setSelected(Boolean.valueOf(mixed_schema).booleanValue());
            }


            setupTable(origConfig, null);




        }

        return 0;
    }

    private int initDSPScreen(java.util.HashMap map, String distrTag, boolean clone) {



        java.awt.CardLayout cardLayout = (java.awt.CardLayout) platformPanel.getLayout();


        cardLayout.show(platformPanel, "DSP");




        transportPanel = new TransportConfigPanel(this, "Receiving host "
                + "transport protocol",
                transportList, null, null,
                null, null, true);

        transportBoxPanel.add(transportPanel);


        productTable1 = createProductTable();
        javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(productTable1);
        productPanel1.add(jScrollPane, java.awt.BorderLayout.CENTER);


        productTable2 = createProductTable();
        jScrollPane = new javax.swing.JScrollPane(productTable2);
        productPanel2.add(jScrollPane, java.awt.BorderLayout.CENTER);


        DistrProductTableModel m1 = (DistrProductTableModel) productTable1.getModel();
        DistrProductTableModel m2 = (DistrProductTableModel) productTable2.getModel();



        origConfig = new java.util.HashMap(map);


        String s = (String) map.get("TAG");


        try {
            origHostConfig = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);
        } catch (Exception e) {
        }

        dcmComboBox.setSelectedItem(s);
        origDCMTag = new String(s);

        String transport1 = (String) map.get("TRANSPORT_1");
        String transport2 = (String) map.get("TRANSPORT_2");
        String transport = (String) map.get("TRANSPORT");

        if (transport1 == null) {
            transportPanel.setTransportConfig(distrTag, transport, transport, true);
        } else {
            transportPanel.setTransportConfig(distrTag, transport1, transport2, true);
        }



        if (!clone) {
            ckptPort = (String) map.get("CHECKPOINT");
        }

        loadShared(map);

        String prod_str = (String) map.get("PRODUCTS_1");
        if (prod_str != null) {
            productMap1 = loadFullProductConfiguration(prod_str, m1);
        }

        prod_str = (String) map.get("PRODUCTS_2");
        if (prod_str != null) {
            productMap2 = loadFullProductConfiguration(prod_str, m2);
        }



        if (clone == false) {
            //confDelete.setEnabled(true);
            jButton9.setEnabled(true);
            existsInDatabase = true;
        }


        return 0;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the FormEditor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        idTextField = new javax.swing.JTextField();
        descTextField = new javax.swing.JTextField();
        platformPanel = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        dcmComboBox = new javax.swing.JComboBox();
        jPanel16 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        autoFailoverCheckBox = new javax.swing.JCheckBox();
        jLabel24 = new javax.swing.JLabel();
        highResolutionTimestampCheckBox = new javax.swing.JCheckBox();
        jLabel27 = new javax.swing.JLabel();
        newsplusOffCheckBox = new javax.swing.JCheckBox();
        jLabel28 = new javax.swing.JLabel();
        reutersKeepAliveAckCheckBox = new javax.swing.JCheckBox();
        jPanel10 = new javax.swing.JPanel();
        codeCheckBox = new javax.swing.JCheckBox();
        jLabel25 = new javax.swing.JLabel();
        codeTextField = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        cardsPanel = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel21 = new javax.swing.JPanel();
        productPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        keepAliveTextField1 = new ids2ui.IntTextField();
        jPanel5 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        locationComboBox1 = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        statisticsComboBox1 = new javax.swing.JComboBox(statisticsList);
        productPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        keepAliveTextField2 = new ids2ui.IntTextField();
        jPanel14 = new javax.swing.JPanel();
        jButton12 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        statisticsComboBox2 = new javax.swing.JComboBox(statisticsList);
        locationComboBox2 = new javax.swing.JComboBox();
        jPanel11 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        deliveryTypesComboBox = new javax.swing.JComboBox();
        delayTextField = new javax.swing.JTextField();
        timerLabel = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        contentTypesComboBox = new javax.swing.JComboBox();
        sendChangesCheckBox = new javax.swing.JCheckBox();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        takeComboBox = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        filenameGenerationComboBox = new javax.swing.JComboBox();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        conversionTypesComboBox = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        encodingTypesComboBox = new javax.swing.JComboBox();
        jLabel18 = new javax.swing.JLabel();
        extentionTextField = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        mixedSchemaCheckBox = new javax.swing.JCheckBox();
        jPanel22 = new javax.swing.JPanel();
        transportBoxPanel = new javax.swing.JPanel();
        ftpTransportPanel = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        deliveryMethodsComboBox = new javax.swing.JComboBox();
        ftpCardsPanel = new javax.swing.JPanel();
        paramsPanel = new javax.swing.JPanel();
        ftpParamsPanel = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        statusPanel1 = new ids2ui.StatusPanel();
        
        summaryCheckBox = new javax.swing.JCheckBox();        
        summaryLabel = new javax.swing.JLabel();
        
        
        getContentPane().setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints1;
        addWindowListener(new java.awt.event.WindowAdapter() {

            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jPanel1.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints2;
        jPanel1.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 10, 2, 10)));

        jLabel1.setText("Distributor ID");
        jLabel1.setLabelFor(idTextField);

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 0;
        gridBagConstraints2.insets = new java.awt.Insets(0, 5, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel1, gridBagConstraints2);

        jLabel2.setText("Description");
        jLabel2.setLabelFor(descTextField);

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.insets = new java.awt.Insets(5, 5, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel2, gridBagConstraints2);

        idTextField.setColumns(5);

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 1;
        gridBagConstraints2.gridy = 0;
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets(0, 0, 5, 25);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints2.weightx = 0.25;
        jPanel1.add(idTextField, gridBagConstraints2);


        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 1;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.gridwidth = 3;
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets(5, 0, 5, 10);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints2.weightx = 1.0;
        jPanel1.add(descTextField, gridBagConstraints2);

        platformPanel.setLayout(new java.awt.CardLayout());


        jLabel11.setText("Sending DCM");
        jLabel11.setLabelFor(dcmComboBox);

        jPanel15.add(jLabel11);

        dcmComboBox.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dcmComboChanged(evt);
            }
        });

        jPanel15.add(dcmComboBox);

        platformPanel.add(jPanel15, "DCM");

        jPanel16.setLayout(new java.awt.FlowLayout(1, 10, 5));

        jLabel8.setText("Sending host->");

        jPanel16.add(jLabel8);

        jLabel7.setText("DSP");
        jLabel7.setLabelFor(dcmComboBox);

        jPanel16.add(jLabel7);

        platformPanel.add(jPanel16, "DSP");

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridwidth = 2;
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.weightx = 0.75;
        jPanel1.add(platformPanel, gridBagConstraints2);

        jLabel23.setText("Automatic failover");

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(5, 5, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel23, gridBagConstraints2);


        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 1;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(autoFailoverCheckBox, gridBagConstraints2);

        jLabel24.setText("Use High Resolution Timestamps");

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 2;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 5, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel24, gridBagConstraints2);


        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 3;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(highResolutionTimestampCheckBox, gridBagConstraints2);

        jLabel27.setText("Block Newsplus content");

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 4;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 5, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel27, gridBagConstraints2);


        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 5;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(newsplusOffCheckBox, gridBagConstraints2);

        jLabel28.setText("Acknowledge Reuters KeepAlive");

        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 6;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 25, 5, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jLabel28, gridBagConstraints2);


        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 7;
        gridBagConstraints2.gridy = 2;
        gridBagConstraints2.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(reutersKeepAliveAckCheckBox, gridBagConstraints2);


        jPanel10.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints17;

        codeCheckBox.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeCheckBoxActionPerformed(evt);
            }
        });

        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 1;
        gridBagConstraints17.gridy = 0;
        gridBagConstraints17.insets = new java.awt.Insets(0, 5, 0, 15);
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        jPanel10.add(codeCheckBox, gridBagConstraints17);

        jLabel25.setText("Enter codes");

        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 2;
        gridBagConstraints17.gridy = 0;
        gridBagConstraints17.insets = new java.awt.Insets(0, 5, 0, 0);
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        jPanel10.add(jLabel25, gridBagConstraints17);


        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 3;
        gridBagConstraints17.gridy = 0;
        gridBagConstraints17.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints17.weightx = 0.2;
        jPanel10.add(codeTextField, gridBagConstraints17);

        jLabel26.setText("Add F/ codes");

        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 0;
        gridBagConstraints17.gridy = 0;
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        jPanel10.add(jLabel26, gridBagConstraints17);

        summaryLabel.setText("Summary");
        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 0;
        gridBagConstraints17.gridy = 1;
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        jPanel10.add(summaryLabel, gridBagConstraints17);
        
        gridBagConstraints17 = new java.awt.GridBagConstraints();
        gridBagConstraints17.gridx = 1;
        gridBagConstraints17.gridy = 1;
        gridBagConstraints17.insets = new java.awt.Insets(0, 5, 0, 15);
        gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
        jPanel10.add(summaryCheckBox, gridBagConstraints17);
        
        gridBagConstraints2 = new java.awt.GridBagConstraints();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 3;
        gridBagConstraints2.gridwidth = 4;
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets(5, 5, 5, 5);
        gridBagConstraints2.weightx = 1.0;
        jPanel1.add(jPanel10, gridBagConstraints2);


        gridBagConstraints1 = new java.awt.GridBagConstraints();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 0;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.weightx = 1.0;
        gridBagConstraints1.weighty = 0.1;
        getContentPane().add(jPanel1, gridBagConstraints1);

        cardsPanel.setLayout(new java.awt.CardLayout());
        cardsPanel.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));

        jPanel19.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints3;


        jPanel21.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints4;
        jPanel21.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)), null));

        productPanel1.setLayout(new java.awt.BorderLayout());
        productPanel1.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)),
                new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder(
                new javax.swing.border.EtchedBorder(), "Home configuration", 2, 2),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(1, 1, 1, 1)))));

        jPanel4.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints5;

        jPanel7.setLayout(new java.awt.FlowLayout(0, 5, 5));

        jLabel3.setText("Keep alive");
        jLabel3.setLabelFor(keepAliveTextField1);

        jPanel7.add(jLabel3);

        keepAliveTextField1.setColumns(3);

        jPanel7.add(keepAliveTextField1);

        gridBagConstraints5 = new java.awt.GridBagConstraints();
        gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints5.weightx = 0.5;
        jPanel4.add(jPanel7, gridBagConstraints5);

        jPanel5.setLayout(new java.awt.FlowLayout(2, 5, 5));

        jButton11.setMargin(new java.awt.Insets(2, 7, 2, 7));
        jButton11.setText("Select all");
        jButton11.setActionCommand("Select all 1");
        jButton11.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectionHandler(evt);
            }
        });

        jPanel5.add(jButton11);

        gridBagConstraints5 = new java.awt.GridBagConstraints();
        gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints5.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints5.weightx = 0.5;
        jPanel4.add(jPanel5, gridBagConstraints5);

        productPanel1.add(jPanel4, java.awt.BorderLayout.SOUTH);

        jPanel2.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints6;
        jPanel2.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 10, 2)));

        jLabel21.setText("Location");

        gridBagConstraints6 = new java.awt.GridBagConstraints();
        gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints6.insets = new java.awt.Insets(0, 0, 10, 0);
        gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
        jPanel2.add(jLabel21, gridBagConstraints6);


        gridBagConstraints6 = new java.awt.GridBagConstraints();
        gridBagConstraints6.insets = new java.awt.Insets(0, 3, 10, 0);
        gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints6.weightx = 0.5;
        jPanel2.add(locationComboBox1, gridBagConstraints6);

        jLabel5.setText("Statistics");
        jLabel5.setLabelFor(statisticsComboBox1);

        gridBagConstraints6 = new java.awt.GridBagConstraints();
        gridBagConstraints6.gridx = 0;
        gridBagConstraints6.gridy = 1;
        gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
        jPanel2.add(jLabel5, gridBagConstraints6);


        gridBagConstraints6 = new java.awt.GridBagConstraints();
        gridBagConstraints6.gridx = 1;
        gridBagConstraints6.gridy = 1;
        gridBagConstraints6.insets = new java.awt.Insets(0, 3, 0, 0);
        gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints6.weightx = 0.5;
        jPanel2.add(statisticsComboBox1, gridBagConstraints6);

        productPanel1.add(jPanel2, java.awt.BorderLayout.NORTH);

        gridBagConstraints4 = new java.awt.GridBagConstraints();
        gridBagConstraints4.gridx = 0;
        gridBagConstraints4.gridy = 0;
        gridBagConstraints4.gridheight = 2;
        gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints4.weightx = 0.5;
        gridBagConstraints4.weighty = 0.75;
        jPanel21.add(productPanel1, gridBagConstraints4);

        productPanel2.setLayout(new java.awt.BorderLayout());
        productPanel2.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)),
                new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder(
                new javax.swing.border.EtchedBorder(), "Away configuration", 2, 2),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(3, 3, 3, 3)))));

        jPanel6.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints7;

        jPanel13.setLayout(new java.awt.FlowLayout(0, 5, 5));

        jLabel4.setText("Keep alive");
        jLabel4.setLabelFor(keepAliveTextField2);

        jPanel13.add(jLabel4);

        keepAliveTextField2.setColumns(3);

        jPanel13.add(keepAliveTextField2);

        gridBagConstraints7 = new java.awt.GridBagConstraints();
        gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints7.weightx = 0.5;
        jPanel6.add(jPanel13, gridBagConstraints7);

        jPanel14.setLayout(new java.awt.FlowLayout(2, 5, 5));

        jButton12.setMargin(new java.awt.Insets(2, 7, 2, 7));
        jButton12.setText("Select all");
        jButton12.setActionCommand("Select all 2");
        jButton12.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productSelectionHandler(evt);
            }
        });

        jPanel14.add(jButton12);

        gridBagConstraints7 = new java.awt.GridBagConstraints();
        gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints7.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints7.weightx = 0.5;
        jPanel6.add(jPanel14, gridBagConstraints7);

        productPanel2.add(jPanel6, java.awt.BorderLayout.SOUTH);

        jPanel3.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints8;
        jPanel3.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 10, 2)));

        jLabel20.setText("Location");

        gridBagConstraints8 = new java.awt.GridBagConstraints();
        gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints8.insets = new java.awt.Insets(0, 0, 10, 0);
        gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
        jPanel3.add(jLabel20, gridBagConstraints8);

        jLabel6.setText("Statistics");
        jLabel6.setLabelFor(statisticsComboBox2);

        gridBagConstraints8 = new java.awt.GridBagConstraints();
        gridBagConstraints8.gridx = 0;
        gridBagConstraints8.gridy = 1;
        gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
        jPanel3.add(jLabel6, gridBagConstraints8);


        gridBagConstraints8 = new java.awt.GridBagConstraints();
        gridBagConstraints8.gridx = 1;
        gridBagConstraints8.gridy = 1;
        gridBagConstraints8.insets = new java.awt.Insets(0, 3, 0, 0);
        gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints8.weightx = 0.5;
        jPanel3.add(statisticsComboBox2, gridBagConstraints8);

        locationComboBox2.setEnabled(false);

        gridBagConstraints8 = new java.awt.GridBagConstraints();
        gridBagConstraints8.insets = new java.awt.Insets(0, 3, 10, 0);
        gridBagConstraints8.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints8.weightx = 0.5;
        jPanel3.add(locationComboBox2, gridBagConstraints8);

        productPanel2.add(jPanel3, java.awt.BorderLayout.NORTH);

        gridBagConstraints4 = new java.awt.GridBagConstraints();
        gridBagConstraints4.gridx = 2;
        gridBagConstraints4.gridy = 0;
        gridBagConstraints4.gridheight = 2;
        gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints4.weightx = 0.5;
        gridBagConstraints4.weighty = 0.75;
        jPanel21.add(productPanel2, gridBagConstraints4);


        jButton7.setToolTipText("Copy DC-II product configuration to DC-I");
        jButton7.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButton7.setText("<<<");
        jButton7.setActionCommand("Copy2-1");
        jButton7.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productActionHandler(evt);
            }
        });

        jPanel11.add(jButton7);

        gridBagConstraints4 = new java.awt.GridBagConstraints();
        gridBagConstraints4.gridx = 1;
        gridBagConstraints4.gridy = 1;
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints4.weighty = 0.33;
        jPanel21.add(jPanel11, gridBagConstraints4);

        jPanel9.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints9;
        jPanel9.setBorder(new javax.swing.border.CompoundBorder(null,
                new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder(
                new javax.swing.border.EtchedBorder(), "Product options", 2, 2),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)))));

        jButton1.setToolTipText("Add a new product");
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productActionHandler(evt);
            }
        });

        gridBagConstraints9 = new java.awt.GridBagConstraints();
        gridBagConstraints9.gridx = 0;
        gridBagConstraints9.gridy = 0;
        gridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints9.insets = new java.awt.Insets(2, 2, 2, 5);
        jPanel9.add(jButton1, gridBagConstraints9);

        jButton2.setToolTipText("Modify selected product");
        jButton2.setText("Modify");
        jButton2.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productActionHandler(evt);
            }
        });

        gridBagConstraints9 = new java.awt.GridBagConstraints();
        gridBagConstraints9.gridx = 1;
        gridBagConstraints9.gridy = 0;
        gridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints9.insets = new java.awt.Insets(2, 2, 2, 5);
        jPanel9.add(jButton2, gridBagConstraints9);

        jButton3.setToolTipText("Delete selected product");
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productActionHandler(evt);
            }
        });

        gridBagConstraints9 = new java.awt.GridBagConstraints();
        gridBagConstraints9.gridx = 2;
        gridBagConstraints9.gridy = 0;
        gridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints9.insets = new java.awt.Insets(2, 2, 2, 2);
        jPanel9.add(jButton3, gridBagConstraints9);

        gridBagConstraints4 = new java.awt.GridBagConstraints();
        gridBagConstraints4.gridx = 0;
        gridBagConstraints4.gridy = 2;
        gridBagConstraints4.gridwidth = 3;
        gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
        jPanel21.add(jPanel9, gridBagConstraints4);


        jButton6.setToolTipText("Copy DC-I product configuration to DC-II");
        jButton6.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButton6.setText(">>>");
        jButton6.setActionCommand("Copy1-2");
        jButton6.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productActionHandler(evt);
            }
        });

        jPanel17.add(jButton6);

        gridBagConstraints4 = new java.awt.GridBagConstraints();
        gridBagConstraints4.gridx = 1;
        gridBagConstraints4.gridy = 0;
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.SOUTH;
        gridBagConstraints4.weighty = 0.33;
        jPanel21.add(jPanel17, gridBagConstraints4);

        jTabbedPane1.addTab("Products", jPanel21);

        jPanel8.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints10;
        jPanel8.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 1;
        gridBagConstraints10.gridy = 0;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(deliveryTypesComboBox, gridBagConstraints10);

        delayTextField.setToolTipText("In seconds");
        delayTextField.setColumns(5);
        delayTextField.setMinimumSize(new java.awt.Dimension(50, 21));
        delayTextField.setText("0");//default chain timer set to 0
        
        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 3;
        gridBagConstraints10.gridy = 0;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(delayTextField, gridBagConstraints10);

        timerLabel.setToolTipText("In seconds");
        timerLabel.setText("Chain timer (sec.)");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 2;
        gridBagConstraints10.gridy = 0;
        gridBagConstraints10.insets = new java.awt.Insets(0, 10, 0, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.4;
        jPanel8.add(timerLabel, gridBagConstraints10);

        jLabel12.setText("Content");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 2;
        gridBagConstraints10.gridy = 1;
        gridBagConstraints10.insets = new java.awt.Insets(0, 10, 0, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel12, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 3;
        gridBagConstraints10.gridy = 1;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(contentTypesComboBox, gridBagConstraints10);

        sendChangesCheckBox.setSelected(true);

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 3;
        gridBagConstraints10.gridy = 2;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(sendChangesCheckBox, gridBagConstraints10);

        jLabel14.setText("Delivery type");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 0;
        gridBagConstraints10.gridy = 0;
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel14, gridBagConstraints10);

        jLabel13.setText("Take type");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 0;
        gridBagConstraints10.gridy = 2;
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel13, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 1;
        gridBagConstraints10.gridy = 2;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(takeComboBox, gridBagConstraints10);

        jLabel15.setText("Filename generation");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 0;
        gridBagConstraints10.gridy = 1;
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel15, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 1;
        gridBagConstraints10.gridy = 1;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(filenameGenerationComboBox, gridBagConstraints10);

        jLabel16.setText("Change messages");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 2;
        gridBagConstraints10.gridy = 2;
        gridBagConstraints10.insets = new java.awt.Insets(0, 10, 0, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel16, gridBagConstraints10);

        jLabel17.setText("Format");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 0;
        gridBagConstraints10.gridy = 3;
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel17, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 1;
        gridBagConstraints10.gridy = 3;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(conversionTypesComboBox, gridBagConstraints10);

        jLabel10.setText("Encoding");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 2;
        gridBagConstraints10.gridy = 3;
        gridBagConstraints10.insets = new java.awt.Insets(0, 10, 0, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel10, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 3;
        gridBagConstraints10.gridy = 3;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 10, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints10.weightx = 0.5;
        jPanel8.add(encodingTypesComboBox, gridBagConstraints10);

        jLabel18.setText("Filename extention");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 0;
        gridBagConstraints10.gridy = 4;
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel18, gridBagConstraints10);

        extentionTextField.setColumns(8);

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 1;
        gridBagConstraints10.gridy = 4;
        gridBagConstraints10.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 15, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(extentionTextField, gridBagConstraints10);

        jLabel22.setText("Mixed case schema");

        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 2;
        gridBagConstraints10.gridy = 4;
        gridBagConstraints10.insets = new java.awt.Insets(0, 10, 0, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(jLabel22, gridBagConstraints10);


        gridBagConstraints10 = new java.awt.GridBagConstraints();
        gridBagConstraints10.gridx = 3;
        gridBagConstraints10.gridy = 4;
        gridBagConstraints10.insets = new java.awt.Insets(0, 5, 15, 0);
        gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
        jPanel8.add(mixedSchemaCheckBox, gridBagConstraints10);

        jTabbedPane1.addTab("Delivery Rules", jPanel8);

        jPanel22.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints11;

        transportBoxPanel.setLayout(new javax.swing.BoxLayout(transportBoxPanel, 0));

        gridBagConstraints11 = new java.awt.GridBagConstraints();
        gridBagConstraints11.gridx = 0;
        gridBagConstraints11.gridy = 0;
        gridBagConstraints11.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints11.weightx = 1.0;
        gridBagConstraints11.weighty = 0.5;
        jPanel22.add(transportBoxPanel, gridBagConstraints11);

        ftpTransportPanel.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints12;
        ftpTransportPanel.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder(
                new javax.swing.border.EtchedBorder(), "Delivery parameters", 2, 2),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));

        jPanel23.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints13;

        jLabel19.setText("Delivery method");

        gridBagConstraints13 = new java.awt.GridBagConstraints();
        gridBagConstraints13.anchor = java.awt.GridBagConstraints.WEST;
        jPanel23.add(jLabel19, gridBagConstraints13);

        deliveryMethodsComboBox.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboChanged(evt);
            }
        });

        gridBagConstraints13 = new java.awt.GridBagConstraints();
        gridBagConstraints13.insets = new java.awt.Insets(0, 5, 0, 0);
        gridBagConstraints13.anchor = java.awt.GridBagConstraints.WEST;
        jPanel23.add(deliveryMethodsComboBox, gridBagConstraints13);

        gridBagConstraints12 = new java.awt.GridBagConstraints();
        gridBagConstraints12.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints12.weightx = 1.0;
        ftpTransportPanel.add(jPanel23, gridBagConstraints12);

        ftpCardsPanel.setLayout(new java.awt.CardLayout());

        paramsPanel.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints14;
        paramsPanel.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder("FTP parameters"),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));

        ftpParamsPanel.setLayout(new javax.swing.BoxLayout(ftpParamsPanel, 0));

        gridBagConstraints14 = new java.awt.GridBagConstraints();
        gridBagConstraints14.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints14.weightx = 0.95;
        gridBagConstraints14.weighty = 1.0;
        paramsPanel.add(ftpParamsPanel, gridBagConstraints14);

        jPanel20.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints15;
        jPanel20.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
                new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder(""),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)))));

        jButton4.setText("Add");
        jButton4.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftpActionHandler(evt);
            }
        });

        gridBagConstraints15 = new java.awt.GridBagConstraints();
        gridBagConstraints15.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints15.insets = new java.awt.Insets(5, 0, 5, 0);
        jPanel20.add(jButton4, gridBagConstraints15);

        jButton5.setText("Delete");
        jButton5.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftpActionHandler(evt);
            }
        });

        gridBagConstraints15 = new java.awt.GridBagConstraints();
        gridBagConstraints15.gridx = 0;
        gridBagConstraints15.gridy = 3;
        gridBagConstraints15.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints15.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints15.weightx = 1.0;
        jPanel20.add(jButton5, gridBagConstraints15);

        jButton13.setText("Modify");
        jButton13.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftpActionHandler(evt);
            }
        });

        gridBagConstraints15 = new java.awt.GridBagConstraints();
        gridBagConstraints15.gridx = 0;
        gridBagConstraints15.gridy = 2;
        gridBagConstraints15.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints15.insets = new java.awt.Insets(0, 0, 5, 0);
        gridBagConstraints15.weightx = 1.0;
        jPanel20.add(jButton13, gridBagConstraints15);

        jButton14.setText("Copy");
        jButton14.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftpActionHandler(evt);
            }
        });

        gridBagConstraints15 = new java.awt.GridBagConstraints();
        gridBagConstraints15.gridx = 0;
        gridBagConstraints15.gridy = 1;
        gridBagConstraints15.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints15.insets = new java.awt.Insets(0, 0, 5, 0);
        jPanel20.add(jButton14, gridBagConstraints15);

        gridBagConstraints14 = new java.awt.GridBagConstraints();
        gridBagConstraints14.gridx = 1;
        gridBagConstraints14.gridy = 0;
        gridBagConstraints14.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints14.weightx = 0.05;
        gridBagConstraints14.weighty = 1.0;
        paramsPanel.add(jPanel20, gridBagConstraints14);

        ftpCardsPanel.add(paramsPanel, "FTP_CARD");


        ftpCardsPanel.add(jPanel25, "PLACEHOLDER");

        gridBagConstraints12 = new java.awt.GridBagConstraints();
        gridBagConstraints12.gridx = 0;
        gridBagConstraints12.gridy = 1;
        gridBagConstraints12.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints12.weightx = 1.0;
        ftpTransportPanel.add(ftpCardsPanel, gridBagConstraints12);

        gridBagConstraints11 = new java.awt.GridBagConstraints();
        gridBagConstraints11.gridx = 0;
        gridBagConstraints11.gridy = 1;
        gridBagConstraints11.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints11.weightx = 1.0;
        gridBagConstraints11.weighty = 0.5;
        jPanel22.add(ftpTransportPanel, gridBagConstraints11);

        jTabbedPane1.addTab("Transport Protocol", jPanel22);

        gridBagConstraints3 = new java.awt.GridBagConstraints();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints3.weightx = 1.0;
        gridBagConstraints3.weighty = 1.0;
        jPanel19.add(jTabbedPane1, gridBagConstraints3);

        cardsPanel.add(jPanel19, "FIELDS_PANEL");

        jPanel26.setLayout(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gridBagConstraints16;

        jLabel9.setText("Please select a DCM");

        gridBagConstraints16 = new java.awt.GridBagConstraints();
        jPanel26.add(jLabel9, gridBagConstraints16);

        cardsPanel.add(jPanel26, "SELECT_DCM");


        gridBagConstraints1 = new java.awt.GridBagConstraints();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 1;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints1.weightx = 1.0;
        gridBagConstraints1.weighty = 0.7;
        getContentPane().add(cardsPanel, gridBagConstraints1);

        jPanel12.setLayout(new java.awt.FlowLayout(1, 25, 5));
        jPanel12.setBorder(new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 5, 2, 5)));

        jButton8.setText("Save");
        jButton8.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formActionHandler(evt);
            }
        });

        jPanel12.add(jButton8);

        jButton9.setText("Delete");
        jButton9.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formActionHandler(evt);
            }
        });

        jPanel12.add(jButton9);

        jButton10.setToolTipText("Close (without saving changes)");
        jButton10.setText("Close");
        jButton10.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                formActionHandler(evt);
            }
        });

        jPanel12.add(jButton10);


        gridBagConstraints1 = new java.awt.GridBagConstraints();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 2;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.weightx = 1.0;
        gridBagConstraints1.weighty = 0.1;
        getContentPane().add(jPanel12, gridBagConstraints1);

        statusPanel1.setBorder(new javax.swing.border.CompoundBorder(
                new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
                new javax.swing.border.EtchedBorder()));


        gridBagConstraints1 = new java.awt.GridBagConstraints();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 3;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.weightx = 1.0;
        gridBagConstraints1.weighty = 0.1;
        getContentPane().add(statusPanel1, gridBagConstraints1);

    }//GEN-END:initComponents

    private void codeCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codeCheckBoxActionPerformed
// Add your handling code here:
        codeTextField.setEnabled(codeCheckBox.isSelected());
        jLabel25.setEnabled(codeCheckBox.isSelected());
    }//GEN-LAST:event_codeCheckBoxActionPerformed

    private void ftpActionHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftpActionHandler
        // Add your handling code here:
        String action = evt.getActionCommand();

        if (action.equals("Add")
                || action.equals("Copy")) {

            int num_rows = ftpParamsModel.getRowCount();
            if (num_rows == Constants.MAX_TCP_ADDRESS) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Only " + Constants.MAX_TCP_ADDRESS
                        + " hosts are allowed", "Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }

            int selected_row = -1;
            boolean new_entry = true;
            if (action.equals("Copy")) {
                selected_row = ftpParamsTable.getSelectedRow();
            }

            FTPParamsDialog dlg = new FTPParamsDialog(this, true,
                    idTextField.getText(),
                    ftpParamsModel,
                    selected_row,
                    new_entry);
            dlg.show();
            Object data[];

            if ((data = dlg.getData()) == null) {
                return;
            }

            ftpParamsModel.addRow(data);
            return;
        }


        if (action.equals("Modify")) {


            if (ftpParamsTable.getSelectedRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Please select a row", "Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }

            int selected_row = ftpParamsTable.getSelectedRow();

            FTPParamsDialog dlg = new FTPParamsDialog(this, true,
                    idTextField.getText(),
                    ftpParamsModel,
                    selected_row,
                    false);
            dlg.show();
            Object data[];

            if ((data = dlg.getData()) == null) {
                return;
            }

            for (int i = 0; i < data.length; i++) {
                ftpParamsModel.setValueAt(data[i], selected_row, i);
            }

            return;
        }

        if (action.equals("Delete")) {


            if (ftpParamsTable.getSelectedRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Please select a row", "Error",
                        javax.swing.JOptionPane.ERROR_MESSAGE);
                return;
            }
            int[] selected_rows = ftpParamsTable.getSelectedRows();
            //if (srows.length == 1) {
            ftpParamsModel.removeRow(selected_rows[0]);
            //return;
            //}



            return;
        }



    }//GEN-LAST:event_ftpActionHandler

    private void dcmComboChanged(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dcmComboChanged
        // Add your handling code here:
    }//GEN-LAST:event_dcmComboChanged

    private void comboChanged(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboChanged
        // Add your handling code here:
        Object src = evt.getSource();
        javax.swing.JComboBox cb = null;

        if (src instanceof javax.swing.JComboBox) {
            cb = (javax.swing.JComboBox) src;
        }

        if (cb == null) {
            return;
        }

        String text = (String) cb.getSelectedItem();

        if (text == null) {
            return;
        }

        if (cb == deliveryMethodsComboBox) {
            java.awt.CardLayout card = (java.awt.CardLayout) ftpCardsPanel.getLayout();
            if (text.startsWith("Light")) {
                card.show(ftpCardsPanel, "PLACEHOLDER");
            } else {
                card.show(ftpCardsPanel, "FTP_CARD");
            }

            ftpTransportPanel.invalidate();
            jPanel21.invalidate();
            validate();

            return;
        }



        if (cb == conversionTypesComboBox) {
            String ext = extentionTextField.getText();
            if (text.startsWith("XML")) {
                jLabel22.setVisible(true);
                mixedSchemaCheckBox.setVisible(true);
                mixedSchemaCheckBox.setSelected(true);//set Mixed Schema to default true
            } else {
                jLabel22.setVisible(false);
                mixedSchemaCheckBox.setVisible(false);
            }
            if (text.startsWith("XML")
                    || text.startsWith("NewsML")
                    || text.startsWith("DISTDOC")) {
                jLabel10.setVisible(true);
                encodingTypesComboBox.setVisible(true);
                if ((ext == null) || (ext.trim().length() == 0)
                        || ext.equals(".txt")) {
                    extentionTextField.setText(".xml");
                }
            } else {
                jLabel10.setVisible(false);
                encodingTypesComboBox.setVisible(false);
                if ((ext == null) || (ext.trim().length() == 0)
                        || ext.equals(".xml")) {
                    extentionTextField.setText(".txt");
                }
            }


            ftpTransportPanel.invalidate();
            jPanel21.invalidate();

            validate();
            return;
        }

        if (cb == deliveryTypesComboBox) {


            String dv = "0";
            String old_v = delayTextField.getText().trim();
            boolean was_default_value = false;
            if ((old_v != null)
                    && (old_v.equals("3600")
                    || old_v.equals("10800")
                    || old_v.equals("0"))) {
                was_default_value = true;
            }

            if (text.startsWith("dowjones")) {
                timerLabel.setText("Delay (sec.)");
                dv = "0";
            } else {
                timerLabel.setText("Chain timer (sec.)");
                if (text.endsWith("Newspaper)")) {
                    dv = "3600";
                } else {
                    dv = "10800";
                }
            }

            /*
             ** Reset the text field only * if old value was also a default
             */
            if ((old_v.length() == 0) || was_default_value) {
                delayTextField.setText(dv);
            }
        }

        updateState();

    }//GEN-LAST:event_comboChanged

    private void updateState() {

        String dt = (String) deliveryTypesComboBox.getSelectedItem();
        String fng = (String) filenameGenerationComboBox.getSelectedItem();


        //System.out.println("DT="+dt+" FNG="+fng);

        if ((dt != null) && dt.startsWith("dowjones")) {
            if ((fng != null) && fng.startsWith("First")) {
                takeComboBox.setSelectedItem("Pre-chained");
                takeComboBox.setEnabled(false);
                sendChangesCheckBox.setSelected(false);
                sendChangesCheckBox.setEnabled(false);
            } else {
                takeComboBox.setEnabled(true);
                filenameGenerationComboBox.setEnabled(true);
                sendChangesCheckBox.setEnabled(true);
            }

        } else {
            takeComboBox.setSelectedItem("Pre-chained");
            takeComboBox.setEnabled(false);

            filenameGenerationComboBox.setSelectedItem("Current take");
            filenameGenerationComboBox.setEnabled(false);
            sendChangesCheckBox.setEnabled(true);
        }


    }

    private void productSelectionHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productSelectionHandler
        // Add your handling code here:
        javax.swing.JTable table = productTable1;
        if (evt.getActionCommand().endsWith("2")) {
            table = productTable2;
        }

        table.selectAll();
    }//GEN-LAST:event_productSelectionHandler

    private void appendProducts(StringBuffer savebuf, DistrProductTableModel model) {
        int nrows = model.getRowCount();

        for (int r = 0; r < nrows; r++) {
            String prod = (String) model.getValueAt(r, 0);

            if (distrConfigType == Constants.DSP_BROADCASTER) {
                savebuf.append(ConfigComm.CONF_US).append(prod);
            } else {
                savebuf.append("<").append(ConfigComm.CONF_US).append(prod);
                String fmt = (String) model.getValueAt(r, 1);
                Integer dly = (Integer) model.getValueAt(r, 2);
                Boolean fw = (Boolean) model.getValueAt(r, 3);
                Boolean np = (Boolean) model.getValueAt(r, 4);
                String dd = (String) model.getValueAt(r, 5);
                String codes = (String) model.getValueAt(r, 6);
                String language = (String) model.getValueAt(r, 7);
                String encoding = (String) model.getValueAt(r, 8);
                String premium_filter = (String) model.getValueAt(r, 9);
                boolean sigabout = (Boolean) model.getValueAt(r, 10);
                if (premium_filter == null)
                    premium_filter = "NONE";
                
                String dict = "NONE", df = "";
                int inx = dd.indexOf("|");
                if (inx < 0) {
                    df = dd;
                    dict = "NONE";
                } else {
                    df = dd.substring(0, inx);
                    dict = dd.substring(inx + 1);
                }


                Long flags = DistributorProductFlagOptions.getFlag(fw, np, df, sigabout);

                savebuf.append(ConfigComm.CONF_US).append(fmt).append(ConfigComm.CONF_US).append(dly.toString()).append(ConfigComm.CONF_US).append(flags.toString()).append(ConfigComm.CONF_US).append(codes).append(ConfigComm.CONF_US).append(dict);

                if (encoding != null && (encoding.trim().length() > 0)
                        && (!encoding.trim().equalsIgnoreCase("default"))) {
                    savebuf.append(ConfigComm.CONF_US).append(language)
                            .append(ConfigComm.CONF_US).append(encoding);
                }
                else
                {
                    savebuf.append(ConfigComm.CONF_US).append("Default")
                            .append(ConfigComm.CONF_US).append("Default");
                }
                
                savebuf.append(ConfigComm.CONF_US).append(premium_filter);

                savebuf.append("/>");
            }



            savebuf.append(ConfigComm.CONF_US);
        }

    }

    private void formActionHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_formActionHandler
        // Add your handling code here:
        String command = evt.getActionCommand();
        Object src = evt.getSource();
        javax.swing.JButton source = null;

        if (src instanceof javax.swing.JButton) {
            source = (javax.swing.JButton) src;
            source.setEnabled(false);
        }

        final Utils.ActionWorker sw = new Utils.ActionWorker(source,
                command) {

            public Object construct() {
                _formActionHandler(cmdButton, action);
                return null;
            }
        };

        sw.start();
    }//GEN-LAST:event_formActionHandler

    private void _formActionHandler(javax.swing.JButton cmdButton,
            String command) {


        try {
            mLock.acquire();
        } catch (InterruptedException ie) {
            Log.getInstance().log_error("Service handler interrupted", ie);
            if (cmdButton != null) {
                cmdButton.setEnabled(true);
            }
            return;
        }


        /*
         ** Disable all buttons while handling request
         */
        boolean flag9 = jButton9.isEnabled();
        jButton8.setEnabled(false); // Save
        jButton9.setEnabled(false); //Delete
        jButton10.setEnabled(false); //Close

        statusPanel1.start("Please wait ...");

        boolean exit_window = true;
        boolean clear_cache = true;

        if (command.equals("Save")) {
            exit_window = saveConfiguration();
        } else if (command.equals("Delete")) {
            exit_window = deleteConfiguration();
        } else {
            clear_cache = false;
            if (javax.swing.JOptionPane.YES_OPTION
                    != Log.getInstance().show_confirm(this, "Please confirm",
                    "Any unsaved changes will be "
                    + "lost.\nAre you sure you want"
                    + " to close window?.")) {
                exit_window = false;

            }
        }


        if (cmdButton != null) {
            cmdButton.setEnabled(true);
        }

        if (!exit_window) {
            jButton8.setEnabled(true); // Save
            if (flag9) {
                jButton9.setEnabled(true); //Delete
            }
            jButton10.setEnabled(true); //Close
        }

        mLock.release();
        statusPanel1.stop();
        statusPanel1.clear();
        if (exit_window) {
            if (clear_cache) {
                CacheManager.removeCache(Constants.GLB_TAG_DISTR_PREFIX + idTextField.getText().trim());
            }
            exitForm(null);
        }

    }

    /*
     ***********************
     *
     * private String validateFCodeToken(String token) { if( (token == null) ||(
     * token.trim().length() <= 3) ) return null;
     *
     * if (!token.substring(0,2).equalsIgnoreCase("F/")) return null;
     *
     * // Don't check quoted strings
     *
     * String tok = token.substring(3,token.length()).trim();
     *
     * int l = tok.length(); if ((tok.charAt(0)=='"') && (tok.charAt(l-1)=='"')
     * ) return token;
     *
     * for (int inx = 0; inx < tok.length(); inx++) { if
     * (!Character.isLetterOrDigit(tok.codePointAt(inx))) return null; }
     *
     * return token; } **********************
     */
    private boolean saveConfiguration() {

        String errstr = new String("Please enter valid data in the following fields: \n");
        int err = 0;
        int i;

        boolean flip_hosts = false;


        DistrProductTableModel tableModel1;
        DistrProductTableModel tableModel2;

        tableModel1 = (DistrProductTableModel) productTable1.getModel();
        tableModel2 = (DistrProductTableModel) productTable2.getModel();

        java.util.HashMap configMap = new java.util.HashMap();


        String id = idTextField.getText();
        id.trim();

        String desc = descTextField.getText();
        desc.trim();


        String hostTag = null, hostID = null;
        if ((distrConfigType == Constants.DCM_LINEHANDLER)
                || (distrConfigType == Constants.DJNEWS_LINEHANDLER)) {
            hostID = (String) dcmComboBox.getSelectedItem();
            hostTag = Constants.GLB_TAG_DCM_PREFIX + hostID;
        } else {
            hostID = Constants.GLB_TAG_DSP;
            hostTag = Constants.GLB_TAG_DSP;
        }


        if (id.length() == 0) {
            err = 1;
            errstr += " ID \n";
        }



        if ((hostID == null)
                || (hostID.length() == 0)
                || hostID.equals(blank)) {
            err = 1;
            errstr += " Sending host \n";
        }


        StringBuffer transport = new StringBuffer();
        StringBuffer transport1 = new StringBuffer();
        StringBuffer transport2 = new StringBuffer();

        StringBuffer estr = new StringBuffer();

        int e1 = -1;
        String transport_key;
        StringBuffer transport_value = new StringBuffer();


        if (distrConfigType == Constants.DSP_BROADCASTER) {
            e1 = 0;
            String transp = recvDCMPanel.transportLabel.getText();
            transport_key = "TRANSPORT";

            transport.append(transport_key).append(ConfigComm.CONF_RS);

            if (transp.startsWith("RBP")) {
                transport_value.append(transp);
            } else {
                String recvDCM = (String) recvDCMPanel.dcmComboBox.getSelectedItem();
                if (recvDCM.equals(blank)) {
                    e1 = -1;
                    err = 1;
                    errstr += " Receiving DCM \n";
                } else {
                    transport_value.append(recvDCM);
                }
            }
            transport.append(transport_value.toString()).append(ConfigComm.CONF_RS);

            configMap.put(transport_key, transport_value.toString());

        } else {
            e1 = transportPanel.getTransportConfig(transport1, transport2,
                    estr);

            if (transport2.length() > 0) {
                transport.append("TRANSPORT_1").append(ConfigComm.CONF_RS).append(transport1.toString()).append(ConfigComm.CONF_RS).append("TRANSPORT_2").append(ConfigComm.CONF_RS).append(transport2.toString()).append(ConfigComm.CONF_RS);

                configMap.put("TRANSPORT_1", transport1.toString());
                configMap.put("TRANSPORT_2", transport2.toString());

            } else {
                transport.append("TRANSPORT").append(ConfigComm.CONF_RS).append(transport1.toString()).append(ConfigComm.CONF_RS);

                configMap.put("TRANSPORT", transport1.toString());
            }
        }


        if (e1 != 0) {
            err = 1;
            errstr += " Transport\n   ";
            errstr += estr.toString();
        }

        int keepAlive1 = -1, keepAlive2 = -1;
        String keepAliveStr1, keepAliveStr2;

        try {
            keepAlive1 = Integer.parseInt(keepAliveTextField1.getText());
            keepAliveStr1 = keepAliveTextField1.getText();
            if (keepAlive1 < Constants.MINKEEPALIVE
                    || keepAlive1 > Constants.MAXKEEPALIVE) {
                err = 1;
                errstr += "Keep Alive - I out of range. (" + Constants.MINKEEPALIVE
                        + "-" + Constants.MAXKEEPALIVE + ").\n";
            }
        } catch (NumberFormatException e) {
            keepAliveStr1 = new String("-");
        }
        try {
            keepAlive2 = Integer.parseInt(keepAliveTextField2.getText());
            keepAliveStr2 = keepAliveTextField2.getText();
            if (keepAlive2 < Constants.MINKEEPALIVE
                    || keepAlive2 > Constants.MAXKEEPALIVE) {
                err = 1;
                errstr += "Keep Alive - II out of range. (" + Constants.MINKEEPALIVE
                        + "-" + Constants.MAXKEEPALIVE + ").\n";
            }
        } catch (NumberFormatException e) {
            keepAliveStr2 = new String("-");
        }

        /*
         **if (keepAlive1 == -1) *{err=1;errstr += " Keep Alive - I \n";} *if
         * (keepAlive2 == -1) *{err=1;errstr += " Keep Alive - II \n";}
         */

        if (tableModel1.getRowCount() == 0) {
            err = 1;
            errstr += " Products - I \n";
        }
        if (tableModel2.getRowCount() == 0) {
            err = 1;
            errstr += " Products - II \n";
        }

        try {

            java.util.HashMap hostmap = ConfigComm.getHashMapDirect(hostTag);


            String location1 = (String) hostmap.get("LOCATION1");
            String location2 = (String) hostmap.get("LOCATION2");
            //System.out.println("Location1: "+location1+" Location2: "+location2);
            String primary_location = (String) locationComboBox1.getSelectedItem();
            LOCATION_BLOCK:
            if (location1 != null && location2 != null) {

                if (primary_location == null) {
                    err = 1;
                    errstr += "Location.\n";
                    break LOCATION_BLOCK;

                }

                String home_location = null;

                if (primary_location.equals(location1)) {
                    home_location = "1";
                } else {
                    home_location = "2";
                    flip_hosts = true;
                }


                configMap.put("HOME_LOCATION", home_location);

            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        if (err == 1) {
            Log.getInstance().show_warning(this, "Error",
                    errstr, null);
            return false;
        }

        String stats1 = (String) statisticsComboBox1.getSelectedItem();
        String stats2 = (String) statisticsComboBox2.getSelectedItem();


        long flags = 0;


        if (codeCheckBox.isSelected()) {
            flags |= CODES_ON;
            String codes = codeTextField.getText();
            if ((codes != null) && codes.trim().length() > 0) {
                configMap.put("CODES_STR", codes.trim());
            }

        }
        
        if (summaryCheckBox.isSelected()) {
            flags |= SUMMARY_ON;            
        }

        configMap.put("OPTIONS_FLAG", Long.toHexString(flags));
        configMap.put("TAG", hostTag);
        configMap.put("KEEPALIVE_1", keepAliveStr1);
        configMap.put("KEEPALIVE_2", keepAliveStr2);
        configMap.put("STATISTICS_1", stats1);
        configMap.put("STATISTICS_2", stats2);


        if (desc.length() > 0) {
            configMap.put("DESCRIPTION", desc);
        }
        String autoFailStr = new Boolean(autoFailoverCheckBox.isSelected()).toString();
        configMap.put("AUTO_FAILOVER", autoFailStr);


        String hiresTSStr = new Boolean(highResolutionTimestampCheckBox.isSelected()).toString();
        configMap.put("HIGH_RESOLUTION_TIMESTAMPS", hiresTSStr);

        String newsplusOffStr = new Boolean(newsplusOffCheckBox.isSelected()).toString();
        configMap.put("NEWSPLUS_OFF", newsplusOffStr);

        String rtkaStr = new Boolean(reutersKeepAliveAckCheckBox.isSelected()).toString();
        configMap.put("REUTERS_KEEPALIVE_ACK", rtkaStr);


        String ckptPort_save = ckptPort;

        boolean delete_cache = false;
        if (existsInDatabase && (origDCMTag != null)
                && !origDCMTag.equals(hostID)) {
            ckptPort = Constants.GLB_DCM_DISTR_CHECKPOINT_STRING;
            //System.out.println("DCM CHanged. Resetting CHECKPOINT "+ckptPort);
            delete_cache = true;
        }


        if (ckptPort != null) {
            configMap.put("CHECKPOINT", ckptPort);
        }




        String ctype = null;

        switch (distrConfigType) {

            case Constants.DSP_BROADCASTER:
                ctype = Constants.BROADCASTER_TEMPLATE;
                break;
            case Constants.DSP_LINEHANDLER:
                ctype = Constants.FULL_CONFIGURATION;
                break;
            case Constants.DCM_LINEHANDLER:
                ctype = Constants.FULL_CONFIGURATION;
                break;
            case Constants.DJNEWS_LINEHANDLER:
                ctype = Constants.DJNEWS_CONFIGURATION;
                break;
        }


        configMap.put("CONFIGURATION_TYPE", ctype);


        int nrows = tableModel1.getRowCount();
        if (nrows > 0) {
            StringBuffer prodbuf = new StringBuffer();
            appendProducts(prodbuf, tableModel1);
            configMap.put("PRODUCTS_1", prodbuf.toString());
        }

        //System.out.println("Product list 1 "+savebuf.toString());


        nrows = tableModel2.getRowCount();
        if (nrows > 0) {
            StringBuffer prodbuf = new StringBuffer();
            appendProducts(prodbuf, tableModel2);
            configMap.put("PRODUCTS_2", prodbuf.toString());
        }



        DJNEWSLH:
        if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {

            String sendChanges = new Boolean(sendChangesCheckBox.isSelected()).toString();


            String contentType = (String) Constants.label2KeyMap.get(
                    (String) contentTypesComboBox.getSelectedItem());

            String ftpDelay = delayTextField.getText();


            String ftpDeliveryType = (String) Constants.label2KeyMap.get(
                    (String) deliveryTypesComboBox.getSelectedItem());

            String ftpFormatType = (String) Constants.label2KeyMap.get(
                    (String) conversionTypesComboBox.getSelectedItem());


            String formatEncoding = (String) encodingTypesComboBox.getSelectedItem();

            String mixedSchema = new Boolean(mixedSchemaCheckBox.isSelected()).toString();



            String ftpDeliveryMethod = (String) Constants.label2KeyMap.get(
                    (String) deliveryMethodsComboBox.getSelectedItem());


            String ftpFileGenType = (String) Constants.label2KeyMap.get(
                    (String) filenameGenerationComboBox.getSelectedItem());


            String ftpTakeType = (String) Constants.label2KeyMap.get(
                    (String) takeComboBox.getSelectedItem());


            String ftpFileExtention = extentionTextField.getText();




            if ((ftpDelay == null) || (ftpDelay.trim().length() == 0)) {
                err = 1;
                errstr += timerLabel.getText();
                errstr += " \n";
            } else {
                try {
                    Integer.parseInt(ftpDelay);
                } catch (Exception e) {
                    err = 1;
                    errstr += timerLabel.getText();
                    errstr += " parsing error \n";
                }
            }

            if (err != 1) {
                configMap.put("DJNEWS_SEND_CHANGES", sendChanges);
                configMap.put("DJNEWS_CONTENT_TYPE", contentType);
                configMap.put("DJNEWS_TIMER", ftpDelay);
                configMap.put("DJNEWS_DELIVERY_TYPE", ftpDeliveryType);
                configMap.put("DJNEWS_FORMAT_TYPE", ftpFormatType);
                configMap.put("DJNEWS_DELIVERY_METHOD", ftpDeliveryMethod);
                configMap.put("DJNEWS_TAKE_TYPE", ftpTakeType);
                configMap.put("DJNEWS_FILE_GENERATION_TYPE", ftpFileGenType);
                configMap.put("DJNEWS_MIXEDCASE_SCHEMA", mixedSchema);
                configMap.put("DJNEWS_LWC_HEADER", Boolean.toString(transportPanel.lwcHeaderCheckBox.isSelected()));
            }


            if ((ftpFileExtention != null)
                    && (ftpFileExtention.trim().length() > 0)) {
                configMap.put("DJNEWS_FILE_EXTENTION", ftpFileExtention);
            }



            if (ftpFormatType.startsWith("XML")
                    || ftpFormatType.startsWith("NEWSML")
                    || ftpFormatType.startsWith("NewsML")
                    || ftpFormatType.startsWith("DISTDOC")) {
                configMap.put("DJNEWS_FORMAT_ENCODING", formatEncoding);
            }



            if (!ftpDeliveryMethod.startsWith("DJNEWS_LWC")) {
                if (ftpParamsTable.isEditing()) {
                    ftpParamsTable.editingCanceled(
                            new javax.swing.event.ChangeEvent(this));
                }


                java.util.HashMap ftpParams = null;
                StringBuffer errmsg = new StringBuffer();
                if (validateData(errmsg)) {
                    err = 1;
                    errstr += errmsg.toString();
                } else {
                    ftpParams = getFTPParams();
                }

                if (err == 1) {
                    break DJNEWSLH;
                }

                configMap.putAll(ftpParams);


            } else {
                configMap.put(Constants.FTP_NUM_ENTRIES, "0");
            }

        } // DJNEWS_LINEHANDLER




        if (err == 1) {
            Log.getInstance().show_warning(this, "Error",
                    errstr, null);
            ckptPort = ckptPort_save;
            return false;
        }



        StringBuffer reqbuf = new StringBuffer();

        int db_req = ConfigComm.ADD_DISTRIBUTOR_KEY;
        if (existsInDatabase) {
            db_req = ConfigComm.SAVE_DISTRIBUTOR_KEY;
        }

        ConfigComm.convertHashMap(reqbuf, Constants.GLB_TAG_DISTR_PREFIX + id,
                db_req, configMap, null, true);



        //System.out.println("SAVE BUF (" + reqbuf.length()  +"): " + reqbuf.toString());



        try {


            byte[] b;

            int s1 = -1, s2 = -1;
            String h1 = null, h2 = null;


            if (existsInDatabase) {
                h1 = (String) origHostConfig.get("HOST1");
                h2 = (String) origHostConfig.get("HOST2");

                if (flip_hosts) {
                    h1 = (String) origHostConfig.get("HOST2");
                    h2 = (String) origHostConfig.get("HOST1");
                }

                s1 = Utils.isLineHandlerRunning(h1, id);
                s2 = Utils.isLineHandlerRunning(h2, id);
            }

            if (Constants.isDistrDCMEditable && existsInDatabase) {
                if (!origDCMTag.equals(hostID)) {
                    if ((s1 != 0) || (s2 != 0)) {
                        Log.getInstance().show_error(this, "Error",
                                "DCMs cannot be changed while line handler"
                                + " is running.", null);
                        dcmComboBox.setSelectedItem(origDCMTag);
                        ckptPort = ckptPort_save;
                        return false;
                    }
                }
            }



            b = ConfigComm.configRequest(reqbuf);

            if (delete_cache) {
                Utils.DeleteDistrCacheThread t1 =
                        new Utils.DeleteDistrCacheThread(h1, id);

                Utils.DeleteDistrCacheThread t2 =
                        new Utils.DeleteDistrCacheThread(h2, id);

                t1.start();
                t2.start();

                Utils.AdminStatus status1 = (Utils.AdminStatus) t1.get();
                Utils.AdminStatus status2 = (Utils.AdminStatus) t2.get();

                if ((status1.status != 0) || (status2.status != 0)) {
                    StringBuffer estr1 = new StringBuffer();
                    if (status1.response.length() > 0) {
                        estr1.append("Host: ").append(h1).append(" ->").append(status1.response).append("\n");
                    }
                    if (status2.response.length() > 0) {
                        estr1.append("Host: ").append(h2).append(" ->").append(status2.response).append("\n");
                    }

                    if (estr1.length() > 0) {
                        Log.getInstance().show_error(this, "Warning",
                                "Distributor cache could not be deleted on previous DCM:\n Please remove using 'fixdistr' command.\n"
                                + estr1.toString(),
                                null);
                    }

                }
            } else if (existsInDatabase) {

                StringBuffer str1 = new StringBuffer();
                StringBuffer str2 = new StringBuffer();


                updateDynamicConfig(1, h1, str1);
                updateDynamicConfig(2, h2, str2);


                if (str1.length() > 0) {
                    str1.insert(0, "xData center - I: \n");
                    str1.append("\n");
                }
                if (str2.length() > 0) {
                    str1.append("xxData center - II: \n").append(str2).append("\n");
                }


                if ((s1 != 0) || (s2 != 0)) {

                    /*
                     ** Warn if transport configuration * is changed while
                     * linehandler(s) * are running
                     */

                    StringBuffer oldConfig = new StringBuffer();
                    StringBuffer newConfig = new StringBuffer();

                    String orig = (String) origConfig.get("TRANSPORT");
                    String orig1 = (String) origConfig.get("TRANSPORT_1");
                    String orig2 = (String) origConfig.get("TRANSPORT_2");

                    if ((orig1 != null) && (orig2 != null)) {
                        oldConfig.append(orig1).append(orig2);
                    } else if (orig != null) {
                        oldConfig.append(orig);
                    }



                    if (transport2.length() > 0) {
                        newConfig.append(transport1).append(transport2);
                    } else {
                        newConfig.append(transport1);
                    }



                    if ((newConfig.length() > 0) && (oldConfig.length() > 0)
                            && !newConfig.toString().trim().equals(oldConfig.toString().trim())) {
                        str1.insert(0, "Line handler(s) have to be restarted "
                                + "to use new transport configuration.\n\n");
                    }
                }


                if (str1.length() > 0) {
                    Log.getInstance().show_warning(this, "Warning",
                            str1.toString(), null);
                }


            }



            /*
             * Send refresh request to other screens
             */

            if (distrConfigType == Constants.DCM_LINEHANDLER) {
                DCMServicesForm servicesForm = (DCMServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DCM + "_" + hostID);

                if (servicesForm != null) {
                    servicesForm.Refresh();
                }


                DistrServicesForm distrServicesForm = (DistrServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DISTRIBUTORS_DETAILED);

                if (distrServicesForm != null) {
                    distrServicesForm.Refresh();
                }

            } else {
                DSPDistrConfigSelectForm lhConfigForm = (DSPDistrConfigSelectForm) WindowEventAdapter.getInstance().findWindow(Constants.CONFIGURATION_DSP_DISTRIBUTORS);
                if (lhConfigForm != null) {
                    lhConfigForm.Refresh();
                }

                DSPServicesForm servicesForm = (DSPServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DSP);
                if (servicesForm != null) {
                    servicesForm.Refresh();
                }

            }

        } catch (Exception e) {
            //e.printStackTrace();
            if (e instanceof DBException) {
                if (((DBException) e).getErrorNo() == Constants.DB_PRESENT_ERR) {
                    Log.getInstance().show_error(this, "Error",
                            "ID: " + id + " is already is use."
                            + "\nPlease choose another ID.",
                            e);
                    ckptPort = ckptPort_save;
                    return false;
                }
                if (((DBException) e).getErrorNo() == Constants.MAX_DISTR_ERR) {
                    Log.getInstance().show_error(this, "Error",
                            "Can't save " + id + ".\n"
                            + "Exceeded limit of distributors on DCM: " + hostID,
                            e);
                    ckptPort = ckptPort_save;
                    return false;
                }
            }

            Log.getInstance().show_error(this, "Error",
                    "Error in saving distributor: " + id + " configuration", e);

            ckptPort = ckptPort_save;
            return false;
        }

        return true;
    } /*
     * saveConfiguration
     */


    private boolean deleteConfiguration() {


        String id = idTextField.getText();
        id.trim();

        StringBuffer reqbuf = new StringBuffer();
        ConfigComm.deleteKeyValue(reqbuf, Constants.GLB_TAG_DISTR_PREFIX + id);


        if (javax.swing.JOptionPane.YES_OPTION
                != Log.getInstance().show_confirm(this, "Confirm delete",
                "Are you sure you want to delete distributor: " + id + " ?.")) {
            return false;
        }

        String h1 = (String) origHostConfig.get("HOST1");
        String h2 = (String) origHostConfig.get("HOST2");

        int s1 = Utils.isLineHandlerRunning(h1, id);
        int s2 = Utils.isLineHandlerRunning(h2, id);


        if ((s1 != 0) || (s2 != 0)) {
            if ((s1 == 1) || (s2 == 1)) {
                Log.getInstance().show_error(this, "Error",
                        "Cannot delete configuration while processes are running.",
                        null);
                return false;
            } else {
                if (javax.swing.JOptionPane.YES_OPTION
                        != Log.getInstance().show_confirm(this, "Warning",
                        "Could not verify that line handler(s) are not running.\n"
                        + "Are you sure you want to delete the distributor.?")) {
                    return false;
                }
            }
        }



        try {
            byte[] b;
            b = ConfigComm.configRequest(reqbuf);

            Utils.DeleteDistrCacheThread t1 =
                    new Utils.DeleteDistrCacheThread(h1, id);

            Utils.DeleteDistrCacheThread t2 =
                    new Utils.DeleteDistrCacheThread(h2, id);

            t1.start();
            t2.start();

            Utils.AdminStatus status1 = (Utils.AdminStatus) t1.get();
            Utils.AdminStatus status2 = (Utils.AdminStatus) t2.get();

            if ((status1.status != 0) || (status2.status != 0)) {
                StringBuffer estr = new StringBuffer();
                if (status1.response.length() > 0) {
                    estr.append(status1.response).append("\n");
                }
                if (status2.response.length() > 0) {
                    estr.append(status2.response).append("\n");
                }

                if (estr.length() > 0) {
                    Log.getInstance().show_error(this, "Warning",
                            "Distributor cache could not be deleted:\n Please remove it using 'fixdistr' command.\n"
                            + estr.toString(),
                            null);
                }

            }


            ConfigComm.deleteFromFavorites(id);



            if (distrConfigType == Constants.DCM_LINEHANDLER) {

                String dcmTag = (String) dcmComboBox.getSelectedItem();
                DCMServicesForm servicesForm = (DCMServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DCM + "_" + dcmTag);
                if (servicesForm != null) {
                    servicesForm.Refresh();
                }


                DistrServicesForm distrServicesForm = (DistrServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DISTRIBUTORS_DETAILED);

                if (distrServicesForm != null) {
                    distrServicesForm.Refresh();
                }

            } else {
                DSPDistrConfigSelectForm lhConfigForm = (DSPDistrConfigSelectForm) WindowEventAdapter.getInstance().findWindow(Constants.CONFIGURATION_DSP_DISTRIBUTORS);
                if (lhConfigForm != null) {
                    lhConfigForm.Refresh();
                }

                DSPServicesForm servicesForm = (DSPServicesForm) WindowEventAdapter.getInstance().findWindow(Constants.SERVICES_DSP);
                if (servicesForm != null) {
                    servicesForm.Refresh();
                }

            }


            java.util.Vector v = WindowEventAdapter.getInstance().findWindows(Constants.STATUS_DISTRIBUTOR_PREFIX
                    + id);

            for (int r = 0; r < v.size(); r++) {
                DistributorStatusForm rform = (DistributorStatusForm) v.get(r);
                rform.exitForm(null);
            }
            v = WindowEventAdapter.getInstance().findWindows(Constants.STATUS_DISTR_RETRANSMISSION_PREFIX
                    + id);

            for (int r = 0; r < v.size(); r++) {
                RetransmissionStatusForm rform = (RetransmissionStatusForm) v.get(r);
                rform.exitForm(null);
            }



        } catch (Exception e) {
            Log.getInstance().show_error(this, "Error",
                    "Error in deleting distributor: " + id + " configuration", e);
            return false;
        }

        return true;
    } /*
     * deleteConfiguration
     */


    private void modifyProducts(DistrProductTableModel model,
            String[] products, String format,
            Integer delay, Boolean freewheel,
            Boolean newsplus_off,
            String deriveddata, String dict,
            String filter, String lang, String encoding,
            String premium_filter,
            Boolean sigabout) {
        
        
        int np = model.getRowCount();
        for (int r = 0; r < products.length; r++) {
            for (int i = 0; i < np; i++) {
                if (products[r].equals((String) model.getValueAt(i, 0))) {
                    if (format != null) {
                        model.setValueAt(new String(format), i, 1);
                    }
                    if (delay != null) {
                        model.setValueAt(new Integer(delay.intValue()), i, 2);
                    }
                    if (freewheel != null) {
                        model.setValueAt(new Boolean(freewheel.booleanValue()), i, 3);
                    }
                    if (newsplus_off != null) {
                        model.setValueAt(new Boolean(newsplus_off.booleanValue()), i, 4);
                    }

                    StringBuilder sb = new StringBuilder();
                    if (deriveddata != null) {
                        sb.append(deriveddata);

                        sb.append("|");
                        if (dict != null) {
                            sb.append(dict);
                            model.setValueAt(sb.toString(), i, 5);
                        }
                    }
                    
                    
                    
                    if (lang != null) {
                        
                    
                    model.setValueAt(lang, i, 7);
                    }

                    if (encoding != null)  {                       
                        model.setValueAt(encoding, i, 8);
                    }

                    if (premium_filter != null)    
                    {
                        model.setValueAt(premium_filter, i, 9);                    
                    }

                    if (filter != null) {
                        model.setValueAt(filter, i, 6);
                    }
                    
                    if (sigabout != null)
                        model.setValueAt(new Boolean(sigabout.booleanValue()), i, 10);
                    
                    
                }
            }
        }

    }

    private void deleteProducts(DistrProductTableModel model,
            String[] products) {
        int np = model.getRowCount();
        for (int r = 0; r < products.length; r++) {
            for (int i = 0; i < np; i++) {
                if (products[r].equals((String) model.getValueAt(i, 0))) {
                    model.removeRow(i);
                }
            }
        }

    }

    private DistrProductStructure getDPS(DistrProductTableModel model, int row) {
        DistrProductStructure dps = new DistrProductStructure();
        dps.product = (String) model.getValueAt(row, 0);
        dps.format = (String) model.getValueAt(row, 1);
        dps.delay = ((Integer) model.getValueAt(row, 2)).intValue();
        dps.freewheel = ((Boolean) model.getValueAt(row, 3)).booleanValue();
        dps.newsplus_off = ((Boolean) model.getValueAt(row, 4)).booleanValue();
        String s = (String) model.getValueAt(row, 5);
        System.out.println("getDPS: " + s);
        int inx = s.indexOf("|");
        if (inx < 0) {
            dps.derived_data = DistributorProductFlagOptions.getDerivedDataOptionFlag(s);
            dps.derived_data_dictionary = "NONE";
        } else {
            String dd = s.substring(0, inx);
            String dict = s.substring(inx + 1);
            System.out.println("getDPS:dict " + dict + " dd " + dd);
            dps.derived_data = DistributorProductFlagOptions.getDerivedDataOptionFlag(dd);
            dps.derived_data_dictionary = dict;
        }
        dps.permTemplate = (String) model.getValueAt(row, 6);

        s = (String) model.getValueAt(row, 7);
        if (s == null) {
            s = "Default";
        }
        dps.language = s;

        s = (String) model.getValueAt(row, 8);
        if (s == null) {
            s = "Default";
        }
        dps.encoding = s;
        
        s = (String) model.getValueAt(row, 9);
        if (s == null) {
            s = "NONE";
        }
        dps.premium_filter = s;
        dps.sigabout = ((Boolean) model.getValueAt(row, 10)).booleanValue();
        return dps;
    }

    private boolean compareDPS(DistrProductStructure dps1, DistrProductStructure dps2) {

        return dps1.compareAttributes(dps2);
        //if (dps1.product.equals(dps2.product)
        //&& dps1.format.equals(dps2.format)
//        if (dps1.format.equals(dps2.format)
//                && (dps1.delay == dps2.delay)
//                && (dps1.freewheel == dps2.freewheel)
//                && (dps1.derived_data == dps2.derived_data)
//                && (dps1.derived_data_dictionary.equals(dps2.derived_data_dictionary))
//               && (dps1.language.equals(dps2.language))
//                && (dps1.encoding.equals(dps2.encoding))
//                && dps1.permTemplate.equals(dps2.permTemplate)
//                && dps1.premium_filter.equals(dps2.premium_filter)) {
//           return true;
//        }
//
//        return false;
    }

    private DistrProductStructure compareAllDPS(DistrProductTableModel model1,
            int srows1[], DistrProductTableModel model2, int srows2[]) {
        DistrProductStructure refDPS = null;

        if (srows1 != null) {
            refDPS = getDPS(model1, srows1[0]);
            for (int i = 1; i < srows1.length; i++) {
                DistrProductStructure dps = getDPS(model1, srows1[i]);
                if (!compareDPS(refDPS, dps)) {
                    return null;
                }
            }
        }

        if (srows2 != null) {
            int i = 0;
            if (refDPS == null) {
                refDPS = getDPS(model2, srows2[0]);
                i = 1;
            }
            for (; i < srows2.length; i++) {
                DistrProductStructure dps = getDPS(model2, srows2[i]);
                if (!compareDPS(refDPS, dps)) {
                    return null;
                }
            }
        }
        System.out.println("REFDPS" + ((refDPS == null) ? "NULL" : "NOT null"));
        return refDPS;
    }

    private void productActionHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productActionHandler
        // Add your handling code here:

        if (distrConfigType == Constants.DSP_BROADCASTER) {

            String action = evt.getActionCommand();
            DistrProductTableModel tableModel1;
            DistrProductTableModel tableModel2;

            tableModel1 = (DistrProductTableModel) productTable1.getModel();
            tableModel2 = (DistrProductTableModel) productTable2.getModel();



            if (productTable1.isEditing()) {
                //productTable1.editingCanceled(new javax.swing.event.ChangeEvent(this));
            }
            if (productTable2.isEditing()) {
                productTable2.editingCanceled(new javax.swing.event.ChangeEvent(this));
            }


            if (action.equals("Add")) {
                int count1 = tableModel1.getRowCount();
                int count2 = tableModel2.getRowCount();
                if ((count1 >= productComboBoxModel.getSize())
                        && (count2 >= productComboBoxModel.getSize())) {
                    Log.getInstance().show_error(this, "Error",
                            "All products are already configured", null);
                    return;
                }




                DSPDistrProductDialog dialog = new DSPDistrProductDialog(this, true,
                        tableModel1,
                        tableModel2,
                        productComboBoxModel,
                        0);
                
                dialog.show();
                int scope = dialog.getScope();
                int NumColumns = tableModel1.getColumnCount();
                DistrProductStructure[] dps = dialog.getDistrProduct1();
                if (dps != null) {
                    for (int k = 0; k < dps.length; k++) {
                        if (((scope == 0) || (scope == 1))
                                && !tableModel1.productExists(dps[k].product)) {

                            Object[] rowData = new Object[NumColumns];
                            rowData[0] = new String(dps[k].product);
                            tableModel1.addRow(rowData);

                        }

                        if (((scope == 0) || (scope == 2))
                                && !tableModel2.productExists(dps[k].product)) {

                            Object[] rowData = new Object[NumColumns];
                            rowData[0] = new String(dps[k].product);
                            tableModel2.addRow(rowData);

                        }
                    } // for k < dps.length

                } // dps != null


                return;
            } // "Add"


            if (action.equals("Delete")) {
                if (productTable1.getSelectionModel().isSelectionEmpty()
                        && productTable2.getSelectionModel().isSelectionEmpty()) {
                    Log.getInstance().show_error(this, "Error",
                            "Please select a product ",
                            null);
                    return;
                }

                int srows1[] = null;
                int srows2[] = null;
                String distprod1[] = null;
                String distprod2[] = null;

                if (!productTable1.getSelectionModel().isSelectionEmpty()) {
                    srows1 = productTable1.getSelectedRows();
                    distprod1 = new String[srows1.length];
                    for (int i = 0; i < srows1.length; i++) {
                        distprod1[i] = (String) productTable1.getValueAt(srows1[i], 0);
                    }
                }

                if (!productTable2.getSelectionModel().isSelectionEmpty()) {
                    srows2 = productTable2.getSelectedRows();
                    distprod2 = new String[srows2.length];
                    for (int i = 0; i < srows2.length; i++) {
                        distprod2[i] = (String) productTable2.getValueAt(srows2[i], 0);
                    }
                }



                DSPDistrProductModifyDialog dialog =
                        new DSPDistrProductModifyDialog(this, true,
                        idTextField.getText(),
                        action,
                        null,
                        distprod1, distprod2,
                        null);
                dialog.show();

                if (dialog.isOK()) {
                    String[] products = dialog.getProducts(1);
                    if (products != null) {
                        deleteProducts(tableModel1, products);
                        productTable1.clearSelection();
                    }

                    products = dialog.getProducts(2);
                    if (products != null) {
                        deleteProducts(tableModel2, products);
                        productTable2.clearSelection();
                    }
                }
                return;
            } //  Delete


            if (action.substring(0, 4).equals("Copy")) {
                javax.swing.JTable srcTable = null, destTable = null;
                DistrProductTableModel srcModel = null, destModel = null;
                java.util.Vector srcVector = null;
                String ka_value = null;
                javax.swing.JTextField destTextField = null;

                if (action.equals("Copy1-2")) {
                    srcTable = productTable1;
                    srcModel = tableModel1;
                    destTable = productTable2;
                    destModel = tableModel2;
                    ka_value = keepAliveTextField1.getText();
                    destTextField = keepAliveTextField2;
                }
                if (action.equals("Copy2-1")) {
                    srcTable = productTable2;
                    srcModel = tableModel2;
                    destTable = productTable1;
                    destModel = tableModel1;
                    ka_value = keepAliveTextField2.getText();
                    destTextField = keepAliveTextField1;
                }
                javax.swing.table.TableColumnModel columnModel = destTable.getColumnModel();
                java.util.Vector columnVector = srcModel.columnVector;

                srcVector = srcModel.getDataVector();
                int rows = srcVector.size();
                int cols = columnVector.size();
                java.util.Vector destVector = new java.util.Vector(rows);

                destModel.setNumRows(0);
                for (int i = 0; i < rows; i++) {
                    Object row_data[] = new Object[cols];
                    row_data[0] = new String((String) srcModel.getValueAt(i, 0));
                    destModel.addRow(row_data);
                }
                destModel.fireTableDataChanged();
                if (ka_value != null) {
                    destTextField.setText(ka_value);
                } else {
                    destTextField.setText("");
                }

            }




        } else {

            String action = evt.getActionCommand();
            DistrProductTableModel tableModel1;
            DistrProductTableModel tableModel2;

            tableModel1 = (DistrProductTableModel) productTable1.getModel();
            tableModel2 = (DistrProductTableModel) productTable2.getModel();

            

            if (productTable1.isEditing()) {
                productTable1.editingCanceled(new javax.swing.event.ChangeEvent(this));
            }
            if (productTable2.isEditing()) {
                productTable2.editingCanceled(new javax.swing.event.ChangeEvent(this));
            }


            if (action.equals("Add")) {
                int count1 = tableModel1.getRowCount();
                int count2 = tableModel2.getRowCount();



                if ((count1 >= productComboBoxModel.getSize())
                        && (count2 >= productComboBoxModel.getSize())) {
                    Log.getInstance().show_error(this, "Error",
                            "All products are already configured",
                            null);
                    return;
                }


                DistrProductDialog dialog = new DistrProductDialog(this, true,
                        tableModel1,
                        tableModel2,
                        productComboBoxModel,
                        distrConfigType,
                        0);

                dialog.show();
                int scope = dialog.getScope();
                DistrProductStructure[] dps = dialog.getDistrProduct1();
                if (dps != null) {
                    for (int k = 0; k < dps.length; k++) {
                        if ((scope == 1) || (scope == 2)) {
                            Object[] rowData;

                            if ((scope == 1)
                                    && !tableModel1.productExists(dps[k].product)) {
                                rowData = new Object[Constants.DistrProductColumnNames.length];
                                rowData[0] = new String(dps[k].product);
                                rowData[1] = new String(dps[k].format);
                                rowData[2] = new Integer(dps[k].delay);
                                rowData[3] = new Boolean(dps[k].freewheel);
                                rowData[4] = new Boolean(dps[k].newsplus_off);
                                StringBuffer sb = new StringBuffer();
                                sb.append(DistributorProductFlagOptions.getDerivedDataOptionString(dps[k].derived_data));
                                sb.append("|");
                                if (dps[k].derived_data_dictionary == null) {
                                    sb.append("NONE");
                                } else {
                                    sb.append(dps[k].derived_data_dictionary);
                                }
                                rowData[5] = sb.toString();
                                rowData[6] = new String(dps[k].permTemplate);
                                String s;
                                if (dps[k].language != null) {
                                    s = new String(dps[k].language);
                                } else {
                                    s = "Default";
                                }
                                rowData[7] = s;

                                if (dps[k].encoding != null) {
                                    s = new String(dps[k].encoding);
                                } else {
                                    s = "Default";
                                }
                                rowData[8] = s;
                                rowData[9] = dps[k].premium_filter;
                                rowData[10] = new Boolean(dps[k].sigabout);
                                tableModel1.addRow(rowData);
                            }

                            if ((scope == 2)
                                    && !tableModel2.productExists(dps[k].product)) {
                                rowData = new Object[Constants.DistrProductColumnNames.length];
                                rowData[0] = new String(dps[k].product);
                                rowData[1] = new String(dps[k].format);
                                rowData[2] = new Integer(dps[k].delay);
                                rowData[3] = new Boolean(dps[k].freewheel);
                                rowData[4] = new Boolean(dps[k].newsplus_off);
                                StringBuffer sb = new StringBuffer();
                                sb.append(DistributorProductFlagOptions.getDerivedDataOptionString(dps[k].derived_data));
                                sb.append("|");
                                if (dps[k].derived_data_dictionary == null) {
                                    sb.append("NONE");
                                } else {
                                    sb.append(dps[k].derived_data_dictionary);
                                }
                                rowData[5] = sb.toString();
                                rowData[6] = new String(dps[k].permTemplate);
                                String s;
                                if (dps[k].language != null) {
                                    s = new String(dps[k].language);
                                } else {
                                    s = "Default";
                                }
                                rowData[7] = s;

                                if (dps[k].encoding != null) {
                                    s = new String(dps[k].encoding);
                                } else {
                                    s = "Default";
                                }
                                rowData[8] = s;
                                rowData[9] = dps[k].premium_filter;                                
                                rowData[10] = new Boolean(dps[k].sigabout);
                                tableModel2.addRow(rowData);
                            }

                        } else if (scope == 0) {

                            Object[] rowData;
                            if (!tableModel1.productExists(dps[k].product)) {
                                rowData = new Object[Constants.DistrProductColumnNames.length];
                                rowData[0] = new String(dps[k].product);
                                rowData[1] = new String(dps[k].format);
                                rowData[2] = new Integer(dps[k].delay);
                                rowData[3] = new Boolean(dps[k].freewheel);
                                rowData[4] = new Boolean(dps[k].newsplus_off);
                                StringBuffer sb = new StringBuffer();
                                sb.append(DistributorProductFlagOptions.getDerivedDataOptionString(dps[k].derived_data));
                                sb.append("|");
                                if (dps[k].derived_data_dictionary == null) {
                                    sb.append("NONE");
                                } else {
                                    sb.append(dps[k].derived_data_dictionary);
                                }
                                rowData[5] = sb.toString();
                                rowData[6] = new String(dps[k].permTemplate);
                                String s;
                                if (dps[k].language != null) {
                                    s = new String(dps[k].language);
                                } else {
                                    s = "Default";
                                }
                                rowData[7] = s;

                                if (dps[k].encoding != null) {
                                    s = new String(dps[k].encoding);
                                } else {
                                    s = "Default";
                                }
                                rowData[8] = s;
                                rowData[9] = dps[k].premium_filter;
                                
                                rowData[10] = new Boolean(dps[k].sigabout);
                                tableModel1.addRow(rowData);
                            }


                            if (!tableModel2.productExists(dps[k].product)) {
                                rowData = new Object[Constants.DistrProductColumnNames.length];
                                rowData[0] = new String(dps[k].product);
                                rowData[1] = new String(dps[k].format);
                                rowData[2] = new Integer(dps[k].delay);
                                rowData[3] = new Boolean(dps[k].freewheel);
                                rowData[4] = new Boolean(dps[k].newsplus_off);
                                StringBuffer sb = new StringBuffer();
                                sb.append(DistributorProductFlagOptions.getDerivedDataOptionString(dps[k].derived_data));
                                sb.append("|");
                                if (dps[k].derived_data_dictionary == null) {
                                    sb.append("NONE");
                                } else {
                                    sb.append(dps[k].derived_data_dictionary);
                                }
                                rowData[5] = sb.toString();
                                rowData[6] = new String(dps[k].permTemplate);
                                String s;
                                if (dps[k].language != null) {
                                    s = new String(dps[k].language);
                                } else {
                                    s = "Default";
                                }
                                rowData[7] = s;

                                if (dps[k].encoding != null) {
                                    s = new String(dps[k].encoding);
                                } else {
                                    s = "Default";
                                }
                                rowData[8] = s;
                                rowData[9] = dps[k].premium_filter;
                                
                                rowData[10] = new Boolean(dps[k].sigabout);
                                tableModel2.addRow(rowData);
                            }
                        }
                    }
                    configModified = true;
                }
                return;
            }

            if (action.equals("Modify") || action.equals("Delete")) {
                if (productTable1.getSelectionModel().isSelectionEmpty()
                        && productTable2.getSelectionModel().isSelectionEmpty()) {
                    Log.getInstance().show_error(this, "Warning",
                            "Please select a product", null);
                    return;
                }

                int srows1[] = null;
                int srows2[] = null;
                String distprod1[] = null;
                String distprod2[] = null;
                DistrProductStructure dps = null;

                java.util.HashSet formats = null;

                if (distrConfigType == Constants.DJNEWS_LINEHANDLER) {
                    formats = new java.util.HashSet();
                    formats.add(Constants.GLB_IDS_FORMAT);
                } else {
                    formats = new java.util.HashSet(formatList);
                    formats.addAll(formatList_AD);
                }


                DSPSparseMatrixModel dspModel1 = null, dspModel2 = null;
                /*
                 * if (distrConfigType == Constants.DSP_LINEHANDLER) { try {
                 * CSCProductsModel m = ConfigComm.getCSCProductsModel();
                 * dspModel1 = new DSPSparseMatrixModel(m,1); dspModel2 = new
                 * DSPSparseMatrixModel(m,2); } catch (Exception e) {
                 * Log.getInstance().log_error("Error in loading DSP product
                 * formats", e);
                 *
                 * }
                 * }
                 */

                if (!productTable1.getSelectionModel().isSelectionEmpty()) {
                    srows1 = productTable1.getSelectedRows();
                    distprod1 = new String[srows1.length];
                    for (int i = 0; i < srows1.length; i++) {
                        distprod1[i] = (String) productTable1.getValueAt(srows1[i], 0);
                        java.util.HashSet prodFmts = new java.util.HashSet(ConfigComm.getCSCSparseMatrixModel().getProductFormats(distprod1[i]));

                        /*
                         * if (distrConfigType == Constants.DSP_LINEHANDLER) {
                         * if (dspModel1!=null) prodFmts = new
                         * java.util.HashSet(dspModel1.getProductFormats(distprod1[i]));
                         * else prodFmts = new
                         * java.util.HashSet(ConfigComm.getIDSProductFormatList());
                         * }
                         */
                        formats.retainAll(prodFmts);
                    }
                }

                if (!productTable2.getSelectionModel().isSelectionEmpty()) {
                    srows2 = productTable2.getSelectedRows();
                    distprod2 = new String[srows2.length];
                    for (int i = 0; i < srows2.length; i++) {
                        distprod2[i] = (String) productTable2.getValueAt(srows2[i], 0);
                        java.util.HashSet prodFmts = new java.util.HashSet(ConfigComm.getCSCSparseMatrixModel().getProductFormats(distprod2[i]));

                        /*
                         * if (distrConfigType == Constants.DSP_LINEHANDLER) {
                         * if (dspModel2!=null) prodFmts = new
                         * java.util.HashSet(dspModel2.getProductFormats(distprod2[i]));
                         * else prodFmts = new
                         * java.util.HashSet(ConfigComm.getIDSProductFormatList());
                         *
                         * }
                         */
                        formats.retainAll(prodFmts);
                    }
                }

                System.out.println("BEFORE DPS");

                dps = compareAllDPS(tableModel1, srows1, tableModel2, srows2);

                String[] fmts = null;
                if (!formats.isEmpty()) {
                    int s = formats.size();
                    fmts = new String[s];

                    fmts = (String[]) formats.toArray(fmts);
                }

                System.out.println("BEFORE DistrProductModifyDialog");

                DistrProductModifyDialog dialog =
                        new DistrProductModifyDialog(this, true,
                        idTextField.getText(),
                        action, fmts,
                        distprod1, distprod2,
                        dps, distrConfigType);
                dialog.show();

                System.out.println("AFTER DistrProductModifyDialog");
                if (dialog.isOK()) {
                    if (action.equals("Modify")) {
                        String format = (String) dialog.getAttribute("Format");
                        String filter = (String) dialog.getAttribute("FilterCodes");
                        Integer delay = (Integer) dialog.getAttribute("Delay");
                        Boolean freewheel = (Boolean) dialog.getAttribute("FreeWheel");
                        Boolean newsplus_off = (Boolean) dialog.getAttribute("NewsplusOff");
                        String deriveddata = (String) dialog.getAttribute("DerivedData");
                        String deriveddatadict = (String) dialog.getAttribute("DerivedDataDictionary");
                        String language = (String) dialog.getAttribute("Language");
                        String encoding = (String) dialog.getAttribute("Encoding");
                        String premium_filter = (String) dialog.getAttribute("PremiumCodes");
                        Boolean sigabout = (Boolean) dialog.getAttribute("SigAbout");
                        System.out.println("DD=" + deriveddata + " DDD=" + deriveddatadict);
                        String[] products = dialog.getProducts(1);
                        if (products != null) {
                            modifyProducts(tableModel1, products, format, delay,
                                    freewheel, newsplus_off, deriveddata, deriveddatadict,
                                    filter, language, encoding, premium_filter,
                                    sigabout);
                        }

                        products = dialog.getProducts(2);
                        if (products != null) {
                            modifyProducts(tableModel2, products, format, delay,
                                    freewheel, newsplus_off, deriveddata, deriveddatadict,
                                    filter, language, encoding, premium_filter,
                                    sigabout);
                        }
                    } else {
                        String[] products = dialog.getProducts(1);
                        if (products != null) {
                            deleteProducts(tableModel1, products);
                            productTable1.clearSelection();
                        }

                        products = dialog.getProducts(2);
                        if (products != null) {
                            deleteProducts(tableModel2, products);
                            productTable2.clearSelection();
                        }
                    }
                    configModified = true;
                }
                return;
            } // Modify || Delete


            if (action.substring(0, 4).equals("Copy")) {
                javax.swing.JTable srcTable = null, destTable = null;
                DistrProductTableModel srcModel = null, destModel = null;
                java.util.Vector srcVector = null;
                String ka_value = null;
                javax.swing.JTextField destTextField = null;

                if (action.equals("Copy1-2")) {
                    srcTable = productTable1;
                    srcModel = tableModel1;
                    destTable = productTable2;
                    destModel = tableModel2;
                    ka_value = keepAliveTextField1.getText();
                    destTextField = keepAliveTextField2;
                }
                if (action.equals("Copy2-1")) {
                    srcTable = productTable2;
                    srcModel = tableModel2;
                    destTable = productTable1;
                    destModel = tableModel1;
                    ka_value = keepAliveTextField2.getText();
                    destTextField = keepAliveTextField1;
                }


                javax.swing.table.TableColumnModel columnModel = destTable.getColumnModel();
                java.util.Vector columnVector = srcModel.columnVector;

                srcVector = srcModel.getDataVector();
                int rows = srcVector.size();
                int cols = columnVector.size();
                java.util.Vector destVector = new java.util.Vector(rows);

                destModel.setNumRows(0);
                for (int i = 0; i < rows; i++) {
                    Object row_data[] = new Object[cols];
                    row_data[0] = new String((String) srcModel.getValueAt(i, 0));
                    row_data[1] = new String((String) srcModel.getValueAt(i, 1));
                    row_data[2] = new Integer(((Integer) srcModel.getValueAt(i, 2)).intValue());
                    row_data[3] = new Boolean(((Boolean) srcModel.getValueAt(i, 3)).booleanValue());
                    row_data[4] = new Boolean(((Boolean) srcModel.getValueAt(i, 4)).booleanValue());
                    row_data[5] = new String((String) srcModel.getValueAt(i, 5));
                    row_data[6] = new String((String) srcModel.getValueAt(i, 6));
                    row_data[7] = new String((String) srcModel.getValueAt(i, 7));
                    row_data[8] = new String((String) srcModel.getValueAt(i, 8));
                    row_data[9] = new String((String) srcModel.getValueAt(i, 9));
                    row_data[10] = new Boolean(((Boolean) srcModel.getValueAt(i, 10)).booleanValue());
                    destModel.addRow(row_data);
                }
                destModel.fireTableDataChanged();
                if (ka_value != null) {
                    destTextField.setText(ka_value);
                } else {
                    destTextField.setText("");
                }

                configModified = true;
            }




        }





    }//GEN-LAST:event_productActionHandler

    private void updateDynamicConfig(int which, String host, StringBuffer respbuf) {


        if (distrConfigType == Constants.DSP_BROADCASTER) {
            boolean ka = false, stats = false;
            DistrProductTableModel tableModel = null;
            String id = idTextField.getText();
            String s1, s2;

            StringBuilder reqBuf = new StringBuilder();
            int ret = 0;


            s1 = (String) origConfig.get("STATISTICS_" + which);
            if (which == 1) {
                s2 = (String) statisticsComboBox1.getSelectedItem();
            } else {
                s2 = (String) statisticsComboBox2.getSelectedItem();
            }
            if (!s1.equals(s2)) {
                stats = true;
                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Statistics changed from " + s1 + " to " + s2);
                }
            }

            if (stats) {
                reqBuf.append(AdminComm.CHANGE_DISTRIBUTOR).append(" ").append(Constants.DEFAULT_KEEPALIVE).append(" ").append(s2).append(";");
            }



            if (reqBuf.length() > 0) {
                reqBuf.insert(0, id + ";");
                ret = AdminComm.sendDynamicMessage(AdminComm.LINE_HANDLER,
                        host, reqBuf.toString(), respbuf);

                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Command: " + reqBuf.toString());
                }
            } else {
                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Config not changed for DC-" + which);
                }
            }
            if (ret == 0) {
                respbuf.setLength(0);
            }
            if (ret == Constants.PROGRAM_NOT_RUNNING) {
                Log.getInstance().log_warning(respbuf.toString(), null);
                ret = 0;
                respbuf.setLength(0);
            }


        } else {

            boolean ka = false, stats = false;
            DistrProductTableModel tableModel = null;
            String id = idTextField.getText();
            String s1, s2;
            String k1, k2;



            StringBuffer permsBuf, changeBuf;

            permsBuf = new StringBuffer();
            changeBuf = new StringBuffer();
            StringBuffer formatMsg = new StringBuffer();
            int ret = 0;


            k1 = (String) origConfig.get("KEEPALIVE_" + which);
            if (which == 1) {
                k2 = keepAliveTextField1.getText();
            } else {
                k2 = keepAliveTextField2.getText();
            }
            if ((k2 != null) && (k2.trim().length() == 0)) {
                k2 = "-";
            }
            if ((k2 != null) && (!k1.equals(k2))) {
                ka = true;
                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Keep alive changed from " + k1 + " to " + k2);
                }
            }




            s1 = (String) origConfig.get("STATISTICS_" + which);
            if (which == 1) {
                s2 = (String) statisticsComboBox1.getSelectedItem();
            } else {
                s2 = (String) statisticsComboBox2.getSelectedItem();
            }
            if (!s1.equals(s2)) {
                stats = true;
                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Statistics changed from " + s1 + " to " + s2);
                }
            }

            if (ka || stats) {
                changeBuf.append(AdminComm.CHANGE_DISTRIBUTOR).append(" ").append(k2).append(" ").append(s2).append(";");
            }


            if (which == 1) {
                tableModel =
                        (DistrProductTableModel) productTable1.getModel();
            } else {
                tableModel =
                        (DistrProductTableModel) productTable2.getModel();
            }


            java.util.HashMap productMap = productMap1;
            if (which == 2) {
                productMap = productMap2;
            }




            int numProducts = tableModel.getRowCount();
            for (int np = 0; np < numProducts; np++) {
                String prod1 = (String) tableModel.getValueAt(np, 0);
                String fmt1 = (String) tableModel.getValueAt(np, 1);
                Integer delay1 = (Integer) tableModel.getValueAt(np, 2);
                Boolean freewheel1 = (Boolean) tableModel.getValueAt(np, 3);
                Boolean newsplusoff1 = (Boolean) tableModel.getValueAt(np, 4);
                String d1 = (String) tableModel.getValueAt(np, 5);
                String perms1 = (String) tableModel.getValueAt(np, 6);
                
                Boolean sigabout1 = (Boolean) tableModel.getValueAt(np, 10);
                Long flags1 = DistributorProductFlagOptions.getFlag(freewheel1, newsplusoff1, d1, sigabout1);

                if (productMap.containsKey(prod1)) {


                    Object r[] = (Object[]) productMap.get(prod1);
                    String prod2 = (String) r[0];
                    String fmt2 = (String) r[1];
                    Integer delay2 = (Integer) r[2];
                    Boolean freewheel2 = (Boolean) r[3];
                    Boolean newsplusoff2 = (Boolean) r[4];
                    String d2 = (String) r[5];
                    String perms2 = (String) r[6];
                    
                    Boolean sigabout2 = (Boolean) r[10];
                    Long flags2 = DistributorProductFlagOptions.getFlag(freewheel2, newsplusoff2, d2, sigabout2);

                    //System.out.println("Comparing prods:"+prod1+" "+prod2);
                    //System.out.println("Comparing prods:"+fmt1+" "+fmt2);
                    //System.out.println("Comparing prods:"+delay1+" "+delay2);
                    //System.out.println("Comparing prods:"+freewheel1+" "+freewheel2);
                    //System.out.println("Comparing prods:"+perms1+" "+perms2);

                    if (!fmt1.equals(fmt2)) {
                        formatMsg.append(prod1).append(" ");
                        Log.getInstance().log_error("Format cannot be changed dynamically",
                                null);
                        break;
                    }


                    if (!perms1.equals(perms2)) {
                        try {
                            if (perms1.equals("NONE")) {
                                permsBuf.append(AdminComm.SET_FILTERING_CODES).append(" ").append(prod1).append(";");

                            } else {
                                java.util.HashMap map =
                                        ConfigComm.getHashMapDirect(Constants.GLB_TAG_FILTERCODE_PREFIX + perms1);
                                permsBuf.append(AdminComm.SET_FILTERING_CODES).append(" ").append(prod1).append(" ").append((String) map.get("CODES")).append(";");
                            }
                        } catch (Exception e) {
                        }

                    }


                }

            }






            StringBuilder reqBuf = new StringBuilder();


            if (changeBuf.length() > 0) {
                reqBuf.append(changeBuf);
            }
            if (permsBuf.length() > 0) {
                //permsBuf.insert(0,AdminComm.SET_FILTERING_CODES);
                reqBuf.append(permsBuf);
            }


            if (Constants.DEBUG && Constants.Verbose > 2) {
                System.out.println("REQUESTBUFFER: " + reqBuf.toString());
            }

            if (reqBuf.length() > 0) {
                reqBuf.insert(0, id + ";");
                ret = AdminComm.sendDynamicMessage(AdminComm.LINE_HANDLER,
                        host, reqBuf.toString(), respbuf);

                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Command: " + reqBuf.toString());
                }
            } else {
                if (Constants.DEBUG && Constants.Verbose > 2) {
                    System.out.println("Config not changed for DC-" + which);
                }
            }
            if (ret == 0) {
                respbuf.setLength(0);
            }
            if (ret == Constants.PROGRAM_NOT_RUNNING) {
                Log.getInstance().log_warning(respbuf.toString(), null);
                ret = 0;
                respbuf.setLength(0);
            }


            /*
             * if (formatMsg.length() > 0) { respbuf.append("\nLine handler must
             * be (re)started to use new format(s): \n").append(formatMsg); }
             */


        }

    }

    /**
     * Exit the Application
     */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm


        if (isExiting) {
            return;
        }



        isExiting = true;

        final javax.swing.JPanel gpanel =
                (javax.swing.JPanel) getGlassPane();

        gpanel.setLayout(new java.awt.GridBagLayout());


        final StatusPanel sp = new StatusPanel();
        sp.setBackground(java.awt.Color.yellow);
        sp.start("Closing window.\nPlease wait..");

        gpanel.add(sp);
        gpanel.validate();
        gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
        gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
        gpanel.setVisible(true);


        final DistributorConfigurationForm This = this;

        final SwingWorker exitThread = new SwingWorker() {

            public Object construct() {
                try {
                    mLock.acquire();
                } catch (InterruptedException ie) {
                }
                return null;
            }

            public void finished() {
                This.setVisible(false);
                sp.stop();
                gpanel.removeAll();
                gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
                gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
                This.dispose();
                WindowEventAdapter.getInstance().unregisterWindow(This);
            }
        };

        exitThread.start();




    }//GEN-LAST:event_exitForm

    public static void main(String args[]) {

        try {
            ConfigComm.initLogin("test", "dist-c1d1,dist-c1d2", "/ids2");

            javax.swing.JFrame frame = null;

            /*
             * frame = new DistributorConfigurationForm("CAP2", false);
             * frame.show ();
             *
             * frame = new
             * DistributorConfigurationForm(Constants.DSP_BROADCASTER,"DLH1",
             * false);
             *
             * frame.show ();
             *
             *
             * frame = new DistributorConfigurationForm(null,	false); frame.show
             * ();
             *
             * frame = new
             * DistributorConfigurationForm(Constants.DSP_BROADCASTER,null,false);
             * frame.show ();
             *
             * frame = new
             * DistributorConfigurationForm(Constants.DSP_LINEHANDLER,null,false);
             * frame.show ();
             */

            frame = new DistributorConfigurationForm(-1, "FTP1", null,
                    false);

            frame.show();

            /*
             * frame = new DistributorConfigurationForm(-1,"EDS1", false);
             *
             * frame.show ();
             *
             * frame = new DistributorConfigurationForm(-1,null, false);
             *
             * frame.show ();
             */

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField idTextField;
    private javax.swing.JTextField descTextField;
    private javax.swing.JPanel platformPanel;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JComboBox dcmComboBox;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JCheckBox autoFailoverCheckBox;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JCheckBox highResolutionTimestampCheckBox;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JCheckBox newsplusOffCheckBox;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JCheckBox reutersKeepAliveAckCheckBox;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JCheckBox codeCheckBox;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JTextField codeTextField;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JPanel cardsPanel;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel productPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JLabel jLabel3;
    private ids2ui.IntTextField keepAliveTextField1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton jButton11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JComboBox locationComboBox1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JComboBox statisticsComboBox1;
    private javax.swing.JPanel productPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JLabel jLabel4;
    private ids2ui.IntTextField keepAliveTextField2;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JButton jButton12;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JComboBox statisticsComboBox2;
    private javax.swing.JComboBox locationComboBox2;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JButton jButton7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JButton jButton6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JComboBox deliveryTypesComboBox;
    private javax.swing.JTextField delayTextField;
    private javax.swing.JLabel timerLabel;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JComboBox contentTypesComboBox;
    private javax.swing.JCheckBox sendChangesCheckBox;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JComboBox takeComboBox;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JComboBox filenameGenerationComboBox;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JComboBox conversionTypesComboBox;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JComboBox encodingTypesComboBox;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JTextField extentionTextField;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JCheckBox mixedSchemaCheckBox;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel transportBoxPanel;
    private javax.swing.JPanel ftpTransportPanel;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JComboBox deliveryMethodsComboBox;
    private javax.swing.JPanel ftpCardsPanel;
    private javax.swing.JPanel paramsPanel;
    private javax.swing.JPanel ftpParamsPanel;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButton10;
    private ids2ui.StatusPanel statusPanel1;
    
    
    private javax.swing.JCheckBox summaryCheckBox;   
    private javax.swing.JLabel summaryLabel;
    // End of variables declaration//GEN-END:variables
}

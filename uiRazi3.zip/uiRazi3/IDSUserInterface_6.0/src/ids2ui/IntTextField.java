/*
**  SCCS Info :  "@(#)IntTextField.java	1.1    00/11/16"
*/
/*
 * IntTextField.java
 *
 * Created on March 7, 2000, 10:51 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class IntTextField extends javax.swing.JTextField {

  /** Creates new IntTextField */
  public IntTextField() {
     super();
  }
  
 
  public IntTextField(int cols) {
    super(cols);
  }

  protected javax.swing.text.Document createDefaultModel() {
    return new UpperCaseDocument();
  }

  static class UpperCaseDocument extends javax.swing.text.PlainDocument {

    public void insertString(int offs, String str, javax.swing.text.AttributeSet a) 
      throws javax.swing.text.BadLocationException {

      if (str == null) {
        return;
        }
      char[] upper = str.toCharArray();
      char[] upper1;
      int l=0;
      for (int i = 0; i < upper.length; i++) {
        if (Character.isDigit(upper[i]))
          upper[l++] = upper[i];
        else 
          java.awt.Toolkit.getDefaultToolkit().beep();
        
      }
      upper1 = new char [l];
      System.arraycopy(upper, 0, upper1, 0, l);
      super.insertString(offs, new String(upper1), a);
    }
  }

  
}

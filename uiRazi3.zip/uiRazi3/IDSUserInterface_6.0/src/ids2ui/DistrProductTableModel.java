/*
**  SCCS Info :  "%W%    %E%"
*/
/*
 * DistrProductTableModel.java
 *
 * Created on March 21, 2000, 1:31 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
  public class DistrProductTableModel 
  	extends javax.swing.table.AbstractTableModel 
  {
    
    public java.util.Vector columnVector;
    private java.awt.Container parentForDialog=null;
	protected int     m_sortCol = 0;
	protected boolean m_sortAsc = true;
	protected java.util.Vector m_vector = null;
	protected int m_columnsCount = Constants.DistrProductColumnNames.length;

	private boolean products_only = false;

      private javax.swing.JTable table = null;


  /** Creates new DistrProductTableModel */
  public DistrProductTableModel(java.awt.Container p) {
	init(p);
  }

  public DistrProductTableModel(java.awt.Container p, boolean prods_only) {
	products_only = prods_only;
	init(p);
  }


  public void setProductsOnlyView(boolean b) {
	products_only=b;
	if (products_only)
		m_columnsCount=1;
	fireTableStructureChanged();
  }


  public void setProductFilterView(javax.swing.JTable t) {
      java.util.Vector v = new java.util.Vector(10);
      table = t;
      javax.swing.table.TableColumnModel m = t.getColumnModel();
      for (int i = 0; i < m.getColumnCount(); i++) {
	  javax.swing.table.TableColumn tc = m.getColumn(i);
	  String s = (String)tc.getHeaderValue();
	  System.out.println("Header value = "+s);
	  if (s.startsWith("Product")
	      || s.startsWith("Filter Codes") )
	      continue;
	  v.add(tc);
      }
      
      if (v.size()>0) {
	  for (int i=0; i< v.size(); i++) {
	      javax.swing.table.TableColumn tc =
		  (javax.swing.table.TableColumn)v.get(i);
	      String s = (String)tc.getHeaderValue();
	      System.out.println("Removing Header value = "+s);
	      m.removeColumn(tc);
	      m_columnsCount--;
	      tc=null;
	  }
	  fireTableStructureChanged();
      }
      
  }



  private void init(java.awt.Container p) {
      parentForDialog=p;

	m_vector = new java.util.Vector();

	if (products_only)
		m_columnsCount=1;

    columnVector = new java.util.Vector(m_columnsCount);
    for (int i = 0; i < m_columnsCount; i++) {
      columnVector.add(Constants.DistrProductColumnNames[i]);
    }
  }
  
  
  public void setValueAt(Object value, int row, int col) {
     if (   (col == 2) 
                    && (value instanceof Integer)) { 
          try {
			  Object[] o = (Object[])m_vector.get(row);
			  o[col] = new Integer(((Integer)value).intValue());
              //super.setValueAt(new Integer(value.toString()), row, col);
          } catch (NumberFormatException e) {
              javax.swing.JOptionPane.showMessageDialog(parentForDialog,
                        "Please enter valid values.");
          }
       } if (col ==0) {
          for (int i = 0; i < getRowCount(); i++) {
            if (i == row ) continue;
			String p1 = value.toString().trim();
			String p2 = getValueAt(i,col).toString().trim();
            if (p1.equals(p2)) {
                javax.swing.JOptionPane.showMessageDialog(parentForDialog,
                        "Product "+p1+" is already added");
                return;
              }
            }
			Object[] o = (Object[])m_vector.get(row);
			o[col] = new String(value.toString());
            //super.setValueAt(value,row,col);
        
      } else {
			Object[] o = (Object[])m_vector.get(row);
			if (value instanceof Boolean )
				o[col] = new Boolean(((Boolean)value).booleanValue());
			if (value instanceof String)
				o[col] = new String((String)value);
				
                //super.setValueAt(value,row,col);
                //fireTableCellUpdated(row, col);
       }
    java.util.Collections.sort(m_vector, new 
        DistrProductComparator(m_sortCol, m_sortAsc));
		fireTableDataChanged();
  }
  
   public Class getColumnClass(int c) {
            Object o =  getValueAt(0, c);
            if (o == null)
                return Object.class;
            else
                 return o.getClass();
   }


    
	public int getRowCount() {
		return m_vector==null ? 0 : m_vector.size();
	}

	public int getColumnCount() { 
		return m_columnsCount;
	}


	public String getColumnName(int column) {
      	String str = Constants.DistrProductColumnNames[column];
		if (column==m_sortCol)
			str += m_sortAsc ? " \273" : " \253";
		return str;
	}
 
  public boolean isCellEditable(int nRow, int nCol) {

    /*
    **
    String colName = Constants.DistrProductColumnNames[nCol];
    if (colName.equals("Product")||colName.equals("Format"))
    	return false;
    return true;
    **
    */

    return false;
  }

  public Object getValueAt(int nRow, int nCol) {
    if (nRow < 0 || nRow>=getRowCount())
      return null;

	Object o =  ((Object[])m_vector.get(nRow))[nCol];
	if (o==null) return "";
	return o;
  }


  public boolean productExists(String p) {
	for (int m = 0; m < m_vector.size(); m++) {
		String prod = (String)((Object[])m_vector.get(m))[0];
		if (prod.equals(p))
			return true;
	}
	return false;
  }




  class ColumnListener extends java.awt.event.MouseAdapter
  {
    protected javax.swing.JTable m_table;

    public ColumnListener(javax.swing.JTable table) {
      m_table = table;
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
      javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
      int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
      int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	  if (m_table.isEditing()) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	  }
		
      if (modelIndex < 0)
        return;
      if (m_sortCol==modelIndex)
        m_sortAsc = !m_sortAsc;
      else
        m_sortCol = modelIndex;

      //for (int i=0; i < m_columnsCount; i++) {
      for (int i=0; i < m_table.getColumnCount(); i++) {
        javax.swing.table.TableColumn column = colModel.getColumn(i);
        column.setHeaderValue(getColumnName(column.getModelIndex()));    
      }
      m_table.getTableHeader().repaint();  

      java.util.Collections.sort(m_vector, new 
        DistrProductComparator(modelIndex, m_sortAsc));
      m_table.tableChanged(
        new javax.swing.event.TableModelEvent(DistrProductTableModel.this)); 
      m_table.repaint();  
    }
  }


class DistrProductComparator implements java.util.Comparator
{
  protected int     m_sortCol;
  protected boolean m_sortAsc;

  public DistrProductComparator(int sortCol, boolean sortAsc) {
    m_sortCol = sortCol;
    m_sortAsc = sortAsc;
  }

  public int compare(Object o1, Object o2) {
    //if(!(o1 instanceof java.util.Vector) || !(o2 instanceof java.util.Vector))
      //return 0;

    int result = 0;
	Object[] v1 = (Object[])o1;
	Object[] v2 = (Object[])o2;
    int d1, d2;
	String s1;
	String s2;
    switch (m_sortCol) {
      case 0:    // product
      case 1:    // format
      case 5:    // permissioning
		s1 = (String)v1[m_sortCol];
		s2 = (String)v2[m_sortCol];
        result = s1.compareTo(s2);
        break;
      case 2:    // delay
		try {
			d1 = ((Integer)v1[m_sortCol]).intValue();
			d2 = ((Integer)v2[m_sortCol]).intValue();
        	result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
		} catch (NumberFormatException nfe){}
        break;
      case 3:    // Free wheel
      case 4:    // News Plus Off
		try {
			s1 = ((Boolean)v1[m_sortCol]).toString();
			s2 = ((Boolean)v2[m_sortCol]).toString();
        	result = s1.compareTo(s2);
		} catch (NumberFormatException nfe){}
        break;
    }

    if (!m_sortAsc)
      result = -result;
    return result;
  }

  public boolean equals(Object obj) {
    return false;
  }
}
  
  public java.util.Vector getDataVector()
  {
	return m_vector;
  }

  public void addRow(Object[] row) 
  {
	m_vector.add(row);
    java.util.Collections.sort(m_vector, new 
        DistrProductComparator(m_sortCol, m_sortAsc));
		fireTableDataChanged();
  }

  public void removeRow(int row) 
  {
	m_vector.remove(row);
	fireTableDataChanged();
  }

  public void setNumRows(int n)
  {
	m_vector.setSize(n);
	fireTableDataChanged();
  }



}

/*
**  SCCS Info :  "%W%    %E%"
*/
/*
 * DistrProductModifyDialog.java
 *
 * Created on April 3, 2001, 3:40 PM
 */
 
package ids2ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.DistributorProductFlagOptions;
import model.PremiumCodesList;
import refactor.ui.forms.CodeTableDialog;
import refactor.ui.forms.DistrCodesEditPanel;
import refactor.ui.model.DistributorPremiumCodesListTableModel;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistrProductModifyDialog extends javax.swing.JDialog {

  private javax.swing.DefaultComboBoxModel formatComboModel;
  private javax.swing.DefaultComboBoxModel templateComboModel;
  private javax.swing.DefaultComboBoxModel derivedDataComboModel
	= new javax.swing.DefaultComboBoxModel(DistributorProductFlagOptions.DerivedDataOptions);
  private javax.swing.DefaultComboBoxModel derivedDataDictComboModel
	= new javax.swing.DefaultComboBoxModel(ConfigComm.getDerivedDataDictionaries());

  private javax.swing.DefaultComboBoxModel languageComboModel
	= new javax.swing.DefaultComboBoxModel(Constants.OutputLanguageOptions);

  private javax.swing.DefaultComboBoxModel encodingComboModel
	= new javax.swing.DefaultComboBoxModel(Constants.OutputEncodingOptions);


  private javax.swing.JList productList1, productList2;
  
  private String Action = null;
  private boolean okflag = false;
  
  
  /** Creates new form DistrProductModifyDialog */
  public DistrProductModifyDialog(java.awt.Frame parent,boolean modal,
			final String distrid,String action,
			String fmts[],
			String dps1[], 
                        String dps2[],
			DistrProductStructure defaults,
			int type	  )
  {
    super (parent, modal);

System.out.println("In DistrProductModifyDialog");


    if (parent != null)
      setLocationRelativeTo(parent);
    


    if (fmts == null) {
	formatComboModel = new javax.swing.DefaultComboBoxModel();
    } else {
	formatComboModel = new javax.swing.DefaultComboBoxModel(fmts) ;
    }


    TemplateListModel tModel = new TemplateListModel(this);
    templateComboModel = new javax.swing.DefaultComboBoxModel(tModel.toArray());
    for (int i = 0; i < templateComboModel.getSize(); i++) {
      Object o = templateComboModel.getElementAt(i);
      if (((String)o).equals(Constants.FILTER_CODES_NONE)) {
        templateComboModel.setSelectedItem(o);
        break;
      }
    }


  


    initComponents ();

    premiumTextField.setEditable(false);
    final javax.swing.JDialog pdlg = this;
      premiumEditButton.addActionListener(new ActionListener() {
          
          public void actionPerformed(ActionEvent e) {
              PremiumCodesList pcl = pcl = ConfigComm.getPremiumCodesList();
                    
              
              String s = premiumTextField.getText();
              CodeTableDialog dlg = new CodeTableDialog(pdlg, true, pcl, s);              
              
              StringBuilder title = new StringBuilder("Edit Premium codes");
              if (distrid != null)
                  title.append(":").append(distrid);
              dlg.setTitle(title.toString());
              
              dlg.setVisible(true);
              
              DistributorPremiumCodesListTableModel pcltm = dlg.getModel();
              if (pcltm != null) {
                  premiumTextField.setText(pcltm.toString());
              }
          }
      });
    
    if (fmts==null){
      formatCheckBox.setEnabled(false);
      formatComboBox.setEnabled(false);
    }
    
    java.awt.CardLayout card = (java.awt.CardLayout) optionsPanel.getLayout();  
    if (action.equalsIgnoreCase("Modify")) {     
      if (distrid!=null)
        setTitle("Edit products: "+distrid);
      else
        setTitle("Edit products");
	  if (defaults!=null) {
		formatCheckBox.setSelected(true);
		formatComboBox.setSelectedItem(defaults.format);

		filterCodesCheckBox.setSelected(true);
		filterCodesComboBox.setSelectedItem(defaults.permTemplate);

		delayCheckBox.setSelected(true);
		delayTextField.setText(Integer.toString(defaults.delay));

		fwCheckBox.setSelected(true);
		freeWheelCheckBox.setSelected(defaults.freewheel);

		npCheckBox.setSelected(true);
		newsplusOffCheckBox.setSelected(defaults.newsplus_off);

		ddCheckBox.setSelected(true);
		dddCheckBox.setSelected(true);
		System.out.println("DD="+defaults.derived_data);
		System.out.println("DDD="+defaults.derived_data_dictionary);
		derivedDataComboBox.setSelectedItem(DistributorProductFlagOptions.getDerivedDataOptionString(defaults.derived_data));
		derivedDataDictComboBox.setSelectedItem(defaults.derived_data_dictionary);

		langCheckBox.setSelected(true);
		encCheckBox.setSelected(true);

                premiumCheckBox.setSelected(true);
                
                if (defaults.language != null && defaults.language.length() > 0) {
                  if (languageComboModel.getIndexOf(defaults.language) < 0) {
                      languageComboModel.addElement(defaults.language);
                  }
                  languageComboBox.setSelectedItem(defaults.language);
              }

		if (defaults.encoding != null && defaults.encoding.length() > 0 )
                {
                    if (encodingComboModel.getIndexOf(defaults.encoding) < 0)
                    {
                        encodingComboModel.addElement(defaults.encoding);
                    }
                    encodingComboBox.setSelectedItem(defaults.encoding);
		}

                if (defaults.premium_filter != null && defaults.premium_filter.length() > 0)
                    premiumTextField.setText(defaults.premium_filter);
                
                sigAboutEditingCheckBox.setSelected(true);
                sigAboutCheckBox.setSelected(defaults.sigabout);
		setState();
	  }

    } else {      
      if (distrid!=null)
        setTitle("Delete products: "+distrid);
      else
        setTitle("Delete products");
    }
    
    card.show(optionsPanel,action);
    Action = new String(action);
    
    
    javax.swing.JScrollPane scroller;

    if (dps1!=null) {
      int num_prods = dps1.length;          
      String[] plist = new String[num_prods];
      for (int i = 0; i < num_prods; i++)
        plist[i] = new String(dps1[i]);
      
      productList1 = new javax.swing.JList(plist);      
      scroller = new javax.swing.JScrollPane(productList1);
      prodPanel1.add(scroller);
      productList1.setSelectionInterval(0,num_prods-1);
    } else {     
      productList1=null;
      selectButton1.setEnabled(false);
      unselectButton1.setEnabled(false);
      prodPanel1.setEnabled(false);
    }
    


    if (dps2!=null) {
      int num_prods = dps2.length;
      String[] plist = new String[num_prods];
      for (int i = 0; i < num_prods; i++)
        plist[i] = new String(dps2[i]);
      
      productList2 = new javax.swing.JList(plist);      
      scroller = new javax.swing.JScrollPane(productList2);            
      prodPanel2.add(scroller);
      productList2.setSelectionInterval(0,num_prods-1);
    } else {   
      productList2=null;
      selectButton2.setEnabled(false);
      unselectButton2.setEnabled(false);
      prodPanel2.setEnabled(false);
    }

    if (type == Constants.DJNEWS_LINEHANDLER) {
	//delayCheckBox.setVisible(false);
	fwCheckBox.setVisible(false);
	freeWheelCheckBox.setVisible(false);
	//npCheckBox.setVisible(false);
	//newsplusOffCheckBox.setVisible(false);
	//delayTextField.setVisible(false);
	formatCheckBox.setVisible(false);
	formatComboBox.setVisible(false);
	
    }

    pack ();




  }


  public boolean isOK() {
	return okflag;
  }

  public String[] getProducts(int dc){
	javax.swing.JList list = null;
	
	if (!okflag) return null;

	if (dc == 1) {
		if ( productList1==null) return null;
		list = productList1;
	} else if (dc == 2) {
		if ( productList2==null) return null;
		list = productList2;
	} else 
		return null;
        
	if (list.isSelectionEmpty())
          return null;
        
        Object sv[] = list.getSelectedValues();
        
        String[] products = new String[sv.length];
        for (int i = 0; i < sv.length; i++)
          products[i] = new String((String)sv[i]);
        
	return products;	
  }

  public Object getAttribute(String name) {
	
	if (!okflag || !Action.equalsIgnoreCase("Modify")) return null;

	if (name.equalsIgnoreCase("Format")) {
		if (!formatCheckBox.isSelected()) return null;
		return new String((String)formatComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("FilterCodes")) {
		if (!filterCodesCheckBox.isSelected()) return null;
		return new String((String)filterCodesComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("Delay")) {
		if (!delayCheckBox.isSelected()) return null;
		return new Integer(delayTextField.getText());
	} else if (name.equalsIgnoreCase("FreeWheel")) {
		if (!fwCheckBox.isSelected()) return null;
		return new Boolean(freeWheelCheckBox.isSelected());
	} else if (name.equalsIgnoreCase("NewsplusOff")) {
		if (!npCheckBox.isSelected()) return null;
		return new Boolean(newsplusOffCheckBox.isSelected());
	} else if (name.equalsIgnoreCase("DerivedData")) {
		if (!ddCheckBox.isSelected()) return null;
		return new String((String)derivedDataComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("DerivedDataDictionary")) {
		if (!ddCheckBox.isSelected()) return null;
		return new String((String)derivedDataDictComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("Language")) {
		if (!langCheckBox.isSelected()) return null;
		return new String((String)languageComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("Encoding")) {
		if (!encCheckBox.isSelected()) return null;
		return new String((String)encodingComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("PremiumCodes")) {
		if (!premiumCheckBox.isSelected()) return null;
		return new String((String)premiumTextField.getText());
	} else if (name.equalsIgnoreCase("SigAbout")) {
		if (!sigAboutEditingCheckBox.isSelected()) return null;
		return new Boolean(sigAboutCheckBox.isSelected());
	} 
		return null;

  }


  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
  private void initComponents () {//GEN-BEGIN:initComponents
    jPanel2 = new javax.swing.JPanel ();
    jButton2 = new javax.swing.JButton ();
    jButton3 = new javax.swing.JButton ();
    productPanel = new javax.swing.JPanel ();
    prodPanel1 = new javax.swing.JPanel ();
    prodPanel2 = new javax.swing.JPanel ();
    jPanel3 = new javax.swing.JPanel ();
    selectButton1 = new javax.swing.JButton ();
    unselectButton1 = new javax.swing.JButton ();
    jPanel4 = new javax.swing.JPanel ();
    selectButton2 = new javax.swing.JButton ();
    unselectButton2 = new javax.swing.JButton ();
    optionsPanel = new javax.swing.JPanel ();
    jPanel1 = new javax.swing.JPanel ();
    formatComboBox = new javax.swing.JComboBox(formatComboModel);
    delayTextField = new ids2ui.IntTextField ();
    freeWheelCheckBox = new javax.swing.JCheckBox ();
    filterCodesComboBox = new javax.swing.JComboBox((javax.swing.ComboBoxModel)templateComboModel);
    formatCheckBox = new javax.swing.JCheckBox ();
    delayCheckBox = new javax.swing.JCheckBox ();
    fwCheckBox = new javax.swing.JCheckBox ();
    ddCheckBox = new javax.swing.JCheckBox ();
    dddCheckBox = new javax.swing.JCheckBox ();
    filterCodesCheckBox = new javax.swing.JCheckBox ();
    npCheckBox = new javax.swing.JCheckBox ();
    newsplusOffCheckBox = new javax.swing.JCheckBox ();
    derivedDataComboBox = new javax.swing.JComboBox (derivedDataComboModel);
    derivedDataDictComboBox = new javax.swing.JComboBox (derivedDataDictComboModel);
    langCheckBox = new javax.swing.JCheckBox ();
    encCheckBox = new javax.swing.JCheckBox ();
    languageComboBox = new javax.swing.JComboBox (languageComboModel);
    encodingComboBox = new javax.swing.JComboBox (encodingComboModel);
    jPanel5 = new javax.swing.JPanel ();
    jLabel1 = new javax.swing.JLabel ();
    
    premiumCheckBox = new javax.swing.JCheckBox("Premium Codes");
    premiumTextField = new javax.swing.JTextField();
    premiumEditButton = new javax.swing.JButton("Edit");
    
    sigAboutEditingCheckBox = new javax.swing.JCheckBox("Sig/About");
    sigAboutCheckBox = new javax.swing.JCheckBox();
    
    getContentPane ().setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints1;
    addWindowListener (new java.awt.event.WindowAdapter () {
      public void windowClosing (java.awt.event.WindowEvent evt) {
        closeDialog (evt);
      }
    }
    );

    jPanel2.setLayout (new java.awt.FlowLayout (1, 15, 5));

      jButton2.setText ("OK");
      jButton2.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          dialogActionHandler (evt);
        }
      }
      );
  
      jPanel2.add (jButton2);
  
      jButton3.setText ("Cancel");
      jButton3.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          dialogActionHandler (evt);
        }
      }
      );
  
      jPanel2.add (jButton3);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 2;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (jPanel2, gridBagConstraints1);

    productPanel.setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints2;
    productPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 10, 10)));

      prodPanel1.setLayout (new javax.swing.BoxLayout (prodPanel1, 0));
      prodPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 5, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("Data center-I: products"))));
  
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 0;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      gridBagConstraints2.weighty = 1.0;
      productPanel.add (prodPanel1, gridBagConstraints2);
  
      prodPanel2.setLayout (new javax.swing.BoxLayout (prodPanel2, 0));
      prodPanel2.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 5, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("Data center-II:products"))));
  
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 1;
      gridBagConstraints2.gridy = 0;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      gridBagConstraints2.weighty = 1.0;
      productPanel.add (prodPanel2, gridBagConstraints2);
  
      jPanel3.setLayout (new java.awt.FlowLayout (1, 10, 5));
  
        selectButton1.setMargin (new java.awt.Insets(2, 7, 2, 7));
        selectButton1.setText ("Select all");
        selectButton1.setActionCommand ("Select all 1");
        selectButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel3.add (selectButton1);
    
        unselectButton1.setMargin (new java.awt.Insets(2, 7, 2, 7));
        unselectButton1.setText ("Unselect all");
        unselectButton1.setActionCommand ("Unselect all 1");
        unselectButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel3.add (unselectButton1);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      productPanel.add (jPanel3, gridBagConstraints2);
  
      jPanel4.setLayout (new java.awt.FlowLayout (1, 10, 5));
  
        selectButton2.setMargin (new java.awt.Insets(2, 7, 2, 7));
        selectButton2.setText ("Select all");
        selectButton2.setActionCommand ("Select all 2");
        selectButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel4.add (selectButton2);
    
        unselectButton2.setMargin (new java.awt.Insets(2, 7, 2, 7));
        unselectButton2.setText ("Unselect all");
        unselectButton2.setActionCommand ("Unselect all 2");
        unselectButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel4.add (unselectButton2);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 1;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      productPanel.add (jPanel4, gridBagConstraints2);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
    gridBagConstraints1.weightx = 1.0;
    gridBagConstraints1.weighty = 1.0;
    getContentPane ().add (productPanel, gridBagConstraints1);

    optionsPanel.setLayout (new java.awt.CardLayout ());

      jPanel1.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints3;
      jPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 10, 10, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.TitledBorder("Select attributes to edit"),
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)))));
  
        formatComboBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (formatComboBox, gridBagConstraints3);
    
        delayTextField.setColumns (10);
        delayTextField.setText ("0");
        delayTextField.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (delayTextField, gridBagConstraints3);
    
        freeWheelCheckBox.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
        freeWheelCheckBox.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
        freeWheelCheckBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (freeWheelCheckBox, gridBagConstraints3);
    
        filterCodesComboBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (filterCodesComboBox, gridBagConstraints3);
    
        formatCheckBox.setText ("Format");
        formatCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (formatCheckBox, gridBagConstraints3);
    
        delayCheckBox.setText ("Delay (mins.)");
        delayCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 25, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (delayCheckBox, gridBagConstraints3);
    
        fwCheckBox.setText ("Free Wheel");
        fwCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 25, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (fwCheckBox, gridBagConstraints3);
    
        filterCodesCheckBox.setText ("Filter codes");
        filterCodesCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (filterCodesCheckBox, gridBagConstraints3);
    
        npCheckBox.setText ("Block WSJ links");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 2;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (npCheckBox, gridBagConstraints3);

        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 2;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (newsplusOffCheckBox, gridBagConstraints3);

        ddCheckBox.setText ("Derived Data");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 2;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (ddCheckBox, gridBagConstraints3);

        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 2;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (derivedDataComboBox, gridBagConstraints3);

        dddCheckBox.setText ("Derived Data Dictionary");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 3;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (dddCheckBox, gridBagConstraints3);

        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 3;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (derivedDataDictComboBox, gridBagConstraints3);

        langCheckBox.setText ("Language");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 4;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (langCheckBox, gridBagConstraints3);
        languageComboBox.setEditable (true);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 4;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (languageComboBox, gridBagConstraints3);

        encCheckBox.setText ("Encoding");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 4;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (encCheckBox, gridBagConstraints3);

        encodingComboBox.setEditable (true);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 4;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (encodingComboBox, gridBagConstraints3);


        /***/
        
        DistrCodesEditPanel panel = new DistrCodesEditPanel();
        
        premiumEditButton = panel.getButton();
        premiumTextField =  panel.getTextField();
        premiumCheckBox = panel.getCheckBox();
        
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 5;
        gridBagConstraints3.gridwidth = 4;
        gridBagConstraints3.insets = new java.awt.Insets (5, 0, 5, 5);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (panel, gridBagConstraints3);
        
        /***/
        sigAboutEditingCheckBox.setText ("Sig/About");
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 6;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (sigAboutEditingCheckBox, gridBagConstraints3);

        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 6;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (sigAboutCheckBox, gridBagConstraints3);

        /***/
        
        
        

      optionsPanel.add (jPanel1, "Modify");
  
      jPanel5.setLayout (new java.awt.FlowLayout (1, 5, 25));
  
        jLabel1.setText ("The selected products will be deleted.");
    
        jPanel5.add (jLabel1);
    
      optionsPanel.add (jPanel5, "Delete");
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 1;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (optionsPanel, gridBagConstraints1);

  }//GEN-END:initComponents

private void selectActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectActionHandler
// Add your handling code here:
    javax.swing.JList list = productList1;
    String command = evt.getActionCommand();
    if (command.endsWith("2"))
      list = productList2;
    int num_prods = list.getModel().getSize();
    if (command.startsWith("Select"))
      list.setSelectionInterval(0,num_prods-1);
    else
      list.clearSelection();
    
  }//GEN-LAST:event_selectActionHandler

private void dialogActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dialogActionHandler
// Add your handling code here:
  if (evt.getActionCommand().equals("OK")) {

	if (ddCheckBox.isSelected() ) {
	int opt = DistributorProductFlagOptions.getDerivedDataOptionFlag((String)derivedDataComboBox.getSelectedItem());
        String s =  (String)derivedDataDictComboBox.getSelectedItem();
System.out.println("OPT="+opt+" "+(String)derivedDataComboBox.getSelectedItem() +" "+ s);
        if ( (opt > 0) && ( (s==null) || s.equalsIgnoreCase("NONE") ) )
        {
          javax.swing.JOptionPane.showMessageDialog(this,"Please select a dictionary","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;

        }
        if ( (opt < 1) && (s!=null) && !s.equalsIgnoreCase("NONE") )
        {
          javax.swing.JOptionPane.showMessageDialog(this,"Cannot select dictionary without derived data ","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;
        }

	}
	okflag = true;


  }        
    closeDialog(null);
  }//GEN-LAST:event_dialogActionHandler

private void cbActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbActionHandler
// Add your handling code here:

	setState();

  }

private void setState() {
	
	
	if (formatCheckBox.isSelected())
		formatComboBox.setEnabled(true);
	else
		formatComboBox.setEnabled(false);
		
	if (filterCodesCheckBox.isSelected())
		filterCodesComboBox.setEnabled(true);
	else
		filterCodesComboBox.setEnabled(false);

	if (delayCheckBox.isSelected())
		delayTextField.setEnabled(true);
	else
		delayTextField.setEnabled(false);

	if (fwCheckBox.isSelected())
		freeWheelCheckBox.setEnabled(true);
	else
		freeWheelCheckBox.setEnabled(false);

	if (npCheckBox.isSelected())
		newsplusOffCheckBox.setEnabled(true);
	else
		newsplusOffCheckBox.setEnabled(false);
        
        boolean state = false;
        if (premiumCheckBox.isSelected())
         state = true;
        premiumTextField.setEnabled(state);
        premiumEditButton.setEnabled(state);

  }//GEN-LAST:event_cbActionHandler

  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
    setVisible (false);
    dispose ();
  }//GEN-LAST:event_closeDialog



  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel productPanel;
  private javax.swing.JPanel prodPanel1;
  private javax.swing.JPanel prodPanel2;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JButton selectButton1;
  private javax.swing.JButton unselectButton1;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JButton selectButton2;
  private javax.swing.JButton unselectButton2;
  private javax.swing.JPanel optionsPanel;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JComboBox formatComboBox;
  private javax.swing.JComboBox derivedDataComboBox;
  private javax.swing.JComboBox derivedDataDictComboBox;
  private ids2ui.IntTextField delayTextField;
  private javax.swing.JCheckBox freeWheelCheckBox;
  private javax.swing.JComboBox filterCodesComboBox;
  private javax.swing.JCheckBox formatCheckBox;
  private javax.swing.JCheckBox delayCheckBox;
  private javax.swing.JCheckBox fwCheckBox;
  private javax.swing.JCheckBox ddCheckBox;
  private javax.swing.JCheckBox dddCheckBox;
  private javax.swing.JCheckBox filterCodesCheckBox;
  private javax.swing.JCheckBox npCheckBox;
  private javax.swing.JCheckBox newsplusOffCheckBox;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JCheckBox langCheckBox;
  private javax.swing.JCheckBox encCheckBox;
  private javax.swing.JComboBox languageComboBox;
  private javax.swing.JComboBox encodingComboBox;
  
  private javax.swing.JCheckBox premiumCheckBox;
  private javax.swing.JTextField premiumTextField;
  private javax.swing.JButton premiumEditButton;
  
  
    private javax.swing.JCheckBox sigAboutEditingCheckBox;
    private javax.swing.JCheckBox sigAboutCheckBox;
  // End of variables declaration//GEN-END:variables

}

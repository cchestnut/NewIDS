/*
**  SCCS Info :  "%W%    %E%"
*/
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import model.DistributorProductFlagOptions;
import model.PremiumCodesList;

 

public class ConfigComm {

    static javax.swing.ProgressMonitor progressMonitor = null;
        
        
    static public void 
        initLoginLite(String unm, String sl,String idir)
	throws Exception
    {
	userName = new String(unm);
	serverList = new String(sl);
	String idsdir = new String(idir);
				
	lastServer=null;
				
	Log.getInstance().log_warning("ConfigComm:Using server list: "
				      +serverList,null);
	Log.getInstance().log_warning("IDS="+idsdir,null);
				
	
    }
		
    static public void 
        initLogin(String unm, String sl,String idir)
	throws Exception
    {
	updateStatus(0);
	initLoginLite( unm,  sl, idir);
	    
	loadConfiguration();
    }


    static public void 
        setProgressMonitor(javax.swing.ProgressMonitor pm) 
    {
	progressMonitor = pm;
    }
        
                        
                        
		
    static public void resetLogin()
    {
  
	CacheManager.clearCache();
	DCMDistributorConfigCache.stop();
                
	statisticsVector=null;
	systemFileVector=null;
	transportTypeVector=null;
	productFormatVector=null;
	dcmSoftwareVersionVector=null;
	dspSoftwareVersionVector=null;
	dcmTypeVector=null;
	readerProtocolVector=null;
	locationList = null;
                

	djnewsDCMTransportTypeVector=null;
	idsTransportTypeVector=null;
	idsProductFormatVector=null;

	dcmVector = null;


	productTypesVector=null;
	RTP_KeysVector=null;
	fixedLocationsMap.clear();

                


	contentTypesVector=null;
	deliveryTypesVector=null;
	conversionTypesVector=null;
	deliveryMethodsVector=null;
	encodingListVector=null;
	fileGenerationTypesVector=null;
	takeTypesVector=null;
	derivedDataDictionariesVector=null;
	outputEncodingListVector=null;




	userName=null;
	serverList=null;
	lastServer=null;
                
	ConfigConnection.closeConnectionPool();
    }




    private static void
        updateStatus(final int status)
	throws InterruptedException
    {
	if (progressMonitor != null) {
	    if (progressMonitor.isCanceled())
		throw new InterruptedException("Login Canceled");
                        
	    Runnable doSetProgressBarValue = new Runnable() {
		    public void run() {
			progressMonitor.setProgress(status);
		    }
		};
	    javax.swing.SwingUtilities.invokeLater(doSetProgressBarValue);
                        
	}
    }
        

    static public void loadConfiguration()
	throws Exception
    {
				
	/*
	**
	FILTER_CODES_NONE      ="NONE";
	DISTRIBUTOR_ID_SIZE = 4;
	**
	*/
                

	int status = 1;
                
	Constants.DEFAULT_KEEPALIVE = 
	    new String(getStringValue("DEFAULT_KEEPALIVE"));
	updateStatus(status++);

                
                
	Constants.DSP_DEFAULT_KEEPALIVE_FORMAT = 
	    new String(getStringValue("DSP_DEFAULT_KEEPALIVE_FORMAT"));
	updateStatus(status++);

                
		
	Constants.DSP_DEFAULT_INPUT_TRANSPORT = 
	    new String(getStringValue("DSP_DEFAULT_INPUT_TRANSPORT"));
	updateStatus(status++);

                
		
	Constants.DSP_DEFAULT_INPUT_FORMAT = 
	    new String(getStringValue("DSP_DEFAULT_INPUT_FORMAT"));
	updateStatus(status++);

                        
	Constants.DSP_DEFAULT_INPUT_PROTOCOL = 
	    new String(getStringValue("DSP_DEFAULT_INPUT_PROTOCOL"));
	updateStatus(status++);


                
                
	Constants.DSP_DEFAULT_DELAY =
	    Integer.parseInt(getStringValue("DSP_DEFAULT_DELAY").trim());

	updateStatus(status++);


                
	String s = getStringValue("DSP_DEFAULT_FREEWHEEL");

	Constants.DSP_DEFAULT_FREEWHEEL=false;
	if (s.equalsIgnoreCase("TRUE")
	    || s.startsWith("Y")
	    || s.startsWith("y")) 
	    Constants.DSP_DEFAULT_FREEWHEEL=true;
	updateStatus(status++);




	Constants.DSP_USE_VERITAS_COMMANDS
	    = getBooleanValue("DSP_USE_VERITAS_COMMANDS", true);

	updateStatus(status++);

                

                
                
	Constants.DSP_DEFAULT_FILTER_CODES = 
	    new String(getStringValue("DSP_DEFAULT_FILTER_CODES"));
	updateStatus(status++);

                

	Constants.DSP_DEFAULT_LINEHANDLER_MODE = 
	    new String(getStringValue("DSP_DEFAULT_LINEHANDLER_MODE"));
	updateStatus(status++);


                

                
	Constants.GLB_IDS_PROTOCOL = 
	    new String(getStringValue("GLB_IDS_PROTOCOL"));
	updateStatus(status++);

                
	Constants.GLB_IDS_FORMAT = 
	    new String(getStringValue("GLB_IDS_FORMAT"));
	updateStatus(status++);

                
	Constants.GLB_IDS_TRANSPORT = 
	    new String(getStringValue("GLB_IDS_TRANSPORT"));
	updateStatus(status++);

                
	Constants.GLB_IDS_TRANSPORT_ADDRESS = 
	    new String(getStringValue("GLB_IDS_TRANSPORT_ADDRESS"));
	updateStatus(status++);

                
	Constants.RBP_INTERFACE_LIST = 
	    new String(getStringValue("RBP_INTERFACE_LIST"));
	updateStatus(status++);
                
				
	Constants.GLB_DCM_INPUT_NAME =
	    new String(getStringValue("GLB_DCM_INPUT_NAME"));
	updateStatus(status++);

                

	Constants.DSP_DEFAULT_KEEPALIVE = Constants.DEFAULT_KEEPALIVE;
				
	Constants.GLB_RETRANS_FORMAT_LIST =
	    new String(getStringValue("GLB_RETRANS_FORMAT_LIST"));
	updateStatus(status++);
                
				
	try {
	    Constants.GLB_ADMIN_FORMAT_LIST 
		= new String(getRawValue("GLB_ADMIN_FORMAT_LIST"));
	} catch (Exception e) {
	    Constants.GLB_ADMIN_FORMAT_LIST = Constants.ADMIN_DEFAULT_FORMAT_LIST;
	}
	updateStatus(status++);



                

	try {
	    Constants.DEFAULT_SW_VERSION_DIR 
		= new String(getStringValue("GLB_DEFAULT_SW_VERSION_DIR"));
	} catch (Exception e) {
	    Constants.DEFAULT_SW_VERSION_DIR = "rel";
	}
	updateStatus(status++);
                


	try {
	    Constants.GLB_DSP_SW_VERSION_LIST 
		= new String(getRawValue("GLB_DSP_SW_VERSION_LIST"));
	} catch (Exception e) {
	    Constants.GLB_DSP_SW_VERSION_LIST = "1.0	1.1";
	}
	updateStatus(status++);

                
                
	try {
	    Constants.GLB_DCM_SW_VERSION_LIST 
		= new String(getRawValue("GLB_DCM_SW_VERSION_LIST"));
	} catch (Exception e) {
	    Constants.GLB_DCM_SW_VERSION_LIST = "1.0	1.1";
	}
	updateStatus(status++);



                

	try {
	    Constants.GLB_DSP_DISTR_CHECKPOINT_STRING 
		= new String(getRawValue("GLB_DSP_DISTR_CHECKPOINT_STRING"));
	} catch (Exception e) {
	    Constants.GLB_DSP_DISTR_CHECKPOINT_STRING 
		= Constants.DEFAULT_DISTR_CHECKPOINT_STRING;
	}
	updateStatus(status++);



                

	try {
	    Constants.GLB_DCM_DISTR_CHECKPOINT_STRING 
		= new String(getRawValue("GLB_DCM_DISTR_CHECKPOINT_STRING")).trim();
	} catch (Exception e) {
	    Constants.GLB_DCM_DISTR_CHECKPOINT_STRING
		= Constants.DEFAULT_DISTR_CHECKPOINT_STRING;
	}
	updateStatus(status++);



                
	try {
	    String d
		= new String(getRawValue("DCM_READER_MSGMGR_DELAY"));
	    Constants.DCM_READER_MSGMGR_DELAY = Integer.parseInt(d.trim());
	} catch (Exception e) {
	    Constants.DCM_READER_MSGMGR_DELAY
		= Constants.DEFAULT_DCM_READER_MSGMGR_DELAY;
	}
	updateStatus(status++);


                

	try {
	    String d
		= new String(getRawValue("DSP_READER_MSGMGR_DELAY"));
	    Constants.DSP_READER_MSGMGR_DELAY = Integer.parseInt(d.trim());
	} catch (Exception e) {
	    Constants.DSP_READER_MSGMGR_DELAY
		= Constants.DEFAULT_DSP_READER_MSGMGR_DELAY;
	}
	updateStatus(status++);



                
	try {
	    String d
		= new String(getRawValue("DCM_MSGMGR_MULTI2UNI_DELAY"));
	    Constants.DCM_MSGMGR_MULTI2UNI_DELAY = Integer.parseInt(d.trim());
	} catch (Exception e) {
	    Constants.DCM_MSGMGR_MULTI2UNI_DELAY
		= Constants.DEFAULT_DCM_MSGMGR_MULTI2UNI_DELAY;
	}
	updateStatus(status++);

	try {
	    String d
		= new String(getRawValue("DCM_DISTRIBUTOR_DORMANT_START_DELAY"));
	    int x = Integer.parseInt(d.trim());
	    if ( (x >= 5) && (x <= 300))
		Constants.DCM_DISTRIBUTOR_DORMANT_START_DELAY = x;
                        
	} catch (Exception e) {
	}
	updateStatus(status++);

                
	try {
	    String d
		= new String(getRawValue("DCM_DISTRIBUTOR_SWITCH_MODE_DELAY"));
	    int x = Integer.parseInt(d.trim());
	    if ( (x >= 0) && (x <= 300))
		Constants.DCM_DISTRIBUTOR_SWITCH_MODE_DELAY = x;
	} catch (Exception e) {
	}
	updateStatus(status++);

                
                
	_getStatisticsList();updateStatus(status++);
	_getSystemFileList();updateStatus(status++);
	_getProductFormatList();updateStatus(status++);
	_getReaderProtocolList();updateStatus(status++);
	_getTransportTypeList();updateStatus(status++);
	_getDCMSoftwareVersionList();updateStatus(status++);
	_getDSPSoftwareVersionList();updateStatus(status++);
	_getDCMTypeList();updateStatus(status++);
		
	_getIDSProductFormatList();updateStatus(status++);
	_getIDSTransportTypeList();updateStatus(status++);

                

	try {
                        
	    _getLocationList();
	} catch (Exception e){
	    locationList = null;
	}
	updateStatus(status++);
                

	try {
	    _getDJNEWSDCMTransportTypeList();
	} catch (Exception e){
	    djnewsDCMTransportTypeVector = null;
	}
	updateStatus(status++);

                
	try {
	    Constants.DCM_VECTOR =
		getDCMList();
	    java.util.Collections.sort(Constants.DCM_VECTOR);
	} catch (DBException dbe ) {
	    int errno = dbe.getErrorNo();
	    if (errno != Constants.KEY_NOT_FOUND)
		throw dbe;
	}
	updateStatus(status++);
		

	cscProductsModel= new CSCProductsModel();
	cscSparseMatrixModel = new CSCSparseMatrixModel(cscProductsModel);
	updateStatus(status++);
	/*
	  try {
	  _getRTPHostKeys();
	  } catch (Exception e) 
	*/
	{
	    RTP_KeysVector = new java.util.Vector(Constants.defaultRTP_Keys.length);
	    for (int i = 0; i < Constants.defaultRTP_Keys.length; i++)
		RTP_KeysVector.add(Constants.defaultRTP_Keys[i]);
	}
	updateStatus(status++);


                
	try {
	    _getProductTypes();
	} catch (Exception e) {
	    productTypesVector = new java.util.Vector(Constants.defaultProductTypes.length);
	    for (int i = 0;i < Constants.defaultProductTypes.length;i++)
		productTypesVector.add(Constants.defaultProductTypes[i]);
	}
	updateStatus(status++);


                


	contentTypesVector = loadVector(Constants.DJNEWS_CONTENT_TYPES,
					contentTypesVector, 
					Constants.default_contentTypes);
	updateStatus(status++);

                

	deliveryTypesVector = loadVector(Constants.DJNEWS_DELIVERY_TYPES,
					 deliveryTypesVector, 
					 Constants.default_deliveryTypes);
	updateStatus(status++);
                

	conversionTypesVector = loadVector(Constants.DJNEWS_CONVERSION_TYPES,
					   conversionTypesVector, 
					   Constants.default_conversionTypes);
	updateStatus(status++);
                
                

	deliveryMethodsVector = loadVector(Constants.DJNEWS_DELIVERY_METHODS,
					   deliveryMethodsVector, 
					   Constants.default_deliveryMethods);
	updateStatus(status++);

                

	encodingListVector = loadVector(Constants.DJNEWS_ENCODING_LIST,
					encodingListVector, 
					Constants.default_encodingList);
	updateStatus(status++);

                
	
	fileGenerationTypesVector = loadVector(Constants.DJNEWS_FILE_GENERATION_TYPES,
					       fileGenerationTypesVector, 
					       Constants.default_fileGenList);
	updateStatus(status++);

                
	
	takeTypesVector = loadVector(Constants.DJNEWS_TAKE_TYPES,
				     takeTypesVector, 
				     Constants.default_takeTypeList);

	updateStatus(status++);


	derivedDataDictionariesVector = loadVector(Constants.GLB_DERIVED_DATA_DICTIONARIES_LIST,
					 derivedDataDictionariesVector, 
					 DistributorProductFlagOptions.DefaultDerivedDataDictOptions);
	updateStatus(status++);

	outputEncodingListVector = loadVector(Constants.GLB_OUTPUT_ENCODING_LIST,
					 outputEncodingListVector, 
					 DistributorProductFlagOptions.DefaultDerivedDataDictOptions);
	updateStatus(status++);

	fixedLocationsMap.clear();
                
	try {
	    String d
		= new String(getRawValue("GLB_ALWAYS_ACTIVE_LOCATION_LIST"));
	    StringBuffer separator = new StringBuffer(",");

		
	    separator.append(ConfigComm.CONF_STX)
		.append(ConfigComm.CONF_ETX)
		.append(ConfigComm.CONF_FS);
                
	    StringTokenizer st = new StringTokenizer(d, separator.toString());
	    while (st.hasMoreTokens()) {
		String t = st.nextToken();
		int inx = t.indexOf(":");
		if (inx <= 0) continue;
		String did = t.substring(0,inx);
		String loc = t.substring(inx+1,t.length());

                                
		fixedLocationsMap.put(did, loc);
	    }
	}
	catch (Exception e){
	}
	updateStatus(status++);
                                
                        
    }  // loadConfiguration


    public static byte[]
	__configRequest(StringBuffer buf)
	throws IOException, DBException {
        
        byte []b  = null;
        ConfigConnection c = ConfigConnection.getConnection();
        b = c.configRequest(buf);
        ConfigConnection.freeConnection(c);
        return b;
        
    }

    public static byte[] 
        configRequest(StringBuffer buf) 
	throws IOException, DBException
    {
	byte []b  = null;
	ConfigConnection c = null;
	IOException io_exc = null;
	DBException db_exc = null;
                
                
	try {
	    c = ConfigConnection.getConnection();
	    b = c.configRequest(buf);
                        
	}
	catch (IOException ioe)
	{
	    io_exc = ioe;
	}
	catch (DBException dbe)
	{
	    db_exc = dbe;
	}
	finally
	{
	    ConfigConnection.freeConnection(c);     
	}

	if (io_exc != null)
	    throw io_exc;
	if (db_exc != null)
	    throw db_exc;
                
	return b;

     
    
    }

    public static byte[]
	configRequestCompressed(StringBuffer buf)
	throws IOException, DBException {
        
        
        
        byte[] b=null;
        int ntries = Constants.NUM_CONNECTION_TRIES;
        boolean done=false;
        boolean insertHeader = true;
        
        if (serverList ==null) {
            throw new DBException("Server list is null");
        }
        
        java.util.StringTokenizer tok
	    = new java.util.StringTokenizer(serverList,", \t");
        
        String serverName = getLastServer();
        if (serverName == null) {
            if (tok.hasMoreTokens())
                serverName = tok.nextToken();
            else
                throw new DBException("Could not get configuration server list");
        }
        
        Socket cserver=null;
        
        while ( !done ) {
            
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("Connecting to host: "+serverName);
            
            try {
                
                cserver = connectToConfigServer(serverName);
                sendRequest(cserver,buf,insertHeader);
                insertHeader = false;
                
            } catch (UnknownHostException uhe) {
                Log.getInstance().log_warning("ConfigComm:Unknown host: "
					      +serverName+".",uhe);
                
                
                ntries=Constants.NUM_CONNECTION_TRIES;
                
                if (tok.hasMoreTokens()) {
                    
                    String previousHost = serverName;
                    serverName = tok.nextToken();
                    
                    Log.getInstance().log_warning(
						  "Could not connect to configuration server"
						  +" on "+previousHost+". Trying "
						  +serverName,
						  uhe);
                    continue;
                    
                } else
                    throw
			new DBException("Could not establish communications"
					+" with configuration server.",
					Constants.COMM_ERR);
                
            } catch (Exception ioEx) {
                
                ntries--;
                
                if (ntries>0) {
                    Log.getInstance().log_warning(
						  "Communication error: Retrying .. "
						  +serverName+".",ioEx);
                    continue;
                    
                } else {
                    
                    ntries=Constants.NUM_CONNECTION_TRIES;
                    
                    if (tok.hasMoreTokens()) {
                        
                        String previousHost = serverName;
                        serverName = tok.nextToken();
                        
                        Log.getInstance().log_warning(
						      "Could not connect to configuration server"
						      +" on "+previousHost+". Trying "
						      +serverName,
						      ioEx);
                        
                        
                        continue;
                        
                    } else
                        throw
			    new DBException("Could not establish communications"
					    +" with configuration server.",
					    Constants.COMM_ERR);
                } /* else ntries */
                
            } /* try - catch */
            
            
            
            insertHeader=false;
            
            
            
            try {
                
                
                b = __getResponse(cserver);
                done=true;
                setLastServer(serverName);
                
            } catch (DBModeException modeEx) {
                
                
                if (tok.hasMoreTokens()) {
                    
                    ntries=Constants.NUM_CONNECTION_TRIES;
                    
                    String previousHost = serverName;
                    serverName = tok.nextToken();
                    Log.getInstance().log_warning(
						  "Server not in master mode on "
						  +previousHost+". Trying "+serverName,
						  modeEx);
                    
                } else {
                    
                    Log.getInstance().log_error(
						"Communication Error:Could not establish "
						+"communications with configuration server. "
						+serverList,
						modeEx);
                    
                    throw new
			DBException("Could not connect to any master server. "
				    +serverList,
				    Constants.MODE_ERR);
                }
                
                
                
            } catch (DBRetryException retryEx) {
                
                ntries--;
                
                if (ntries>0) {
                    Log.getInstance().log_warning("Configuration server in "
						  +"sync. mode on "
						  +serverName+" .Retrying",
						  null);
                    continue;
                } else
                    throw new DBException("Configuration server still in "
					  +"sync. mode. "+serverList,
					  Constants.SYNC_ERR);
                
                
                
                
            } catch (IOException ioEx) {
                
                ntries--;
                if (ntries>0) {
                    Log.getInstance().log_warning("Communication error: "
						  +serverName+" .Retrying ",
						  null);
                    continue;
                } else
                    throw new DBException("Error in retrieving configuration "
					  +"from configuration server. "
					  +serverName,Constants.COMM_ERR);
            }
            
            
            
        } /* While ! done */
        
        return b;
        
    }
    
    


    public static byte[] 
        configRequest(String HL, StringBuffer buf) 
	throws IOException, DBException
    {

	byte[] b=null;
	int ntries = Constants.NUM_CONNECTION_TRIES;
	boolean done=false;
	boolean insertHeader = true;


	if (HL ==null) {
	    throw new DBException("Server list is null");
	}
	String hostList = HL;
    
	java.util.StringTokenizer tok 
	    = new java.util.StringTokenizer(hostList,", \t");


    
	String serverName;
    
    
	if (tok.hasMoreTokens())
	    serverName = tok.nextToken();
	else
	    throw new DBException("Could not get configuration server list");
    
    
	Socket server=null;
	while ( !done ) {
	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Connecting to host: "+serverName);
      
	    try {

		server = connectToConfigServer(serverName);
		sendRequest(server,buf,insertHeader);
		insertHeader=false;
	    } catch (UnknownHostException uhe) {
		Log.getInstance().log_warning("ConfigComm:Unknown host: "
					      +serverName+".",uhe);


		ntries=Constants.NUM_CONNECTION_TRIES;
		    
		if (tok.hasMoreTokens()) {
		    
		    String previousHost = serverName;
		    serverName = tok.nextToken();
		    
		    Log.getInstance().log_warning(
						  "Could not connect to configuration server"
						  +" on "+previousHost+". Trying "
						  +serverName,
						  uhe);
		    continue;
		    
		} else         
		    throw 
			new DBException("Could not establish communications"
					+" with configuration server.",
					Constants.COMM_ERR);

	    } catch (Exception ioEx) {
		ntries--;
        
		if (ntries>0) {
		    Log.getInstance().log_warning("Communication error: "
						  +"Retrying .. "
						  +serverName+".",ioEx);
		    continue;

		} else {

		    ntries=Constants.NUM_CONNECTION_TRIES;

		    if (tok.hasMoreTokens()) {

			String previousHost = serverName;
			serverName = tok.nextToken();

			Log.getInstance().log_warning(
						      "Could not connect to configuration server"
						      +" on "+previousHost+". Trying "+serverName,
						      ioEx);

			continue;

		    } else         
			throw 
			    new DBException("Could not establish communications"
					    +" with configuration server.",
					    Constants.COMM_ERR);

		} /* else ntries */
        
	    } /* try catch */
      


	    insertHeader=false;


	    try {

		b = getResponse(server);
		done=true;

	    } catch (DBModeException modeEx) {


		if (tok.hasMoreTokens()) {

		    ntries=Constants.NUM_CONNECTION_TRIES;

		    String previousHost = serverName;
		    serverName = tok.nextToken();

		    Log.getInstance().log_warning(
						  "Server not in master mode on "
						  +previousHost+". Trying "+serverName,
						  modeEx);

		} else {

		    Log.getInstance().log_error(
                                                "Communication Error:Could not establish "
                                                +"communications with configuration server. "
                                                +serverList,
                                                modeEx);

		    throw new 
			DBException("Could not connect to any master server. "
				    +serverList,
				    Constants.MODE_ERR);
		}


	    } catch (DBRetryException retryEx) {

		ntries--;

		if (ntries>0) {
		    Log.getInstance().log_warning("Configuration server in "
						  +"sync. mode on "
						  +serverName+" .Retrying",
						  null);
		    continue;
		} else
		    throw new DBException("Configuration server still in "
					  +"sync. mode. "+serverList,
					  Constants.SYNC_ERR);

	    } catch (IOException ioEx) {

		ntries--;
		if (ntries>0) {
		    Log.getInstance().log_warning("Communication error: "
						  +serverName+" .Retrying ",
						  null);
		    
		    continue;
		} else
		    throw new DBException("Error in retrieving configuration "
					  +"from configuration server. "
					  +serverName,Constants.COMM_ERR);
	    }
	} /* While ! done */
    
	return b;
    
    }





    static public String getRawValue(String key) 
	throws Exception
    {
	byte [] b;
	StringBuffer reqbuf = new StringBuffer();
				
	getKey(reqbuf,key);
	b = configRequest(reqbuf);

	/*
	** Format of returned buffer:
	**   Header<CONF_STX>Value(s)<CONF_FS><CONF_ETX>
	*/

	String result = new String(b);
	String datastr = result.substring(result.indexOf(ConfigComm.CONF_STX)+1);
				

	int inx2 = datastr.indexOf(ConfigComm.CONF_ETX);
	int inx1 = datastr.lastIndexOf(ConfigComm.CONF_FS, inx2);

	if(inx1>=0)
	    return datastr.substring(0, inx1);
	else if (inx2 >= 0)
	    return datastr.substring(0, inx2);
		    
	return null;
				
    }
    
    
    static public String getRawListValue(String keylist)
	throws Exception {
        byte [] b;
        StringBuffer reqbuf = new StringBuffer();
        
        createHeader(reqbuf, QUERY_REQUEST, GET_KEYLIST_INFO,keylist.length());
        addStrBuf(reqbuf,keylist);
        b = configRequest(reqbuf);
        
        String result = new String(b);
        String datastr = result.substring(result.indexOf(ConfigComm.CONF_STX)+1);
        
        StringBuffer sep1 = new StringBuffer();
        sep1.append(CONF_ETX);
        
        
        java.util.StringTokenizer tokenizer
	    = new java.util.StringTokenizer(datastr, sep1.toString());
        
        if (tokenizer.hasMoreTokens())
            return new String(tokenizer.nextToken());
        
        return null;
        
    }
    
    
    static public String getRawListValueCompressed(String keylist)
	throws Exception {
        byte [] b;
        StringBuffer reqbuf = new StringBuffer();
        
        createHeaderCompressed(reqbuf, QUERY_REQUEST, GET_KEYLIST_INFO,keylist.length());
        addStrBuf(reqbuf,keylist);
        b = configRequestCompressed(reqbuf);
        
        String result = new String(b);
        String datastr = result.substring(result.indexOf(ConfigComm.CONF_STX)+1);
        
        StringBuffer sep1 = new StringBuffer();
        sep1.append(CONF_ETX);
        
        
        java.util.StringTokenizer tokenizer
	    = new java.util.StringTokenizer(datastr, sep1.toString());
        
        if (tokenizer.hasMoreTokens())
            return new String(tokenizer.nextToken());
        
        return null;
        
    }
   

    static public String getStringValue(String key) 
	throws Exception
    {
				
	StringBuffer sep1 = new StringBuffer();
	sep1.append(CONF_US).append(CONF_FS).
	    append(CONF_GS).append(CONF_ETX);
				
	String datastr = getRawValue(key);
	if (datastr == null) 
	    return null;

	java.util.StringTokenizer tokenizer 
	    = new java.util.StringTokenizer(datastr,
					    sep1.toString());

	if (tokenizer.hasMoreTokens()) 
	    return new String(tokenizer.nextToken());

	return null;
				
    }
		

    public static boolean 
	getBooleanValue(String k, boolean default_value)
    {
	boolean b = default_value;
	try {
	    String s = getStringValue(k);

	    if (s == null)
		return b;

	    if (s.equalsIgnoreCase("TRUE")
		|| s.equalsIgnoreCase("YES"))
		return true;
	    else
		return false;
	}
	catch (Exception e) { }

	return b;
    }



    public static java.util.HashMap getHashMap(String confkey) 
	throws IOException, DBException, DBModeException
    {
	if ((confkey==null)||(confkey.trim().length()==0)) return null;

	CacheEntry ce
	    = (CacheEntry)CacheManager.getCache(confkey);

	if (ce != null) {
	    if (Constants.Verbose > 1)
		System.out.println("Found "+confkey
				   +" in cache.");
                                
	    return (java.util.HashMap)ce.object;
	}

	return getHashMapDirect(confkey);
    }

        
        
                        
    public static java.util.HashMap getHashMapDirect(String confkey) 
	throws IOException, DBException, DBModeException
    {
    
                              
	java.util.HashMap map = null;
	StringBuffer reqbuf = new StringBuffer();
	byte[] b;
	String key,value;
      
	ConfigComm.getKey(reqbuf,confkey);
	b = ConfigComm.configRequest(reqbuf);


	String respbuf = new String(b);
	int index = respbuf.indexOf(ConfigComm.CONF_STX) +1;      
      
	String databuf = respbuf.substring(index);

	StringBuffer separator = new StringBuffer();
	separator.append(ConfigComm.CONF_ETX).
	    append(ConfigComm.CONF_RS);
      
	java.util.StringTokenizer st = 
	    new java.util.StringTokenizer(databuf,
					  separator.toString());
	map = new java.util.HashMap(10);
      
	while (st.hasMoreTokens()) {

	    key = st.nextToken();
	    key.trim();

	    if (st.hasMoreTokens()) {
		value = st.nextToken();
		value.trim();
	    } else {
		continue;
	    }
	  
	    if (key.length() > 0) 
		map.put(key,value);
	} /* while */


	CacheEntry ce =
	    new CacheEntry(map, confkey,  Constants.CacheTTLSecs);
	CacheManager.putCache(ce);
                        
	return map;
      
    }
    


    public static void
        deleteFromFavorites(String id) 
    {
		
	try {
	    StringBuffer reqbuf = new StringBuffer();
	    StringBuffer favorites = new StringBuffer();
			
	    ConfigComm.getKey(reqbuf,Constants.GLB_DISTR_FAVORITES_LIST);    
	    byte[] b = ConfigComm.configRequest(reqbuf);
	    String tmp = new String(b);
	    int index = tmp.indexOf(ConfigComm.CONF_STX)+1;
			
	    String datastr = tmp.substring(index);

			
	    StringBuffer sep = new StringBuffer(",");
	    sep.append(ConfigComm.CONF_FS).append(ConfigComm.CONF_ETX);
			
	    java.util.StringTokenizer tokenizer 
		= new java.util.StringTokenizer(datastr,sep.toString());
	    int numTokens = tokenizer.countTokens();
	    int knt=0;

	    for (int i = 0; i < numTokens; i++) {
		String token = tokenizer.nextToken();
		if (id.equals(token)) continue;
		favorites.append(token).append(",");
		knt++;
	    }
	    int l = favorites.length();
	    if (l>0) favorites.setLength(l-1); // remove training ','
	    reqbuf.setLength(0);
	    if (knt==0) {
		ConfigComm.deleteKeyValue(reqbuf,
					  Constants.GLB_DISTR_FAVORITES_LIST);
	    } else {
		ConfigComm.addFavoritesList(reqbuf,favorites.toString());
	    }

	    ConfigComm.configRequest(reqbuf);

	} catch (DBException dbex) {
	    if (dbex.getErrorNo() != Constants.KEY_NOT_FOUND)
		Log.getInstance().log_error(
					    "Could not delete "+id+" from favorites list.",
					    dbex);
	} catch (Exception e) {
	    Log.getInstance().log_error(
					"Could not delete "+id+" from favorites list.",
					e);
	}

    }



  
    public static int 
        modeRequest(String host,int type, int m) 
	throws IOException, DBException, DBModeException
    {
	StringBuffer reqbuf = new StringBuffer();
	byte[] b = null;

	
	createHeader(reqbuf, ADMIN_REQUEST, type ,0);
	if (type == SET_MODE) {
	    reqbuf.append(m).append(CONF_US);
	}

	reqbuf.append(CONF_ETX);

	/*
	  b = configRequest(host,reqbuf);
	*/

	int len=reqbuf.length()+Constants.MIN_HEADER_BYTES;
	long checksum=55555;
	StringBuffer sb = new StringBuffer();
	sb.append(CONF_SOH).append(Integer.toString(len))
	    .append(CONF_FS)
	    .append(Long.toString(checksum));
	sb.append("                  ");
	sb.setLength(Constants.MIN_HEADER_BYTES);
	reqbuf.insert(0,sb);

	StringBuffer rbuf = new StringBuffer();

	rbuf.append(host)
	    .append(ConfigComm.CONF_GS)
	    .append(reqbuf);

	b = AdminComm.serviceRequest(getServerList(),
				     AdminComm.PROXY_MESSAGE,AdminComm.CONFIGSERVER, 
				     rbuf.toString());

	String respbuf = new String(b);
	int index = respbuf.indexOf(ConfigComm.CONF_STX) +1;        
        
	String databuf = respbuf.substring(index);


	StringBuffer separator = new StringBuffer();
	separator.append(ConfigComm.CONF_ETX).
	    append(ConfigComm.CONF_US);
	


	if (type == GET_MODE) {
	    java.util.StringTokenizer st = 
		new java.util.StringTokenizer(databuf,
					      separator.toString());
	    if (st.hasMoreTokens()) {
		String s = st.nextToken();
		try {
		    int mode = Integer.parseInt(s.trim());
		    return mode;
		} catch (Exception e){}
	    }
	    return -1;
	}
        
	
	return 0;
	
    }

    public static java.util.Vector getDCMList() 
	throws Exception 
    {
		
	StringBuffer reqbuf = new StringBuffer();
	String       respbuf,databuf;
	byte[] b;
		
		
	ConfigComm.getTagKey(reqbuf,ConfigComm.GET_DCM_ALL_INFO);
	b = ConfigComm.configRequest(reqbuf);
	respbuf = new String(b);
	int index = respbuf.indexOf(ConfigComm.CONF_STX)+1;
	databuf = respbuf.substring(index);
		
	java.util.StringTokenizer rowTokenizer, colTokenizer;
	StringBuffer rowSeparator, colSeparator;

	rowSeparator = new StringBuffer();
	colSeparator = new StringBuffer();
		
	rowSeparator.append(ConfigComm.CONF_STX)
	    .append(ConfigComm.CONF_ETX)
	    .append(ConfigComm.CONF_FS);
		
	colSeparator.append(ConfigComm.CONF_ETX)
	    .append(ConfigComm.CONF_RS);
		
	rowTokenizer = new 
	    java.util.StringTokenizer(databuf,rowSeparator.toString());

	int num = rowTokenizer.countTokens();
	java.util.Vector dcmVector = new java.util.Vector(num);
	while (rowTokenizer.hasMoreTokens()) {
	    rowTokenizer.nextToken(); // Skip "key"
	    String fstr = rowTokenizer.nextToken();
	    colTokenizer = new
		java.util.StringTokenizer(fstr,colSeparator.toString());
			
	    while (colTokenizer.hasMoreTokens()) {
		String k = colTokenizer.nextToken(); 
		if (k.equals("ID")) {
		    String h = colTokenizer.nextToken();
		    dcmVector.add(h);                                    
		}
	    }
			
	}
	return dcmVector;
    }

    public static boolean
        getLastUpdateTime(java.util.ArrayList arr)
	throws Exception
    {
	    
	StringBuffer reqbuf = new StringBuffer();
	createHeader(reqbuf, QUERY_REQUEST, GET_LAST_UPDATE_TIME, 0);
	reqbuf.append(CONF_ETX);
                
	byte[] b = configRequest(reqbuf);

	
	String respbuf = new String(b);
	int index = respbuf.indexOf(ConfigComm.CONF_STX) +1;        
        
	String databuf = respbuf.substring(index);


	StringBuffer separator = new StringBuffer();
	separator.append(ConfigComm.CONF_ETX).
	    append(ConfigComm.CONF_US);
	


	java.util.StringTokenizer st = 
	    new java.util.StringTokenizer(databuf,
					  separator.toString());

	if (st.countTokens() >= 2) {

	    String srvr_time_str = st.nextToken();
	    String last_updt_str = st.nextToken();
	    arr.clear();
	    try {
		Long l1 = new Long(srvr_time_str);
		Long l2 = new Long(last_updt_str);
		arr.add(0, l1);
		arr.add(1, l2);
                                
		return true;
                                
	    } catch (Exception e){
		e.printStackTrace();
	    }
	}
	
	return false;
                
    }




        

    public static synchronized CSCProductsModel getCSCProductsModel() {
	return cscProductsModel;
    }




    public static synchronized CSCSparseMatrixModel getCSCSparseMatrixModel() {
	return cscSparseMatrixModel;
    }


    public static synchronized void setCSCProductsModel(CSCProductsModel m) {
	cscProductsModel = m;
    }




    public static synchronized void setCSCSparseMatrixModel(CSCSparseMatrixModel m) {
	cscSparseMatrixModel = m;
    }

    private static PremiumCodesList pcl = null;

    public static synchronized void setPremiumCodesList(PremiumCodesList _pcl)
    {
        pcl = _pcl;
    }
    
    public static synchronized PremiumCodesList getPremiumCodesList() {
        if (pcl != null) {
            return pcl;
        }

        String v = Constants.DEFAULT_PREMIUM_CODES_LIST;
        
        try {
            v = ConfigComm.getStringValue(Constants.GLB_TAG_PREMIUM_FILTER_CODES);
        } catch (Exception e) {
        }
        pcl = PremiumCodesList.parse(v);
        return pcl;
    }
		
    public static synchronized java.util.Vector getStatisticsList() {
	try {
	    return _getStatisticsList();
	} catch (Exception e) {
	    return null;
	}
    }

    public static synchronized java.util.Vector getSystemFileList() {
	try {
	    return _getSystemFileList();
	} catch (Exception e) {
	    return null;
	}
    }
		
    public static synchronized java.util.Vector getIDSProductFormatList() {
	try {
	    return _getIDSProductFormatList();
	} catch (Exception e) {
	    return null;
	}
    }
		
    public static synchronized java.util.Vector getProductFormatList() {
	try {
	    return _getProductFormatList();
	} catch (Exception e) {
	    return null;
	}
    }

    public static synchronized java.util.Vector getReaderProtocolList() {
	try {
	    return _getReaderProtocolList();
	} catch (Exception e) {
	    return null;
	}
				
    }
		
		
    public static synchronized java.util.Vector getIDSTransportTypeList() {
	try {
	    return _getIDSTransportTypeList();
	} catch (Exception e) {
	    return null;
	}

    }

    public static synchronized java.util.Vector getDJNEWSDCMTransportTypeList() {
	try {
	    return _getDJNEWSDCMTransportTypeList();
	} catch (Exception e) {
	    return null;
	}

    }


    public static synchronized java.util.Vector getTransportTypeList() {
	try {
	    return _getTransportTypeList();
	} catch (Exception e) {
	    return null;
	}
    }

    public static synchronized java.util.Vector getDCMSoftwareVersionList() {
	try {
	    return _getDCMSoftwareVersionList();
	} catch (Exception e) {
	    return null;
	}	
    }



    public static synchronized java.util.Vector getDSPSoftwareVersionList() {
	try {
	    return _getDSPSoftwareVersionList();
	} catch (Exception e) {
	    return null;
	}
    }

    public static synchronized java.util.Vector getDCMTypeList() {
	try {
	    return _getDCMTypeList();
	} catch (Exception e) {
	    return null;
	}
    }

		
    public static synchronized java.util.Vector getProductTypes() {
	try {
	    return _getProductTypes();
	} catch (Exception e) {
	    return null;
	}
    }

        
    public static synchronized java.util.Vector getRTPHostKeys() {
	try {
	    return RTP_KeysVector;
	    //return _getRTPHostKeys();
	} catch (Exception e) {
	    return null;
	}
    }

	
    public static synchronized java.util.Vector getLocationList() {
	try {
	    return _getLocationList();
	} catch (Exception e) {
	    return null;
	}
    }

    public static synchronized java.util.Vector getContentTypes() {
	return contentTypesVector;
    }


    public static synchronized java.util.Vector getDeliveryTypes() {
	return deliveryTypesVector;
    }


    public static synchronized java.util.Vector getConversionTypes() {
	return conversionTypesVector;
    }


    public static synchronized java.util.Vector getDeliveryMethods() {
	return deliveryMethodsVector;
    }


    public static synchronized java.util.Vector getEncodingList() {
	return encodingListVector;
    }


    public static synchronized java.util.Vector getTakeTypes() {
	return takeTypesVector;
    }


    public static synchronized java.util.Vector getFileGenerationTypes() {
	return fileGenerationTypesVector;
    }
	

    public static synchronized java.util.Vector getDerivedDataDictionaries() {
	return derivedDataDictionariesVector;
    }

    public static synchronized java.util.Vector getOutputEncodingListVector() {
	return outputEncodingListVector;
    }
			

    private static
	java.util.Vector parseList(String datastr)
    {

	java.util.Vector v = new java.util.Vector(10);

	if (datastr == null) 
	    return v;

	StringBuffer sep1 = new StringBuffer();
	sep1.append(CONF_US).append(CONF_FS).
	    append(CONF_GS).append(CONF_ETX);
	
	datastr.trim();
	java.util.StringTokenizer tokenizer 
	    = new java.util.StringTokenizer(datastr,
					    sep1.toString());

	while (tokenizer.hasMoreTokens()) 
	    v.add(tokenizer.nextToken());


	return v;
    }


    private static 
	java.util.Vector  getValueAsList(String key)
	throws Exception
    {

	return parseList(getRawValue(key));

    }


    private static 
	java.util.Vector  getValueAsListUsingQuery(int query_id)
	throws Exception
    {
	StringBuffer reqbuf = new StringBuffer();
	createHeader(reqbuf, QUERY_REQUEST, query_id ,0);
	reqbuf.append(CONF_ETX);
		    
	byte [] b = configRequest(reqbuf);
	
	String result = new String(b);
	String datastr 
	    = result.substring(result.indexOf(ConfigComm.CONF_STX)+1);
	
	return ( parseList(datastr) );


    }

 
    public static synchronized 
	java.util.Vector loadVector(String key,
				    java.util.Vector vector, 
				    String[] defaults) 
    {
	
	if (vector == null) {
	    synchronized(ConfigComm.class) {
		if (vector==null) {
		    Exception exc = null;
		    try 
		    {
			vector = getValueAsList(key);
		    } 
		    catch (Exception e) { exc = e;}
			
		    if (vector == null)
			vector = new java.util.Vector(10);

		    
		    if ((defaults != null) && (vector.size() == 0))
		    {
			Log.getInstance().log_warning("Using defaults for "
						      +key,exc);
			
			for (int i = 0; i < defaults.length;i++)
			    vector.add(defaults[i]);
		    }
		    
		}
	    }/* synchronized */
	}/* if == null */
	
	return vector;
    }


    private static synchronized java.util.Vector _getProductFormatList() 
	throws Exception
    {
	if (productFormatVector == null) {
	    synchronized(ConfigComm.class) {
		if (productFormatVector==null) {
		    productFormatVector 
			= getValueAsListUsingQuery(GET_PRODUCT_FORMAT_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return productFormatVector;
    }
    

  
 
    private static synchronized java.util.Vector _getReaderProtocolList() 
	throws Exception 
    {
	if (readerProtocolVector == null) {
	    synchronized(ConfigComm.class) {
		if (readerProtocolVector==null) {
		    readerProtocolVector 
			= getValueAsListUsingQuery(GET_READER_PROTOCOL_LIST);
		}
	    } /* synchronized */
	} /* if == null */
	
	return readerProtocolVector;
    }
    
				   
    private static synchronized java.util.Vector _getStatisticsList() 
	throws Exception 
    {
	
	if (statisticsVector == null) {
	    synchronized(ConfigComm.class) {
		if (statisticsVector==null) {
		    statisticsVector = getValueAsList(Constants.GLB_STATISTICS_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return statisticsVector;
    }


    private static synchronized java.util.Vector _getSystemFileList() 
	throws Exception
    {
	
	if (systemFileVector == null) {
	    synchronized(ConfigComm.class) {
		if (systemFileVector==null) {
		    systemFileVector = getValueAsList(Constants.GLB_SYSFILE_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return systemFileVector;
    }


    
    private static synchronized java.util.Vector _getIDSProductFormatList() 
	throws Exception
    {
	if (idsProductFormatVector == null) {
	    synchronized(ConfigComm.class) {
		if (idsProductFormatVector==null) {
		    idsProductFormatVector = getValueAsList(Constants.GLB_IDS_PRODUCT_FORMATS);
		}
	    }/* synchronized */
	}/* if == null */
	
	return idsProductFormatVector;
    }

		
		
    private static synchronized java.util.Vector _getIDSTransportTypeList() 
	throws Exception
    {
	if (idsTransportTypeVector == null) {
	    synchronized(ConfigComm.class) {
		if (idsTransportTypeVector==null) {
		    idsTransportTypeVector = getValueAsList(Constants.GLB_IDS_TRANSPORT_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return idsTransportTypeVector;
    }
		
		
		
    private static synchronized java.util.Vector _getDJNEWSDCMTransportTypeList() 
	throws Exception
    {
	if (djnewsDCMTransportTypeVector == null) {
	    synchronized(ConfigComm.class) {
		if (djnewsDCMTransportTypeVector==null) {
		    djnewsDCMTransportTypeVector = getValueAsList(Constants.GLB_DJNEWS_DCM_TRANSPORT_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return djnewsDCMTransportTypeVector;
    }
		
		
    private static synchronized java.util.Vector _getTransportTypeList() 
	throws Exception
    {
	if (transportTypeVector == null) {
	    synchronized(ConfigComm.class) {
		if (transportTypeVector==null) {
		    transportTypeVector = getValueAsList(Constants.GLB_TRANSPORT_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return transportTypeVector;
    }


    
    private static synchronized java.util.Vector _getDCMTypeList() 
	throws Exception 
    {
	if (dcmTypeVector == null) {
	    synchronized(ConfigComm.class) {
		if (dcmTypeVector==null) {
		    dcmTypeVector = getValueAsList(Constants.GLB_DCM_TYPES_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return dcmTypeVector;
    }
    
    
    
    private static synchronized java.util.Vector _getProductTypes() 
	throws Exception 
    {
	
	if (productTypesVector == null) {
	    synchronized(ConfigComm.class) {
		if (productTypesVector==null) {
		    productTypesVector = getValueAsList(Constants.GLB_PRODUCT_TYPES_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return productTypesVector;
    }
    
    
   

    private static synchronized java.util.Vector _getLocationList() 
	throws Exception 
    {
	
	if (locationList == null) {
	    synchronized(ConfigComm.class) {
		if (locationList==null) {
		    locationList = getValueAsList(Constants.GLB_LOCATION_LIST);
		}
	    }/* synchronized */
	}/* if == null */
	
	return locationList;
    }
    











    private static synchronized java.util.Vector _getDCMSoftwareVersionList() 
	throws Exception
    {
	if (dcmSoftwareVersionVector == null) {
	    synchronized(ConfigComm.class) {
		if (dcmSoftwareVersionVector==null) {
		    dcmSoftwareVersionVector = new java.util.Vector(6);
		    dcmSoftwareVersionVector.add(Constants.DEFAULT_SW_VERSION_LABEL);
		    StringBuffer sep1 = new StringBuffer();
		    sep1.append(CONF_US).append(CONF_FS)
			.append(CONF_GS)
			.append(CONF_ETX);
		    java.util.StringTokenizer tokenizer 
			= new java.util.StringTokenizer(Constants.GLB_DCM_SW_VERSION_LIST,
							sep1.toString());
		    while (tokenizer.hasMoreTokens()) {
			dcmSoftwareVersionVector.add(tokenizer.nextToken());
		    }
		}
	    }/* synchronized */
	}/* if == null */
	
	return dcmSoftwareVersionVector;
    }
    
    
    
    private static synchronized java.util.Vector _getDSPSoftwareVersionList() 
	throws Exception
    {
	if (dspSoftwareVersionVector == null) {
	    synchronized(ConfigComm.class) {
		if (dspSoftwareVersionVector==null) {
		    dspSoftwareVersionVector = new java.util.Vector(6);
		    dspSoftwareVersionVector.add(Constants.DEFAULT_SW_VERSION_LABEL);
		    StringBuffer sep1 = new StringBuffer();
		    sep1.append(CONF_US).append(CONF_FS)
			.append(CONF_GS)
			.append(CONF_ETX);
		    java.util.StringTokenizer tokenizer 
			= new java.util.StringTokenizer(Constants.GLB_DSP_SW_VERSION_LIST,
							sep1.toString());
		    while (tokenizer.hasMoreTokens()) {
			dspSoftwareVersionVector.add(tokenizer.nextToken());
		    }
		}
	    }/* synchronized */
	}/* if == null */
	
	return dspSoftwareVersionVector;
    }
    









    public final synchronized static void setLastServer(String val) {
	lastServer = new String(val);
    }
    
    public final synchronized static String getLastServer() {
	return lastServer;
    }

  
  
    
  
  
    static void 
        addStrBuf(StringBuffer b,String s)
    {
	b.append(s).append(CONF_FS).append(CONF_ETX);

    }

    static void
        addKeyValue(StringBuffer p, String key, String value, char sep)
    {
	p.append(key).append(sep).append(value).append(sep);
    }

    static void
        addStrKeyValue(StringBuffer p, String key, String value)
    {
	addKeyValue(p,key,value, CONF_FS);
    }

    static void
        addRecordKeyValue(StringBuffer p, String key, String value)
    {
	addKeyValue(p,key,value, CONF_RS);
    }

    static void
        endKeyValue(StringBuffer p )
    {
	p.append(CONF_ETX);
    }


    static void
        adminRequest(StringBuffer buf, int arg)
    {
	createHeader(buf, ADMIN_REQUEST, arg ,0);
    }

    public static void
        getKey(StringBuffer buf, String key)
    {
	createHeader(buf, QUERY_REQUEST, GET_KEY,key.length());
	addStrBuf(buf,key);
    }


    static void
        getTagKey(StringBuffer buf, int key)
    {
	createHeader(buf, QUERY_REQUEST, key ,0);
	buf.append(CONF_ETX);
    }

    static void
        getServKey(StringBuffer buf, int type, String keys)
    {
	if (keys!=null) {
	    createHeader(buf, QUERY_REQUEST, type ,keys.length());
	    addStrBuf(buf,keys);
	} else {
	    createHeader(buf, QUERY_REQUEST, type ,0);      
	    buf.append(CONF_ETX);
	}
    }  


    public static void
        saveKeyValue(StringBuffer buf, String key, String value)
    {

	int len = key.length() + value.length();

	len += 2;

	createHeader(buf, DATABASE_REQUEST, SAVE_KEY, len);
	addStrKeyValue(buf, key, value);
	endKeyValue(buf);


    }

    static void 
        deleteKeyValue(StringBuffer buf, String key)
    {
	createHeader(buf, DATABASE_REQUEST, DELETE_KEY,key.length());
	addStrBuf(buf,key);
    }
  
  

    static void
        saveProducts(StringBuffer buf, String key, String value)
    {

	int len = key.length() + value.length();

	len += 2;

	createHeader(buf, DATABASE_REQUEST, SAVE_PRODUCTS, len);
	addStrKeyValue(buf, key, value);
	endKeyValue(buf);


    }

    static void
        clearProductCache(StringBuffer buf)
    {
				

	createHeader(buf, DATABASE_REQUEST, CLEAR_UNUSED_CACHE_ENTRIES, 0);				
	endKeyValue(buf);


    }


    public static String
        convertHashMap(StringBuffer ib, String config_key, int config_type,
                       java.util.HashMap map,
                       String null_value, boolean ignore_empty) 
    {
	StringBuffer hdrbuf = new StringBuffer();
	StringBuffer buf = ib;


	if (buf==null) buf = new StringBuffer();

                
	java.util.Iterator key_iterator
	    = map.keySet().iterator();

	int count = map.size();
	int len  = 0;
                
	for (int i = 0; i < count; i++){
	    String key = (String)key_iterator.next();
	    String value = (String)map.get(key);
                        
	    if (value == null) {
		if (null_value != null)
		    value = null_value;
		else
		    continue;
	    }
                        
                        
                        
	    if ( (value.length() == 0 )
		 && ignore_empty)
		continue;
                        
	    len += key.length() + 1;
	    len += value.length() + 1;
	    addRecordKeyValue(buf, key, value);
	}
                
	createHeader(hdrbuf, DATABASE_REQUEST, config_type, len);
	hdrbuf.append(config_key).append(CONF_FS);
                
	buf.insert(0,hdrbuf.toString());

	buf.append(CONF_FS).append(CONF_ETX);
                
                        
	return buf.toString();
                
    }
        
                        

        


    public static void 
        saveDistrTag(StringBuffer buf, String id, String conf, boolean newEntry)
    {
	int len = conf.length();
    
	if (newEntry)
	    createHeader(buf, DATABASE_REQUEST, ADD_DISTRIBUTOR_KEY, len);
	else
	    createHeader(buf, DATABASE_REQUEST, SAVE_DISTRIBUTOR_KEY, len);

	buf.append(Constants.GLB_TAG_DISTR_PREFIX).append(id).append(CONF_FS);
	buf.append(conf);
	buf.append(CONF_FS);
	endKeyValue(buf);

    }

  
  
    public static void 
        addFilterCode(StringBuffer buf,String id,String desc,String codes, boolean newEntry)
    {
	int len = id.length() +  codes.length() ;
    
	len += "ID".length() + "CODES".length() ;

	if (desc.length()>0) {
	    len += ( desc.length() + "DESCRIPTION".length() );
	    len += 6;
	} else
	    len += 4;

	if (newEntry)
	    createHeader(buf, DATABASE_REQUEST, ADD_KEY, len);
	else
	    createHeader(buf, DATABASE_REQUEST, SAVE_KEY, len);
	

	buf.append(Constants.GLB_TAG_FILTERCODE_PREFIX).append(id).append(CONF_FS);

	addRecordKeyValue(buf, "ID", id);
	addRecordKeyValue(buf, "CODES", codes);
	if (desc.length()>0) 
	    addRecordKeyValue(buf, "DESCRIPTION", desc);
	buf.append(CONF_FS);
	endKeyValue(buf);

    }
  
  
    public static void 
        addFavoritesList(StringBuffer buf,String list)
    {

	createHeader(buf, DATABASE_REQUEST, SAVE_KEY, 0);

	addStrKeyValue(buf, Constants.GLB_DISTR_FAVORITES_LIST, 
		       list);
	endKeyValue(buf);

    }
  

    public static Socket 
        connectToConfigServer(String serverName) 
	throws IOException
    {
                    
	Socket sock = NBConnect.Connect(serverName,
					Constants.CONFIG_SERVER_PORT,
					Constants.ConnectTimeout);
                
        
	sock.setTcpNoDelay(true);
	/*sock.setKeepAlive(true);*/
	/* Set timeout */
	sock.setSoTimeout(Constants.NetworkTimeout);
                

	return sock;


    }

    public static void 
        sendRequest(Socket server, 
                    StringBuffer buf, 
                    boolean insertHeader) 
	throws IOException
    {
	
	int len=buf.length()+Constants.MIN_HEADER_BYTES;
	long checksum=55555;
    
	BufferedOutputStream dout 
	    = new BufferedOutputStream( server.getOutputStream() );

	if (insertHeader) {

	    StringBuffer b = new StringBuffer();
	    b.append(CONF_SOH).append(Integer.toString(len)).append(CONF_FS)
		.append(Long.toString(checksum));
	    b.append("                  ");
	    b.setLength(Constants.MIN_HEADER_BYTES);
	    buf.insert(0,b);

	}
    
	if (Constants.DEBUG && Constants.Verbose>1)
	    System.out.println("Buffer " + buf.toString() );

	dout.write(buf.toString().getBytes(),0,buf.length()); 
	dout.flush();

	
    }

  
    public static byte[] 
        getResponse(Socket server) 
	throws IOException, DBException, DBModeException
    {

	InputStream din = server.getInputStream();

	byte[] hdrb = new byte[Constants.MIN_HEADER_BYTES];

	din.read(hdrb,0,Constants.MIN_HEADER_BYTES);
	String hdr = new String(hdrb);

	StringBuffer sep =  new StringBuffer();
	sep.append(CONF_FS).append(CONF_SOH);

	java.util.StringTokenizer tok = 
	    new java.util.StringTokenizer(hdr,sep.toString());

	if (Constants.DEBUG && Constants.Verbose>1)
	    System.out.println("getResponse:Response "+hdr+ " "+hdr.length());

	int len=0;

	if (tok.hasMoreTokens()) {
	    String token = tok.nextToken();
      
	    try {
		len = Integer.parseInt(token);
	    } catch (Exception e) {
		Log.getInstance().log_error("ConfigComm:Error in parsing "
					    +"length of response",e);
		len = 0;
	    }
	}

	if (len == 0) throw 
			  new IOException("Error in parsing length of response");

	int rlen = len - Constants.MIN_HEADER_BYTES;
    
	byte[] b = new byte[len];

	int nleft=rlen,nread=0,offset=Constants.MIN_HEADER_BYTES;

	while (nleft > 0) {
	    nread = din.read(b,offset,nleft);
	    if (nread <= 0) break;
	    nleft -= nread;
	    offset += nread;
	}
    
	if (offset != len) 
	    throw new IOException("Error in reading server response");   
    
	System.arraycopy(hdrb,0,b,0,Constants.MIN_HEADER_BYTES);

	//server.close();

    
	tok =  new java.util.StringTokenizer(new String(b),sep.toString());

	for (int i = 0; i < Constants.NUM_HEADER_FIELDS; i++) {
	    if (tok.hasMoreTokens()) {
		String s = tok.nextToken();
	    } else {
		throw new IOException("Error in parsing header information");
	    }
	}
    
	int errno = -2;
	String token = tok.nextToken();
	try {
	    errno = Integer.parseInt(token);
	} catch (Exception e) {
	    Log.getInstance().log_error("ConfigComm:Error in parsing error "
					+"number from response",e);
	}



    
	if (Constants.DEBUG && Constants.Verbose>1)
	    System.out.println("Read bytes "+new String(b)+ " Error no: "+errno);
      
	if (errno == -2) throw 
			     new IOException("Error in parsing status from "
					     +"server response");

	if (errno == Constants.MODE_ERR) throw new DBModeException();

	if ((errno == Constants.SYNC_ERR)
	    ||(errno==Constants.COMM_ERR)) throw new DBRetryException();

    
	if (errno != 0) throw new DBException("Data base error",errno,b);
	//if (errno != 0) throw new DBException("Data base error",errno);
    
    
	return b;
    }


    private static byte[] uncompress(byte[] b) {
        // Create the decompressor and give it the data to compress
        Inflater decompressor = new Inflater();
        decompressor.setInput(b);
        
        // Create an expandable byte array to hold the decompressed data
        ByteArrayOutputStream bos = new ByteArrayOutputStream(b.length);
        
        // Decompress the data
        byte[] buf = new byte[1024];
        while (!decompressor.finished()) {
            try {
                int count = decompressor.inflate(buf);
                bos.write(buf, 0, count);
            } catch (DataFormatException e) {
            }
        }
        try {
            bos.close();
        } catch (IOException e) {
        }
        
        // Get the decompressed data
        return bos.toByteArray();
        
    }
    
    
        
    private static byte[]
	__getResponse(Socket server)
	throws IOException, DBException, DBModeException {
        
        InputStream din = server.getInputStream();
        
        byte[] hdrb = new byte[Constants.MIN_HEADER_BYTES];
        
        din.read(hdrb,0,Constants.MIN_HEADER_BYTES);
        
        
        
        String hdr = new String(hdrb);
        
        StringBuffer sep =  new StringBuffer();
        sep.append(CONF_FS).append(CONF_SOH);
        
        java.util.StringTokenizer tok =
	    new java.util.StringTokenizer(hdr,sep.toString());
        
        if (Constants.DEBUG && Constants.Verbose>1)
            System.out.println("getResponse:Response "+hdr+ " "+hdr.length());
        
        int len=0;
        
        if (tok.hasMoreTokens()) {
            String token = tok.nextToken();
            
            try {
                len = Integer.parseInt(token);
            } catch (Exception e) {
                Log.getInstance().log_error("ConfigComm:Error in parsing "
					    +"length of response",e);
                len = 0;
            }
        }
        
        if (len == 0) throw
			  new IOException("Error in parsing length of response");
        
        int rlen = len - Constants.MIN_HEADER_BYTES;
        
        //System.out.println("getResponse:Length "+len+ " Rlen "+rlen);
        
        byte[] cb = new byte[rlen];
        
        int nleft=rlen,nread=0,offset=0;
        
        while (nleft > 0) {
            nread = din.read(cb,offset,nleft);
            if (nread <= 0) break;
            nleft -= nread;
            offset += nread;
        }
        
        if (offset != rlen)
            throw new IOException("Error in reading server response");
        
        //System.arraycopy(hdrb,0,cb,0,Constants.MIN_HEADER_BYTES);
        
        //System.out.println("CRESPONSE "+new String(cb));
        
        server.close();
        
        byte[] ub = uncompress(cb);
        
        //System.out.println("Compressed len= "+cb.length+" Uncompressed len= "+ub.length);
        
        byte[] b = new byte[ub.length+Constants.MIN_HEADER_BYTES];
        System.arraycopy(hdrb,0,b,0,Constants.MIN_HEADER_BYTES);
        System.arraycopy(ub,0,b,Constants.MIN_HEADER_BYTES,ub.length);
        //System.out.println("RESPONSE "+new String(b));
        
        tok =  new java.util.StringTokenizer(new String(b),sep.toString());
        
        for (int i = 0; i < Constants.NUM_HEADER_FIELDS; i++) {
            if (tok.hasMoreTokens()) {
                String s = tok.nextToken();
            } else {
                throw new IOException("Error in parsing header information");
            }
        }
        
        int errno = -2;
        String token = tok.nextToken();
        try {
            errno = Integer.parseInt(token);
        } catch (Exception e) {
            Log.getInstance().log_error("ConfigComm:Error in parsing error "
					+"number from response",e);
        }
        
        
        
        
        if (Constants.DEBUG && Constants.Verbose>1)
            System.out.println("Read bytes "+new String(b)+ " Error no: "+errno);
        
        if (errno == -2) throw
			     new IOException("Error in parsing status from "
					     +"server response");
        
        if (errno == Constants.MODE_ERR) throw new DBModeException();
        
        if ((errno == Constants.SYNC_ERR)
	    ||(errno==Constants.COMM_ERR)) throw new DBRetryException();
        
        
        if (errno != 0) throw new DBException("Data base error",errno,b);
        //if (errno != 0) throw new DBException("Data base error",errno);
        
        
        return b;
    }
    
    
  
    public static void
        createHeader(StringBuffer  buf, int msgtype, int reqtype, int len)
    {
	String host = new String();
	try {
	    host = InetAddress.getLocalHost().getHostName();
	}
	catch (Exception e) {}
      
	buf.append(CONF_FS)
	    .append(Integer.toString(msgtype)) .append(CONF_FS)
	    .append(Integer.toString(reqtype)) .append(CONF_FS)
	    .append(Integer.toString(CLIENT_API_J_SRCID)) .append(CONF_FS)
	    .append(host).append(CONF_FS)
	    .append(userName) .append(CONF_FS)
	    .append(Integer.toString(0)).append(CONF_FS)
	    .append(Integer.toString(0)).append(CONF_FS)
	    .append(Integer.toString(-1)).append(CONF_FS)
	    .append(CONF_STX);
      
    }


    public static void
	createHeaderCompressed(StringBuffer  buf, int msgtype, int reqtype, int len) {
        String host = new String();
        try {
            host = InetAddress.getLocalHost().getHostName();
        }
        catch (Exception e) {}
        
        buf.append(CONF_FS)
	    .append(Integer.toString(msgtype)) .append(CONF_FS)
	    .append(Integer.toString(reqtype)) .append(CONF_FS)
	    .append(Integer.toString(CLIENT_API_J_SRCID)) .append(CONF_FS)
	    .append(host).append(CONF_FS)
	    .append(userName) .append(CONF_FS)
	    .append(Integer.toString(0)).append(CONF_FS)
	    .append(Integer.toString(0)).append(CONF_FS)
	    .append(Integer.toString(8899)).append(CONF_FS)
	    .append(CONF_STX);
        
    }
    
    
    public static int checkHeader(String hdr) {
		
	return 0;
	
    }
    
    static long
        msg_checksum(String buf)
    {
	/* Compute Internet Checksum for "count" bytes
	 *         beginning at location "addr".
	 */
	byte [] b = buf.getBytes();
	int i=0, count = buf.length();
	
	long sum = 0;
	
	while( count > 1 )  {
	    /*  This is the inner loop */
	    sum +=  b[i];
	    i++;
	    count -= 2;
	}
	
	/*  Add left-over byte, if any */
	if( count > 0 )
	    sum += b[i];
	
	/*  Fold 32-bit sum to 16 bits */
	while ((sum>>16) > 0)
	    sum = (sum & 0xffff) + (sum >> 16);
	
	return  ~sum;
    }
    
    
    public static String getUserName()
    {
	return userName;
    }
    
    public static String getServerList()
    {
	return serverList;
    }
 
 

    /*  Data Members */
  
    public static final char		CONF_SOH =  '\u0001';
    public static final char		CONF_STX =  '\u0002';
    public static final char		CONF_ETX =  '\u0003';
    public static final char		CONF_RS  =  '\u001E';
    public static final char		CONF_FS  =  '\u001F';
    public static final char		CONF_GS  =  '\u001D';
    public static final char		CONF_US  =  '\u0009';
    /*static final char		CONF_US  =  '\u001C';*/
    static final int 		CLIENT_API_C_SRCID = 5000;
    static final int 		CLIENT_API_J_SRCID = 5001;
    static final int 		MASTER_SRCID = 5002;
    static final int 		SLAVE_SRCID = 5003;


    static final int 		REQUEST_TYPE = 0;
    public static final int 		DATABASE_REQUEST=100;
    static final int 		QUERY_REQUEST=101;
    static final int 		ADMIN_REQUEST=102;
    static final int 		COMMAND_REQUEST=103;
    static final int 		FILE_REQUEST=104;
  
    static final int 		REQUEST_DATA = 200;
    static final int 		REQUEST_STATUS = 201;
    static final int 		REQUEST_ACK = 202;

    /* Database requests */
    static final int      ADD_KEY = 1000;
    static final int      SAVE_KEY = 1001;
    static final int      DELETE_KEY = 1002;
    static final int      ADD_DSP_KEY = 1003;
    static final int      SAVE_DSP_KEY = 1004;
    static final int      ADD_DCM_KEY = 1005;
    static final int      SAVE_DCM_KEY = 1006;
    static final int      ADD_DISTRIBUTOR_KEY = 1007;
    public static final int      SAVE_DISTRIBUTOR_KEY = 1008;
    static final int      SAVE_PRODUCTS = 1009;
    static final int      CLEAR_UNUSED_CACHE_ENTRIES = 1010;
    static final int      CLEAR_ALL_DCMS = 1011;
    static final int      CLEAR_DSP = 1012;
    static final int      CLEAR_ALL_DISTRIBUTORS = 1013;
        

    static final int      CONFIG_IDLE_MODE = 0;
    static final int      CONFIG_MASTER_MODE = 5454;
    static final int      CONFIG_SLAVE_MODE = 4545;
    static final int      CONFIG_SYNC_MODE = 7777;
    static final int      CONFIG_SHUTDOWN = 7779;


    /* Query requests */
    static final int      GET_KEY  = 2000;
    static final int      GET_DSP_FOR_HOST = 2001;
    static final int      GET_DCM_SW_VERSION_FOR_HOST = 2002;
    static final int      GET_DCM_IDS_NAME = 2003;
    static final int      GET_DISTRIBUTOR_CONFIG = 2004;
    static final int      GET_FILTERCODES_FOR_PRODUCT = 2005;
    static final int      GET_PRODUCT_FORMAT_LIST = 2006;
    static final int      GET_ALL_FILTERCODES_INFO = 2007;
    static final int      GET_ALL_DCM_LIST = 2008;
    static final int      GET_DCM_ALL_INFO = 2009;	
    static final int      GET_DIST_ALL_INFO = 2010;
    static final int      GET_DCM_SOFT_VERSION = 2011;
    static final int      GET_DSP_SOFT_VERSION = 2012;
    static final int      GET_READER_PROTOCOL_LIST = 2013;
    static final int      GET_DISTRIBUTORS_USING_FILTER = 2014;
    static final int	  GET_DISTRPRODS_USING_FILTER = 2015;
    static final int      VALIDATE_FILTER_STRING = 2016;
    static final int      GET_DSP_DIST_ALL_INFO = 2017;
    static final int      GET_DCM_DIST_ALL_INFO = 2018;
    static final int      GET_DISTRIBUTORS_USING_PRODUCT = 2019;
    static final int      GET_KEY_LIST = 2020;
    static final int      GET_DCM_PRODUCTS = 2021;
    //static final int      GET_RTP_HOST_LIST = 2022;
    static final int      GET_LAST_UPDATE_TIME = 2022;
    static final int      SUBSCRIBE_UPDATE_TIME = 2023;
    static final int      GET_KEY_INFO = 2024;
    static final int      GET_KEYLIST_INFO = 2025;


    /* For ADMIN REQUESTS */
    static final int      SYNCHRONIZE_DB = 3000;
    static final int      SET_MODE = 3001;
    static final int      GET_MODE = 3002;

    static final int      DSP_GET_MODE = 5000;
    static final int      DSP_CHANGE_MODE = 5001;
    static final int      DSP_SEND_MODE = 5002;

  
    static private java.util.Vector statisticsVector=null;
    static private java.util.Vector systemFileVector=null;
    static private java.util.Vector transportTypeVector=null;
    static private java.util.Vector productFormatVector=null;
    static private java.util.Vector dcmSoftwareVersionVector=null;
    static private java.util.Vector dspSoftwareVersionVector=null;
    static private java.util.Vector dcmTypeVector=null;
    static private java.util.Vector readerProtocolVector=null;

    static private java.util.Vector djnewsDCMTransportTypeVector=null;
    static private java.util.Vector idsTransportTypeVector=null;
    static private java.util.Vector idsProductFormatVector=null;

    static private java.util.Vector dcmVector=null;

    static private java.util.Vector productTypesVector=null;
    static private java.util.Vector RTP_KeysVector=null;


    static private java.util.Vector contentTypesVector=null;
    static private java.util.Vector deliveryTypesVector=null;
    static private java.util.Vector conversionTypesVector=null;
    static private java.util.Vector deliveryMethodsVector=null;
    static private java.util.Vector encodingListVector=null;
    static private java.util.Vector fileGenerationTypesVector=null;
    static private java.util.Vector takeTypesVector=null;
    static private java.util.Vector derivedDataDictionariesVector=null;
    static private java.util.Vector outputEncodingListVector=null;

    static private java.util.Vector locationList=null;
        
    static private String   userName="USER-NAME";
    static private String   serverList=null;
    static private String   lastServer=null;


    static private CSCProductsModel cscProductsModel = null;
    static private CSCSparseMatrixModel cscSparseMatrixModel = null;

    static public java.util.HashMap fixedLocationsMap = new java.util.HashMap();


}

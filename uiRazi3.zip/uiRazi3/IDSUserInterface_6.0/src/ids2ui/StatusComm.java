/*
**  SCCS Info :  "@(#)StatusComm.java	1.7    05/08/25"
*/
/*
 * StatusComm.java
 *
 * Created on October 16, 2000, 4:47 PM
 */
 
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;


/** 
 *
 * @author  srz
 * @version 
 */
public class StatusComm extends Object {

  static private boolean _init = false;
  static private String dspList=null;
  static private String lastServer=null;
  
  private java.net.Socket server = null;
  
  /** Creates new StatusComm */
  public StatusComm()  throws Exception{
    if (!_init) throw new Exception("StatusComm: Not initialized");
    server = null;
  }


        private static String StatusServers[];
        private static java.util.Random rand = new java.util.Random();
        
        
   static public void init(String dList)
  {
    _init = true;    
	lastServer = null;
    dspList = new String(dList);	
    Log.getInstance().log_warning("StatusComm:Using server list: "
					      +dspList,null);

    java.util.StringTokenizer tok
            = new java.util.StringTokenizer(dspList,", ");
    int n = tok.countTokens();
    if (n == 0)
            StatusServers = null;
    else
            StatusServers = new String[n];
    for (int i = 0; i < n; i++)
            StatusServers[i] = tok.nextToken();
    
    
  }
  
   static public void resetLogin()
  {
          _init = false;    
          lastServer = null;
          dspList = null;
          StatusServers = null;
  }


        private static String getNextHost()
                throws DBException
        {
                
                
                
                
                if ( (StatusServers == null)
                     || (StatusServers.length == 0) )
                        throw new DBException("Could not get status server list");
                
                
                String s =  StatusServers[rand.nextInt(StatusServers.length)];

                if (Constants.DEBUG && Constants.Verbose>2)
                        System.out.println("Directing status request to "+s
                                   +" "+new Date());

                return s;
                
             
        }
        
                        

  public String statusRequest(String host, String progName, String progId) 
  throws Exception {
    
    
    
    byte[] b=null;
    
    int ntries = Constants.NUM_CONNECTION_TRIES;
    boolean done=false;

    java.util.StringTokenizer tok = new java.util.StringTokenizer(dspList,", ");

        if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("statusRequest:Requesting status for Host: "+host
			   +" Program: "+progName+" ProgID: "+progId);
    
    String serverName = getNextHost() ;
    
    
    
    
    while ( !done ) {
      if (Constants.DEBUG && Constants.Verbose>2)
        System.out.println("StatusComm:Connecting to host: "+serverName);
      
      try {

	if (Constants.DEBUG && Constants.Verbose>2)
		    System.out.println("Connecting to : "+serverName+" for status");

        //server = new java.net.Socket(serverName,12759);
	try {
        	server = connectToStatusServer(serverName);
	} 
	catch (Exception e)
	{
		serverName = getNextHost();
        	if (serverName != null)
			server = connectToStatusServer(serverName);
	}


	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("Connected to : "+serverName+" for status");

        StringBuffer req = new StringBuffer();
        req.append("anyof(").append(host).append(")").append(",")
	    .append(progName).append(",")
	    .append(progId);
	    
	/*.append("anyof(").append(progName).append(")").append(",")
	  .append("anyof(").append(progId).append(")");*/

		req.append('\0'); // NULL terminate

                    if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("StatusComm: "+req.length()+" "+req.toString());


        java.io.BufferedOutputStream dout = new java.io.BufferedOutputStream(server.getOutputStream());
        dout.write(req.toString().getBytes(),0,req.length());
        dout.flush();
  

      } catch (UnknownHostException uhe) {
	  Log.getInstance().log_warning("StatusComm:Unknown host: "
					+serverName+".",uhe);
	  
	  
	  ntries=Constants.NUM_CONNECTION_TRIES;
	  
	  if (tok.hasMoreTokens()) {
	      
	      String previousHost = serverName;
	      serverName = tok.nextToken();
	      
	      Log.getInstance().log_warning(
			      "Could not connect to status server"
			      +" on "+previousHost+". Trying "
			      +serverName,
			      uhe);
	      continue;
	      
	  } else         
	      throw 
		  new DBException("Could not establish communications"
				  +" with status server.",
				  Constants.COMM_ERR);
	  
        
      } catch (Exception ioEx) {

	  if (server!=null) server.close();
	  ntries--;
	  
	  if (Constants.DEBUG && Constants.Verbose>2) {
	      System.out.println("Error in connect: "+ioEx.getMessage());
	      System.out.println("Could not connect to status server on: "+serverName);
	  }
	  
	  
	  
	  if (ntries>0) {
            Log.getInstance().log_warning("StatusComm:Communication error: Retrying .. "
                        +serverName+".",ioEx);
            continue;
        } else {
            ntries=Constants.NUM_CONNECTION_TRIES;
            if (tok.hasMoreTokens()) {
              serverName = tok.nextToken();
              Log.getInstance().log_warning(
                  "Could not connect. Trying "+serverName,
                  ioEx);
              continue;
            } else         
              throw new DBException("Error in retrieving status from DSP "
										+serverName);
        }        
      }
      
     if (Constants.DEBUG && Constants.Verbose>2)
	 System.out.println("Reading status ..."); 

      try {
        
        java.io.InputStream din = server.getInputStream();
        byte[] lbytes = new byte[8];
        din.read(lbytes,0,8);
        String s = new String(lbytes);
        int len = Integer.parseInt(s);
        b = new byte[len];
		int nleft=len,nread=0,offset=0;

		while (nleft > 0) {
			nread = din.read(b,offset,nleft);
            if (nread <= 0) break;
            nleft -= nread;
            offset += nread;
		}
        
     	if (Constants.DEBUG && Constants.Verbose>2)
	 		System.out.println("Status ..."+len+" bytes."+"( "+s+")"); 

        done=true;
        lastServer=new String(serverName);
      } catch (java.io.IOException ioEx) {
		if (server!=null) server.close();
        ntries--;
        if (ntries>0) {
            Log.getInstance().log_warning("StatusComm:Communication error: "
							+serverName+" .Retrying ",null);
            continue;
          } else
            throw new DBException("Error in reading status from server "
									+serverName);
      }
	  if (server!=null) server.close();
    }
    
	server.close();

    String resp =  new String(b);


    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("statusRequest:Status response:"+resp+"\n");
    
	return resp; 
    
  }
  


 public String statusQuery(String query) 
  throws Exception {
    
    
    
    byte[] b=null;
    
    int ntries = Constants.NUM_CONNECTION_TRIES;
    boolean done=false;

    java.util.StringTokenizer tok = new java.util.StringTokenizer(dspList,", ");

    if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("statusRequest:Query: "+query);
    

    String serverName = getNextHost() ;

    
    
    while ( !done ) {
      if (Constants.DEBUG && Constants.Verbose>2)
        System.out.println("StatusComm:Connecting to host: "+serverName);
      
      try {

	if (Constants.DEBUG && Constants.Verbose>2)
		    System.out.println("Connecting to : "+serverName+" for status");

        //server = new java.net.Socket(serverName,12759);
	server = connectToStatusServer(serverName);
	

	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("Connected to : "+serverName+" for status");

       

        java.io.BufferedOutputStream dout = new java.io.BufferedOutputStream(server.getOutputStream());
        dout.write(query.getBytes(),0,query.length());
        dout.flush();
        
        
      } catch (Exception ioEx) {

		if (server!=null) server.close();
        ntries--;

	if (Constants.DEBUG && Constants.Verbose>2) {
	    System.out.println("Error in connect: "+ioEx.getMessage());
	    System.out.println("Could not connect to status server on: "+serverName);
	}



        if (ntries>0) {
            Log.getInstance().log_warning("StatusComm:Communication error: Retrying .. "
                        +serverName+".",ioEx);
            continue;
        } else {
            ntries=Constants.NUM_CONNECTION_TRIES;
            if (tok.hasMoreTokens()) {
              serverName = tok.nextToken();
              Log.getInstance().log_warning(
                  "Could not connect. Trying "+serverName,
                  ioEx);
              continue;
            } else         
              throw new DBException("Error in retrieving status from DSP "
										+serverName);
        }        
      }
      
     if (Constants.DEBUG && Constants.Verbose>2)
	 System.out.println("Reading status ..."); 

      try {
        
        java.io.InputStream din = server.getInputStream();
        byte[] lbytes = new byte[8];
        din.read(lbytes,0,8);
        String s = new String(lbytes);
        int len = Integer.parseInt(s);
        b = new byte[len];

		int nleft=len,nread=0,offset=0;

		while (nleft > 0) {
			nread = din.read(b,offset,nleft);
            if (nread <= 0) break;
            nleft -= nread;
            offset += nread;
		}

		if (offset != len)
			throw new IOException("Error in reading status server response");

        
     	if (Constants.DEBUG && Constants.Verbose>2)
	 		System.out.println("Status ..."+len+" bytes."+"( "+s+")"); 

        done=true;
        lastServer=new String(serverName);
      } catch (java.io.IOException ioEx) {
		if (server!=null) server.close();
        ntries--;
        if (ntries>0) {
            Log.getInstance().log_warning("StatusComm:Communication error: "
							+serverName+" .Retrying ",null);
            continue;
          } else
            throw new DBException("Error in reading status from server "
									+serverName);
      }
	  if (server!=null) server.close();
    }
    
	server.close();
    String resp =  new String(b);
    
 
    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("statusRequest:Status response:"+resp+"\n");
    
	return resp;
  }
  

  private static Socket connectToStatusServer(String serverName) 
      throws IOException
  {
      /*
      Socket sock =  new Socket(serverName, Constants.ADMIN_SERVER_PORT);
      */
      Socket sock = TimeoutSocket.Connect(serverName, 
					  Constants.STATUS_SERVER_PORT,
					  Constants.ConnectTimeout);

 	/* Set timeout */
      sock.setSoTimeout(Constants.NetworkTimeout);
	  sock.setTcpNoDelay(true);

      return sock;
  }




  
}

/*
**  SCCS Info :  "@(#)CacheEntry.java	1.2    04/05/10"
*/
package ids2ui;

public class CacheEntry
        implements Cacheable
{
        
        private Object identifier = null;
        public  Object object     = null;

        private java.util.Date expirationTime  = null;
        private long           configTimeStamp = 0;
        private long           accessTime      = 0;

        private long           accessCount   = 0;
        



        public CacheEntry(Object obj, Object id, int cacheTime)
        {
                this.object = obj;
                this.identifier = id;

                    // cacheTime of 0 means it lives on indefinitely.
                if (cacheTime != 0)
                {
                        expirationTime = new java.util.Date();
                        java.util.Calendar cal = java.util.Calendar.getInstance();
                        cal.setTime(expirationTime);
                        cal.add(cal.SECOND, cacheTime);
                        expirationTime = cal.getTime();
                }
                
                configTimeStamp = CacheManager.getConfigTimeStamp();
                accessTime      = System.currentTimeMillis();
                accessCount     = 1;
        }


        public boolean isExpired()
        {

                if (expirationTime != null)
                {
                        if (expirationTime.before(new java.util.Date()))
                        {
                                return true;
                        }
                        else
                        {
                                return false;
                        }
                }
                else
                        return false;
        }


        public Object getIdentifier()
        {
                return identifier;
        }



        public long getConfigTimeStamp()
        {
                return configTimeStamp;
        }



        synchronized public long getAccessTime()
        {
                return accessTime;
        }

        synchronized public long getAccessCount()
        {
                return accessCount;
        }


        synchronized public void updateAccess() 
        {
                accessTime = System.currentTimeMillis();
                accessCount++;
        }
        

}

/*
**  SCCS Info :  "@(#)FIFOSemaphore.java	1.1    01/07/10"
*/
/*
  File: FIFOSemaphore.java

*/

package ids2ui;



public class FIFOSemaphore extends QueuedSemaphore {
  
  /** 
   * Create a Semaphore with the given initial number of permits.
   * Using a seed of one makes the semaphore act as a mutual exclusion lock.
   * Negative seeds are also allowed, in which case no acquires will proceed
   * until the number of releases has pushed the number of permits past 0.
  **/

  public FIFOSemaphore(long initialPermits) { 
    super(new FIFOWaitQueue(), initialPermits);
  }

  /** 
   * Simple linked list queue used in FIFOSemaphore.
   * Methods are not synchronized; they depend on synch of callers
  **/

  protected static class FIFOWaitQueue extends WaitQueue {
    protected WaitNode head_ = null;
    protected WaitNode tail_ = null;

    protected void insert(WaitNode w) {
      if (tail_ == null) 
        head_ = tail_ = w;
      else {
        tail_.next = w;
        tail_ = w;
      }
    }

    protected WaitNode extract() { 
      if (head_ == null) 
        return null;
      else {
        WaitNode w = head_;
        head_ = w.next;
        if (head_ == null) tail_ = null;
        w.next = null;  
        return w;
      }
    }
  }

}

/*
**  SCCS Info :  "@(#)CacheManager.java	1.2    04/05/10"
*/

package ids2ui;
public class CacheManager {


        private static java.util.Date EPOCH = new java.util.Date(0);


        public static void
        putCache(Cacheable object)
        {
                cacheHashMap.put(object.getIdentifier(), object);
        }

        
        public static void
        removeCache(Object id)
        {
                cacheHashMap.remove(id);
        }
        
        
	synchronized public static void
        clearCache()
	{
		cacheHashMap.clear();


                
                configUpdateTimeStamp = 0;
                configServerTimeStamp = 0;
                
                    // Stop configUpdateThread
	}


       
        

        public static Cacheable
        getCache(Object identifier)
        {

                Cacheable object
                        = (Cacheable)(cacheHashMap.get(identifier));
                
                if (object == null)
                        return null;

                boolean stale = is_stale(object);
                
                if (Constants.Verbose > 2 )
                        if (stale)
                                System.out.println("Object "+identifier+" is stale.");
                
                        
                if (object.isExpired() || stale)
                {
                        cacheHashMap.remove(identifier);
                        return null;
                }
                else
                {
                        object.updateAccess();
                        
                        return object;
                }
        }


 
        private static java.util.Calendar cal = java.util.Calendar.getInstance();
        private static boolean is_stale(Cacheable object) 
        {
                        
                long config_update_time  = getConfigTimeStamp();
                long cache_load_time     = object.getConfigTimeStamp();


                if (Constants.Verbose>1)
                        System.out.println(object.getIdentifier()+":->"
                                           +"\n\tCache  time "+new java.util.Date(cache_load_time)
                                           +"\n\tUpdate time "+new java.util.Date(config_update_time));


                return config_update_time > cache_load_time;
                
        }

        

            /* This is the HashMap that contains all objects in the cache. */
        private static
        java.util.Map cacheHashMap
        = java.util.Collections.synchronizedMap(new java.util.HashMap());
        
        




        private static long configUpdateTimeStamp  = 0;
        private static long configServerTimeStamp  = 0;
        
        
        synchronized public static long getConfigTimeStamp() 
        {
                return configUpdateTimeStamp;
        }
        
        synchronized public static long getConfigServerTimeStamp() 
        {
                return configServerTimeStamp;
        }

        
        synchronized private static void setConfigUpdateTime(long serverMS, long updateMS)
        {
                configUpdateTimeStamp = updateMS;
                configServerTimeStamp = serverMS;
        }
        


        private static Thread configUpdateThread
        = new Thread()  {
                public void run() 
                {
                        int milliSecondSleepTime = Constants.ConfigCheckMilliSecs;
                        java.util.ArrayList times = new java.util.ArrayList(2);
                        
                        while (true ) {

                                boolean status = false;
                                
                                try {
                                        status = ConfigComm.getLastUpdateTime(times);
                                } catch (Exception e){
                                        e.printStackTrace();
                                }
                                        
                                if (status ) {
                                        
                                        long srvr_time_l   = ((Long)times.get(0)).longValue();
                                        long last_update_l = ((Long)times.get(1)).longValue();


                                        setConfigUpdateTime(srvr_time_l*1000,
                                                            last_update_l*1000);


                                        
                                        if (Constants.Verbose > 2 ) {
                                                
                                                java.util.Date srvr_time
                                                        = new java.util.Date(srvr_time_l*1000);
                                                java.util.Date last_update
                                                        = new java.util.Date(last_update_l*1000);
                                                
                                                System.out.println("   CS time       : "
                                                                   +srvr_time
                                                                   +"\n   CS update time: "
                                                                   +last_update
                                                                   +"\n   Local time    : "
                                                                   +new java.util.Date());
                                                
                                        }
                                        
                                        
                                } else
                                        setConfigUpdateTime(0,0);
                                
                                
                                try {
                                        Thread.sleep(milliSecondSleepTime);
                                }
                                catch (InterruptedException ie){
                                }
                        }
                        
                }
            };
        

        
        private static Thread clearCacheThread = new Thread(
                new Runnable() {
                int milliSecondSleepTime = 5000;
                                
                public void run()  {
                        
                        while (true)
                        {
                                java.util.Set keySet = cacheHashMap.keySet();
                                try  {        
                                        synchronized(cacheHashMap) {
                                                
                                                java.util.Iterator keys = keySet.iterator();
                                                
                                                while(keys.hasNext())  {
                                                        Object key = keys.next();
                                                        Cacheable value = (Cacheable)cacheHashMap.get(key);
                                                        
                                                            /* Remove entry, if expired */
                                                        if (value.isExpired()) 
                                                                cacheHashMap.remove(key);

                                                }
                                        }
                                }
                                catch (java.util.ConcurrentModificationException cme)
                                { //Ignore
                                }
                                try {
                                        Thread.sleep(this.milliSecondSleepTime);
                                }
                                catch (InterruptedException ie)
                                { //Ignore
                                }
                                
                        } // while true
                } // run 
        });




        
        static
        {
                try
                {
                        clearCacheThread.setPriority(Thread.MIN_PRIORITY);
                        clearCacheThread.start();

                        configUpdateThread.start();
                        
                }
                catch(Exception e)
                {
                            //Ignore but log
                        Log.getInstance().log_error("CacheManager:Static Block failed",e);
                }
        }

            //Disallow instances
        private CacheManager()
        {
        }

}

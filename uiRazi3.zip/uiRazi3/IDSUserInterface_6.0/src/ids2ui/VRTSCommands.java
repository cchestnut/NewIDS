
/*
**  SCCS Info :  "@(#)VRTSCommands.java	1.3    08/12/05"
*/
package ids2ui;
import java.util.*;
import java.io.*;


public class VRTSCommands 
{
                
        public static final int HARES = 1;
        public static final int HAGRP = 2;
        public static final int ONLINE = 10;
        public static final int OFFLINE = 11;
        public static final int DEPEND = 12;



        

        
        public static String[]
        getSystemList(String serverList)
                throws Exception
        {
                String cmd = "/usr/local/bin/op hasys -list";



                
                String s = do_hacmd(serverList, cmd);


                
                if (s != null)
                        s = s.trim();
                else
                        throw new Exception("Can't get list of hosts from veritas");
                
                
                StringTokenizer st = new StringTokenizer(s,"\n");
                int num_nodes = st.countTokens();
                if (num_nodes <= 0)
                        throw new Exception("Can't get list of hosts from veritas");
                ArrayList  nodes = new ArrayList(num_nodes);

                for (int i = 0; i < num_nodes; i++) {
                        String host = st.nextToken();
                        if (host.trim().length()==0)
                                continue;

                        
                        nodes.add(host.trim());
                        
                }
                
                return (String[])nodes.toArray(new String[1]);
        }




        
        
        public static String
        findOnlineSystemForGroup(String serverList, String g)
                throws Exception
        {
                return findOnlineSystem(serverList, HAGRP, g);
        }
        
        
        public static String
        findOnlineSystemForResource(String serverList, String r)
                throws Exception
        {
                return findOnlineSystem(serverList, HARES, r);
        }
        
        public static String
        findOnlineSystem(String serverList, int type, String arg)
                throws Exception
        {

                String[] nodes = getSystemList(serverList);
                
                
                StringBuffer sb =
                        new StringBuffer("/usr/local/bin/op ");
                if (type == HAGRP)
                        sb.append("hagrp -state ");
                else 
                        sb.append("hares -state ");

                
                sb.append(arg)
                        .append(" -sys ");
                
                int len = sb.length();
                
                for (int i = 0; i < nodes.length; i++) {
                        
                        sb.setLength(len);
                        sb.append(nodes[i]);

                        String s = do_hacmd(serverList, sb.toString());
                        if ( (s != null) 
                             && (s.trim().equals("ONLINE")) )
                                return nodes[i];
                }
                
                throw new Exception(((type==HAGRP)?"Group":"Resource")
                                    +" '"+arg
                                    +"' is not online on any system");
        }


 

        public static String
        getSystemStatus(String serverList, String host)
                throws Exception
        {
                StringBuffer buf
                        = new StringBuffer("/usr/local/bin/op hasys -state ");
                buf.append(host);
                
                
                
                String s = do_hacmd(serverList, buf.toString());

                if (s != null) 
                        return s.trim();

                return null;
                
        }




        
        public static String
        getGroupStatus(String serverList, String group, String host)
                throws Exception
        {
                StringBuffer buf
                        = new StringBuffer("/usr/local/bin/op hagrp -state ");
                buf.append(group)
                        .append(" -sys ")
                        .append(host);

                String s = do_hacmd(serverList, buf.toString());
                if (s != null) 
                        return s.trim();

                return null;
        }



    
        
        
        public static String
        ha_online_resource(String serverList, String[] res) 
                throws Exception
        {
                return ha_command(serverList,HARES, ONLINE, res, null);
        }

        public static String
        ha_offline_resource(String serverList, String[] res) 
                throws Exception
        {
                return ha_command(serverList,HARES, OFFLINE, res, null);
        }

        
        public static String
        ha_online_group(String serverList, String[] group) 
                throws Exception
        {
                return ha_command(serverList,HAGRP, ONLINE, group, null);
        }

        public static String
        ha_offline_group(String serverList, String[] group) 
                throws Exception
        {
                return ha_command(serverList,HAGRP, OFFLINE, group, null);
        }

 
        public static String
        ha_online_resource(String serverList, String[] res, String system) 
                throws Exception
        {
                return ha_command(serverList,HARES, ONLINE, res, system);
        }

        public static String
        ha_offline_resource(String serverList, String[] res, String system) 
                throws Exception
        {
                return ha_command(serverList,HARES, OFFLINE, res, system);
        }

        
        public static String
        ha_online_group(String serverList, String[] group, String system) 
                throws Exception
        {
                return ha_command(serverList,HAGRP, ONLINE, group, system);
        }

        public static String
        ha_offline_group(String serverList, String[] group, String system) 
                throws Exception
        {
                return ha_command(serverList,HAGRP, OFFLINE, group, system);
        }
        
        
        public static String
        ha_clear_resource(String serverList, String res, String host)
                throws Exception
        {
                return ha_clear(serverList, HARES, res, host);
        }

        public static String
        ha_clear_group(String serverList, String group, String host)
                throws Exception
        {
                return ha_clear(serverList, HAGRP, group, host);
        }

        public static String
        ha_res_depend(String serverList, String res)
                throws Exception
        {
                StringBuffer command = new StringBuffer("/usr/local/bin/op hares -dep ");
                if (res != null)
                        command.append(res);

                return do_hacmd(serverList, command.toString());
        }
        
        
        
        private static String
        ha_command(String serverList, int type, int option,
                   String[] list, String system)
                throws Exception
        {
                
                StringBuffer command = new StringBuffer();

                
                if (system == null)
                        system = findOnlineSystemForResource(serverList,
                                                             "watchdog");
                
                String opcmdpath = "/usr/local/bin/op ";
                
                String hacmd = null, haopt = null;
                
                
                if (type==HARES)
                        hacmd = " hares ";
                else if (type == HAGRP)
                        hacmd =" hagrp ";
                
                if (option == ONLINE)
                        haopt = " -online ";
                else if (option == OFFLINE)
                        haopt = " -offline ";
                else if (option == DEPEND)
                        haopt = " -dep ";
                
                
                
                String syscmd = " -sys "+system+" ";
                
                for (int i = 0; i < list.length ; i++) {
                        
                             command.append(opcmdpath)
                                .append(hacmd)
                                .append(haopt)
                                .append(list[i])
                                .append(syscmd)
                                .append(";");
                        
                }
                
                command.insert(0,"( ");
                command.append(" )");
                
                
                return do_hacmd(serverList, command.toString());
                
        }


        

        public static String
        ha_switch(String serverList, String tohost, String group)
                throws Exception
        {
                StringBuffer command = new StringBuffer("/usr/local/bin/op hagrp -switch ");
                command.append(group)
                        .append(" -to ")
                        .append(tohost);

                return do_hacmd(serverList, command.toString());

        }
        

        public static String
        ha_start(String host)
                throws Exception
        {
                return rexec(host,"/usr/local/bin/op hastart -force ");
        }
        
        public static String
        ha_stop(String host) 
                throws Exception
        {
                return rexec(host,"/usr/local/bin/op hastop -sys "+host);
        }




        private static String
        ha_clear(String serverList, int type, String arg, String host)
                throws Exception
        {
        
                StringBuffer buf
                        = new StringBuffer("/usr/local/bin/op ");

                if (type == HAGRP)
                        buf.append("hagrp -clear ");
                else
                        buf.append("hares -clear ");


                buf.append(arg)
                        .append(" -sys ")
                        .append(host);

                String s = do_hacmd(serverList, buf.toString());
                
                if (s != null) 
                        return s.trim();

                return null;
                
        }


 
        private static String do_hacmd(String serverList, String command)
                throws Exception
        {

                    /*
**************************
                byte b[]
                        = AdminComm.serviceRequest(serverList,
                                                   AdminComm.EXEC_COMMAND,
                                                   AdminComm.RUN_COMMAND,
                                                   command);
                String s = new String(b);
                                
                int inx = s.indexOf(ConfigComm.CONF_STX)+1;
                
                if (inx > 0)
                        return s.substring(inx);
                else
                        return null;


**************************
*/
                
                StringTokenizer st = new StringTokenizer(serverList, ", ");
                int n = st.countTokens();
                for (int i = 0; i < n; i++) {
                        String host = st.nextToken();
		System.out.println("Rexecing '"+command+"' on host '"+host);
                        try {
				if (Constants.DEBUG && Constants.Verbose>1)
					System.out.println("REXEC on "+host+" : '"+command+"'.");
                                return rexec(host, command);
                        }
                        catch (Exception e) {
                                Log.getInstance().log_error("Command failed"
                                                           +" on '"+host
                                                            +"'. ",e);
	
                        }
                }
                return null;
        }


        
        private static String
        rexec(String host, String command)
                throws Exception
        {
                String username = "ids2adm";
                String password = "520ids2#";
                
                RExecClient client;
                client = new RExecClient();

                client.connect(host);
                client.rexec(username, password, command);

                ByteArrayOutputStream haout = new ByteArrayOutputStream(1024);
                
                        
                IOUtil.readWrite(client.getInputStream(),
                                 client.getOutputStream(),
                                 null, haout);
                

                client.disconnect();

                return  haout.toString();
                
                
        }
        
        
}

        



                       
    /*
*****************************
               

RExecClient client;
client = new RExecClient();

StringTokenizer st = new StringTokenizer(serverList,",");

boolean done = false;
                
while ( ! done  && st.hasMoreTokens()) {
String host = st.nextToken();

System.out.println("Connecting to "+host);
                        
try {
client.connect(host);
}
catch (Exception e) {
System.out.println("Can't connect to "+host);
continue;
}
                        
String username = "ids2adm";
String password = "ids2adm";
System.out.println("Connected. Sending command.");
                        
client.rexec(username, password, command.toString());

ByteArrayOutputStream haout = new ByteArrayOutputStream(1024);
System.out.println("Send command waiting for output.");
                        
IOUtil.readWrite(client.getInputStream(),
client.getOutputStream(),
System.in, System.out);

    //System.out.println("Response = "+haout.toString());
                        

    client.disconnect();
    done = true;
    }


    *****************************************
    */

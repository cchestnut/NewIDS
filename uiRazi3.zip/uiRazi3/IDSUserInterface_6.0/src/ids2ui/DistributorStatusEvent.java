/*
**  SCCS Info :  "@(#)DistributorStatusEvent.java	1.3    04/04/01"
*/
/*
 * DistributorStatusEvent.java
 *
 * Created on October 18, 2000, 12:41 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistributorStatusEvent extends java.util.EventObject {
  private String name=null;
  private String host=null;
  private String timeStamp=null;
  private String mode=null;
  private String protocol=null;
  private String keepalive=null;
  private String statistics=null;
  private String checkpoint=null;

  private int   status;
  private String   error_string;
  
  /** Creates new DistributorStatusEvent */
  public DistributorStatusEvent(Object source) {
    super(source);
  }
  
  public void copy(DistributorStatusEvent e) {
    source = e.getSource();
    name=e.name;
    host=e.host;
    timeStamp=e.timeStamp;
    mode=e.mode;
    protocol=e.protocol;
    keepalive=e.keepalive;
    statistics=e.statistics;
    checkpoint=e.checkpoint;

    status=e.status;
    error_string=e.error_string;
  }
  
  
  public DistributorStatusEvent(Object source, String id,String hst, 
				String tm, String md, String prot, String ka, String stats,
				String ckpt) {
    super(source);
    name = new String (id);
    host = new String(hst);
    mode = new String(md);
    timeStamp = new String (tm);
    protocol = new String (prot);
    keepalive = new String(ka);
    statistics = new String(stats);
    if (ckpt!=null)
      checkpoint = new String(ckpt);
    status = 0;
  }

        
        public DistributorStatusEvent(Object source, String id, String hst, 
                                      int s, String e) {
                super(source);
                name = new String (id);
                host = new String(hst);
                status = s;
                error_string = new String (e);
        }
        


        
  public DistributorStatusEvent(Object source, int s, String e) {
    super(source);
    status = s;
    error_string = new String (e);
  }
  
  public int getStatus() { return status; }  
  
  public String getError() { return error_string; }
  
  public String getName() { return name; }
  public String getTimeStamp() { return timeStamp; }
  public String getMode() { return mode;}
  public String getHost() { return host; }
  public String getCheckpoint() { return checkpoint; }
  public String getKeepalive() { return keepalive; }
  public String getStatistics() { return statistics;}
  public String getProtocol() { return protocol; }
  
}

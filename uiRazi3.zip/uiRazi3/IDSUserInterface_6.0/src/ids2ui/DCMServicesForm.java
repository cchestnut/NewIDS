/*
**  SCCS Info :  "@(#)DCMServicesForm.java	1.32    04/12/08"
*/
/*
 * DCMServices.java
 *
 * Created on June 29, 2000, 9:43 AM
 */
 
package ids2ui;

import java.util.*;
import javax.swing.table.*;
import javax.swing.*;
/** 
 *
 * @author  srz
 * @version 
 */
public class DCMServicesForm 
    extends javax.swing.JFrame 
    implements TaskListener, javax.swing.event.ListSelectionListener 
{

    private javax.swing.JTable dataServicesTable;
    private DCMDataServicesStatusModel dataServicesModel;

    private javax.swing.JTable distrTable;
    private DCMDistributorStatusModel distrModel;

    private javax.swing.JTable systemServicesTable;
    private SystemServicesStatusModel systemServicesModel;


    private javax.swing.JRadioButton noneRB=null;
    private javax.swing.table.TableCellRenderer serviceCellRenderer=null;
  

    private String dcmName;

    javax.swing.event.DocumentListener docListener = null;


    private DCMServicesForm myFrame;

   

    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();
    private volatile boolean isExiting = false;

    /** Creates new form DCMServices */
    public DCMServicesForm(String dcm) {
	setTitle(" DCM Services Screen: "+dcm);

	try {
		serviceCellRenderer = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultServiceCellColorMap);
	} catch (Exception e) {
		Log.getInstance().log_error("DCMServicesForm:Error in "
				+"creating cell renderer.",e);
	}

	myFrame = this;

	WindowEventAdapter.getInstance().registerWindow(Constants.SERVICES_DCM+"_"+dcm, this);



	
        dcmName = new String(dcm);
          
          
	initComponents ();
        myInitComponents ();
        pack ();

	
	
	updateTimer.start();
    }



    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;
	updateUIState(0);

	int srows[] = distrTable.getSelectedRows();

	idTextF.getDocument().removeDocumentListener( docListener);

	if (srows.length!=1)
		idTextF.setText("");
	else
		idTextF.setText((String)distrTable.getValueAt(srows[0],0));

	idTextF.getDocument().addDocumentListener( docListener);


    }


    public void Refresh() {
        try {
	    
	    dataServicesModel.Refresh();
	    distrModel.Refresh();
	    systemServicesModel.Refresh();

	} catch (Exception e){
	    Log.getInstance().log_error("DCMServicesForm: Status update failed:",
					e);
	}
        
    }    
    
    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }

    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 

	    if (s==null)
		statusPanel1.start();
	    else
		statusPanel1.start(s);
	}
    }

    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(java.util.EventObject evt) {
	taskEnded("Status updated @ "+new java.util.Date().toString());
    }


    public void taskEnded(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel1.stop();

	    if (s!=null)
		statusPanel1.showStatus(s);

	    updateUIState(0);
                //repaint();
	}
    }

  

        private void updateDistrUI(int flags) 
        {
                        
                              
                startButton.setEnabled(false);
                switchButton.setEnabled(false);
                stopButton.setEnabled(false);
                modeButton.setEnabled(false);
                statusButton.setEnabled(false);

                
                retransRequestButton.setEnabled(false);
                retransStatusButton.setEnabled(false);
                
                copyButton.setEnabled(false);
                modifyButton.setEnabled(false);
                deleteButton.setEnabled(false);
                x25LinkButton.setEnabled(false);


                
                boolean validLocation = true;
                
                String location = (String)locationComboBox.getSelectedItem();
                if ((location==null)
                    || location.equals(Constants.PICK_LOCATION))
                        validLocation = false;
                
                int[] srows = distrTable.getSelectedRows();


                
                if (srows.length==1) {
                        int row = srows[0];
                        String v1 = (String)distrTable.getValueAt(row,3);
                        String v2 = (String)distrTable.getValueAt(row,4);

                        boolean serviceButtonsEnabled = validLocation;
                        
                        statusButton.setEnabled(true);

                        

                        if ( ((v1!=null) && v1.equals("ACTIVE"))
                             || ((v2!=null) && v2.equals("ACTIVE")))
                                retransRequestButton.setEnabled(true);
                        else
                                retransRequestButton.setEnabled(false);
                        
                        retransStatusButton.setEnabled(true); 


                        
                        boolean configButtonsEnabled = true;
                        
                        copyButton.setEnabled(configButtonsEnabled);
                        modifyButton.setEnabled(configButtonsEnabled);
                        deleteButton.setEnabled(configButtonsEnabled);
                        x25LinkButton.setEnabled(configButtonsEnabled);

                        
                        int inx = jTabbedPane1.indexOfTab("Configuration");
                        if (inx >=0) {
                                if (AccessLevel.MENU_ACCESS_LEVEL == 0 )  
                                        jTabbedPane1.setEnabledAt(inx, true);
                                else
                                        jTabbedPane1.setEnabledAt(inx, false);
                        }
                        

                        
                } 
                 

                if ( validLocation && srows.length > 0) {
                        startButton.setEnabled(true);
                        stopButton.setEnabled(true);
                        modeButton.setEnabled(true);
                        switchButton.setEnabled(true);
                }

                if (AccessLevel.MENU_ACCESS_LEVEL != 0 ) {
                        addButton.setEnabled(false);
                        modifyButton.setEnabled(false);
                        deleteButton.setEnabled(false);
                        copyButton.setEnabled(false);
                        x25LinkButton.setEnabled(false);
                }

                
        }


        
    public void updateUIState(int flags) {

	boolean enable;


	
	enable = false;
	int srows[] = systemServicesTable.getSelectedRows();
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String name = (String)systemServicesTable.getValueAt(row, 0);
	    if (name.equals("Retransmission Server")) {
		enable = true;
		break;
	    }
	}
	jButton2.setEnabled(enable); // Status button


        
        updateDistrUI(flags);
                

	srows = dataServicesTable.getSelectedRows();
	if (srows.length==1) {
	    int row = srows[0];
	    String name = (String)dataServicesTable.getValueAt(srows[0],0);	
	    String v1 = (String)dataServicesTable.getValueAt(srows[0],1);
	    String v2 = (String)dataServicesTable.getValueAt(srows[0],2);
	    if ((v1!=null) && v1.startsWith("Running")) {
		if (name.startsWith("Reader"))
		    statusButton11.setEnabled(true);
		startButton11.setEnabled(false);
	    } else {
		stopButton11.setEnabled(false);
	    }
	    if ((v2!=null) && v2.startsWith("Running")) {
		if (name.startsWith("Reader"))
		    statusButton21.setEnabled(true);
		startButton21.setEnabled(false);
	    } else {
		stopButton21.setEnabled(false);
	    }
	} else {
	    statusButton11.setEnabled(false);
	    stopButton21.setEnabled(false);
	}


	if (srows.length==0) {
	    startButton11.setEnabled(false);
	    startButton21.setEnabled(false);
	    stopButton11.setEnabled(false);
	    stopButton21.setEnabled(false);
	    statusButton11.setEnabled(false);
	    statusButton21.setEnabled(false);
	} else {
	    startButton11.setEnabled(true);
	    startButton21.setEnabled(true);
	    stopButton11.setEnabled(true);
	    stopButton21.setEnabled(true);
	}

  
    }



    private void myInitComponents() {



      if (AccessLevel.MENU_ACCESS_LEVEL != 0 ) {
      	jButton19.setEnabled(false); // DCM Configuration
        addButton.setEnabled(false);
        modifyButton.setEnabled(false);
        deleteButton.setEnabled(false);
        copyButton.setEnabled(false);
        
      }

	/*
	** Create JTable for displaying data services and assiciate a model with the table
	*/
	dataServicesModel
	    = new DCMDataServicesStatusModel(Constants.DCMServicesTable,
					  Constants.GLB_TAG_DCM_PREFIX+dcmName);

    
	dataServicesTable = new javax.swing.JTable(dataServicesModel){
	    public javax.swing.table.TableCellRenderer getCellRenderer(int row,int column) {
		if ( (serviceCellRenderer!=null)
			&& ((column==1)||(column==2)))
		    return serviceCellRenderer;

		return super.getCellRenderer(row,column);
	    }

	};

	
	/* Create listerner to popup status when double clicked in the reader status cell */
	dataServicesTable.addMouseListener( new java.awt.event.MouseAdapter() {
	    public void mouseClicked(java.awt.event.MouseEvent evt) {
		if (evt.getClickCount() != 2) 
		    return;
		int row = dataServicesTable.getSelectedRow();
		int col = dataServicesTable.getSelectedColumn();

		if (col==0) return;

		String name = (String)dataServicesModel.getValueAt(row,0);

		System.out.println("STATUS NAME "+name);

		if (!name.startsWith("Reader") &&  !name.startsWith("Message"))
		    return;

		String value = (String)dataServicesModel.getValueAt(row,col);
		if ((value!=null) && value.equals(Constants.RUNNING)) {
		    int stype = Constants.DCM_READER;
		    if (name.startsWith("Message"))
			stype = Constants.MSGMGR;
		    value = (String)dataServicesModel.getValueAt(row,0);
		    int inx = value.indexOf(":");
		    String progname = value.substring(0,inx-1);
		    name     = value.substring(inx+1);

		    String serverList = null;
		    if (col==1) serverList = dataServicesModel.getDC1PHost();
		    if (col==2) serverList = dataServicesModel.getDC2PHost();
		    if (serverList == null) {
			Log.getInstance().log_error("Could not get hosts for DCM:"
						    +dcmName, null);
			return;
		    }

                    
                            

		    StatusHandler statushandler 
			= StatusHandler.getInstance();
		    try {statushandler.displayStatus(myFrame, stype,col, serverList,
                                                     dcmName,name);
                    }
                    catch (Exception e)
                    {
                    }
                           
		}
	    }
	});

	int w = dataServicesTable.getFontMetrics(dataServicesTable.getFont()).stringWidth(Constants.NOT_RUNNING);

	java.awt.Insets insets = ((javax.swing.JComponent)dataServicesTable.getCellRenderer(0,1)).getInsets();
	
	w+= (insets.left+insets.right);

	dataServicesTable.getColumnModel().getColumn(1).setPreferredWidth(w );
	dataServicesTable.getColumnModel().getColumn(2).setPreferredWidth(w );
	dataServicesTable.getColumnModel().getColumn(0).setPreferredWidth(w*4 );

	dataServicesTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200,85));

	
	javax.swing.JScrollPane jScrollPane1
	    = new javax.swing.JScrollPane(dataServicesTable);

	dataTablePanel.add(jScrollPane1,java.awt.BorderLayout.CENTER);


	/* Create listener to sort when clicked on column header */
	javax.swing.table.JTableHeader header 
	    = dataServicesTable.getTableHeader();

	header.addMouseListener(
				dataServicesModel.new ColumnListener(dataServicesTable,rwLock));
      

	/*
	** End creation of data services table
	*/




	/* 
	** Create a JTable for displaying distributors configured on this DCM
	*/

	distrModel = new DCMDistributorStatusModel(dcmName);
    
    
    
        distrTable = new javax.swing.JTable(distrModel) {
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row,int column) {

		if ( (serviceCellRenderer!=null)
			&& ((column==3)||(column==4)))
		    return serviceCellRenderer;
		return super.getCellRenderer(row,column);
	    }
        };

	

	distrTable.addMouseListener( new ActionHandlers.DCMDistributorStatusAdapter(this, distrTable) );


	w = distrTable.getFontMetrics(distrTable.getFont()).stringWidth(Constants.NOT_RUNNING);
	insets = ((javax.swing.JComponent)distrTable.getCellRenderer(0,1)).getInsets();
	
	w+= (insets.left+insets.right);

	distrTable.getColumnModel().getColumn(2).setPreferredWidth(w*4 );
	distrTable.getColumnModel().getColumn(3).setPreferredWidth(w);
	distrTable.getColumnModel().getColumn(4).setPreferredWidth(w);
	distrTable.getColumnModel().getColumn(0).setPreferredWidth(w);
	distrTable.getColumnModel().getColumn(1).setPreferredWidth(w);


	distrTable.setPreferredScrollableViewportSize(new java.awt.Dimension(300,100));
        docListener = new ActionHandlers.IDFieldListener(this, distrTable, idTextF);

	javax.swing.JScrollPane jScrollPane2 
	    = new javax.swing.JScrollPane(distrTable);

	distrTablePanel.add(jScrollPane2,java.awt.BorderLayout.CENTER);
      
	
	header = distrTable.getTableHeader();
	header.addMouseListener(
				distrModel.new ColumnListener(distrTable,rwLock));
      

	/*
	** End creation of Distributor table
	*/


	/*
	** Create a JTable for displaying system services
	*/
	
	systemServicesModel
	    = new SystemServicesStatusModel(Constants.DCMServicesTable3,
					    Constants.GLB_TAG_DCM_PREFIX+dcmName);

      
	systemServicesTable = new javax.swing.JTable(systemServicesModel) {
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row, int column) {

		if ( (serviceCellRenderer!=null)
			&& ((column==1)||(column==2)) )
		    return serviceCellRenderer;

		return super.getCellRenderer(row,column);
	    }

	};


	systemServicesTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200,85));
	
	systemServicesTable.addMouseListener( new java.awt.event.MouseAdapter() {

	    public void mouseClicked(java.awt.event.MouseEvent evt) {

		if (evt.getClickCount() != 2)
		    return;

		int row = systemServicesTable.getSelectedRow();
		int col = systemServicesTable.getSelectedColumn();
		if (col == 0) return;

		String name = (String)systemServicesModel.getValueAt(row,0);
		if (!name.startsWith("Retransmission"))
		    return;


		String value = (String)systemServicesTable.getValueAt(row,col);

		if ((value!=null) && value.equals(Constants.RUNNING)) {
		    
		    String serverList1 = dataServicesModel.getDC1PHost();
		    String serverList2 = dataServicesModel.getDC2PHost();

		    if ((serverList1 == null)||(serverList2 == null)) {
			Log.getInstance().log_error("Could not get hosts for DCM:"
						    +dcmName, null);
			return;
		    }

		    javax.swing.JFrame f1 
			= (javax.swing.JFrame)WindowEventAdapter
			        .getInstance().findWindow(Constants.STATUS_RETRANSMISSION_PREFIX+dcmName);
		    
		    if (f1!=null) {
			f1.show();
			return;
		    }
		    try {
			RetransmissionStatusForm f
			    = new RetransmissionStatusForm(dcmName,
							   null, 
							   serverList1,
							   serverList2);
			    f.show();
		    } catch (Utils.DuplicateWindowException dwe) {
		    } catch (Exception exc) {
			    Log.getInstance().log_error("Error in displaying "
						    +"retransmission status "
						    +"dialog:"
						    +dcmName, null);
			}
		}
	    }
	});




	w = systemServicesTable.getFontMetrics(systemServicesTable.getFont()).stringWidth(Constants.NOT_RUNNING);

	insets = ((javax.swing.JComponent)systemServicesTable.getCellRenderer(0,1)).getInsets();
	
	w+= (insets.left+insets.right);

	systemServicesTable.getColumnModel().getColumn(2).setPreferredWidth(w );
	systemServicesTable.getColumnModel().getColumn(1).setPreferredWidth(w );
	systemServicesTable.getColumnModel().getColumn(0).setPreferredWidth(w*4 );


	javax.swing.JScrollPane jScrollPane3 
	= new javax.swing.JScrollPane(systemServicesTable);

	adminTablePanel.add(jScrollPane3,java.awt.BorderLayout.CENTER);
      

	
	header = systemServicesTable.getTableHeader();
	header.addMouseListener(
				systemServicesModel.new ColumnListener(systemServicesTable,rwLock));
      


	/*
	** End creation of system services table
	*/



	/*
	** Create a timer for updating models periodically
	*/

	Utils.UpdateModel m[] = new Utils.UpdateModel[3];

	m[0] = distrModel;
	m[1] = systemServicesModel;
	m[2] = dataServicesModel;
	
	Utils.UpdateListenerList updater = new Utils.UpdateListenerList(rwLock,
									this,
									m);

	
	updateTimer = new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs,
					    updater);
	



        /*
	** Setup radio buttons so that both mode buttons can be unselected
	*/

	javax.swing.ButtonGroup group;
	noneRB = new javax.swing.JRadioButton();
	
	group = new javax.swing.ButtonGroup();
	group.add(normalRB);
	group.add(hotRB);
	group.add(coldRB);
	group.add(dormantRB);
	group.add(noneRB);


	noneRB.setSelected(true);

        
        locationComboBox.setRenderer( new IDS_SwingUtils.LocationComboBoxRenderer());
        
        String[] a = new String[1];
        a[0] = dcmName;
        
        Utils.loadDCMLocationList(locationComboBox, Arrays.asList( a ) );


        
	idTextF.getDocument().addDocumentListener( docListener ); 
     
   
	dataServicesTable.getSelectionModel().addListSelectionListener(this);
	systemServicesTable.getSelectionModel().addListSelectionListener(this);
	distrTable.getSelectionModel().addListSelectionListener(this);

        
        jPanel26.setBorder (new javax.swing.border.TitledBorder(Constants.DC1_LOCATION_LABEL));
        jPanel27.setBorder (new javax.swing.border.TitledBorder(Constants.DC2_LOCATION_LABEL));
       
        try {
                HashMap map = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcmName);
                String l1 = (String)map.get("LOCATION1");
                String l2 = (String)map.get("LOCATION2");
                if (l1 != null)
                        jPanel26.setBorder (new javax.swing.border.TitledBorder(l1));
                if (l2!=null)
                        jPanel27.setBorder (new javax.swing.border.TitledBorder(l2));
        }
        catch (Exception e){
        }
        
       
  
        ActionHandlers.SwitchActionHandler switchHandler
                = new ActionHandlers.SwitchActionHandler(this, this,
                                                         rwLock, updateTimer,
                                                         distrTable, locationComboBox,
                                                         normalRB, hotRB, coldRB, dormantRB);
        switchButton.addActionListener(switchHandler);
        
        ActionHandlers.ProcessActionHandler serviceHandler
                = new ActionHandlers.ProcessActionHandler(this, this,
                                                          rwLock, updateTimer,
                                                          distrTable, locationComboBox,
                                                          normalRB, hotRB, coldRB, dormantRB,
                                                          noneRB, -1);
        
        startButton.addActionListener(serviceHandler);
        stopButton.addActionListener(serviceHandler);
        modeButton.addActionListener(serviceHandler);
        
        
                ActionHandlers.DistributorStatusHandler statusHandler
                = new ActionHandlers.DistributorStatusHandler(this,
                                               distrTable,
                                               Constants.DCM_LINEHANDLER,
                                               locationComboBox);
                statusButton.addActionListener(statusHandler);
        
        
                retransRequestButton.addActionListener( new ActionHandlers.RetransRequestActionHandler(this, this, rwLock, updateTimer, distrTable, null));
        
       
                retransStatusButton.addActionListener( new ActionHandlers.RetransStatusActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                x25LinkButton.addActionListener( new ActionHandlers.X25LinkConfigActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                addButton.addActionListener( new ActionHandlers.AddDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, dcmName));

                modifyButton.addActionListener( new ActionHandlers.EditDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null, false));


                copyButton.addActionListener( new ActionHandlers.EditDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null, true));


                deleteButton.addActionListener( new ActionHandlers.DeleteDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                distrSelectAllButton.addActionListener( new ActionHandlers.SelectAllActionHandler(distrTable));
                
                dataServicesSelectAllButton.addActionListener( new ActionHandlers.SelectAllActionHandler(dataServicesTable));
  
                jCheckBox1.addActionListener( new ActionHandlers.ShowRunningActionHandler(this, this, rwLock, updateTimer, distrTable));
        


                locationComboBox.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {  updateUIState(0); }
                }
                                                   );

                ActionHandlers.DCMDataServicesHandler dataServiceHandler
                        = new ActionHandlers.DCMDataServicesHandler(this, this,
                                                                    rwLock,
                                                                    updateTimer,
                                                                    dataServicesTable,
                                                                    null, dcmName);
                

                startButton11.addActionListener(dataServiceHandler);
                stopButton11.addActionListener(dataServiceHandler);
                startButton21.addActionListener(dataServiceHandler); 
                stopButton21.addActionListener(dataServiceHandler);     
                
                ActionHandlers.DCMDataStatusHandler dataStatusHandler
                        = new ActionHandlers.DCMDataStatusHandler(this, this,
                                                                    rwLock,
                                                                    updateTimer,
                                                                    dataServicesTable,
                                                                    null, dcmName);

                statusButton11.addActionListener(dataStatusHandler);
                statusButton21.addActionListener(dataStatusHandler);




                ActionHandlers.DCMRetransStatusHandler retransStatusHandler
                        = new ActionHandlers.DCMRetransStatusHandler(this, this,
                                                                     rwLock,
                                                                     updateTimer,
                                                                     systemServicesTable,
                                                                     null, dcmName,
                                                                     dataServicesModel);
                jButton2.addActionListener(retransStatusHandler);

                jButton19.addActionListener(new java.awt.event.ActionListener() 
                                            {
                                                    public void actionPerformed(java.awt.event.ActionEvent evt) 
                                                    {

                                                            StringBuffer sb = new StringBuffer(evt.getActionCommand());
                                                            
                                                            String key = sb.append(dcmName).toString();
  
                                                            
                                                            java.awt.Window f =
                                                            (java.awt.Window)WindowEventAdapter.getInstance().findWindow(key);
                                                            
                                                            
                                                            
                                                            if (f == null) {
                                                                    try {
                                                                            f =  new DCMConfigForm(dcmName);
                                                                    } catch (Exception e) {
                                                                            Log.getInstance().show_error(myFrame,"Error",
                                                                                                         "Error in creating window:\n\t"
                                                                                                         +e.getMessage(), e);
                                                                    }
                                                            }
                                                            
                                                            
                                                            if (f != null) 
                                                                    f.show();
                                                            
                                                    }
                                                    
                                            }
                                            );
                

                ActionHandlers.ExitHandler exitHandler =
                new ActionHandlers.ExitHandler(this,
                                               this,
                                               rwLock, 
                                               updateTimer,
                                               distrTable);
                                                  
                closeButton.addActionListener(exitHandler);
                addWindowListener(exitHandler);


                
    }  // End of myInitComponents()







    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents () {//GEN-BEGIN:initComponents
      jTabbedPane1 = new javax.swing.JTabbedPane ();
      jPanel1 = new javax.swing.JPanel ();
      dataTablePanel = new javax.swing.JPanel ();
      jPanel5 = new javax.swing.JPanel ();
      jPanel10 = new javax.swing.JPanel ();
      dataServicesSelectAllButton = new javax.swing.JButton ();
      jPanel26 = new javax.swing.JPanel ();
      startButton11 = new javax.swing.JButton ();
      stopButton11 = new javax.swing.JButton ();
      statusButton11 = new javax.swing.JButton ();
      jPanel27 = new javax.swing.JPanel ();
      startButton21 = new javax.swing.JButton ();
      stopButton21 = new javax.swing.JButton ();
      statusButton21 = new javax.swing.JButton ();
      jPanel2 = new javax.swing.JPanel ();
      distrTablePanel = new javax.swing.JPanel ();
      jPanel3 = new javax.swing.JPanel ();
      jPanel4 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      idTextF = new ids2ui.UCTextField ();
      jPanel16 = new javax.swing.JPanel ();
      distrSelectAllButton = new javax.swing.JButton ();
      jCheckBox1 = new javax.swing.JCheckBox ();
      jTabbedPane2 = new javax.swing.JTabbedPane ();
      jPanel9 = new javax.swing.JPanel ();
      jPanel11 = new javax.swing.JPanel ();
      switchButton = new javax.swing.JButton ();
      locationComboBox = new javax.swing.JComboBox ();
      startButton = new javax.swing.JButton ();
      stopButton = new javax.swing.JButton ();
      modeButton = new javax.swing.JButton ();
      statusButton = new javax.swing.JButton ();
      jLabel2 = new javax.swing.JLabel ();
      jPanel13 = new javax.swing.JPanel ();
      dormantRB = new javax.swing.JRadioButton ();
      normalRB = new javax.swing.JRadioButton ();
      hotRB = new javax.swing.JRadioButton ();
      coldRB = new javax.swing.JRadioButton ();
      jLabel3 = new javax.swing.JLabel ();
      jPanel14 = new javax.swing.JPanel ();
      retransStatusButton = new javax.swing.JButton ();
      retransRequestButton = new javax.swing.JButton ();
      jPanel15 = new javax.swing.JPanel ();
      addButton = new javax.swing.JButton ();
      copyButton = new javax.swing.JButton ();
      modifyButton = new javax.swing.JButton ();
      deleteButton = new javax.swing.JButton ();
      x25LinkButton = new javax.swing.JButton ();
      jPanel6 = new javax.swing.JPanel ();
      adminTablePanel = new javax.swing.JPanel ();
      jPanel8 = new javax.swing.JPanel ();
      jButton2 = new javax.swing.JButton ();
      jPanel24 = new javax.swing.JPanel ();
      jButton19 = new javax.swing.JButton ();
      closeButton = new javax.swing.JButton ();
      statusPanel1 = new ids2ui.StatusPanel ();
      getContentPane ().setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;

      jTabbedPane1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));

        jPanel1.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints2;
  
          dataTablePanel.setLayout (new java.awt.BorderLayout ());
          dataTablePanel.setBorder (new javax.swing.border.TitledBorder(""));
    
            jPanel5.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints3;
      
              jPanel10.setLayout (new java.awt.FlowLayout (1, 25, 5));
        
                dataServicesSelectAllButton.setText ("Select all");
                dataServicesSelectAllButton.setActionCommand ("AllData");
          
                jPanel10.add (dataServicesSelectAllButton);
          
              gridBagConstraints3 = new java.awt.GridBagConstraints ();
              gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints3.weightx = 1.0;
              jPanel5.add (jPanel10, gridBagConstraints3);
        
            dataTablePanel.add (jPanel5, java.awt.BorderLayout.SOUTH);
      
          gridBagConstraints2 = new java.awt.GridBagConstraints ();
          gridBagConstraints2.gridwidth = 2;
          gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints2.weightx = 1.0;
          gridBagConstraints2.weighty = 1.0;
          jPanel1.add (dataTablePanel, gridBagConstraints2);
    
          jPanel26.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints4;
          jPanel26.setBorder (new javax.swing.border.TitledBorder("First location"));
    
            startButton11.setText ("Start");
            startButton11.setForeground (new java.awt.Color (0, 150, 50));
            startButton11.setActionCommand ("START1");
            startButton11.setLabel ("START");
      
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 0;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.NORTHWEST;
            jPanel26.add (startButton11, gridBagConstraints4);
      
            stopButton11.setText ("Stop");
            stopButton11.setForeground (java.awt.Color.red);
            stopButton11.setActionCommand ("STOP1");
            stopButton11.setLabel ("STOP");
      
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 1;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.NORTHEAST;
            jPanel26.add (stopButton11, gridBagConstraints4);
      
            statusButton11.setText ("Status");
            statusButton11.setForeground (java.awt.Color.blue);
            statusButton11.setActionCommand ("STATUS1");
            statusButton11.setLabel ("STATUS");
      
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 2;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.SOUTHWEST;
            jPanel26.add (statusButton11, gridBagConstraints4);
      
          gridBagConstraints2 = new java.awt.GridBagConstraints ();
          gridBagConstraints2.gridx = 0;
          gridBagConstraints2.gridy = 1;
          gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
          gridBagConstraints2.weightx = 0.5;
          jPanel1.add (jPanel26, gridBagConstraints2);
    
          jPanel27.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints5;
          jPanel27.setBorder (new javax.swing.border.TitledBorder("Second location"));
    
            startButton21.setText ("Start");
            startButton21.setForeground (new java.awt.Color (0, 150, 50));
            startButton21.setActionCommand ("START2");
            startButton21.setLabel ("START");
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 0;
            gridBagConstraints5.gridy = 0;
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.NORTH;
            jPanel27.add (startButton21, gridBagConstraints5);
      
            stopButton21.setText ("Stop");
            stopButton21.setForeground (java.awt.Color.red);
            stopButton21.setActionCommand ("STOP2");
            stopButton21.setLabel ("STOP");
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 1;
            gridBagConstraints5.gridy = 0;
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.NORTH;
            jPanel27.add (stopButton21, gridBagConstraints5);
      
            statusButton21.setText ("Status");
            statusButton21.setForeground (java.awt.Color.blue);
            statusButton21.setActionCommand ("STATUS2");
            statusButton21.setLabel ("STATUS");
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 2;
            gridBagConstraints5.gridy = 0;
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.SOUTH;
            jPanel27.add (statusButton21, gridBagConstraints5);
      
          gridBagConstraints2 = new java.awt.GridBagConstraints ();
          gridBagConstraints2.gridx = 1;
          gridBagConstraints2.gridy = 1;
          gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
          gridBagConstraints2.weightx = 0.5;
          jPanel1.add (jPanel27, gridBagConstraints2);
    
        jTabbedPane1.addTab ("Data services", jPanel1);
  
        jPanel2.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints6;
  
          distrTablePanel.setLayout (new java.awt.BorderLayout ());
          distrTablePanel.setBorder (new javax.swing.border.TitledBorder(""));
    
            jPanel3.setLayout (new java.awt.BorderLayout ());
      
        
                jLabel1.setText ("ID");
          
                jPanel4.add (jLabel1);
          
                idTextF.setColumns (5);
          
                jPanel4.add (idTextF);
          
              jPanel3.add (jPanel4, java.awt.BorderLayout.WEST);
        
              jPanel16.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints7;
        
                distrSelectAllButton.setMargin (new java.awt.Insets(2, 7, 2, 7));
                distrSelectAllButton.setText ("Select all");
          
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.anchor = java.awt.GridBagConstraints.EAST;
                jPanel16.add (distrSelectAllButton, gridBagConstraints7);
          
                jCheckBox1.setText ("View running programs only ");
          
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.insets = new java.awt.Insets (0, 10, 0, 5);
                gridBagConstraints7.anchor = java.awt.GridBagConstraints.EAST;
                jPanel16.add (jCheckBox1, gridBagConstraints7);
          
              jPanel3.add (jPanel16, java.awt.BorderLayout.EAST);
        
            distrTablePanel.add (jPanel3, java.awt.BorderLayout.SOUTH);
      
          gridBagConstraints6 = new java.awt.GridBagConstraints ();
          gridBagConstraints6.gridwidth = 2;
          gridBagConstraints6.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints6.weightx = 1.0;
          gridBagConstraints6.weighty = 1.0;
          jPanel2.add (distrTablePanel, gridBagConstraints6);
    
    
            jPanel9.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints8;
            jPanel9.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
      
              jPanel11.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints9;
              jPanel11.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));
        
                switchButton.setText ("Switch");
                switchButton.setForeground (java.awt.Color.red);
                switchButton.setActionCommand ("SWITCH");
                switchButton.setLabel ("SWITCH");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 4;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel11.add (switchButton, gridBagConstraints9);
          
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 1;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (0, 5, 0, 15);
                jPanel11.add (locationComboBox, gridBagConstraints9);
          
                startButton.setText ("Start");
                startButton.setForeground (new java.awt.Color (0, 150, 50));
                startButton.setActionCommand ("START");
                startButton.setLabel ("START");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 2;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel11.add (startButton, gridBagConstraints9);
          
                stopButton.setText ("Stop");
                stopButton.setForeground (java.awt.Color.red);
                stopButton.setActionCommand ("STOP");
                stopButton.setLabel ("STOP");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 3;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel11.add (stopButton, gridBagConstraints9);
          
                modeButton.setText ("Set Mode");
                modeButton.setForeground (java.awt.Color.red);
                modeButton.setActionCommand ("MODE");
                modeButton.setLabel ("SET MODE");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 5;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel11.add (modeButton, gridBagConstraints9);
          
                statusButton.setText ("Status");
                statusButton.setForeground (java.awt.Color.blue);
                statusButton.setActionCommand ("STATUS");
                statusButton.setLabel ("STATUS");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 6;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel11.add (statusButton, gridBagConstraints9);
          
                jLabel2.setText ("Location");
          
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 0;
                gridBagConstraints9.gridy = 0;
                jPanel11.add (jLabel2, gridBagConstraints9);
          
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.gridx = 0;
              gridBagConstraints8.gridy = 1;
              gridBagConstraints8.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints8.insets = new java.awt.Insets (0, 0, 5, 0);
              jPanel9.add (jPanel11, gridBagConstraints8);
        
              jPanel13.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints10;
        
                dormantRB.setText ("Dormant");
          
                gridBagConstraints10 = new java.awt.GridBagConstraints ();
                gridBagConstraints10.gridx = 4;
                gridBagConstraints10.gridy = 0;
                gridBagConstraints10.insets = new java.awt.Insets (0, 10, 0, 5);
                gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
                jPanel13.add (dormantRB, gridBagConstraints10);
          
                normalRB.setText ("Normal");
          
                gridBagConstraints10 = new java.awt.GridBagConstraints ();
                gridBagConstraints10.gridx = 1;
                gridBagConstraints10.gridy = 0;
                gridBagConstraints10.insets = new java.awt.Insets (0, 5, 0, 5);
                gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
                jPanel13.add (normalRB, gridBagConstraints10);
          
                hotRB.setText ("Hot");
          
                gridBagConstraints10 = new java.awt.GridBagConstraints ();
                gridBagConstraints10.gridx = 2;
                gridBagConstraints10.gridy = 0;
                gridBagConstraints10.insets = new java.awt.Insets (0, 5, 0, 5);
                gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
                jPanel13.add (hotRB, gridBagConstraints10);
          
                coldRB.setText ("Cold");
          
                gridBagConstraints10 = new java.awt.GridBagConstraints ();
                gridBagConstraints10.gridx = 3;
                gridBagConstraints10.gridy = 0;
                gridBagConstraints10.insets = new java.awt.Insets (0, 5, 0, 5);
                gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
                jPanel13.add (coldRB, gridBagConstraints10);
          
                jLabel3.setText ("Start/Switch modes");
          
                gridBagConstraints10 = new java.awt.GridBagConstraints ();
                gridBagConstraints10.gridx = 0;
                gridBagConstraints10.gridy = 0;
                gridBagConstraints10.insets = new java.awt.Insets (0, 0, 0, 10);
                gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
                jPanel13.add (jLabel3, gridBagConstraints10);
          
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints8.insets = new java.awt.Insets (2, 0, 10, 0);
              gridBagConstraints8.anchor = java.awt.GridBagConstraints.SOUTH;
              gridBagConstraints8.weightx = 1.0;
              jPanel9.add (jPanel13, gridBagConstraints8);
        
            jTabbedPane2.addTab ("Services", jPanel9);
      
            jPanel14.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints11;
            jPanel14.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 5, 5, 5)));
      
              retransStatusButton.setText ("Retransmission Status");
              retransStatusButton.setActionCommand ("RTP_STATUS");
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.gridx = 1;
              gridBagConstraints11.gridy = 0;
              gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.NORTHWEST;
              gridBagConstraints11.weightx = 0.5;
              gridBagConstraints11.weighty = 0.8;
              jPanel14.add (retransStatusButton, gridBagConstraints11);
        
              retransRequestButton.setText ("Retransmission request");
              retransRequestButton.setActionCommand ("RTP_REQUEST");
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.gridx = 0;
              gridBagConstraints11.gridy = 0;
              gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.NORTHEAST;
              gridBagConstraints11.weightx = 0.5;
              gridBagConstraints11.weighty = 0.8;
              jPanel14.add (retransRequestButton, gridBagConstraints11);
        
            jTabbedPane2.addTab ("Retransmission", jPanel14);
      
            jPanel15.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints12;
            jPanel15.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 5, 5, 5)));
      
              addButton.setToolTipText ("Add a new distributor ");
              addButton.setText ("Add ");
              addButton.setActionCommand ("ADD");
        
              gridBagConstraints12 = new java.awt.GridBagConstraints ();
              gridBagConstraints12.gridx = 0;
              gridBagConstraints12.gridy = 0;
              gridBagConstraints12.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints12.anchor = java.awt.GridBagConstraints.NORTH;
              gridBagConstraints12.weighty = 0.8;
              jPanel15.add (addButton, gridBagConstraints12);
        
              copyButton.setToolTipText ("Copy distributor's configuration to create new");
              copyButton.setText ("Copy");
              copyButton.setActionCommand ("COPY");
        
              gridBagConstraints12 = new java.awt.GridBagConstraints ();
              gridBagConstraints12.gridx = 1;
              gridBagConstraints12.gridy = 0;
              gridBagConstraints12.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints12.anchor = java.awt.GridBagConstraints.NORTH;
              gridBagConstraints12.weighty = 0.8;
              jPanel15.add (copyButton, gridBagConstraints12);
        
              modifyButton.setToolTipText ("Modify distributor's configuration");
              modifyButton.setText ("Modify");
              modifyButton.setActionCommand ("MODIFY");
        
              gridBagConstraints12 = new java.awt.GridBagConstraints ();
              gridBagConstraints12.gridx = 2;
              gridBagConstraints12.gridy = 0;
              gridBagConstraints12.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints12.anchor = java.awt.GridBagConstraints.NORTH;
              gridBagConstraints12.weighty = 0.8;
              jPanel15.add (modifyButton, gridBagConstraints12);
        
              deleteButton.setToolTipText ("Delete distributor from database");
              deleteButton.setText ("Delete");
              deleteButton.setActionCommand ("DELETE");
        
              gridBagConstraints12 = new java.awt.GridBagConstraints ();
              gridBagConstraints12.gridx = 3;
              gridBagConstraints12.gridy = 0;
              gridBagConstraints12.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints12.anchor = java.awt.GridBagConstraints.NORTH;
              gridBagConstraints12.weighty = 0.8;
              jPanel15.add (deleteButton, gridBagConstraints12);
        
              x25LinkButton.setText ("X.25 Link Menu");
              x25LinkButton.setActionCommand ("X25_LINK_MENU");
        
              gridBagConstraints12 = new java.awt.GridBagConstraints ();
              gridBagConstraints12.gridx = 4;
              gridBagConstraints12.gridy = 0;
              gridBagConstraints12.insets = new java.awt.Insets (5, 10, 5, 5);
              gridBagConstraints12.anchor = java.awt.GridBagConstraints.NORTH;
              gridBagConstraints12.weighty = 0.8;
              jPanel15.add (x25LinkButton, gridBagConstraints12);
        
            jTabbedPane2.addTab ("Configuration", jPanel15);
      
          gridBagConstraints6 = new java.awt.GridBagConstraints ();
          gridBagConstraints6.gridx = 0;
          gridBagConstraints6.gridy = 1;
          gridBagConstraints6.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints6.weightx = 1.0;
          jPanel2.add (jTabbedPane2, gridBagConstraints6);
    
        jTabbedPane1.addTab ("Distributor services", jPanel2);
  
        jPanel6.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints13;
  
          adminTablePanel.setLayout (new java.awt.BorderLayout ());
          adminTablePanel.setBorder (new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), ""));
    
            jPanel8.setLayout (new java.awt.FlowLayout (1, 25, 5));
      
              jButton2.setText ("Status");
              jButton2.setActionCommand ("RTP_DCM_STATUS");
        
              jPanel8.add (jButton2);
        
            adminTablePanel.add (jPanel8, java.awt.BorderLayout.SOUTH);
      
          gridBagConstraints13 = new java.awt.GridBagConstraints ();
          gridBagConstraints13.gridwidth = 2;
          gridBagConstraints13.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints13.weightx = 1.0;
          gridBagConstraints13.weighty = 1.0;
          jPanel6.add (adminTablePanel, gridBagConstraints13);
    
        jTabbedPane1.addTab ("System services", jPanel6);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints1.weightx = 1.0;
      gridBagConstraints1.weighty = 1.0;
      getContentPane ().add (jTabbedPane1, gridBagConstraints1);

      jPanel24.setLayout (new java.awt.FlowLayout (1, 20, 5));

        jButton19.setText ("DCM configuration");
        jButton19.setActionCommand (Constants.CONFIGURATION_DCM_PREFIX);
  
        jPanel24.add (jButton19);
  
        closeButton.setText ("Close");
  
        jPanel24.add (closeButton);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 1;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (jPanel24, gridBagConstraints1);

      statusPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
      new javax.swing.border.EtchedBorder()));


      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 2;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (statusPanel1, gridBagConstraints1);

    }//GEN-END:initComponents



   
  

       

    

    





    




    
    


    /** Exit the Application */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel dataTablePanel;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JButton dataServicesSelectAllButton;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JButton startButton11;
    private javax.swing.JButton stopButton11;
    private javax.swing.JButton statusButton11;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JButton startButton21;
    private javax.swing.JButton stopButton21;
    private javax.swing.JButton statusButton21;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel distrTablePanel;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel jLabel1;
    private ids2ui.UCTextField idTextF;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JButton distrSelectAllButton;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JButton switchButton;
    private javax.swing.JComboBox locationComboBox;
    private javax.swing.JButton startButton;
    private javax.swing.JButton stopButton;
    private javax.swing.JButton modeButton;
    private javax.swing.JButton statusButton;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JRadioButton dormantRB;
    private javax.swing.JRadioButton normalRB;
    private javax.swing.JRadioButton hotRB;
    private javax.swing.JRadioButton coldRB;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JButton retransStatusButton;
    private javax.swing.JButton retransRequestButton;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JButton addButton;
    private javax.swing.JButton copyButton;
    private javax.swing.JButton modifyButton;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton x25LinkButton;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel adminTablePanel;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton closeButton;
    private ids2ui.StatusPanel statusPanel1;
    // End of variables declaration//GEN-END:variables

  

    
	    

   
   
}

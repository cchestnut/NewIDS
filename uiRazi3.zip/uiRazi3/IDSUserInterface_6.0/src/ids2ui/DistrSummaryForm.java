/*
**  SCCS Info :  "@(#)DistrSummaryForm.java	1.15    04/04/01"
*/
/*
 * DistrSummaryForm.java
 *
 * Created on December 1, 2000, 10:51 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistrSummaryForm 
    extends javax.swing.JFrame 
    implements TaskListener, javax.swing.event.ListSelectionListener
{

    private javax.swing.JTable summaryTable = null;
    private DistrSummaryForm  myFrame = null;
    private javax.swing.table.TableCellRenderer stateCellRenderer=null;

    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock(); 

    private volatile boolean isExiting = false;
        javax.swing.event.DocumentListener docListener = null;

    /** Creates new form DistrSummaryForm */
    public DistrSummaryForm() {

	try {
		stateCellRenderer = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultDistrSummaryCellColorMap);
	} catch (Exception e) {
		Log.getInstance().log_error("DistrSummaryForm:Error in "
			+"creating cell renderer.",e);
	}

	myFrame = this;
	setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

	initComponents ();
	myInitComponents ();
    
	pack ();

	updateTimer.start();
	WindowEventAdapter.getInstance().registerWindow(Constants.SERVICES_DISTRIBUTORS_SUMMARY,this);

    }

    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;
	int srows[] = summaryTable.getSelectedRows();

	idTextF.getDocument().removeDocumentListener( docListener);

	if (srows.length!=1)
		idTextF.setText("");
	else
		idTextF.setText((String)summaryTable.getValueAt(srows[0],0));

	idTextF.getDocument().addDocumentListener( docListener);
		

    }

    private void myInitComponents()
    {

	if (AccessLevel.MENU_ACCESS_LEVEL > 1) 
		jButton6.setEnabled(false);

	DistrSummaryStatusModel model = new DistrSummaryStatusModel();


	summaryTable = new javax.swing.JTable(model) {
	    public javax.swing.table.TableCellRenderer getCellRenderer(int row, int column) {
		if ((stateCellRenderer!=null)
			&& ((column==2) || (column==3)))
		    return stateCellRenderer;

		return super.getCellRenderer(row,column);
	    }
	
	};


	javax.swing.table.JTableHeader header = summaryTable.getTableHeader();
	header.addMouseListener(model.new ColumnListener(summaryTable, rwLock));
    
	tablePanel.add(new javax.swing.JScrollPane(summaryTable),java.awt.BorderLayout.CENTER);
    
    
	Utils.UpdateListener updater = new Utils.UpdateListener(rwLock, this,
								model);

	updateTimer = new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, updater);
	


        docListener = new ActionHandlers.IDFieldListener(this, summaryTable, idTextF);
         
	idTextF.getDocument().addDocumentListener( docListener );   
    	
	summaryTable.getSelectionModel().addListSelectionListener(myFrame);


	summaryTable.addMouseListener( new java.awt.event.MouseAdapter() {
	    public void mouseClicked(java.awt.event.MouseEvent evt) {
		if (evt.getClickCount() != 2) 
		    return;

		int row = summaryTable.getSelectedRow();
		int col = summaryTable.getSelectedColumn();
		if (col<=1) return;
		
		String value = (String)summaryTable.getValueAt(row,col);
		
		if ((value!=null) && 
		    ( value.startsWith("Running")
		      || value.startsWith("UP")
		      || value.startsWith("DOWN") 
		      || value.startsWith("ACTIVE")
		      || value.startsWith("DORMANT") ) ) {
		    
		    DistrSummaryStatusModel mdl
			= (DistrSummaryStatusModel)summaryTable.getModel();
		    String distr = (String)mdl.getValueAt(row,0);
		    String stype = mdl.getType(row);

                    int location_index = col-1;
		    int type = Constants.DCM_LINEHANDLER;
		    if (stype.startsWith(Constants.GLB_TAG_DSP))
			type = Constants.DSP_BROADCASTER;
                    else {
                            try {
                                java.util.HashMap
                                        m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX
                                                                  +distr);
                                
                                String pl = (String)m.get("HOME_LOCATION");
                                if (pl!=null && !pl.equals("1")) {
                                        if (col==2) 
                                                location_index = 2;
                                        
                                        if (col==3) 
                                                location_index = 1;
                                }
                        }
                        catch (Exception e){
                        }
                    }
                    
		    
		    
		    try {
			DistributorStatusForm f 
			    = new DistributorStatusForm(type,location_index,distr);
			f.show();
		    } catch (Exception ex) {}
		}
	    }
	});
	


    } // End of myInitComponents()



    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }

    public void taskStarted(final String s) {
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	
	if (s==null)
	    statusPanel.start();
	else
	    statusPanel.start(s);
	}
    }

    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(java.util.EventObject evt) {	
	taskEnded("Status updated @ "+new java.util.Date().toString());
    }


    public void taskEnded(final String s) {
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}	
	    };		
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();
	    if (s!=null)
		statusPanel.showStatus(s);
	    repaint();
	}
    }


    


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents () {//GEN-BEGIN:initComponents
      tablePanel = new javax.swing.JPanel ();
      jPanel4 = new javax.swing.JPanel ();
      jButton6 = new javax.swing.JButton ();
      jPanel1 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      idTextF = new ids2ui.UCTextField ();
      jPanel2 = new javax.swing.JPanel ();
      jButton1 = new javax.swing.JButton ();
      jButton2 = new javax.swing.JButton ();
      statusPanel = new ids2ui.StatusPanel ();
      getContentPane ().setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;
      setTitle ("Distributor Services Favorites Screen");
      addWindowListener (new java.awt.event.WindowAdapter () {
        public void windowClosing (java.awt.event.WindowEvent evt) {
          exitForm (evt);
        }
      }
      );

      tablePanel.setLayout (new java.awt.BorderLayout ());
      tablePanel.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.EtchedBorder()));

        jPanel4.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints2;
        jPanel4.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
  
          jButton6.setText ("Edit favorites list");
          jButton6.setActionCommand ("Edit");
          jButton6.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              actionHandler (evt);
            }
          }
          );
    
          gridBagConstraints2 = new java.awt.GridBagConstraints ();
          gridBagConstraints2.gridx = 1;
          gridBagConstraints2.gridy = 0;
          jPanel4.add (jButton6, gridBagConstraints2);
    
          jPanel1.setLayout (new java.awt.FlowLayout (0, 5, 5));
    
            jLabel1.setText ("ID");
      
            jPanel1.add (jLabel1);
      
            idTextF.setColumns (6);
      
            jPanel1.add (idTextF);
      
          gridBagConstraints2 = new java.awt.GridBagConstraints ();
          gridBagConstraints2.gridx = 0;
          gridBagConstraints2.gridy = 0;
          gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
          gridBagConstraints2.weightx = 0.25;
          jPanel4.add (jPanel1, gridBagConstraints2);
    
        tablePanel.add (jPanel4, java.awt.BorderLayout.SOUTH);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints1.weightx = 1.0;
      gridBagConstraints1.weighty = 1.0;
      getContentPane ().add (tablePanel, gridBagConstraints1);

      jPanel2.setLayout (new java.awt.FlowLayout (1, 25, 5));

        jButton1.setText ("Refresh");
        jButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            actionHandler (evt);
          }
        }
        );
  
        jPanel2.add (jButton1);
  
        jButton2.setText ("Close");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            actionHandler (evt);
          }
        }
        );
  
        jPanel2.add (jButton2);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 1;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (jPanel2, gridBagConstraints1);

      statusPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));


      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 2;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (statusPanel, gridBagConstraints1);

    }//GEN-END:initComponents

    private void actionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actionHandler
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;

	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_actionHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();

    }//GEN-LAST:event_actionHandler


    private void _actionHandler(javax.swing.JButton cmdButton, String command)
    {

	if (command.equals("Edit")) {
	    try {
		new DistrFavoritesForm(this).show();
	    } catch (Exception e) {
		Log.getInstance().show_error(this,"Error",
					     "Error in displaying dialog",e);
	    }
	    cmdButton.setEnabled(true);
	    return;
	}



	if (command.equals("Refresh")) {
	    DistrSummaryStatusModel model
		= (DistrSummaryStatusModel)summaryTable.getModel();
	    try {
		rwLock.writeLock().acquire();
		model.Refresh();
		rwLock.writeLock().release();
	    } catch (Exception e) {}

	    cmdButton.setEnabled(true);
	    return;
	}
  
	exitForm(null);
  

    }
    






    /** Exit the Application */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm

	if (isExiting) return;

	isExiting = true;

	if (updateTimer!=null)
	    updateTimer.stop();

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);

	
	final DistrSummaryForm This = this;
	

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();

		    DistrSummaryStatusModel model 
			= (DistrSummaryStatusModel) summaryTable.getModel();
		    model.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();

    }//GEN-LAST:event_exitForm

 


    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel tablePanel;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton jButton6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jLabel1;
    private ids2ui.UCTextField idTextF;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private ids2ui.StatusPanel statusPanel;
    // End of variables declaration//GEN-END:variables

}

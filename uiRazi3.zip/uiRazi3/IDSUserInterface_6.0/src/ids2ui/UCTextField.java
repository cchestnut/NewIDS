/*
**  SCCS Info :  "@(#)UCTextField.java	1.1    00/11/16"
*/
/*
 * UCTextField.java
 *
 * Created on March 6, 2000, 5:12 PM
 */
 
package ids2ui;
import javax.swing.*;
import javax.swing.text.*;

/** 
 *
 * @author  srz
 * @version 
 */
public class UCTextField extends javax.swing.JTextField {

  /** Creates new UCTextField */
 public UCTextField() {
    super();
  }


  public UCTextField(int cols) {
    super(cols);
  }

  protected javax.swing.text.Document createDefaultModel() {
    return new UpperCaseDocument();
  }

  static class UpperCaseDocument extends javax.swing.text.PlainDocument {

    public void insertString(int offs, String str, javax.swing.text.AttributeSet a) 
      throws javax.swing.text.BadLocationException {

      if (str == null) {
        return;
        }
      char[] upper = str.toCharArray();
      char[] upper1;
      int l=0;
      for (int i = 0; i < upper.length; i++) {
        if (Character.isLetterOrDigit(upper[i]))
          upper[l++] = Character.toUpperCase(upper[i]);
        else 
          java.awt.Toolkit.getDefaultToolkit().beep();
        
      }
      upper1 = new char [l];
      System.arraycopy(upper, 0, upper1, 0, l);
      super.insertString(offs, new String(upper1), a);
    }
  }

  
}

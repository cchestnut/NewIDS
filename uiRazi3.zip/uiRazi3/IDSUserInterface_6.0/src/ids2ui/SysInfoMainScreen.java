/*
**  SCCS Info :  "@(#)SysInfoMainScreen.java	1.8    03/03/12"
*/
/*
 * SysInfoMainScreen.java
 *
 * Created on December 26, 2000, 1:35 PM
 */
 
package ids2ui;


/** 
 *
 * @author  srz
 * @version 
 */
public class SysInfoMainScreen extends javax.swing.JFrame {

   private java.util.Vector fileList=null;
   private javax.swing.JTable configTable=null;
   private java.util.Vector transportList = null;
   private java.util.Vector formatList=null;
   private java.util.Vector protocolList=null;

   private javax.swing.JTextArea valueTextArea 	
						= new javax.swing.JTextArea(10,40);
  
  
  /** Creates new form SysInfoMainScreen */
  public SysInfoMainScreen() throws Exception {
    
    fileList = ConfigComm.getSystemFileList();    
    transportList = ConfigComm.getIDSTransportTypeList();
    formatList = new java.util.Vector(ConfigComm.getIDSProductFormatList());
    protocolList = new java.util.Vector(ConfigComm.getReaderProtocolList());

    initComponents ();
    
    
    pack ();
    
    WindowEventAdapter.getInstance().registerWindow(Constants.CONFIGURATION_SYSINFO,this);

    jButton1.setEnabled(false);//Close
    jButton4.setEnabled(false); //Retrieve
    jButton5.setEnabled(false); //Save Key-Value
    jButton6.setEnabled(false); //Delete Key-Value
    jButton8.setEnabled(false);	// Save protocol

    final SwingWorker loader = new SwingWorker() {
	    Exception err = null;
	    public Object construct() {
		statusPanel.start("Loading configuration. Please wait..");
		try {    
    			myInitComponents();    
		} catch (Exception e) {
		    err = e;
		    return (e);
		}
		return null;
		
	    }

	    public void finished() {
		statusPanel.stop();
		if (err==null) {
    			showConfig();
    			jButton4.setEnabled(true); //Retrieve
    			jButton5.setEnabled(true); //Save Key-Value
    			jButton6.setEnabled(true); //Delete Key-Value
    			jButton8.setEnabled(true);	// Save protocol
		    statusPanel.clear();
		} else {
		    statusPanel.showStatus(err.getMessage());
		}
    		jButton1.setEnabled(true);//Close
	    }
	};

	loader.start();
  }
  

  private void myInitComponents() 
  throws Exception
  {
  


		byte [] b;
		StringBuffer reqbuf = new StringBuffer();
		
		ConfigComm.createHeader(reqbuf, ConfigComm.QUERY_REQUEST, 
								 ConfigComm.GET_KEY_LIST ,0);
		reqbuf.append(ConfigComm.CONF_ETX);
		

		b = ConfigComm.configRequest(reqbuf);
		String result = new String(b);
		String datastr 
				= result.substring(result.indexOf(ConfigComm.CONF_STX)+1);


		StringBuffer sep1 = new StringBuffer();
		sep1.append(ConfigComm.CONF_US).append(ConfigComm.CONF_FS).
				append(ConfigComm.CONF_GS).append(ConfigComm.CONF_ETX);
		datastr.trim();
		
		java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(datastr,sep1.toString());
		int numTokens = tokenizer.countTokens();
		String [] items = new String[numTokens];

		for (int i = 0; i < numTokens; i++ ) {
			items[i] = tokenizer.nextToken();
		}
		
		java.util.Arrays.sort(items);


		javax.swing.DefaultComboBoxModel 
			model = new javax.swing.DefaultComboBoxModel(items);

		keyComboBox.setModel(model);

		keyComboBox.setSelectedItem(items[0]);
   
    
  }
  
  
  private void showConfig()
  {

	nameTextField.setText(Constants.GLB_DCM_INPUT_NAME);
	protocolComboBox.setSelectedItem(Constants.GLB_IDS_PROTOCOL);
	formatComboBox.setSelectedItem(Constants.GLB_IDS_FORMAT);
	transportComboBox.setSelectedItem(Constants.GLB_IDS_TRANSPORT);

	rbpInterfaceTextField.setText(Constants.RBP_INTERFACE_LIST);


	String transport = Constants.GLB_IDS_TRANSPORT;

	if (transport.startsWith("TCP")) {
		tcpPortTextField.setText(Constants.GLB_IDS_TRANSPORT_ADDRESS);
	} else if (transport.startsWith("RBP")) {
		rbpIDTextField.setText(Constants.GLB_IDS_TRANSPORT_ADDRESS);
	} 


	transportChanged(null);
  }

  private void saveConfig()
  {
	String name = nameTextField.getText();
	String protocol = (String)protocolComboBox.getSelectedItem();
	String format = (String)formatComboBox.getSelectedItem();
	String transport = (String)transportComboBox.getSelectedItem();
	String rbplist = rbpInterfaceTextField.getText();
	String address = null;

	if (javax.swing.JOptionPane.YES_OPTION 
				!= Log.getInstance().show_confirm(this, "Confirmation dialog",
							"Are you sure you want to save the parameters?"))
		return;

	if (transport.startsWith("TCP")) {
		address = tcpPortTextField.getText();
	} else if (transport.startsWith("RBP")) {
		address = rbpIDTextField.getText();
	}  else {
		Log.getInstance().show_error(this,"Error",
					 "Unknown transport type.",null);
    	return ;
	}

	if ((address==null) || (address.trim().length()==0) ) {
		Log.getInstance().show_error(this,"Error",
					 "Please specify all fields.",null);
	}


	StringBuffer buf1 = new StringBuffer();
	StringBuffer buf2 = new StringBuffer();
	StringBuffer buf3 = new StringBuffer();
	StringBuffer buf4 = new StringBuffer();
	StringBuffer buf5 = new StringBuffer();
	StringBuffer buf6 = new StringBuffer();

	ConfigComm.saveKeyValue(buf1,"GLB_DCM_INPUT_NAME", name);
	ConfigComm.saveKeyValue(buf2,"GLB_IDS_PROTOCOL", protocol);
	ConfigComm.saveKeyValue(buf3,"GLB_IDS_FORMAT", format);
	ConfigComm.saveKeyValue(buf4,"GLB_IDS_TRANSPORT", transport);
	ConfigComm.saveKeyValue(buf5,"GLB_IDS_TRANSPORT_ADDRESS", address);
	ConfigComm.saveKeyValue(buf6,"RBP_INTERFACE_LIST", rbplist);

	try {
		byte [] b;
		 
		b = ConfigComm.configRequest(buf1);
		b = ConfigComm.configRequest(buf2);
		b = ConfigComm.configRequest(buf3);
		b = ConfigComm.configRequest(buf4);
		b = ConfigComm.configRequest(buf5);
		b = ConfigComm.configRequest(buf6);

		Constants.GLB_DCM_INPUT_NAME = new String(name);
		Constants.GLB_IDS_PROTOCOL = new String(protocol);
		Constants.GLB_IDS_FORMAT = new String(format);
		Constants.GLB_IDS_TRANSPORT = new String(transport);
		Constants.GLB_IDS_TRANSPORT_ADDRESS = new String(address);
		Constants.RBP_INTERFACE_LIST = new String(rbplist);

	} catch (Exception e) {
		Log.getInstance().show_error(this,"Error",
					 "Error in saving configuration.",e);
	}

	return ;
  }



  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
  private void initComponents () {//GEN-BEGIN:initComponents
    jPanel1 = new javax.swing.JPanel ();
    jPanel8 = new javax.swing.JPanel ();
    jPanel9 = new javax.swing.JPanel ();
    jLabel1 = new javax.swing.JLabel ();
    nameTextField = new javax.swing.JTextField ();
    jPanel10 = new javax.swing.JPanel ();
    jLabel2 = new javax.swing.JLabel ();
    protocolComboBox = new javax.swing.JComboBox(protocolList);
    jLabel3 = new javax.swing.JLabel ();
    formatComboBox = new javax.swing.JComboBox(formatList);
    jLabel4 = new javax.swing.JLabel ();
    transportComboBox = new javax.swing.JComboBox(transportList);
    transportPanel = new javax.swing.JPanel ();
    jPanel12 = new javax.swing.JPanel ();
    jPanel16 = new javax.swing.JPanel ();
    jLabel9 = new javax.swing.JLabel ();
    tcpPortTextField = new javax.swing.JTextField ();
    jPanel21 = new javax.swing.JPanel ();
    jLabel10 = new javax.swing.JLabel ();
    rbpIDTextField = new javax.swing.JTextField ();
    jLabel11 = new javax.swing.JLabel ();
    rbpInterfaceTextField = new javax.swing.JTextField ();
    jPanel22 = new javax.swing.JPanel ();
    jButton8 = new javax.swing.JButton ();
    jPanel5 = new javax.swing.JPanel ();
    jPanel7 = new javax.swing.JPanel ();
    jLabel5 = new javax.swing.JLabel ();
    keyComboBox = new javax.swing.JComboBox ();
    jLabel6 = new javax.swing.JLabel ();
    jScrollPane1 = new javax.swing.JScrollPane(valueTextArea);
    jPanel11 = new javax.swing.JPanel ();
    jButton4 = new javax.swing.JButton ();
    jButton5 = new javax.swing.JButton ();
    jButton6 = new javax.swing.JButton ();
    jPanel3 = new javax.swing.JPanel ();
    sysFileComboBox = new javax.swing.JComboBox(fileList);
    jButton3 = new javax.swing.JButton ();
    jPanel4 = new javax.swing.JPanel ();
    jButton2 = new javax.swing.JButton ();
    jButton7 = new javax.swing.JButton ();
    jPanel2 = new javax.swing.JPanel ();
    jButton1 = new javax.swing.JButton ();
    statusPanel = new ids2ui.StatusPanel ();
    getContentPane ().setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints1;
    setTitle ("System Configuration Main Screen");
    addWindowListener (new java.awt.event.WindowAdapter () {
      public void windowClosing (java.awt.event.WindowEvent evt) {
        exitForm (evt);
      }
    }
    );

    jPanel1.setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints2;
    jPanel1.setToolTipText ("");
    jPanel1.setBorder (new javax.swing.border.CompoundBorder(
    new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
    new javax.swing.border.EtchedBorder()));

      jPanel8.setLayout (new java.awt.BorderLayout ());
      jPanel8.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
      new javax.swing.border.TitledBorder("DSP-DCM Communication parameters"))));
  
        jPanel9.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints3;
    
          jLabel1.setText ("DCM Input Name");
      
          gridBagConstraints3 = new java.awt.GridBagConstraints ();
          gridBagConstraints3.gridx = 0;
          gridBagConstraints3.gridy = 0;
          gridBagConstraints3.insets = new java.awt.Insets (5, 5, 5, 10);
          gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
          jPanel9.add (jLabel1, gridBagConstraints3);
      
          nameTextField.setToolTipText ("Shared name for DCM input servers");
          nameTextField.setNextFocusableComponent (protocolComboBox);
      
          gridBagConstraints3 = new java.awt.GridBagConstraints ();
          gridBagConstraints3.gridx = 1;
          gridBagConstraints3.gridy = 0;
          gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints3.insets = new java.awt.Insets (5, 0, 5, 10);
          gridBagConstraints3.weightx = 1.0;
          jPanel9.add (nameTextField, gridBagConstraints3);
      
          jPanel10.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints4;
      
            jLabel2.setText ("Protocol");
            jLabel2.setLabelFor (protocolComboBox);
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 4;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 10);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.EAST;
            jPanel10.add (jLabel2, gridBagConstraints4);
        
            protocolComboBox.setNextFocusableComponent (formatComboBox);
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 5;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 0);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.EAST;
            jPanel10.add (protocolComboBox, gridBagConstraints4);
        
            jLabel3.setText ("Format");
            jLabel3.setLabelFor (formatComboBox);
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 2;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 10);
            jPanel10.add (jLabel3, gridBagConstraints4);
        
            formatComboBox.setNextFocusableComponent (transportComboBox);
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 3;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 15);
            jPanel10.add (formatComboBox, gridBagConstraints4);
        
            jLabel4.setText ("Transport");
            jLabel4.setLabelFor (transportComboBox);
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 0;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 10);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
            jPanel10.add (jLabel4, gridBagConstraints4);
        
            transportComboBox.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                transportChanged (evt);
              }
            }
            );
        
            gridBagConstraints4 = new java.awt.GridBagConstraints ();
            gridBagConstraints4.gridx = 1;
            gridBagConstraints4.gridy = 0;
            gridBagConstraints4.insets = new java.awt.Insets (2, 0, 5, 15);
            gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
            jPanel10.add (transportComboBox, gridBagConstraints4);
        
          gridBagConstraints3 = new java.awt.GridBagConstraints ();
          gridBagConstraints3.gridx = 0;
          gridBagConstraints3.gridy = 1;
          gridBagConstraints3.gridwidth = 2;
          gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints3.weightx = 1.0;
          jPanel9.add (jPanel10, gridBagConstraints3);
      
        jPanel8.add (jPanel9, java.awt.BorderLayout.NORTH);
    
        transportPanel.setLayout (new java.awt.CardLayout ());
        transportPanel.setBorder (new javax.swing.border.CompoundBorder(
        new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
        new javax.swing.border.TitledBorder(
        new javax.swing.border.EtchedBorder(), "Transport configuration")));
    
      
          transportPanel.add (jPanel12, "TransportBlank");
      
          jPanel16.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints5;
      
            jLabel9.setText ("Service/Port");
        
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 0;
            gridBagConstraints5.gridy = 1;
            gridBagConstraints5.insets = new java.awt.Insets (3, 0, 0, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            jPanel16.add (jLabel9, gridBagConstraints5);
        
        
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 1;
            gridBagConstraints5.gridy = 1;
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (3, 0, 0, 0);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints5.weightx = 0.25;
            jPanel16.add (tcpPortTextField, gridBagConstraints5);
        
          transportPanel.add (jPanel16, "TransportTCP");
      
          jPanel21.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints6;
      
            jLabel10.setText ("Application ID");
        
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.insets = new java.awt.Insets (0, 0, 10, 5);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            jPanel21.add (jLabel10, gridBagConstraints6);
        
            rbpIDTextField.setColumns (8);
            rbpIDTextField.setText ("0");
        
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints6.insets = new java.awt.Insets (0, 0, 10, 0);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints6.weightx = 0.75;
            jPanel21.add (rbpIDTextField, gridBagConstraints6);
        
            jLabel11.setText ("Interface Names");
        
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.gridx = 0;
            gridBagConstraints6.gridy = 1;
            gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 5);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            jPanel21.add (jLabel11, gridBagConstraints6);
        
            rbpInterfaceTextField.setText ("qfe0 qfe1");
        
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.gridx = 1;
            gridBagConstraints6.gridy = 1;
            gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints6.weightx = 0.75;
            jPanel21.add (rbpInterfaceTextField, gridBagConstraints6);
        
          transportPanel.add (jPanel21, "TransportRBP");
      
        jPanel8.add (transportPanel, java.awt.BorderLayout.CENTER);
    
        jPanel22.setLayout (new java.awt.FlowLayout (1, 25, 5));
    
          jButton8.setText ("Save");
          jButton8.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              saveConfig (evt);
            }
          }
          );
      
          jPanel22.add (jButton8);
      
        jPanel8.add (jPanel22, java.awt.BorderLayout.SOUTH);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 0;
      gridBagConstraints2.gridwidth = 2;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints2.weightx = 1.0;
      gridBagConstraints2.weighty = 0.25;
      jPanel1.add (jPanel8, gridBagConstraints2);
  
      jPanel5.setLayout (new java.awt.BorderLayout ());
      jPanel5.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
      new javax.swing.border.TitledBorder("Key value editor"))));
  
        jPanel7.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints7;
    
          jLabel5.setText ("Configuration key");
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 0;
          gridBagConstraints7.gridy = 0;
          gridBagConstraints7.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
          jPanel7.add (jLabel5, gridBagConstraints7);
      
          keyComboBox.setActionCommand ("Retrieve");
          keyComboBox.setEditable (true);
          keyComboBox.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              keyValueHandler (evt);
            }
          }
          );
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 1;
          gridBagConstraints7.gridy = 0;
          gridBagConstraints7.insets = new java.awt.Insets (0, 10, 10, 0);
          gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
          jPanel7.add (keyComboBox, gridBagConstraints7);
      
          jLabel6.setText ("Value");
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 0;
          gridBagConstraints7.gridy = 1;
          gridBagConstraints7.anchor = java.awt.GridBagConstraints.NORTHWEST;
          jPanel7.add (jLabel6, gridBagConstraints7);
      
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 1;
          gridBagConstraints7.gridy = 1;
          gridBagConstraints7.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints7.insets = new java.awt.Insets (0, 10, 0, 0);
          gridBagConstraints7.weightx = 1.0;
          gridBagConstraints7.weighty = 1.0;
          jPanel7.add (jScrollPane1, gridBagConstraints7);
      
        jPanel5.add (jPanel7, java.awt.BorderLayout.CENTER);
    
        jPanel11.setLayout (new java.awt.FlowLayout (1, 20, 5));
    
          jButton4.setToolTipText ("Retrieve value from configuration server");
          jButton4.setText ("Retrieve");
          jButton4.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              keyValueHandler (evt);
            }
          }
          );
      
          jPanel11.add (jButton4);
      
          jButton5.setToolTipText ("Save configuration");
          jButton5.setText ("Save");
          jButton5.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              keyValueHandler (evt);
            }
          }
          );
      
          jPanel11.add (jButton5);
      
          jButton6.setToolTipText ("Delete key value from configuration database");
          jButton6.setText ("Delete");
          jButton6.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              keyValueHandler (evt);
            }
          }
          );
      
          jPanel11.add (jButton6);
      
        jPanel5.add (jPanel11, java.awt.BorderLayout.SOUTH);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.gridwidth = 2;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 1.0;
      gridBagConstraints2.weighty = 1.0;
      jPanel1.add (jPanel5, gridBagConstraints2);
  
      jPanel3.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints8;
      jPanel3.setBorder (new javax.swing.border.CompoundBorder(null,
      new javax.swing.border.TitledBorder("System Files")));
  
    
        gridBagConstraints8 = new java.awt.GridBagConstraints ();
        jPanel3.add (sysFileComboBox, gridBagConstraints8);
    
        jButton3.setText ("Edit");
        jButton3.setEnabled (false);
    
        gridBagConstraints8 = new java.awt.GridBagConstraints ();
        gridBagConstraints8.insets = new java.awt.Insets (0, 15, 0, 0);
        jPanel3.add (jButton3, gridBagConstraints8);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 2;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints2.insets = new java.awt.Insets (5, 10, 5, 5);
      gridBagConstraints2.weightx = 0.5;
      jPanel1.add (jPanel3, gridBagConstraints2);
  
      jPanel4.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints9;
      jPanel4.setBorder (new javax.swing.border.CompoundBorder(null,
      new javax.swing.border.TitledBorder("Product Cache Configuration")));
  
        jButton2.setText ("View");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            showProductCache (evt);
          }
        }
        );
    
        gridBagConstraints9 = new java.awt.GridBagConstraints ();
        gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
        jPanel4.add (jButton2, gridBagConstraints9);
    
        jButton7.setText ("Clear unused products");
        jButton7.setActionCommand ("Clear deleted product entries");
        jButton7.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            clearCache (evt);
          }
        }
        );
    
        gridBagConstraints9 = new java.awt.GridBagConstraints ();
        gridBagConstraints9.insets = new java.awt.Insets (5, 5, 5, 5);
        jPanel4.add (jButton7, gridBagConstraints9);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 1;
      gridBagConstraints2.gridy = 2;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
      gridBagConstraints2.weightx = 0.5;
      jPanel1.add (jPanel4, gridBagConstraints2);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
    gridBagConstraints1.weightx = 1.0;
    gridBagConstraints1.weighty = 1.0;
    getContentPane ().add (jPanel1, gridBagConstraints1);

    jPanel2.setBorder (new javax.swing.border.CompoundBorder(
    new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
    new javax.swing.border.EtchedBorder()));

      jButton1.setText ("Close");
      jButton1.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          closeForm (evt);
        }
      }
      );
  
      jPanel2.add (jButton1);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 1;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (jPanel2, gridBagConstraints1);

    statusPanel.setBorder (new javax.swing.border.CompoundBorder(null,
    new javax.swing.border.EtchedBorder()));


    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 2;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (statusPanel, gridBagConstraints1);

  }//GEN-END:initComponents

private void clearCache (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearCache
// Add your handling code here:
  StringBuffer reqbuf = new StringBuffer();
  
  
  ConfigComm.clearProductCache(reqbuf);

  try {
		byte[] b = ConfigComm.configRequest(reqbuf);
   } catch (DBException dbex) {
		int errno = ((DBException)dbex).getErrorNo();
		switch (errno) {
		case Constants.MODE_ERR:
			Log.getInstance().show_error(this,
							"Mode Error", 
							"Could not save key configuration.\n"
							+"Configuration server(s) not in primary mode.",
							dbex);
			return ;
		case Constants.SYNC_ERR:
			Log.getInstance().show_error(this,
							"Sync Error", 
							"Could not save key configuration.\n"
							+"Configuration servers are currently syncing.\n",
					dbex);
					return ;
		case Constants.COMM_ERR:
			Log.getInstance().show_error(this,
							"Communication Error",  
							"Could not connect to configuration server.",
								dbex);
			return ;
		default:
			Log.getInstance().show_error(this,
							"Configuration Error", 
							"Could not save key configuration.\n",
							dbex);
			return ;
		}
		
	} catch (Exception e) {
		Log.getInstance().show_error(this,"Error",
					"Could not save key configuration.\n",
					e);
		return ; 
	} 
    
  
  
  }//GEN-LAST:event_clearCache

private void retrieveKey() {

	String key = (String)keyComboBox.getSelectedItem();
	if ((key==null)||(key.trim().length()==0)) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	}
  
  try {
    String value = ConfigComm.getRawValue(key);
    valueTextArea.setText(value);
   } catch (DBException dbex) {
		valueTextArea.setText("");
		int errno = ((DBException)dbex).getErrorNo();
		switch (errno) {
		case Constants.MODE_ERR:
			Log.getInstance().show_error(this,
							"Mode Error", 
							"Could not retrieve key configuration.\n"
							+"Configuration server(s) not in primary mode.",
							dbex);
			return ;
		case Constants.SYNC_ERR:
			Log.getInstance().show_error(this,
							"Sync Error", 
							"Could not retrieve key configuration.\n"
							+"Configuration servers are currently syncing.\n",
					dbex);
					return ;
		case Constants.COMM_ERR:
			Log.getInstance().show_error(this,
							"Communication Error",  
							"Could not connect to configuration server.",
								dbex);
			return ;
		case Constants.KEY_NOT_FOUND:
			Log.getInstance().show_error(this,
							"Warning",  
							"Key does not exist in configuration database.",
								dbex);
			return ;
		default:
			Log.getInstance().show_error(this,
							"Configuration Error", 
							"Could not retrieve key configuration.\n",
							dbex);
			return ;
		}
		
	} catch (Exception e) {
		valueTextArea.setText("");
		Log.getInstance().show_error(this,"Error",
					"Could not retrieve key configuration.\n",
					e);
		return ; 
	} 
  
}




private void saveKeyValue(){

	String key = (String)keyComboBox.getSelectedItem();
	String value = valueTextArea.getText();

	if ((key==null)||(value==null)
			||(key.trim().length()==0)||(value.trim().length()==0)) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	}


	if (javax.swing.JOptionPane.YES_OPTION 
				!= Log.getInstance().show_confirm(this, "Confirmation dialog",
							"Are you sure you want to save: "+key))
		return;


	StringBuffer reqbuf = new StringBuffer();

	ConfigComm.saveKeyValue(reqbuf,key,value);

	try {
		byte[] b = ConfigComm.configRequest(reqbuf);
   } catch (DBException dbex) {
		int errno = ((DBException)dbex).getErrorNo();
		switch (errno) {
		case Constants.MODE_ERR:
			Log.getInstance().show_error(this,
							"Mode Error", 
							"Could not save key configuration.\n"
							+"Configuration server(s) not in primary mode.",
							dbex);
			return ;
		case Constants.SYNC_ERR:
			Log.getInstance().show_error(this,
							"Sync Error", 
							"Could not save key configuration.\n"
							+"Configuration servers are currently syncing.\n",
					dbex);
					return ;
		case Constants.COMM_ERR:
			Log.getInstance().show_error(this,
							"Communication Error",  
							"Could not connect to configuration server.",
								dbex);
			return ;
		default:
			Log.getInstance().show_error(this,
							"Configuration Error", 
							"Could not save key configuration.\n",
							dbex);
			return ;
		}
		
	} catch (Exception e) {
		Log.getInstance().show_error(this,"Error",
					"Could not save key configuration.\n",
					e);
		return ; 
	} 
  
}

private void deleteKeyValue() {
	String key = (String)keyComboBox.getSelectedItem();

	if ((key==null)||(key.trim().length()==0)) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	}

	if (javax.swing.JOptionPane.YES_OPTION 
				!= Log.getInstance().show_confirm(this, "Confirmation dialog",
							"Are you sure you want to delete: "+key))
		return;
	StringBuffer reqbuf = new StringBuffer();

	ConfigComm.deleteKeyValue(reqbuf,key);

	try {
		byte[] b = ConfigComm.configRequest(reqbuf);
   } catch (DBException dbex) {
		int errno = ((DBException)dbex).getErrorNo();
		switch (errno) {
		case Constants.MODE_ERR:
			Log.getInstance().show_error(this,
							"Mode Error", 
							"Could not delete key configuration.\n"
							+"Configuration server(s) not in primary mode.",
							dbex);
			return ;
		case Constants.SYNC_ERR:
			Log.getInstance().show_error(this,
							"Sync Error", 
							"Could not delete key configuration.\n"
							+"Configuration servers are currently syncing.\n",
					dbex);
					return ;
		case Constants.COMM_ERR:
			Log.getInstance().show_error(this,
							"Communication Error",  
							"Could not connect to configuration server.",
								dbex);
			return ;
		case Constants.KEY_NOT_FOUND:
			Log.getInstance().show_error(this,
							"Warning",  
							"Key does not exist in configuration database.",
								dbex);
			return ;
		default:
			Log.getInstance().show_error(this,
							"Configuration Error", 
							"Could not delete key configuration.\n",
							dbex);
			return ;
		}
		
	} catch (Exception e) {
		Log.getInstance().show_error(this,"Error",
					"Could not delete key configuration.\n",
					e);
		return ; 
	} finally {
		valueTextArea.setText("");
 	} 
}


    
private void keyValueHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keyValueHandler
// Add your handling code here:
    String action = evt.getActionCommand();

    if (action.equals("Retrieve"))
      retrieveKey();
    else if (action.equals("Save"))
      saveKeyValue();
    else if (action.equals("Delete"))
      deleteKeyValue();
    
  }//GEN-LAST:event_keyValueHandler

private void saveTable (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveTable
// Add your handling code here:
  }//GEN-LAST:event_saveTable

private void saveConfig (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveConfig
// Add your handling code here:
    saveConfig();
  }//GEN-LAST:event_saveConfig

private void transportChanged (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transportChanged
// Add your handling code here:  
  java.awt.CardLayout l = (java.awt.CardLayout)transportPanel.getLayout();

  String selectstr = (String)transportComboBox.getSelectedItem();
  if (selectstr.substring(0,3).equals("TCP"))
  	l.show((java.awt.Container)transportPanel,"TransportTCP");  
  else if (selectstr.substring(0,3).equals("RBP"))
  	l.show((java.awt.Container)transportPanel,"TransportRBP");
  else
  	l.show((java.awt.Container)transportPanel,"TransportBlank");

  }//GEN-LAST:event_transportChanged

private void showProductCache (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showProductCache
// Add your handling code here:
  
  javax.swing.JFrame v = (javax.swing.JFrame)WindowEventAdapter.getInstance().findWindow(Constants.CONFIGURATION_PRODUCT_CACHE);
  
  if (v==null)
      v = new ProductCacheConfigForm();
  
    v.show();  
 
  
  }//GEN-LAST:event_showProductCache

private void closeForm (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeForm
// Add your handling code here:
  exitForm(null);
  }//GEN-LAST:event_closeForm

  /** Exit the Application */
  private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
    //System.exit (0);
    setVisible(false);
    dispose();
    WindowEventAdapter.getInstance().unregisterWindow(this);
  }//GEN-LAST:event_exitForm

 
    
    

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel1;
  private javax.swing.JPanel jPanel8;
  private javax.swing.JPanel jPanel9;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JTextField nameTextField;
  private javax.swing.JPanel jPanel10;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JComboBox protocolComboBox;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JComboBox formatComboBox;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JComboBox transportComboBox;
  private javax.swing.JPanel transportPanel;
  private javax.swing.JPanel jPanel12;
  private javax.swing.JPanel jPanel16;
  private javax.swing.JLabel jLabel9;
  private javax.swing.JTextField tcpPortTextField;
  private javax.swing.JPanel jPanel21;
  private javax.swing.JLabel jLabel10;
  private javax.swing.JTextField rbpIDTextField;
  private javax.swing.JLabel jLabel11;
  private javax.swing.JTextField rbpInterfaceTextField;
  private javax.swing.JPanel jPanel22;
  private javax.swing.JButton jButton8;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JPanel jPanel7;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JComboBox keyComboBox;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JPanel jPanel11;
  private javax.swing.JButton jButton4;
  private javax.swing.JButton jButton5;
  private javax.swing.JButton jButton6;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JComboBox sysFileComboBox;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton7;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton jButton1;
  private ids2ui.StatusPanel statusPanel;
  // End of variables declaration//GEN-END:variables

}

/*
**  SCCS Info :  "@(#)DistrSummaryStateCellRenderer.java	1.1    00/12/07"
*/
package ids2ui;
 
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;


public class DistrSummaryStateCellRenderer extends JLabel
    implements TableCellRenderer {
  protected static Border noFocusBorder; 
 
  public DistrSummaryStateCellRenderer() {
    noFocusBorder = new EmptyBorder(1, 2, 1, 2);
    setOpaque(true);
    setBorder(noFocusBorder);  
  }

  public Component getTableCellRendererComponent(JTable table, Object value,
                 boolean isSelected, boolean hasFocus, int row, int column) {
    Color foreground = null;
    Color background = null;
    Font font = null;
    TableModel model = table.getModel();

	String s = (String)table.getValueAt(row,column);
	if ((s!=null))  {
		if (s.startsWith("UP"))
			foreground = java.awt.Color.green.darker().darker();
		else if (s.startsWith("DORMANT"))
			foreground = java.awt.Color.blue;
		else if (s.startsWith("DOWN"))
			foreground = java.awt.Color.red;
		else
			foreground = java.awt.Color.pink;
			
	} else
		foreground = java.awt.Color.pink;

	setFont(table.getFont());

    if (isSelected) {
      setForeground((foreground != null) ? foreground
                          : table.getSelectionForeground());
      setBackground(table.getSelectionBackground());
    } else {
      setForeground((foreground != null) ? foreground 
			  : table.getForeground());
      setBackground((background != null) ? background 
			  : table.getBackground());
    }
    
    if (hasFocus) {
      setBorder( UIManager.getBorder("Table.focusCellHighlightBorder") );
      if (table.isCellEditable(row, column)) {
	setForeground((foreground != null) ? foreground
	              : UIManager.getColor("Table.focusCellForeground") );
	setBackground( UIManager.getColor("Table.focusCellBackground") );
      }
    } else {
      setBorder(noFocusBorder);
    }
    setValue(value);        
    return this;
  }
    
  protected void setValue(Object value) {
    setText((value == null) ? "" : value.toString());
  }
}



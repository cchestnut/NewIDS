/*
**  SCCS Info :  "@(#)ServiceCellRenderer.java	1.2    01/01/15"
*/
package ids2ui;
 
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;


public class ServiceCellRenderer extends JLabel
    implements TableCellRenderer {
  protected static Border noFocusBorder; 
 
  public ServiceCellRenderer() {
    noFocusBorder = new EmptyBorder(1, 2, 1, 2);
    setOpaque(true);
    setBorder(noFocusBorder);  
  }

  public Component getTableCellRendererComponent(JTable table, Object value,
                 boolean isSelected, boolean hasFocus, int row, int column) {
    Color foreground = null;
    Color background = null;
    Font font = null;
    TableModel model = table.getModel();

	String s = (String)table.getValueAt(row,column);
	if ((s!=null) 
		&& (s.startsWith("Running")
				||s.startsWith("ACTIVE")
				||s.startsWith("DORMANT")))
		foreground = java.awt.Color.blue;
	else if ((s!=null) && (s.equals("Not Configured")))
		foreground = java.awt.Color.orange;
	else
		foreground = java.awt.Color.red;

	setFont(table.getFont());

    if (isSelected) {
      setForeground((foreground != null) ? foreground
                          : table.getSelectionForeground());
      setBackground(table.getSelectionBackground());
    } else {
      setForeground((foreground != null) ? foreground 
			  : table.getForeground());
      setBackground((background != null) ? background 
			  : table.getBackground());
    }
    
    if (hasFocus) {
      setBorder( UIManager.getBorder("Table.focusCellHighlightBorder") );
      if (table.isCellEditable(row, column)) {
	setForeground((foreground != null) ? foreground
	              : UIManager.getColor("Table.focusCellForeground") );
	setBackground( UIManager.getColor("Table.focusCellBackground") );
      }
    } else {
      setBorder(noFocusBorder);
    }
    setValue(value);        
    return this;
  }
    
  protected void setValue(Object value) {
    setText((value == null) ? "" : value.toString());
  }
}



/*
**  SCCS Info :  "@(#)DSPSparseMatrixModel.java	1.2    02/07/24"
*/
/*
 * DSPSparseMatrixModel.java
 *
 */

package ids2ui;

import javax.swing.SwingUtilities;
import javax.swing.tree.TreePath;

/**
 */

public class DSPSparseMatrixModel 
extends AbstractTreeTableModel 
{

    // Names of the columns.
    //static protected String[]  cNames = null;
    static protected String[]  columnNames = null;

    
    // Types of the columns.
                                         
    static protected CSCProductsModel productsModel = null;

    protected boolean             isValid;
    protected ProductFormatNode	reloadNode;
    int                           reloadCount;
    
    private java.util.HashMap productMap = null;

    private java.util.HashMap productConversionMap = new java.util.HashMap(10);

    private java.util.Vector adminFormats = new java.util.Vector(5);

    private boolean                dataEdited = false;

    int data_center=1;
    public DSPSparseMatrixModel(CSCProductsModel model, int dc) 
    throws Exception
    {
	super(null);
	data_center = dc;
	productsModel = model;
	productMap = productsModel.getProductMap();
	loadData();

	isValid=true;
	root = new ProductFormatNode( new ProductFormatData("Products"));

	update();

    }
    


    /*
    ** Copy Constructor
    */
       
    public DSPSparseMatrixModel(DSPSparseMatrixModel model) 
    {
	super(null);
	productsModel = model.productsModel;
	productMap = productsModel.getProductMap();
	adminFormats = (java.util.Vector)model.adminFormats.clone();

	java.util.Iterator iterator =
	    model.productFormatMap.keySet().iterator();

	while (iterator.hasNext()) {
	    String key = (String) iterator.next();
	    String[] values = (String[]) model.productFormatMap.get(key);
	    String[] new_values = null;
	    if (values!=null) {
		new_values = new String[values.length];
		System.arraycopy(values,0,
				 new_values, 0,
				 values.length);
	    }
	    productFormatMap.put(new String(key),new_values);
	}

	for (int c = 0; c < model.getColumnCount(); c++) {
		columnNames[c] = new String(model.getColumnName(c));
	}
	
	isValid=true;
	root = new ProductFormatNode( new ProductFormatData("Products"));

	update();

    }
    

    synchronized public void setProductModel(CSCProductsModel model) {
	productsModel = model;
	productMap = productsModel.getProductMap();
	update();
    }




    public boolean isCellEditable(Object node, int column) {
	ProductFormatNode         pn = (ProductFormatNode)node;
	
	if ((column>0) && pn.getProduct().isRoot()) return false;

	
	if ((column == 1))
	    return false;
	
	if (column > 1) {
	    String fmt = columnNames[column];
	    return Utils.isValidProductFormat(pn.getProduct().getName(),
					      pn.isContainer(),
					      fmt);
	    
	    /*
*******************
	    
if (pn.getProduct().isContainer())
return Utils.isValidProductFormat(pn.getProduct().getName(),
pn.isContainer(),
fmt);
else if (pn.getProduct().isSubProduct()) {
String ifmt = pn.getProduct().getInputFormat();
if ((ifmt!=null) && (ifmt.equals(fmt)) )
return false;
}

*******************
*/
	}

	return true;
    }
     


   
    public boolean isEdited() {
	return dataEdited;
    }
 
    private void update()
    {
	
	productConversionMap.clear();


	java.util.Iterator iterator  = productFormatMap.keySet().iterator();
	

	while (iterator.hasNext()) {
	    String k = (String) iterator.next();
	    String pf[] = (String[]) productFormatMap.get(k);
	    StringBuffer msgmgr_key = new StringBuffer("-");
	    boolean no_conversion = true;
	    String prod = pf[0];
	    String ifmt = null;
	    String s[] = (String[])productMap.get(prod);

	    if (s==null) {
		continue;
	    }


	    if ( (!Utils.parseBooleanString(s[5])  
		  && !s[6].equals("-")) 
		 || (k.equals(prod) && prod.equals(s[6])) ) {
		
		String f[] = (String[])productFormatMap.get(s[6]+"_CONTAINER");
		if ( (f!=null) && (f.length>1))
		    ifmt = f[1];
		else
		    continue;
	    } else {
		ifmt = Constants.GLB_IDS_FORMAT;		
	    }
		
	    msgmgr_key.insert(0,ifmt);

	    for (int i = 1; i < pf.length; i++) {
		msgmgr_key.append(pf[i]).append("_");
		no_conversion = false;
	    }

;
	    if (no_conversion) {
		msgmgr_key.append(ifmt);
	    } 
	    
	    if (msgmgr_key.toString().endsWith("_")) {
		int l = msgmgr_key.length();msgmgr_key.setLength(l-1); 
	    }

	    StringBuffer value = (StringBuffer)productConversionMap.get(msgmgr_key.toString());
	    if (value==null) value = new StringBuffer();
	    value.append(prod).append(" ");
	    productConversionMap.put(msgmgr_key.toString(), value);
	}
	

	
	
	if (Constants.Verbose >2) {

	    iterator  = productConversionMap.keySet().iterator();
	    
	    while (iterator.hasNext()) {
		String k = (String) iterator.next();
		StringBuffer value = (StringBuffer) productConversionMap.get(k);
		System.out.println("Manager : "+k);
		System.out.println("\tProducts: "+value.toString()+"\n");
	    }
	}
	
	

    }

    
    public synchronized java.util.Vector 
	getProductFormats(String product)
    {

	if (product==null) return null;

	if (product.equals(Constants.ADMIN_PRODUCT_ID)) {
	    return new java.util.Vector(adminFormats);
	}


	String[] formats = (String[])productFormatMap.get(product);
	
	java.util.Vector v = null;
	if (formats!=null) {
	    v = new java.util.Vector(formats.length);
	    for (int i = 1; i < formats.length; i++)
		v.add(new String(formats[i]));
	} else {
	    v = new java.util.Vector(1);
	    v.add(Constants.GLB_IDS_FORMAT);
	}
	

	return v;
    }


    public synchronized java.util.Vector 
	getFormatProducts(String format)
    {



	java.util.Vector pv = new java.util.Vector(10);

	if (format.equals(Constants.GLB_IDS_FORMAT)) {

	    String products[] = productsModel.getProducts();

	    java.util.Vector v = new java.util.Vector(products.length);

	    for (int i= 0; i < products.length; i++)
		if (!products[i].equals(Constants.ADMIN_PRODUCT_ID))
		    pv.add(new String(products[i]));

	    

	} else {

	    java.util.Iterator iterator = productFormatMap.keySet().iterator();

	    while (iterator.hasNext()) {

		String prod = (String)iterator.next();
		String [] formats = (String[]) productFormatMap.get(prod);

		if (formats != null) {

		    for (int i = 1; i < formats.length; i++) {
			if (format.equals(formats[i])) {
			    pv.add(new String(prod));
			    break;
			}
		    }

		}

	    }
	}


	if (Constants.GLB_ADMIN_FORMAT_LIST.indexOf(format) >= 0)
		pv.add(new String(Constants.ADMIN_PRODUCT_ID));

	    

	return  pv;
    }





    private void loadData()
	throws Exception
    {


	java.util.HashMap dspConfig
                = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);

	String ifstr = (String)dspConfig.get("INPUT_FEED"+Integer.toString(data_center));

	

	StringBuffer separator = new StringBuffer();
	separator.append(ConfigComm.CONF_GS)
	    .append(ConfigComm.CONF_ETX);
	
	java.util.StringTokenizer st
	    = new java.util.StringTokenizer(ifstr, separator.toString());
	

	while (st.hasMoreTokens()) {

	    String s = st.nextToken();

	    java.util.StringTokenizer fst
		= new java.util.StringTokenizer(s,",");
	    
	    
	    String name,format,transport,products,protocol;
	    
	    name = format = transport = products = protocol = null;
	    
	    name = fst.nextToken();
	    if (fst.hasMoreTokens())
		format = fst.nextToken();
	    
	    if (fst.hasMoreTokens())
		protocol = fst.nextToken();
	    
	    if (fst.hasMoreTokens())
		transport = fst.nextToken();
	    
	    if (fst.hasMoreTokens())
		products = fst.nextToken();
	    

	    if (products == null) {

	    } else {
		java.util.StringTokenizer prodToken
		    = new java.util.StringTokenizer(products," ");

		while (prodToken.hasMoreTokens()){
		    String prodID = prodToken.nextToken();
		    
		    if (prodID.equals(Constants.ADMIN_PRODUCT_ID))
			continue;
		    
		    
		    java.util.ArrayList convList= new java.util.ArrayList();

		    convList.add(prodID);

		    convList.add(Constants.GLB_IDS_FORMAT);
		    if (!format.equals(Constants.GLB_IDS_FORMAT))
			convList.add(format);

		    String[] productFormatData = (String[])convList.toArray(new String[0]);
		    productFormatMap.put(prodID,productFormatData);
		}
	    }

	}


	separator.setLength(0);
	separator.append(ConfigComm.CONF_FS)
		.append(ConfigComm.CONF_GS)
		.append(ConfigComm.CONF_US)
		.append(ConfigComm.CONF_ETX);


	java.util.StringTokenizer tokenizer
	    = new java.util.StringTokenizer(Constants.GLB_ADMIN_FORMAT_LIST, separator.toString());
	
	adminFormats.removeAllElements();
	while (tokenizer.hasMoreTokens()) {
	    String fmt = tokenizer.nextToken();
	    adminFormats.add(fmt);
	}

	java.util.Vector fmts = ConfigComm.getProductFormatList();

	java.util.ArrayList clist = new java.util.ArrayList(fmts.size()+1);

	clist.add(0,"Product");
	clist.add(1,"Output Format");

	
	int k = 2;
	for (int i = 0; i < fmts.size(); i++) {
	    String f = (String)fmts.get(i);
	    if (!f.equals(Constants.GLB_IDS_FORMAT)) {
		clist.add(k++,new String(f));
	    }
	}
	
	columnNames = (String[])clist.toArray(new String[1]);
	

    }


    //
    // The TreeModel interface
    //

    /**
	* Returns the number of children of <code>node</code>.
	    */
    public int getChildCount(Object node) { 
	Object[] children = getChildren(node); 
	return (children == null) ? 0 : children.length;
    }
    
    /**
	* Returns the child of <code>node</code> at index <code>i</code>.
	    */
    public Object getChild(Object node, int i) { 
	return getChildren(node)[i]; 
    }
    
    /**
    * Returns true if the passed in object represents a leaf, false
    * otherwise.
    */
    public boolean isLeaf(Object node) {
	return ((ProductFormatNode)node).isLeaf();
    }
    
    

    //
    //  The TreeTableNode interface. 
    //
    
    /**
    * Returns the number of columns.
    */
    public int getColumnCount() {
	return columnNames.length;
    }
    
    /**
    * Returns the name for a particular column.
    */
    public String getColumnName(int column) {
	return columnNames[column];
    }
    
    /**
    * Returns the class for the particular column.
    */
    public Class getColumnClass(int column) {
	if (column==0) return TreeTableModel.class;
	if (column==1) return String.class;
	return Boolean.class;
    }
    

    /**
    * Returns the value of the particular column.
    */
    public Object getValueAt(Object node, int column) {
        ProductFormatNode pn = (ProductFormatNode)node;
	ProductFormatData pd = pn.getProduct();
	
	
        try {
            switch(column) {
            case 0:
                return pd.getName();
            case 1:
                return pd.getInputFormat();
            default:
		String fmt = columnNames[column];
                return new Boolean((boolean)pd.isFormatOn(fmt));
            }
        }
        catch  (SecurityException se) { }
	
        return null;
    }
    
  //
    // Some convenience methods. 
    //

    /**
     * Reloads the children of the specified node.
     */
    public void reloadChildren(Object node) {
	ProductFormatNode         pn = (ProductFormatNode)node;

	synchronized(this) {
	    reloadCount++;
	}
	pn.resetSize();
	new Thread(new ProductFormatNodeLoader((ProductFormatNode)node)).start();
    }

    /**
     * Stops and waits for all threads to finish loading.
     */
    public void stopLoading() {
	isValid = false;
	synchronized(this) {
	    while (reloadCount > 0) {
		try {
		    wait();
		} catch (InterruptedException ie) {}
	    }
	}
	isValid = true;
    }


    /**
     * Returns the path <code>node</code> represents.
     */
    public String getPath(Object node) {
	return ((ProductFormatNode)node).getProduct().getPath();
    }

    /**
     * Returns the total size of the receiver.
     */
    public long getTotalSize(Object node) {
	return ((ProductFormatNode)node).totalSize();
    }

    /**
     * Returns true if the receiver is loading any children.
     */
    public boolean isReloading() {
	return (reloadCount > 0);
    }

    /**
     * Returns the path to the node that is being loaded.
     */
    public TreePath getPathLoading() {
	ProductFormatNode      rn = reloadNode;

	if (rn != null) {
	    return new TreePath(rn.getPath());
	}
	return null;
    }

    /**
     * Returns the node being loaded.
     */
    public Object getNodeLoading() {
	return reloadNode;
    }

    public synchronized void setValueAt(Object value, Object node, int column) {

	if (column<=1)  
	    return;
	   
	ProductFormatNode productNode = ((ProductFormatNode)node);

	if (productNode.getProduct().isRoot()) return;
	
	String fmt = columnNames[column];

	dataEdited = true;

	productNode.updateFormat(fmt, (Boolean)value);
	
	update();
	
	productNode.nodeChanged();
    }


    protected ProductFormatData getProduct(Object node) {
	ProductFormatNode productNode = ((ProductFormatNode)node); 
	return productNode.getProduct();       
    }

    protected Object[] getChildren(Object node) {
	ProductFormatNode productNode = ((ProductFormatNode)node); 
	return productNode.getChildren(); 
    }


    protected static ProductFormatNode[] EMPTY_CHILDREN = new ProductFormatNode[0];




    public  java.util.HashMap getMsgMgrs()
    {
	return productConversionMap;
    }


    public String toString() {

	 java.util.Iterator iter =
	     productFormatMap.keySet().iterator();
	 
	 StringBuffer result = new StringBuffer();
	 
	 while (iter.hasNext()) {
	     String key = (String)iter.next();
	     result.append(ConfigComm.CONF_GS)
		 .append(key)
		 .append(ConfigComm.CONF_US);

	     String []formats = (String[])productFormatMap.get(key);
	     if (formats==null) continue;
	     for (int j = 1; j < formats.length; j++) {
		 result.append(formats[j])
		     .append(ConfigComm.CONF_US);
	     }
	 }


	 //System.out.println("CONV TABLE :\n"+result.toString());
	 return result.toString();


    }


    
    public synchronized int addProduct(String id) {

	String prodData[] = new String[1];
	prodData[0] = new String(id);
	productFormatMap.put(new String(id),prodData);
	update();
	reloadChildren(root);

	dataEdited = true;

	return 0;
    }

    private int modifyProduct(String id) {

	return 0;
    }


    public synchronized int deleteProduct(String ID ) {
	
	String [] s = (String[])productFormatMap.get(ID);

	if (s==null) {
		return -1;
	}
	
	productFormatMap.remove(ID);
	update();
	reloadChildren(root);
	dataEdited = true;
	return 0;


    }

 
    /**================================================*/

    class ProductFormatNode {
	
	protected ProductFormatData        product; 
	/** Parent FileNode of the receiver. */
	private ProductFormatNode            parent;
	/** Children of the receiver. */
	protected ProductFormatNode[]        children; 
	/** Size of the receiver and all its children. */
	protected long              totalSize;
	/** Valid if the totalSize has finished being calced. */
	protected boolean           totalSizeValid;
	/** Path of the receiver. */
	protected String            canonicalPath;



	protected ProductFormatNode(ProductFormatData prod) {
	    this(null, prod);
	}
	
	protected ProductFormatNode(ProductFormatNode parent, ProductFormatData prod) {
	    this.parent = parent;
	    this.product = prod;
	    canonicalPath = prod.getPath();
	    if (isLeaf()) {
		totalSize = 1;
		totalSizeValid = true;
	    }
	}
	

	public void updateFormat(String fmt, Boolean isOn) {
	    boolean affects_other_cells = 
		product.updateFormat(fmt,isOn.booleanValue());
	    if (affects_other_cells)
		nodeChanged();
	}

	public String toString() {
	    return product.getName();
	}
	
	public ProductFormatData getProduct() {
	    return product;
	}
	
	public boolean isContainer() {
	    return product.isContainer();
	}

	public long totalSize() {
	    return totalSize;
	}

	
	public ProductFormatNode getParent() {
	    return parent;
	}
	
	public boolean isLeaf() {
	    return product.isLeaf();
	}

	/**
	 * Returns true if the total size is valid.
	 */
	public boolean isTotalSizeValid() {
	    return totalSizeValid;
	}

	protected void resetSize() {
	    alterTotalSize(-totalSize);
	}
	
	protected ProductFormatNode[] getChildren() {
	    return children;
	}
	
	protected void loadChildren()
	{
	    totalSize = product.length();
	    children = createChildren();
	    for (int counter = children.length - 1; counter >= 0; counter--) {
		Thread.yield(); // Give the GUI CPU time to draw itself.
		if (!children[counter].isLeaf() ) {
		    children[counter].loadChildren();
		}
		totalSize += children[counter].totalSize();
		
		if (!isValid) {
		    counter = 0;
		}
	    }
	    if (isValid) {
		totalSizeValid = true;
	    }	    
	    
	}  	

	/**
	* Loads the children of of the receiver.
	*/
	protected ProductFormatNode[] createChildren() {
	    ProductFormatNode[]        retArray = null;
	    
	    try {
		String[] subprods = product.getSubProducts();
		if(subprods != null) {
		    
		    retArray = new ProductFormatNode[subprods.length]; 
		    String path = product.getPath();
		    for(int i = 0; i < subprods.length; i++) {
			ProductFormatData subProduct = new ProductFormatData(path, subprods[i]); 
			retArray[i] = new ProductFormatNode(this, subProduct);
		    }
		}
	    } catch (SecurityException se) {}
	    if (retArray == null) {
		retArray = EMPTY_CHILDREN;
	    }
	    return retArray;
	}

	/**
	 * Returns true if the children have been loaded.
	 */
	protected boolean loadedChildren() {
	    return (!product.isContainer() || (children != null));
	}


	/**
	 * Gets the path from the root to the receiver.
	 */
	public ProductFormatNode[] getPath() {
	    return getPathToRoot(this, 0);
	}

	/**
	 * Returns the canonical path for the receiver.
	 */
	public String getCanonicalPath() {
	    return canonicalPath;
	}


	protected ProductFormatNode[] getPathToRoot(ProductFormatNode aNode, int depth) {
	    ProductFormatNode[]              retNodes;

	    if(aNode == null) {
		if(depth == 0)
		    return null;
		else
		    retNodes = new ProductFormatNode[depth];
	    }
	    else {
		depth++;
		retNodes = getPathToRoot(aNode.getParent(), depth);
		retNodes[retNodes.length - depth] = aNode;
	    }
	    return retNodes;
	}


	/**
	 * Sets the children of the receiver, updates the total size,
	 * and if generateEvent is true a tree structure changed event
	 * is created.
	 */
	protected void setChildren(ProductFormatNode[] newChildren,
				   boolean generateEvent) {
	    long           oldSize = totalSize;

	    totalSize = product.length();
	    children = newChildren;
	    for (int counter = children.length - 1; counter >= 0;
		 counter--) {
		totalSize += children[counter].totalSize();
	    }


	    if (generateEvent) {
		ProductFormatNode[]   path = getPath();

		fireTreeStructureChanged(DSPSparseMatrixModel.this, path, null,
					 null);

		ProductFormatNode             parent = getParent();

		if (parent != null) {
		    parent.alterTotalSize(totalSize - oldSize);
		}
	    }
	}


	protected synchronized void alterTotalSize(long sizeDelta) {
	    if (sizeDelta != 0 && (parent = getParent()) != null) {
		totalSize += sizeDelta;
		nodeChanged();
		parent.alterTotalSize(sizeDelta);
	    }
	    else {
		// Need a way to specify the root.
		totalSize += sizeDelta;
	    }
	}

	/**
	 * This should only be invoked on the event dispatching thread.
	 */
	protected synchronized void setTotalSizeValid(boolean newValue) {
	    if (totalSizeValid != newValue) {
		nodeChanged();
		totalSizeValid = newValue;

		ProductFormatNode          parent = getParent();

		if (parent != null) {
		    parent.childTotalSizeChanged(this);
		}
	    }
	}

	/**
	 * Marks the receivers total size as valid, but does not invoke
	 * node changed, nor message the parent.
	 */
	protected synchronized void forceTotalSizeValid() {
	    totalSizeValid = true;
	}

	/**
	 * Invoked when a childs total size has changed.
	 */
	protected synchronized void childTotalSizeChanged(ProductFormatNode child) {
	    if (totalSizeValid != child.isTotalSizeValid()) {
		if (totalSizeValid) {
		    setTotalSizeValid(false);
		}
		else {
		    ProductFormatNode[]    children = getChildren();

		    for (int counter = children.length - 1; counter >= 0;
			 counter--) {
			if (!children[counter].isTotalSizeValid()) {
			    return;
			}
		    }
		    setTotalSizeValid(true);
		}
	    }
	    
	}

	/**
	 * Can be invoked when a node has changed, will create the
	 * appropriate event.
	 */
	protected void nodeChanged() {
	    ProductFormatNode        parent = getParent();

	    if (parent != null) {
		ProductFormatNode[]   path = parent.getPath();
		int[]        index = { getIndexOfChild(parent, this) };
		Object[]     children = { this };

		fireTreeNodesChanged(DSPSparseMatrixModel.this, path,  index,
				     children);
	    }
	}
    }  /* Class ProductFormatNode */


    class ProductFormatNodeLoader
	implements Runnable 
    {
	/** Node creating children for. */
	ProductFormatNode          node;
	

	ProductFormatNodeLoader(ProductFormatNode node) {
	    this.node = node;
	    node.setChildren(node.createChildren(), true);
	    node.setTotalSizeValid(false);
	}

	public void run() {
	    ProductFormatNode[]      children = node.getChildren();

	    
	    for (int counter = children.length - 1; counter >= 0; counter--) {
		if (!children[counter].isLeaf()) {
		    reloadNode = children[counter];
		    loadChildren(children[counter]);
		    reloadNode = null;
		}
		if (!isValid) {
		    counter = 0;
		}
	    }
	    
	    if (isValid) {
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
			node.setChildren(node.getChildren(), true);
			synchronized(DSPSparseMatrixModel.this) {
			    reloadCount--;
			    DSPSparseMatrixModel.this.notifyAll();
			}
		    }
		});
	    }
	    else {
		synchronized(DSPSparseMatrixModel.this) {
		    reloadCount--;
		    DSPSparseMatrixModel.this.notifyAll();
		}
	    }
	}

	protected void loadChildren(ProductFormatNode node) {
	    if (!node.isLeaf() ) {
		final ProductFormatNode[]      children = node.createChildren();

		for (int counter = children.length - 1; counter >= 0;
		     counter--) {
		    if (!children[counter].isLeaf()) {
			if ( children[counter].isContainer()) {
			    children[counter].loadChildren();
			}
			else {
			    children[counter].forceTotalSizeValid();
			}
		    }
		    if (!isValid) {
			counter = 0;
		    }
		}
		if (isValid) {
		    final ProductFormatNode       pn = node;

		    // Reset the children 
		    SwingUtilities.invokeLater(new Runnable() {
			public void run() {
			    pn.setChildren(children, true);
			    pn.setTotalSizeValid(true);
			    pn.nodeChanged();
			}
		    });
		}
	    }
	    else {
		node.forceTotalSizeValid();
	    }
	}
    } /* Class ProductFormatNodeLoader */



    private java.util.HashMap productFormatMap = new java.util.HashMap(50);

    

 public class ProductFormatData {

     
     
     
     String	product;

     boolean      isRoot=false;
     boolean      isContainee = false;
     String        path;

   

    
     private String getPath(String id) {

	 if (id==null)
	     return null;

	 if (id.equals("Products"))
	     return id;

	 String[] s = (String[])productMap.get(id);

	 if (s==null || s.length<7)
	     return null;

	 if (Utils.parseBooleanString(s[5])
	     || s[6].equals("-")
	     || s[6].equals(id))
	     return "Products/"+id;
	 else  
	     return getPath(s[6])+"/"+id;

	 
     }

  

     public ProductFormatData(String p) {

	 //System.out.println("ProductFormatData : "+p);

	 if (p.equals("Products")) {
	     isRoot=true;
	     product = new String(p);
	     path = new  String(p);
	 }
     }
     

     public ProductFormatData(String p, String id) {

	 String[] s = (String[])productMap.get(id);
	 
	 product = new String(id);
	 String pp = getPath(p);
	 if (pp==null)
	     pp = p;
	 path = new String(pp+"/"+id);

	 //System.out.println("ProductFormatData: "+path);

	 if (p.endsWith(id)) {
	     isContainee = true;
	 }



     }


     public String getName() {
	 return product;
     }

     public long  length() { return (isRoot)? 0: 1 ; }


     public String[] getSubProducts() {

	 if (isRoot) {
	     return productsModel.getProductsWithoutAD();
	 } if (isContainee) {
	     return null;
	 }else {
	     return productsModel.getSubProducts(product);
	 }

     }



     public String getPath() {
	 return path;
     }

     
     public boolean isRoot() {
	 return isRoot;
     }


     public boolean isLeaf() {

	 if (isRoot)
	     return false;

	 if (isContainee)
	     return true;

	 String s[] = (String[])productMap.get(product);
	 
	 if ((s!=null) && (s.length>=6)
	     && Utils.parseBooleanString(s[5]))
	     return false;
	 
	 return true;
     }
     

     public boolean isContainer() {
	 return !isLeaf();
     }

     public boolean isFormatOn(String fmt)
     {

	 if (isRoot) return false;

	 String s[] = null;
	 if (isContainer()){
	     s = (String[])productFormatMap.get(product+"_CONTAINER");
	 } else {
	     s = (String[])productFormatMap.get(product);
	 }
	 
	 if ((s==null) || (s.length==1))  return false;

	 for (int i = 1; i < s.length; i++)
	     if (fmt.equals(s[i])) return true;

	 return false;

     }


     public boolean updateFormat(String fmt, boolean isOn) {
	 String s[] = null;
	 String key = null;

	 boolean container_changed = false;

	 if (isContainer()) {

	     if (!Utils.isValidProductFormat(product, true, fmt))
		 return container_changed;
		 
	     s = (String[])productFormatMap.get(product+"_CONTAINER");
	     container_changed = true;

	     if (s==null) {

		 String[] n = new String[2];
		 n[0] = new String(product);
		 n[1] = new String(fmt);

		 productFormatMap.put(n[0]+"_CONTAINER",n);

		 return container_changed;
	     }


	     key = product+"_CONTAINER";

	 } else {

	     s = (String[])productFormatMap.get(product);

	     if (s==null) {

		 String[] n = new String[2];
		 n[0] = new String(product);
		 n[1] = new String(fmt);

		 productFormatMap.put(n[0],n);
		 return container_changed;

	     }

	     key = product;
	 }
	 
	if (isOn && isFormatOn(fmt)) return container_changed;
	


	java.util.ArrayList newList = new java.util.ArrayList(10);

	if (isOn) {
	    
	    int k = 0;
	    newList.add(k++,new String(s[0]));

	    if (isContainer() ) {
		newList.add(k++, new String(fmt));
	    } else {
		for (int c = 2; c< columnNames.length; c++) {
		    
		    String cfmt = columnNames[c];
		    
		    if (cfmt.equals(fmt)) {
			newList.add(k++, new String(fmt));
		    } else {
			for ( int i = 1; i < s.length; i++) {
			    if (cfmt.equals(s[i])) {
				newList.add(k++,new String(s[i]));
				break;
			    }
			} // for
		    } //else
		}  // for c = 2
	    }
	} else {

	    
	    int k = 0;
	    newList.add(k++,new String(s[0]));

	    for (int i = 1; i < s.length; i++) {
		if (!fmt.equals(s[i])) 
		    newList.add(k++, new String(s[i]));
	    }
	}



	productFormatMap.remove(key);
	
	String[] newfmts = (String[]) newList.toArray(new String[1]);
	productFormatMap.put(key,newfmts);

	return container_changed;

     } // updateFormat()






     public boolean isSubProduct() {


	 if (isContainee) return true;

	 String s[] = (String[])productMap.get(product);

	 return (!Utils.parseBooleanString(s[5])
		 && !s[6].equals("-"));
	 

     }

     public String getInputFormat()
     {

	 if (isRoot) return "";

	 if (isSubProduct()) {
	     String s[] = (String[])productMap.get(product);
	     String f[] = (String[])productFormatMap.get(s[6]+"_CONTAINER");
	     if ((f==null)||(f.length<2))
		 return "";
	     return f[1];
	 } else {
	     return Constants.GLB_IDS_FORMAT;
	 }
     }


     
     
 } /* Class ProductFormatData */

}

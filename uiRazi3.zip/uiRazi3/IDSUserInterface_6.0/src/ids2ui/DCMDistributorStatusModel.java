/*
**  SCCS Info :  "@(#)DCMDistributorStatusModel.java	1.8    07/12/14"
*/
/*
 * DCMDistributorStatusModel.java
 *
 * Created on May 24, 2000, 5:08 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

public class DCMDistributorStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements	Utils.UpdateModel
{
  
    private String 		   	m_dcmList = null;

    private java.util.HashMap	m_distrData = null;

    protected int     		m_sortCol = 0;
    protected boolean 		m_sortAsc = true;
    protected java.util.Vector 	m_vector = null;
        protected int listeners = 0;
        
    protected int 			m_columnsCount = 
	Constants.DistributorStatusTableColumnNames.length;

        private boolean m_showRunningOnly = false;
        
        DCMDistributorStatusModel This = null;
        
    


        public void addTableModelListener(javax.swing.event.TableModelListener l)
        {
                super.addTableModelListener(l);
                listeners++;
        }
        
        public void removeTableModelListener(javax.swing.event.TableModelListener l)
        {
                super.removeTableModelListener(l);
                listeners--;
                
        }
        
    public DCMDistributorStatusModel() {
	this((String)null);
    }
 
    public DCMDistributorStatusModel(String dlist)
    {
	m_vector = new java.util.Vector(200);
	m_distrData  = new java.util.HashMap(200);
	m_dcmList = dlist;
        This = this;
        
        DCMDistributorConfigCache.subscribe(this, dlist);
        
    }


        public void showRunningOnly(boolean b)
        {
                m_showRunningOnly = b;
        }
        
                        
  
    public byte[] saveState()
    throws Exception
    {

	//java.io.FileOutputStream fout = new java.io.FileOutputStream(filep);
	java.io.ByteArrayOutputStream fout = new java.io.ByteArrayOutputStream();
	java.io.ObjectOutputStream out = new java.io.ObjectOutputStream(fout);

	out.writeObject(m_vector);
	out.flush();

	out.writeObject(m_distrData);
	out.flush();

	byte[] bytes = fout.toByteArray();

	fout.close();
	return bytes;

    }

  
    public void restoreState(byte[] bytes)
    throws Exception
    {

	//java.io.FileInputStream fin = new java.io.FileInputStream(filep);
	java.io.ByteArrayInputStream fin = new java.io.ByteArrayInputStream(bytes);
	java.io.ObjectInputStream in = new java.io.ObjectInputStream(fin);

	m_vector = (java.util.Vector)in.readObject();
	m_distrData = (java.util.HashMap)in.readObject();

	fin.close();

	fireTableDataChanged();
    }



    

    public void loadConfig(String dlist) {
	m_dcmList = dlist;
	Refresh();
	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("Load Config called:"+dlist);
    }



    synchronized public String getHost1(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_distrData!=null)) {
	    String data[] = (String[])m_distrData.get(id);
	    return data[0];
	}
	return null;
    }

    synchronized public String getHost2(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_distrData!=null)) {
	    String data[] = (String[])m_distrData.get(id);
	    return data[1];
	}
	return null;
    }

    synchronized public String getPHost1(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_distrData!=null)) {
	    String data[] = (String[])m_distrData.get(id);
	    return data[2];
	}
	return null;
    }

    synchronized public String getPHost2(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_distrData!=null)) {
	    String data[] = (String[])m_distrData.get(id);
	    return data[3];
	}
	return null;
    }


    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }



    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int col) {
	int column = col;
      	String str = Constants.DistributorStatusTableColumnNames[column];
	if (col==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 

    synchronized public Object getValueAt(int nRow, int nCol) {
	
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }

    synchronized public java.util.Vector getDataVector(){
	return m_vector;
    }



    synchronized public void addRow(Object[] o) {
	m_vector.add(o);

	java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	fireTableDataChanged();

    }
	
    synchronized public void removeRow(int r) {
	m_vector.remove(r);

	fireTableDataChanged();

    }

        boolean running = true;
        
    synchronized public void stop() {
	//threadPool.waitForAll(true);
            running = false;
                /*
                  if (loadConfigThread != null)
                    loadConfigThread.interrupt();
                */
            
	m_vector.clear();
	m_vector = null;

    }


       
        boolean blockOnFirst = true;
        
        
        
        public void Update() 
                throws Exception 
        {
                

                int numRows = 0;
                int sColumn = 2;
                
                if (Constants.DEBUG && Constants.Verbose>2)
                        System.out.println("DCMDistributorStatusModel: Updating..");
                
                
                
                java.util.Vector u_vector = new java.util.Vector();
                java.util.HashMap u_distrData = new  java.util.HashMap();
                java.util.HashMap hostmap = new java.util.HashMap();


                int max_retries = 1;
                    /*
                System.out.println("Waiting for configuration to load."
                                   +m_dcmList+" "
                                   +new java.util.Date());
                    */

                for (int retries = 0; retries < max_retries; ) {

                        boolean is_subscribed =
                                DCMDistributorConfigCache.getData(this,
                                                                  blockOnFirst, u_vector,
                                                                  u_distrData,  hostmap);
                        if (!is_subscribed ) {
                                DCMDistributorConfigCache.subscribe(this, m_dcmList);
                                System.out.println("Re-subscribing: "+this);
                                blockOnFirst = true;
                                retries++;
                                continue;
                        }
                        
                        if (blockOnFirst && u_vector.size()==0) {
                                //System.out.println("Retrying..");
                                retries++;
                                continue;
                        }
                        break;
                }
                

                blockOnFirst = false;
                   
                    /*
                System.out.println("Configuration loaded."
                                   +m_dcmList+" "
                                   +new java.util.Date());
                    */

                
                numRows = u_vector.size();
                if ( numRows==0) {
                        synchronized (this) {
                                m_vector.removeAllElements();
                                m_distrData.clear();
                                fireTableDataChanged();
                        }
                        return;
                }
                        
                
                
                
 
                java.util.Iterator iter = hostmap.keySet().iterator();

                java.util.Vector workers = new java.util.Vector(20);
                StringBuffer hostList = new StringBuffer();
                StringBuffer distrList = new StringBuffer();
                
                while (iter.hasNext()) {
                        
                        String dcm = (String)iter.next();
                        DistrHostData distrHostData = (DistrHostData) hostmap.get(dcm);
                        
                        
                        
                        StringBuffer hostQuery = new StringBuffer();
                        StringBuffer query1 = new StringBuffer();
                        

                        query1.append("#4 *, dcm_linehand, *").append('\0');
                        
                        hostQuery.append("anyof(").append(distrHostData.dc1Host)
                                .append(") anyof(").append(distrHostData.dc2Host)
                                .append(")");
                        
                            /*
                            ** Use ' ' for hostname separator for status query
                            */
                        for (int i = 0; i < hostQuery.length(); i++) 
                                if (hostQuery.charAt(i)==',')
                                        hostQuery.setCharAt(i,' ');
                        
                            //hostList.append(hostQuery)
                            //.append(" ");
                            //distrList.append(distrHostData.distrList)
                            // .append(" ");;
                        
                        
                        StringBuffer query = new StringBuffer("#4 allof(");
                        query.append(hostQuery)
                            .append("),dcm_linehand, allof(");
                        
                        query.append(distrHostData.distrList);
                        query.append(")").append('\0');
                        
                        Utils.StatusQueryThread queryThread = 
                            new Utils.StatusQueryThread(query1.toString());
                        
                        workers.add(queryThread);
                        queryThread.start();
                        break;
                        
                } /* While iter hasNext() */

                    /*
                      StringBuffer query = new StringBuffer("#4 allof(")
                    .append(hostList)
                    .append("),dcm_linehand, allof(")
                    .append(distrList)
                    .append(")").append('\0');

                System.out.println("Query "+query.toString());
                
                Utils.StatusQueryThread queryThread1 = 
                    new Utils.StatusQueryThread(query.toString());
                
                workers.add(queryThread1);
                queryThread1.start();
                    */
                
                int active = 0;
                    
                for (int r = 0; r < u_vector.size(); r++) {
                    Object[] s = (Object[])u_vector.get(r);
                    if (s==null)
                        continue;
                    s[sColumn+1]= Constants.NO_STATUS;
                    s[sColumn+2]= Constants.NO_STATUS;
                    s[sColumn+3]= "";
                    u_vector.setElementAt(s,r); 
                }
                    
                int numWorkers = workers.size();
                for (int w = 0 ; w < numWorkers; w++ ) {
                        
                        Utils.StatusQueryThread queryThread 
                                = (Utils.StatusQueryThread)workers.get(w);
                        
                        
                        Utils.QueryData queryData = (Utils.QueryData) queryThread.get();
                        
                        if (queryData.error != null) {
                                Log.getInstance().log_error("Error in retrieving status",
                                                            queryData.error);
                        }
                        
                        String statusBuffer = queryData.result;
                        
                            //System.out.println("QUERY RESPONSE: "+w+" :->\n"+statusBuffer+"\n->\n");
                        
                        if (statusBuffer == null) {
                                Log.getInstance().log_warning("Error in retrieving Line handlers status: status buffer is null",null);
                                continue;
                        }
                        
                        
                        java.util.StringTokenizer recordTokenizer 
                                = new java.util.StringTokenizer(statusBuffer,"\n");
                        
                        int numRecords = recordTokenizer.countTokens();

	    

                        for (int n = 0; n < numRecords; n++) {

                                String record = recordTokenizer.nextToken();
                                java.util.StringTokenizer fieldTokenizer 
                                        = new java.util.StringTokenizer(record,",");
                                int numTokens = fieldTokenizer.countTokens();
                                if (numTokens >=5) {
                                        
                                        String timestamp = fieldTokenizer.nextToken();
                                        String status = fieldTokenizer.nextToken().trim();
                                        String host = fieldTokenizer.nextToken().trim();
                                        String progname = fieldTokenizer.nextToken();
                                        String id = fieldTokenizer.nextToken().trim();
                                        String lhmode = Constants.NO_STATUS;
                                        
                                        
                                        boolean match = false;
                                        for (int i = 0; i< numRows; i++) {
                                                
                                                String did = ((String[])u_vector.get(i))[0];
                                                String data[] = (String[])u_distrData.get(did);
                                                String host1 = data[2];
                                                String host2 = data[3];
                                                String location1 = data[4];
                                                String location2 = data[5];
                                                
                                                
                                                

                                                
                                                if (did.equals(id)) {
                                                        
                                                        if (status.equals("status")) {
                                                                
                                                                    //System.out.println("id: "+id+" host1: "+host1+" host2: "+host2+" host: "+host);
                                                                if (numTokens > 5)
                                                                        lhmode = fieldTokenizer.nextToken();
                                                                
                                                                if (Constants.findPattern(host1,host)) {
                                                                        Object[] s = (Object[])u_vector.get(i);
                                                                        s[sColumn+1] = lhmode;
                                                                        if (lhmode.equals("ACTIVE")){
                                                                            active++;
                                                                            s[sColumn+3] = location1;
                                                                        }
                                                                        
                                                                        u_vector.setElementAt(s,i);
                                                                } else if (Constants.findPattern(host2,host)) {
                                                                        Object[] s = (Object[])u_vector.get(i);
                                                                        s[sColumn+2] = lhmode;
                                                                        if (lhmode.equals("ACTIVE")){
                                                                            active++;
                                                                            s[sColumn+3] = location2;
                                                                        }
                                                                        
                                                                        u_vector.setElementAt(s,i);
                                                                } else {
                                                                        Log.getInstance().log_error("Could not "
                                                                                                    +"match status host names:"+id+" ["
                                                                                                    +host+"] : <"+host1+"> <"
                                                                                                    +host2+">", null);
                                                                }
                                                                
                                                        } else {
                                                                String es = fieldTokenizer.nextToken();
                                                                if (host1.replace(',',' ').trim().equals(host)) {
                                                                        Object[] s = (Object[])u_vector.get(i);
                                                                        s[sColumn+1] = es;
                                                                        u_vector.setElementAt(s,i);
                                                                } else if (host2.replace(',',' ').trim().equals(host)) {
                                                                        Object[] s = (Object[])u_vector.get(i);
                                                                        s[sColumn+2] = es;
                                                                        u_vector.setElementAt(s,i);
                                                                } else {
                                                                        Log.getInstance().log_error("Could not "
                                                                                                    +"match status host names:"+id+" ["
                                                                                                    +host+"] : <"+host1+"> <"
                                                                                                    +host2+">", null);
                                                                }
                                                                
                                                        }
                                                        match = true;
                                                        break;
                                                } /* if did == id */
                                                
                                                
                                        } /* for i < numRows */
                                        
                                        if (Constants.DEBUG && Constants.Verbose>2)
                                            if (!match) {
                                                Log.getInstance().log_error("Could not "
                                                                            +"match record:"+record, null);
                                                
                                            }
                                        
                                } else {
                                        Log.getInstance().log_error("Malformed status record ("
                                                                    +numTokens+") : "+record, null);
                                }
                                
                                
                        } /* For n < numRecords */
                        
                        
                } /* for w < numWorkers */
                java.util.Date d = new java.util.Date();
                if (Constants.DEBUG && Constants.Verbose>2)
                    System.out.println(d.toString() + "Num active = "+active);
                
                if (m_showRunningOnly) {
                
                for (int r = 0; r < u_vector.size(); ) {
                        Object[] s = (Object[])u_vector.get(r);
                        String s1 = (String)s[sColumn+1];
                        String s2 = (String)s[sColumn+2];

                        
                        if ( (s1.equals(Constants.ERROR_STATUS)
                            || s1.equals(Constants.NO_STATUS))

                            && (s2.equals(Constants.ERROR_STATUS)
                                || s2.equals(Constants.NO_STATUS)) ) {
                                u_vector.remove(r);
                        }
                        else
                                r++;
                        
                }
        }
        

	java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));

	int newRows = 0, oldRows = 0;
	synchronized (this ) {
	    if (m_vector != null)  {
		oldRows = m_vector.size();
		m_vector.clear();
	    }
	    m_vector = null;
	    m_vector = u_vector;
	    newRows = m_vector.size();
	    if (m_distrData != null) m_distrData.clear();
	    m_distrData = null;
	    m_distrData = u_distrData;
	}
	
        IDS_SwingUtils.fireTableChanged(this, oldRows, newRows);
        

	//fireTableDataChanged();


	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DCMDistributorStatusModel: Update done.");


    } /* Update () */





    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;
	
	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel 
		= m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }

	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;


		
	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }

	    m_table.getTableHeader().repaint();  

	    synchronized (DCMDistributorStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, m_sortAsc));
	    }

	  
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DCMDistributorStatusModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release();
	    
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;

	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }

	


}



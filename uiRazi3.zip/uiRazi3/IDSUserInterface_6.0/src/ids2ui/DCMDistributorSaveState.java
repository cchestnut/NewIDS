/*
**  SCCS Info :  "@(#)DCMDistributorSaveState.java	1.6    07/12/14"
*/

/*
 * DCMDistributorSaveState.java
 *
 * Created on Septembet 16, 2002, 11:17 AM
 */
 
package ids2ui;
import java.util.Arrays;


/** 
 *
 * @author  srz
 * @version 
 */
public class DCMDistributorSaveState extends javax.swing.JFrame 
    implements TaskListener, javax.swing.event.ListSelectionListener 
{

        private javax.swing.JTable distrTable;
        private DCMDistributorSaveState myFrame;
        private javax.swing.table.TableCellRenderer serviceCellRenderer=null;
        
        private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();
        
        private volatile boolean isExiting = false;
        
        private boolean validState = false;
        javax.swing.event.DocumentListener docListener = null;
        

    /** Creates new form DistrServicesScreen */
    public DCMDistributorSaveState() {

	WindowEventAdapter.getInstance().registerWindow(
                      Constants.DCM_DISTRIBUTOR_SAVE_STATE,
			this);


	try {
		serviceCellRenderer
                        = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultServiceCellColorMap);
	} catch (Exception e) {
		Log.getInstance().log_error("DCMDistributorSaveState:Error in "
					+"creating cell renderer.",e);
	}

	setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	myFrame = this;

	initComponents ();
	myInitComponents ();

	updateUIState(0);

	pack ();
	
	saveButton.setEnabled(false);


	if (StandAlone)
          taskStarted("Loading configuration..");
        
    }


    public void enableState() {
	saveButton.setEnabled(true);
	taskEnded("Configuration loaded.");
    }


    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;
	updateUIState(0);

	int srows[] = distrTable.getSelectedRows();

	idTextF.getDocument().removeDocumentListener( docListener);

	if (srows.length!=1)
		idTextF.setText("");
	else
		idTextF.setText((String)distrTable.getValueAt(srows[0],0));

	idTextF.getDocument().addDocumentListener( docListener);
		
    }


   


    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }

    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 

	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}

    }


    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(java.util.EventObject evt) {
	taskEnded("Status updated @ "+new java.util.Date().toString());
    }

    public void taskEnded(final String s) {


	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);

	    updateUIState(0);
	    repaint();
	}
    }





    public void updateUIState(int flags) {

	boolean enable1,enable2;
	    
	

	    
	if (!validState) {
	    startButton1.setEnabled(false);
	    startButton2.setEnabled(false);
	    saveButton.setEnabled(false);
	    
	    return;
	}
        
        saveButton.setEnabled(true);

        String location = (String)locationComboBox.getSelectedItem();

        boolean enabled = false;

        int srows[] = distrTable.getSelectedRows();
        
        if (!location.equals(Constants.PICK_LOCATION)) {

                for (int i = 0; i < srows.length; i++) {
                        String mode1 = (String)distrTable.getValueAt(srows[i],3);
                        String mode2 = (String)distrTable.getValueAt(srows[i],4);
                        
                        if ( ( (mode1!=null)
                             && (mode1.equals("ACTIVE") 
                                 || mode1.equals("DORMANT")) )
                             || ( (mode2!=null)
                                  && (mode2.equals("ACTIVE") 
                                      || mode2.equals("DORMANT")) ) ) {
                                        enabled = true;
                                        break;
                        }
                }
        }
        
    
	startButton1.setEnabled(enabled);
	startButton2.setEnabled(enabled);
            
        if (flags != 1) {
                String dcms[] = new String[srows.length];
                for (int i = 0; i < srows.length; i++) 
                        dcms[i] = (String)distrTable.getValueAt(srows[i], 1);
                
                        
                Utils.loadDCMLocationList(locationComboBox, Arrays.asList(dcms) );
        }
            

	
    } /* updateUIState() */



    private void myInitComponents()
    {

	javax.swing.ButtonGroup group;
     
    
	group = new javax.swing.ButtonGroup();
	group.add(normalRB1);
	group.add(hotRB1);
	group.add(coldRB1);

	normalRB1.setSelected(true);



	DCMDistributorStatusModel distrModel 
	    = new DCMDistributorStatusModel();
        distrModel.showRunningOnly(true);
        

        distrTable = new javax.swing.JTable( distrModel){
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row,int column) {

		if ((serviceCellRenderer!=null)
			&& ((column==3)||(column==4)))
			return serviceCellRenderer;
		return super.getCellRenderer(row,column);

	    }
        };

	
	distrTable.setPreferredScrollableViewportSize(new java.awt.Dimension(300,100));

	docListener = new ActionHandlers.IDFieldListener(this, distrTable, idTextF);


	javax.swing.table.JTableHeader header = distrTable.getTableHeader();
	header.addMouseListener(
				 distrModel.new ColumnListener(distrTable,rwLock));

	distrTable.getSelectionModel().addListSelectionListener(this);

	distrTable.addMouseListener( new ActionHandlers.DCMDistributorStatusAdapter(this, distrTable) );


	
	


	javax.swing.JScrollPane tableScrollPane = new javax.swing.JScrollPane(distrTable);
	tablePanel.add (tableScrollPane, java.awt.BorderLayout.CENTER);
        


        Utils.loadLocationList(locationComboBox);

        locationComboBox.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {  updateUIState(1); }
        }
                                           );

        locationComboBox.setRenderer( new IDS_SwingUtils.LocationComboBoxRenderer());

        
	idTextF.getDocument().addDocumentListener( docListener );


        selectAllButton.addActionListener( new ActionHandlers.SelectAllActionHandler(distrTable));
        
        currentStateButton.addActionListener(
                new ActionHandlers.ActionHandler(this,this,
                                                 rwLock,null,
                                                 distrTable) 
                {
                        public void handler(javax.swing.JButton cmdButton, String command) 
                        {
                                getCurrentState();
                                if (cmdButton!=null)
                                        cmdButton.setEnabled(true);
                        }
                        
                }
                );
                                                                      
        
        saveButton.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                        saveToFile (evt);
                }
        }
                                      );

        
        loadButton.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                        loadFromFile (evt);
                }
        }
                                      );

        ActionHandlers.RestoreStateActionHandler stateActionHandler
                = new ActionHandlers.RestoreStateActionHandler(this, this,
                                                               rwLock,null,
                                                               distrTable,
                                                               locationComboBox,
                                                               normalRB1, hotRB1, coldRB1,
                                                               null);
        
        startButton1.addActionListener( stateActionHandler );
        startButton2.addActionListener( stateActionHandler );
        
          ActionHandlers.ExitHandler exitHandler =
                                                  new ActionHandlers.ExitHandler(this,this, rwLock, 
                                                                  null, distrTable);
                                                  
                closeButton.addActionListener(exitHandler);
                addWindowListener(exitHandler); 

        
    } // End of myInitComponents() 




        public void getCurrentState() 
        {
                validState = false;
                updateUIState(0);
                
                taskStarted("Retrieving status..");
                
                DCMDistributorStatusModel model
                = (DCMDistributorStatusModel)distrTable.getModel();
                try {
                        model.Update();
                        validState = true;
                        updateUIState(0);
                        taskEnded("State retrieved.");
                }
                catch (Exception e) {
                        taskEnded("Error in retrieving current state.");
                }
                updateUIState(0);
        }
        

        public void saveToFile (java.awt.event.ActionEvent evt) 
        {
                statusPanel.showStatus("Saving state..");

                String cDir = System.getProperty("user.dir");
                java.io.File currDir = new java.io.File(cDir);
                javax.swing.JFileChooser chooser
                        = new javax.swing.JFileChooser(currDir);
                
                chooser.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
                
                int returnVal = chooser.showSaveDialog(this);
                
                
                if (returnVal == javax.swing.JFileChooser.APPROVE_OPTION)
                {
                        try {
                                DCMDistributorStatusModel model =
                                        (DCMDistributorStatusModel) distrTable.getModel();
                                byte[] bytes = model.saveState();


                                java.io.File file = chooser.getSelectedFile();
                                java.io.FileOutputStream fout = new java.io.FileOutputStream(file);
                                fout.write(bytes);
                                fout.flush();
                                fout.close();
                                taskEnded("State saved in "
                                          +file.getCanonicalPath());
                                
                        } catch (Exception ex) {
                                Log.getInstance().show_error(this,"Error",
                                                             "Error in saving state: "
                                                             +ex.getMessage(),
                                                             ex);
                                taskEnded("Save state failed.");
                        }
                        
                } else {
                        taskEnded("Save cancelled");
                }
                
        }


        public void loadFromFile (java.awt.event.ActionEvent evt) 
        {

               
                taskStarted("Loading state..");
                        
                String cDir = System.getProperty("user.dir");
                java.io.File currDir = new java.io.File(cDir);
                javax.swing.JFileChooser chooser = new javax.swing.JFileChooser(currDir);
                chooser.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
                int returnVal = chooser.showOpenDialog(this);
                if (returnVal == javax.swing.JFileChooser.APPROVE_OPTION) {
                                
                        java.io.File file = chooser.getSelectedFile();

                        try {
                                DCMDistributorStatusModel model = (DCMDistributorStatusModel) distrTable
.getModel();
                                java.io.FileInputStream fin = new java.io.FileInputStream(file);
                                byte[] bytes = new byte[(int)file.length()];
                                fin.read(bytes,0,bytes.length);
                                
                                fin.close();
                                
                                
                                model.restoreState(bytes);
                                validState = true;
                                taskEnded("State retrieved.");
                        } catch (Exception e) {
                                taskEnded("Error in retrieving state");
                                Log.getInstance().show_error(this,"Error",
                                                             "Error in retrieving "
                                                             +"saved state: "
                                                             +e.getMessage(),
                                                             e);
                                
                        }
                } else {
                        taskEnded("Action cancelled.");
                }
                
                updateUIState(0);

                
	}






    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel8 = new javax.swing.JPanel ();
          tablePanel = new javax.swing.JPanel ();
          jPanel4 = new javax.swing.JPanel ();
          jPanel5 = new javax.swing.JPanel ();
          idLabel = new javax.swing.JLabel ();
          idTextF = new ids2ui.UCTextField ();
          jPanel1 = new javax.swing.JPanel ();
          selectAllButton = new javax.swing.JButton ();
          jPanel2 = new javax.swing.JPanel ();
          optionPanel11 = new javax.swing.JPanel ();
          normalRB1 = new javax.swing.JRadioButton ();
          hotRB1 = new javax.swing.JRadioButton ();
          coldRB1 = new javax.swing.JRadioButton ();
          jLabel2 = new javax.swing.JLabel ();
          jPanel11 = new javax.swing.JPanel ();
          startButton1 = new javax.swing.JButton ();
          locationComboBox = new javax.swing.JComboBox ();
          jLabel1 = new javax.swing.JLabel ();
          startButton2 = new javax.swing.JButton ();
          jPanel7 = new javax.swing.JPanel ();
          saveButton = new javax.swing.JButton ();
          loadButton = new javax.swing.JButton ();
          currentStateButton = new javax.swing.JButton ();
          jPanel3 = new javax.swing.JPanel ();
          closeButton = new javax.swing.JButton ();
          statusPanel = new ids2ui.StatusPanel ();
          getContentPane ().setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;
          setTitle ("Distributor Save State ");

          jPanel8.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
          jPanel8.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));

            tablePanel.setLayout (new java.awt.BorderLayout ());
            tablePanel.setBorder (new javax.swing.border.CompoundBorder(
            new javax.swing.border.CompoundBorder(
            new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
            new javax.swing.border.TitledBorder(
            new javax.swing.border.EtchedBorder(), "Saved state of linehandlers", 2, 2,
            new java.awt.Font ("Dialog", 1, 12), java.awt.Color.darkGray)),
            new javax.swing.border.LineBorder(java.awt.Color.black)));
  
              jPanel4.setLayout (new java.awt.BorderLayout ());
    
      
                  idLabel.setText ("ID");
        
                  jPanel5.add (idLabel);
        
                  idTextF.setColumns (5);
        
                  jPanel5.add (idTextF);
        
                jPanel4.add (jPanel5, java.awt.BorderLayout.WEST);
      
      
                  selectAllButton.setMargin (new java.awt.Insets(2, 7, 2, 7));
                  selectAllButton.setText ("Select all");
        
                  jPanel1.add (selectAllButton);
        
                jPanel4.add (jPanel1, java.awt.BorderLayout.EAST);
      
              tablePanel.add (jPanel4, java.awt.BorderLayout.SOUTH);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 0;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.weightx = 1.0;
            gridBagConstraints2.weighty = 1.0;
            jPanel8.add (tablePanel, gridBagConstraints2);
  
            jPanel2.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints3;
            jPanel2.setBorder (new javax.swing.border.TitledBorder(""));
  
              optionPanel11.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints4;
    
                normalRB1.setSelected (true);
                normalRB1.setText ("Normal");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 1;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
                optionPanel11.add (normalRB1, gridBagConstraints4);
      
                hotRB1.setText ("Hot");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 2;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
                optionPanel11.add (hotRB1, gridBagConstraints4);
      
                coldRB1.setText ("Cold");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 3;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
                optionPanel11.add (coldRB1, gridBagConstraints4);
      
                jLabel2.setText ("Mode of active line handlers");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 0;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.insets = new java.awt.Insets (0, 0, 0, 10);
                optionPanel11.add (jLabel2, gridBagConstraints4);
      
              gridBagConstraints3 = new java.awt.GridBagConstraints ();
              gridBagConstraints3.gridx = 0;
              gridBagConstraints3.gridy = 1;
              gridBagConstraints3.gridwidth = 2;
              gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints3.insets = new java.awt.Insets (10, 0, 0, 0);
              gridBagConstraints3.weightx = 1.0;
              jPanel2.add (optionPanel11, gridBagConstraints3);
    
              jPanel11.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints5;
    
                startButton1.setText ("Start in saved mode");
                startButton1.setActionCommand ("START");
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 2;
                gridBagConstraints5.gridy = 0;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (0, 10, 0, 0);
                jPanel11.add (startButton1, gridBagConstraints5);
      
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 1;
                gridBagConstraints5.gridy = 0;
                gridBagConstraints5.insets = new java.awt.Insets (0, 5, 0, 0);
                jPanel11.add (locationComboBox, gridBagConstraints5);
      
                jLabel1.setText ("Location");
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 0;
                jPanel11.add (jLabel1, gridBagConstraints5);
      
                startButton2.setText ("Start in switched mode");
                startButton2.setActionCommand ("START_SWITCHED");
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 3;
                gridBagConstraints5.gridy = 0;
                gridBagConstraints5.insets = new java.awt.Insets (0, 10, 0, 0);
                jPanel11.add (startButton2, gridBagConstraints5);
      
              gridBagConstraints3 = new java.awt.GridBagConstraints ();
              gridBagConstraints3.gridx = 0;
              gridBagConstraints3.gridy = 2;
              gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints3.insets = new java.awt.Insets (10, 0, 0, 0);
              gridBagConstraints3.weightx = 1.0;
              gridBagConstraints3.weighty = 0.75;
              jPanel2.add (jPanel11, gridBagConstraints3);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 2;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.weightx = 1.0;
            jPanel8.add (jPanel2, gridBagConstraints2);
  
            jPanel7.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints6;
            jPanel7.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)));
  
              saveButton.setToolTipText ("Saves the current state of all DCM linehandlers ");
              saveButton.setText ("Save ..");
              saveButton.setActionCommand ("SAVE_STATE");
    
              gridBagConstraints6 = new java.awt.GridBagConstraints ();
              gridBagConstraints6.gridx = 1;
              gridBagConstraints6.gridy = 0;
              gridBagConstraints6.weightx = 0.25;
              jPanel7.add (saveButton, gridBagConstraints6);
    
              loadButton.setToolTipText ("Retrieves the saved state");
              loadButton.setText ("Load ..");
              loadButton.setActionCommand ("RESTORE_STATE");
    
              gridBagConstraints6 = new java.awt.GridBagConstraints ();
              gridBagConstraints6.gridx = 2;
              gridBagConstraints6.gridy = 0;
              gridBagConstraints6.weightx = 0.25;
              jPanel7.add (loadButton, gridBagConstraints6);
    
              currentStateButton.setText ("Get current state");
              currentStateButton.setActionCommand ("GET_STATE");
    
              gridBagConstraints6 = new java.awt.GridBagConstraints ();
              gridBagConstraints6.gridx = 0;
              gridBagConstraints6.gridy = 0;
              gridBagConstraints6.weightx = 0.25;
              jPanel7.add (currentStateButton, gridBagConstraints6);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 1;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.weightx = 1.0;
            jPanel8.add (jPanel7, gridBagConstraints2);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 1.0;
          gridBagConstraints1.weighty = 1.0;
          getContentPane ().add (jPanel8, gridBagConstraints1);

          jPanel3.setLayout (new java.awt.FlowLayout (1, 25, 5));

            closeButton.setText ("Close");
  
            jPanel3.add (closeButton);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (jPanel3, gridBagConstraints1);

          statusPanel.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));


          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (statusPanel, gridBagConstraints1);

        }//GEN-END:initComponents




   






   
 

    /** Exit the Application */
	public boolean StandAlone = false;

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
	
	try {
	    StringBuffer userName = new StringBuffer();
	    StringBuffer hostList = new StringBuffer();
	    StringBuffer idsDir   = new StringBuffer();
            
	    DCMDistributorSaveState ssFrame = new DCMDistributorSaveState ();
            ssFrame.StandAlone = true;
	    ssFrame.show();
	    UILoginDialog dlg = new UILoginDialog(ssFrame,true);
	    dlg.show();
	    if (dlg.getLoginParams(userName,hostList,idsDir)) {
		ConfigComm.initLoginLite(userName.toString(),
		     hostList.toString(),
		     idsDir.toString());
		StatusRequest.init(hostList.toString());
		ssFrame.enableState();
	    } else
		System.exit(1);
	}
	catch (Exception e) {
	    e.printStackTrace();
	}

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel tablePanel;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel idLabel;
    private ids2ui.UCTextField idTextF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton selectAllButton;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel optionPanel11;
    private javax.swing.JRadioButton normalRB1;
    private javax.swing.JRadioButton hotRB1;
    private javax.swing.JRadioButton coldRB1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JButton startButton1;
    private javax.swing.JComboBox locationComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton startButton2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton saveButton;
    private javax.swing.JButton loadButton;
    private javax.swing.JButton currentStateButton;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton closeButton;
    private ids2ui.StatusPanel statusPanel;
    // End of variables declaration//GEN-END:variables

  

}

 

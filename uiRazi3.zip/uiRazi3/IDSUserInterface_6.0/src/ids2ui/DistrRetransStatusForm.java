/*
**  SCCS Info :  "@(#)DistrRetransStatusForm.java	1.7    04/04/20"
*/
/*
 * DistrRetransStatusForm.java
 *
 * Created on December 21, 2000, 4:26 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistrRetransStatusForm 
    extends javax.swing.JFrame 
    implements TaskListener  
{
    private DistrRetransStatusModel  statusModel = null;
    private javax.swing.JTable statusTable = null;
    private javax.swing.JFrame myFrame=null;
  

    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();

    private volatile boolean isExiting = false;


    /** Creates new form DistrRetransStatusForm */
    public DistrRetransStatusForm(String id, String dcmTag,
				  String hostlist1, String hostlist2) 
	throws Exception 
    {
	
     
	myFrame = this;
            
	StringBuffer key = 
	    new StringBuffer(Constants.STATUS_DISTR_RETRANSMISSION_PREFIX);
	key.append(id);
          
	javax.swing.JFrame f 
	    = (javax.swing.JFrame)WindowEventAdapter
	    .getInstance().findWindow(key.toString());
	if (f!=null) {
	    f.show();
	    setVisible(false);
	    dispose();
	    throw new Utils.DuplicateWindowException();	 
	}
	
	initComponents ();
	myInitComponents(id, dcmTag, hostlist1, hostlist2);


        WindowEventAdapter.getInstance().registerWindow(key.toString(),
							this);

        
	pack ();


	updateTimer.start();


    }





    public void Refresh () 
    {

	if (statusModel==null) return;

	taskStarted(new java.util.EventObject(this));
	try {
	    rwLock.writeLock().acquire();
	} catch (Exception e){
		taskEnded();
		return;
	}
	statusModel.Refresh();

   	rwLock.writeLock().release();     
	taskEnded();

    }




    /** Called when a task is scheduled to start. */
    public void taskStarted(java.util.EventObject event) {
	taskStarted("Updating status.");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }


    public void taskStarted(final  String s) {
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 
	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}

    }

     
    /** Called when a task ends. */
    public void taskEnded() {
	taskEnded((String)null);
    }



    public void taskEnded(final  String s) {
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);
	    else
		statusPanel.clear();

	    repaint();
	}
	
    }

  
    public void taskEnded(final java.util.EventObject event) {

	
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(event);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    if (event instanceof RetransmissionStatusEvent) {
		RetransmissionStatusEvent evt = 
		    (RetransmissionStatusEvent)event;

		if (evt.getStatus()==0) {
		    timeLabel.setText(evt.getTimeStamp());
		    taskEnded("Status updated @ "
			      +new java.util.Date().toString());
		} else {
		    taskEnded(evt.getError());
		}
	    } else {
		taskEnded("Status updated.");
	    }
	}

    }
 
  
 



    private void myInitComponents(String id, String dcmTag, 
				  String hostlist1,String hostlist2) 
	throws Exception
    {

            if (dcmTag == null) {
                java.util.HashMap config = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+id);
                String dcmKey = (String)config.get("TAG");
                config = ConfigComm.getHashMap(dcmKey);
                dcmTag = dcmKey.substring(Constants.GLB_TAG_DCM_PREFIX.length());
                hostlist1 = (String)config.get("PHOST1");
                hostlist2 = (String)config.get("PHOST2");
        }
	try {
	    statusModel = new DistrRetransStatusModel(id,dcmTag,
						      hostlist1,hostlist2);
 
	} catch (Exception e) { 
	    //Log.getInstance().show_error(this,"Error",e.getMessage(),e);
	    Log.getInstance().log_error(e.getMessage(),e);
	    setVisible(false);
	    dispose();
	    throw e;
	}
    
      
	statusTable = new javax.swing.JTable(statusModel);


	javax.swing.JScrollPane jScrollPane1 = 
	    new javax.swing.JScrollPane(statusTable);
	tablePanel.add (jScrollPane1, java.awt.BorderLayout.CENTER);


	
	javax.swing.table.JTableHeader header = statusTable.getTableHeader();
	header.addMouseListener(statusModel.new ColumnListener(statusTable,
							       rwLock));
	
	
    
	dcmLabel.setText(dcmTag);
	idLabel.setText(id);
	String title = getTitle();
	setTitle(title+id);

    
	timeLabel.setForeground(statusTable.getForeground());
	idLabel.setForeground(statusTable.getForeground());
	dcmLabel.setForeground(statusTable.getForeground());       
    

	Utils.UpdateEventListener updater 
	    = new Utils.UpdateEventListener(rwLock, this,
					    statusModel);

	updateTimer = 
	    new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, 
				  updater);   
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents () {//GEN-BEGIN:initComponents
      jPanel1 = new javax.swing.JPanel ();
      jPanel3 = new javax.swing.JPanel ();
      jButton1 = new javax.swing.JButton ();
      jButton2 = new javax.swing.JButton ();
      statusPanel = new ids2ui.StatusPanel ();
      jPanel2 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      idLabel = new javax.swing.JLabel ();
      jLabel3 = new javax.swing.JLabel ();
      timeLabel = new javax.swing.JLabel ();
      jLabel5 = new javax.swing.JLabel ();
      dcmLabel = new javax.swing.JLabel ();
      tablePanel = new javax.swing.JPanel ();
      setTitle ("Retransmission Status: ");
      addWindowListener (new java.awt.event.WindowAdapter () {
        public void windowClosing (java.awt.event.WindowEvent evt) {
          exitForm (evt);
        }
      }
      );

      jPanel1.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;
      jPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)), null));

        jPanel3.setLayout (new java.awt.FlowLayout (1, 15, 5));
  
          jButton1.setText ("Refresh");
          jButton1.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              Refresh (evt);
            }
          }
          );
    
          jPanel3.add (jButton1);
    
          jButton2.setText ("Close");
          jButton2.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              closeDialog (evt);
            }
          }
          );
    
          jPanel3.add (jButton2);
    
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.weightx = 1.0;
        jPanel1.add (jPanel3, gridBagConstraints1);
  
  
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 1;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.weightx = 1.0;
        jPanel1.add (statusPanel, gridBagConstraints1);
  

      getContentPane ().add (jPanel1, java.awt.BorderLayout.SOUTH);

      jPanel2.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints2;
      jPanel2.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.EtchedBorder()));

        jLabel1.setText ("ID");
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.insets = new java.awt.Insets (5, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel2.add (jLabel1, gridBagConstraints2);
  
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints2.weightx = 0.5;
        jPanel2.add (idLabel, gridBagConstraints2);
  
        jLabel3.setText ("Time");
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.insets = new java.awt.Insets (5, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel2.add (jLabel3, gridBagConstraints2);
  
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints2.weightx = 0.5;
        jPanel2.add (timeLabel, gridBagConstraints2);
  
        jLabel5.setText ("DCM");
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.insets = new java.awt.Insets (5, 0, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel2.add (jLabel5, gridBagConstraints2);
  
  
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.gridx = 1;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints2.weightx = 0.5;
        jPanel2.add (dcmLabel, gridBagConstraints2);
  

      getContentPane ().add (jPanel2, java.awt.BorderLayout.NORTH);

      tablePanel.setLayout (new javax.swing.BoxLayout (tablePanel, 0));
      tablePanel.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.EtchedBorder()));


      getContentPane ().add (tablePanel, java.awt.BorderLayout.CENTER);

    }//GEN-END:initComponents

    private void Refresh (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Refresh
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		Refresh();
		return null;
	    }

	    public void finished(){
		if (cmdButton!=null) cmdButton.setEnabled(true);
	    }
	};

	sw.start();    
  
    }//GEN-LAST:event_Refresh



    private void closeDialog (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeDialog
	// Add your handling code here:
	exitForm(null);
    }//GEN-LAST:event_closeDialog




    /** Exit the Application */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm

	if (isExiting) return;

	isExiting = true;

	if (updateTimer!=null)
	    updateTimer.stop();

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final DistrRetransStatusForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();
		    //model.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();




    
    }//GEN-LAST:event_exitForm

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private ids2ui.StatusPanel statusPanel;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel dcmLabel;
    private javax.swing.JPanel tablePanel;
    // End of variables declaration//GEN-END:variables
  
  
}


    /*
    **  SCCS Info :  "@(#)UpdateFilterCodes.java	1.1    05/03/31"
    */

/*
 * UpdateFilterCodes.java
 *
 * Created on March 31, 2005, 10:21 AM
 */

package ids2ui;
import java.util.*;
import java.io.*;

/** 
 *
 * @author  srz
 * @version 
 */
public class UpdateFilterCodes
{

            /*
            ** Validate & Update filter codes
            **
            ** FILTERID1<TAB>FILTERDESCRIPTION1<TAB>FILTERCODES1<NL>
            ** FILTERID2<TAB>FILTERDESCRIPTION2<TAB>FILTERCODES2<NL>
            ** FILTERID3<TAB>FILTERDESCRIPTION3<TAB>FILTERCODES3<NL>
            */


        public static char separatorChar[] =
        { 0x9 };
        
        

        public static boolean
        validateFilterCode(String id, String codes,
                                        StringBuffer errbuf)
        {

                errbuf.setLength(0);

                StringBuffer reqbuf = new StringBuffer();
                
                ConfigComm.getServKey(reqbuf,
                                      ConfigComm.VALIDATE_FILTER_STRING,
                                      codes);
                
                try {
                        byte [] b0 = ConfigComm.configRequest(reqbuf);
                        
                        String rbuf = new String(b0);
                        int index = rbuf.indexOf(ConfigComm.CONF_STX) +1;
                        
                        StringBuffer separator = new StringBuffer();
                        
                        String databuf = rbuf.substring(index);
                        separator.append(ConfigComm.CONF_ETX)
                                .append(ConfigComm.CONF_US)
                                .append(ConfigComm.CONF_FS);
                        
                        java.util.StringTokenizer st =
                                new java.util.StringTokenizer(databuf,
                                                              separator.toString());
                        int ret = -1;
                        
                        if (st.hasMoreTokens()) {
                                String s = st.nextToken();
                                try {
                                        ret = Integer.parseInt(s);
                                } catch (Exception e){}
                        }
                        
                        if (ret != 0) {
                                String errStr = null;
                                if (st.hasMoreTokens()) 
                                        errStr =  st.nextToken();
                                errbuf.append("Filter '")
                                        .append(id)
                                        .append("': Syntax error: \n")
                                        .append(errStr);
                                
                                return false;
                        }
                        
                } catch (Exception e) {
                        errbuf.append("Filter '")
                                .append(id)
                                .append("' : Error in validating syntax \n")
                                .append(e.getMessage());
                        return false;
                }

                return true;
                
        }


        public static boolean
        checkDistributors(String filter_id, String filter_codes,
                          Vector distrList, StringBuffer errbuf)
        {

                errbuf.setLength(0);
                distrList.clear();
                
                StringBuffer reqbuf = new StringBuffer();
                ConfigComm.getServKey(reqbuf,
                                      ConfigComm.GET_DISTRPRODS_USING_FILTER,
                                      filter_id);


                
                
                try
                {
                        byte[] b1 = ConfigComm.configRequest(reqbuf);

                            /*
                            ** Format:
                            ** |ID;host11,host12;p1,p2;host21,host22;p1,p2;|
                            ** |ID;host11,host12;p1,p2;host21,host22;p1,p2;|
                            **
                            */

                        String rbuf = new String(b1);
                        int index = rbuf.indexOf(ConfigComm.CONF_STX) +1;
                        StringBuffer rowsep = new StringBuffer("|");
                        rowsep.append(ConfigComm.CONF_FS)
                                .append(ConfigComm.CONF_ETX);
                        StringBuffer colsep = new StringBuffer(";");
                        
                        String databuf = rbuf.substring(index);
                        
                        java.util.StringTokenizer rt =
                                new java.util.StringTokenizer(databuf,
                                                              rowsep.toString());
                        
                        
                        while (rt.hasMoreTokens())
                        {
                                
                                String [] datastr = null;
                                
                                String s = rt.nextToken();
                                java.util.StringTokenizer ct =
                                        new java.util.StringTokenizer(s,
                                                                      colsep.toString());
                                datastr = new String[6];
                                
                                datastr[0] = null;
                                datastr[1] = null;
                                datastr[2] = null;
                                datastr[3] = null;
                                datastr[4] = null;
                                datastr[5] = filter_codes;
                                
                                if (ct.hasMoreTokens())
                                        datastr[0] = ct.nextToken();
                                if (ct.hasMoreTokens())
                                        datastr[1] = ct.nextToken();
                                if (ct.hasMoreTokens())
                                        datastr[2] = ct.nextToken();
                                if (ct.hasMoreTokens())
                                        datastr[3] = ct.nextToken();
                                if (ct.hasMoreTokens())
                                        datastr[4] = ct.nextToken();
                                
                                
                                distrList.add(datastr);
                                
                                
                        }
                        
                        
                        
                        
                        
                }
                catch (Exception e )
                {
                        
                        if (e instanceof DBException)
                        {
                                if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND)
                                        return true;
                        }
                        

                        errbuf.append("Error in checking distributors using filter '")
                                .append(filter_id)
                                .append("' \n")
                                .append(e.getMessage());
                        
                        return false;
                        
                }
                
		
                return true;
                
        }
        


        public static boolean
        saveFilter(String id, String desc, String codes, StringBuffer errbuf)
        {

                errbuf.setLength(0);
                
                boolean newEntry = false;
                
                try
                {
                        StringBuffer reqbuf = new StringBuffer();
                        ConfigComm.addFilterCode(reqbuf,id, desc, codes, newEntry);

                        byte [] b = ConfigComm.configRequest(reqbuf);
                
                }
                catch (Exception e)
                {
                        errbuf.append("Error in saving filter '")
                                .append(id)
                                .append("' \n")
                                .append(e.getMessage());
                        
                        return false;
                }

                return true;
                
        }
        
        public static boolean
        updateDistributors(Vector distrList, StringBuffer errbuf)
        {
                int sz = distrList.size();

                
                java.util.Vector workers  = new java.util.Vector(sz*2);
                
                for (int l = 0; l < sz; l++)
                {
                        String []datastr = (String[])distrList.elementAt(l);
                        String distrid = datastr[0];
                        String host1 = datastr[1];
                        String prodlist1 = datastr[2];
                        String host2 = datastr[3];
                        String prodlist2 = datastr[4];
                        String filter_codes = datastr[5];
                        
                        StringBuffer respbuf = new StringBuffer();

                            /* Update DC-I  line handler */
                        int r1 = Utils.isLineHandlerRunning(host1,distrid);
                        if ((r1==1) && (prodlist1!=null) && !prodlist1.equals("-"))
                        {

                                
                                java.util.StringTokenizer pt 
                                        = new java.util.StringTokenizer(prodlist1,",");
                                
                                while (pt.hasMoreTokens()) {
                                        
                                        String prod = pt.nextToken();
                                        StringBuffer updatebuf1 = new StringBuffer();
                                        updatebuf1.append(distrid+";"
                                                          +AdminComm.SET_FILTERING_CODES+
                                                          " "+prod+" "+filter_codes+";");

                                        System.out.println("\tQueing filter update for '"
                                                           +distrid+"':"+prod+" on '"+host1+"'");
                                        
                                        Utils.AdminWorker worker 
                                                = new Utils.AdminWorker(AdminComm.SET_FILTERING_CODES,
                                                                        host1, updatebuf1.toString());
                                        worker.start();

                                        workers.add(worker);
                                }
                        }


                            /* Update DC-II  line handler */

                        int r2 = Utils.isLineHandlerRunning(host2,distrid);
                        
                        if ( (r2==1) && (prodlist2!=null) && !prodlist2.equals("-"))
                        {
                                java.util.StringTokenizer pt 
                                        = new java.util.StringTokenizer(prodlist2,",");
                                
                                while (pt.hasMoreTokens())
                                {
                                        String prod = pt.nextToken();
                                        StringBuffer updatebuf2 = new StringBuffer();
                                        updatebuf2.append(distrid+";"
                                                          +AdminComm.SET_FILTERING_CODES+
                                                          " "+prod+" "+filter_codes+";");


                                        Utils.AdminWorker worker 
                                                = new Utils.AdminWorker(AdminComm.SET_FILTERING_CODES,
                                                                        host2, updatebuf2.toString());

                                        System.out.println("\tQueing filter update for '"
                                                           +distrid+"':"+prod+" on '"+host2+"'");

                                        worker.start();

                                        workers.add(worker);
                                }
                        }

                } /* For l < sz */ 

                
                    /* Now retrieve status */
                boolean update_err = false;
                
                for (int nw = 0; nw < workers.size(); nw++)
                {
                        Utils.AdminWorker w = (Utils.AdminWorker) workers.get(nw);
		
                        Utils.AdminStatus status 
                                = (Utils.AdminStatus) w.get();
                        if (status.status != 0) {
                                update_err=true;
                                Log.getInstance().log_error(status.response.toString(),
                                                            null);
                        }
                }

                
                
                return !update_err;
                
        }
        
                

        public static boolean
        updateFilter(boolean validate_filter,
                     boolean do_dynamic_update,
                     boolean continue_on_errors,
                     String filter_id, String filter_desc,
                     String filter_codes)
        {
                
                StringBuffer errbuf = new StringBuffer();

                if (validate_filter && !validateFilterCode(filter_id, filter_codes, errbuf) )
                {
                        System.out.println(errbuf);

                        if (!continue_on_errors)
                                return false;
                }
                

                if (!saveFilter(filter_id, filter_desc, filter_codes, errbuf))
                {
                        System.out.println(errbuf);

                        return false;
                }

                Vector distrList = new Vector(10);
                
                if ( !checkDistributors( filter_id, filter_codes,
                                        distrList, errbuf))
                {
                        System.out.println(errbuf);
                
                        if (!continue_on_errors)
                                return false;
                }

                if (distrList.size() == 0)
                {
                        System.out.println("Did not find any distributors with "
                                           +filter_id+" configured.");
                        if (!continue_on_errors)
                                return false;
                        else
                                return true;
                }
                
                
                if (do_dynamic_update && !updateDistributors(distrList, errbuf))
                {
                        System.out.println(errbuf);

                        if (!continue_on_errors)
                                return false;
                }

                return true;
                
                
        }
        
                                

        public static void
        ImportCodes(boolean resource,
                    String input_file,
                    boolean validate_filter,
                    boolean do_dynamic_update,
                    boolean continue_on_errors)
                throws Exception
        {
               

                java.io.LineNumberReader fileReader
                        = new java.io.LineNumberReader( 
                                new java.io.InputStreamReader(new FileInputStream(input_file)));


		
		char	COMMENT = '#';
		String line = null;

                String filter_id, filter_desc, filter_codes;
                int NUM_TOKENS = 3;
                
		while ( (line = fileReader.readLine()) != null)
                {
			
			if ( (line.trim().length()==0)
                             || (line.charAt(0)==COMMENT) )
				continue;

                        String separator = new String(separatorChar);
                        
                        StringTokenizer st = new StringTokenizer(line, separator);

                        if (st.countTokens() != NUM_TOKENS)
                        {
                                System.out.println("Error parsing line "
                                                   + fileReader.getLineNumber()
                                                   + " in file "+input_file+" : Expecting "+
                                                   + NUM_TOKENS +" , got "+st.countTokens());
                                
                                
                        }
                        
                        filter_id = st.nextToken();
                        filter_desc = st.nextToken();
                        filter_codes = st.nextToken();
                        
                        System.out.println("== BEGIN ========= filter '"+filter_id+"'");
                        if (updateFilter(validate_filter,
                                         do_dynamic_update,
                                         continue_on_errors,
                                         filter_id,
                                         filter_desc,
                                         filter_codes) )
                        {
                                System.out.println("\t... DONE");
                        }
                        else
                        {
                                System.out.println("\t... FAILED");
                        }
                        System.out.println("== END ========= filter '"+filter_id+"'");
                        
              

		}
	}




        	
	private static void Usage()
	{
	
		System.out.println("Usage: java -jar ImportFilterCodes.jar dsp_host_list filter_file1 filter_file2 ..");
                System.out.println("\tFormat of filter file(s):");
                System.out.println("\t\tFILTERID1<TAB>FILTERDESCRIPTION1<TAB>FILTERCODES1<NL>");
                System.out.println("\t\tFILTERID2<TAB>FILTERDESCRIPTION2<TAB>FILTERCODES2<NL>");
                System.out.println("\t\tFILTERID3<TAB>FILTERDESCRIPTION3<TAB>FILTERCODES3<NL>");

		System.exit(1);
	}


	
        
        public static void main(String[] args)
        {

                boolean validate_filter = true;
                boolean do_dynamic_update = true;
                boolean continue_on_errors = false;
                boolean resource = false;


                StringBuffer userName = new StringBuffer();
                StringBuffer hostList = new StringBuffer();
                StringBuffer idsDir   = new StringBuffer();
                        
                if ( args.length < 2)
                {
                        Usage();
                }
                
                userName.append("ids2adm");
                idsDir.append("/ids2");
                hostList.append(args[0]);
                
                
                System.out.println("Configuration host list: "
                                   +hostList.toString());


                try
                {
                        ConfigComm.initLoginLite(userName.toString(),
                                                 hostList.toString(),
                                                 idsDir.toString());
                }
                catch (Exception e)
                {
                        System.out.println("Cannot initialize login session:");
                        e.printStackTrace();
                }
                
                
              	
                
                for (int i = 1; i < args.length; i++)
                {
                        System.out.println("#### BEGIN ### file '"+args[i]+"'");
                        try
                        {
                                
                                ImportCodes(resource,
                                            args[i],
                                            validate_filter,
                                            do_dynamic_update,
                                            continue_on_errors);
                        }
                        catch (Exception e)
                        {
                                e.printStackTrace();
                        }
                        
                        System.out.println("#### END ### file '"+args[i]+"'");
                }


                System.exit(0);
                

        }
        


}
        


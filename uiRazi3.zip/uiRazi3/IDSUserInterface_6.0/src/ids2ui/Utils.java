/*
**  SCCS Info :  "@(#)Utils.java	1.24    07/12/14"
*/
/*
 * Utils.java
 *
 * Created on June 29, 2000, 9:43 AM
 */


package ids2ui;

import java.util.*;

public class Utils {

 
    public static class DuplicateWindowException 
	extends Exception 
    { 
	DuplicateWindowException()
	{
	    super("Duplicate Window");
	}
    }
   

    public static class DataParsingException
	extends Exception
    {
	public DataParsingException()
	{
	    super("Data Parsing Exception: ");
	}

	public DataParsingException(String s)
	{
	    super("Data Parsing Exception: "+s);
	}
    }


    public static String productVectorToString(java.util.Vector prodList)
    {
	StringBuffer productList = new StringBuffer();
	for (int i = 0; i < prodList.size(); i++) {
	    String prodid = (String)prodList.get(i);
	    productList.append(prodid).append(" ");
	}

	return productList.toString();
    }


    public static String productArrayToString(String[] prodList)
    {
	StringBuffer productList = new StringBuffer();
	for (int i = 0; i < prodList.length; i++) {
	    productList.append(prodList[i]).append(" ");
	}

	return productList.toString();
    }


    public static class QueryData {
	public String result = null;
	public Exception error = null;

	public QueryData(Exception e) 
	{
	    result = null;
	    error = e;
	}

	public QueryData(String data)
	{
	    error = null;
	    result = data;
	}
    }



        public static String getProgramStatus(String hostList, String progName,
                                       String prodID)
                throws Exception
        {
                        
                StringBuffer HostKey1 = new StringBuffer();
                String sep = new String(" ,\t");
                java.util.StringTokenizer st =
                        new java.util.StringTokenizer(hostList,sep);
                    
                    while (st.hasMoreTokens()) {
                            String hostName = st.nextToken();
                            HostKey1.append(hostName).append(" ");
                    }
        
                    return StatusRequest.getInstance().statusQuery(
                            HostKey1.toString().trim(),
                            progName,
                            prodID);
        }
        


    public static class StatusQueryThread extends SwingWorker {
	String query = null;
	QueryData data = null;

    	public StatusQueryThread(String qry) {
	    query = qry;
    	}

    	public Object construct() {
	    try {
		String statusBuffer = 
		    StatusRequest.getInstance().statusQuery(query);
		return new QueryData(statusBuffer);
	    } catch (Exception e) {
		return new QueryData(e);
	    }
	}

    }
	

    public static class UpdateTimer extends javax.swing.Timer {

	public UpdateTimer(java.awt.event.ActionListener l) {
	    this(Constants.ServiceStatusUpdateMilliSecs,l);
	}


	public UpdateTimer(int delay,java.awt.event.ActionListener l) {
	    super(delay,l);
	    setRepeats(true);
	    setCoalesce(true);
	    setInitialDelay(0);
	}
	
    }


    public static interface BasicUpdateModel {
    }


    public static interface UpdateModel extends BasicUpdateModel {
	public void Update() throws Exception;
    }


    public static interface UpdateEventModel extends BasicUpdateModel  {
	public java.util.EventObject Update();
    }


    public static class UpdateListener 
	implements java.awt.event.ActionListener 
    {
	TaskListener task;
	UpdateModel  model;
	FIFOReadWriteLock rwLock;

        volatile SwingWorker updateThread =  null;
        
	public UpdateListener(FIFOReadWriteLock lk, TaskListener l,
			      UpdateModel m) {
	    task = l;
	    model = m;
	    rwLock  =lk;
	}

	public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (updateThread != null) {
                System.out.println("Task running\n");
                return;
            }
            
            
	    updateThread = new SwingWorker() {
		Exception error = null;
		Thread me = null;
		public Object construct() {
		    me = Thread.currentThread();
		    try {
                                //rwLock.writeLock().acquire();
                                //task.taskStarted(new java.util.EventObject(task));
			model.Update();
			return null;
		    } catch (Exception e) {
			error = e;
			return e;
		    }
		}

		public void finished() {
		    
		    if (error != null) {
                                //task.taskEnded("Status update failed.");
			Log.getInstance().log_error("Status update failed.",
						    error);
		    } else {
                                //task.taskEnded(new java.util.EventObject(task));
		    }
                        //rwLock.writeLock().release();
                    updateThread = null;
		}
	    };
	    updateThread.start();
	}
    }



    public static class UpdateEventListener 
	implements java.awt.event.ActionListener 
    {
	TaskListener task;
	UpdateEventModel  model;
	FIFOReadWriteLock rwLock;
        volatile SwingWorker updateThread = null;
        
	public UpdateEventListener(FIFOReadWriteLock lk, TaskListener l,
			      UpdateEventModel m) {
	    task = l;
	    model = m;
	    rwLock  =lk;
	}

	public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (updateThread != null) {
                System.out.println("In progress. Skipping");
                return;
            }
            
	     updateThread = new SwingWorker() {
		Exception error = null;
		java.util.EventObject statusEvent = null;


		public Object construct() {
		    try {
			rwLock.writeLock().acquire();
			task.taskStarted(new java.util.EventObject(task));
			statusEvent = model.Update();
			return null;
		    } catch (Exception e) {
			error = e;
			return e;
		    }
		}

		public void finished() {
		    
		    if (error != null) {
			task.taskEnded("Status update failed.");
			Log.getInstance().log_error("Status update failed.",
						    error);
		    } else {
			task.taskEnded(statusEvent);
		    }
                    
		    rwLock.writeLock().release();
                    updateThread = null;
		}
	    };
	    updateThread.start();
	}
    }





    public static class UpdateListenerList implements java.awt.event.ActionListener {
	TaskListener task;
	UpdateModel  []models;
	FIFOReadWriteLock rwLock;
            volatile SwingWorker updateThread = null;
            
	public UpdateListenerList(FIFOReadWriteLock lk, TaskListener l,
			      UpdateModel m[]) {
	    task = l;
	    models = m;
	    rwLock  =lk;
	}

	public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (updateThread != null)
                {
                    System.out.println("In progress. skipping.");
                        if (Constants.DEBUG && Constants.Verbose>2)
                                Log.getInstance().log_warning("Skipping update cycle. Previous instance still running.", null);
                        return;
                        
                }

                        
                
	    updateThread = new SwingWorker() {
		Exception error = null;
		public Object construct() {
		    try {
                                //rwLock.writeLock().acquire();
                                //task.taskStarted(new java.util.EventObject(task));

			UpdateThread [] threads 
			    = new UpdateThread[models.length];

			for (int i = 0; i < models.length; i++) 
			    threads[i] = new UpdateThread(models[i]);

			for (int i = 0 ; i < models.length; i++) 
			    threads[i].start();


			for (int i = 0; i < models.length; i++) {
                                if (Constants.DEBUG && Constants.Verbose>2)
                                        System.out.println("Thread status "
                                                           +i+" start "
                                                           +new Date());
                                
                                Exception e1 = (Exception)threads[i].get();
                                if (Constants.DEBUG && Constants.Verbose>2)
                                        System.out.println("Thread status "
                                                           +i+" end "
                                                           +new Date());
                                
			    if ( e1 != null) { error = e1; }
			}

			return error;
		    } catch (Exception e) {
			error = e;
			return e;
		    }
		}

		public void finished() {
		    
		    if (error != null) {
                                //task.taskEnded("Status update failed.");
			Log.getInstance().log_error("Status update failed.",
						    error);
		    } else {
                                //task.taskEnded(new java.util.EventObject(task));
		    }
                    if (Constants.DEBUG && Constants.Verbose>2)
                            System.out.println("Stopping thread :"
                                               +updateThread+" "
                                               +new Date()+"\n");
                    updateThread = null;
                        //rwLock.writeLock().release();
		}
	    };

            
            if (Constants.DEBUG && Constants.Verbose>2)
                    System.out.println("\nStarting thread :"
                                       +updateThread+" "+new Date());
            
	    updateThread.start();
	}


	private class UpdateThread extends SwingWorker {
	    Exception error = null;
	    UpdateModel model;

	    public UpdateThread(UpdateModel m) {
		model = m;
	    }
	    public Object construct() {
		try {
		    model.Update();
		    return null;
		} catch (Exception e) {
		    error = e;
		    return e;
		}
	    }

	}

    }





        
        public static class UpdateListenerList2 implements java.awt.event.ActionListener {
	TaskListener task;
	UpdateModel  [] sync_models;
               	UpdateModel  [] async_models;
 
	FIFOReadWriteLock rwLock;
            volatile SwingWorker updateThread = null;
            
	public UpdateListenerList2(FIFOReadWriteLock lk, TaskListener l,
			      UpdateModel m1[], UpdateModel m2[]) {
	    task = l;
	    sync_models = m1;
	    async_models = m2;
	    rwLock  =lk;
	}

	public void actionPerformed(java.awt.event.ActionEvent evt) {
            if (updateThread != null)
            {
                System.out.println("Update in progress. Skipping..");
                return;
            }
            
	    updateThread = new SwingWorker() {
		Exception error = null;
		public Object construct() {
		    try {
			rwLock.writeLock().acquire();
			task.taskStarted(new java.util.EventObject(task));

			UpdateThread [] threads 
			    = new UpdateThread[sync_models.length+async_models.length];



			for (int i = 0; i < sync_models.length; i++) 
			    threads[i] = new UpdateThread(sync_models[i]);
                        
			for (int i = sync_models.length; i < threads.length; i++) 
			    threads[i] = new UpdateThread(async_models[i-sync_models.length]);



			for (int i = 0 ; i < threads.length; i++) 
			    threads[i].start();


			for (int i = 0; i < sync_models.length; i++) {

			    Exception e1 = (Exception)threads[i].get();
			    if ( e1 != null) { error = e1; }
			}


			return error;
		    } catch (Exception e) {

                            e.printStackTrace();
                            
			error = e;
			return e;
		    }
		}

		public void finished() {
		    

		    if (error != null) {

			task.taskEnded("Status update failed.");
                        error.printStackTrace();
                        
			Log.getInstance().log_error("Status update failed.",
						    error);
		    } else {

			task.taskEnded(new java.util.EventObject(task));
		    }
		    rwLock.writeLock().release();
                    updateThread = null;
		}
	    };
	    updateThread.start();
	}


	private class UpdateThread extends SwingWorker {
	    Exception error = null;
	    UpdateModel model;

	    public UpdateThread(UpdateModel m) {
		model = m;
	    }
	    public Object construct() {
		try {
                    System.out.println("Update called. "+ (new Date().toString()));
		    model.Update();
		    return null;
		} catch (Exception e) {
		    error = e;
		    return e;
		}
	    }

	}

    }




        
    public static class AdminStatus {
	int status;
	StringBuffer  response;
	public AdminStatus() {
	    status = 0;
	    response = new StringBuffer();
	}
    }

    public static class AdminWorker extends  SwingWorker  {

	AdminStatus status = new AdminStatus();
	int option = -1;
	String hostList = null;
	String request = null;

	public AdminWorker(int opt, String host, String req) {
	    option = opt;
	    hostList = host;
	    request = req;
	}

	public Object construct() {

	    if (Constants.DEBUG && Constants.Verbose>2)
		    System.out.println("AdminWorker:HOST: "+hostList+"->"
				       +request);

	    int r = -1;
	    if ((option==AdminComm.CHANGE_MODE) 
		|| (option==AdminComm.SET_FILTERING_CODES) ) {
		r = AdminComm.sendDynamicMessage(AdminComm.LINE_HANDLER,
						 hostList, 
						 request,
						 status.response);
	    } else {		
		r = AdminComm.processAction(option,
					    hostList,
					    request,
					    status.response);
	    }

	    //status.status = r;
	    return status;

	}

    }




    public static class DeleteDistrCacheThread extends  SwingWorker  
    {

	AdminStatus status = new AdminStatus();
	String hostList = null;
	String distrID = null;

	public DeleteDistrCacheThread(String host, String did) {
	    hostList = host;
	    distrID = did;
	}

	public Object construct() {

	    if (Constants.DEBUG && Constants.Verbose>2)
		    System.out.println("DeleteDistrCacheThread:HOST: "
				       +hostList+"->"
				       +distrID);

	    int r = AdminComm.sendDynamicMessage(AdminComm.DELETE_DISTRIBUTOR_CACHE,
						 hostList, 
						 distrID,
						 status.response);

	    status.status = r;
	    return status;

	}

    }


    public static abstract class ActionWorker extends  SwingWorker  {
	public javax.swing.JButton cmdButton = null;
	public String action = null;

	public ActionWorker(javax.swing.JButton btn,String c ) {
	    cmdButton = btn;
	    action = c;
	}
    }

    public static class CSStatusEvent {
	int mode1=-1;
	int mode2=-1;
	Object src = null;
	public CSStatusEvent(int m1, int m2) {
	    mode1=m1;
	    mode2=m2;
	}
	int getDC1Mode() { return mode1; }
	int getDC2Mode() { return mode2; }
    }

    public static class CSStatusListener {
	public void statusUpdated(CSStatusEvent evt) {}
    }


    private static class CSModeThread extends  SwingWorker {
	String serverList = null;
	CSModeThread(String sl) {
	    serverList = sl;
	}

	public Object construct() {
	    try {
		int mode = ConfigComm.modeRequest(serverList,
						  ConfigComm.GET_MODE,0);
		return new Integer(mode);
	    } catch (Exception e) {
		Log.getInstance().log_error("Could not retrieve Config Server mode:"+serverList, e);
	    }
	    return new Integer(-1);
	}
    }


    public static class CSStatusModel 
	implements UpdateModel {

	CSStatusListener listener = null;

	public CSStatusModel(CSStatusListener l)
	{
	    listener = l;
	}

	private void fireStatusEvent(int m1, int m2)
	{
	    if (listener!=null) {
		listener.statusUpdated(new Utils.CSStatusEvent(m1,m2));
	    }

	}


	public void Update()
	    throws Exception {
	    
	    java.util.HashMap map = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);
		
	    String serverList1 = (String)map.get("PHOST1");
	    String serverList2 = (String)map.get("PHOST2");
            StringBuffer hostlist1 = new StringBuffer((String)map.get("HOST1"));
            StringBuffer hostlist2 = new StringBuffer((String)map.get("HOST2"));

            if (serverList1!=null) hostlist1.append(",").append(serverList1);
            if (serverList2!=null) hostlist2.append(",").append(serverList2);
            
            
	    CSModeThread thread1  = new CSModeThread(hostlist1.toString());
	    CSModeThread thread2  = new CSModeThread(hostlist2.toString());
            thread1.start();
            thread2.start();

            int mode1 = ((Integer)thread1.get()).intValue();
            int mode2 = ((Integer)thread2.get()).intValue();

	    fireStatusEvent(mode1, mode2);
	}

    }






        public static class VRTSStatusEvent {
                HashMap stat1=null;
                HashMap stat2=null;
                Object src = null;
                public VRTSStatusEvent(HashMap s1, HashMap s2) {
                        stat1=s1;
                        stat2=s2;
                }
                HashMap getDC1VRTSStatus() { return stat1; }
                HashMap getDC2VRTSStatus() { return stat2; }
        }
        
        public static class VRTSStatusListener {
                public void statusUpdated(VRTSStatusEvent evt) {}
        }
        


        private static class VRTSStatusThread extends  SwingWorker {
                String serverList = null;
                String vrtsGroup = null;
                HashMap statusMap = null;
                
                VRTSStatusThread(String g, String sl) {
                        vrtsGroup = g;
                        serverList = sl;
                }
                
                public Object construct() {
                        statusMap = new HashMap(4);


                        
                        try {

                                String nodes[]
                                        = VRTSCommands.getSystemList(serverList);
                                
                                String group = vrtsGroup;
                                if (group == null)
                                        group= "IDS2GROUP";
                                

                                
                                for (int i = 0; i < nodes.length; i++) {
                                        
                                        String s =
                                                VRTSCommands.getSystemStatus(serverList, nodes[i]);
                                        

                                        
                                        StringBuffer resp = new StringBuffer();
                                        if (s != null)
                                                resp.append(s);
                                        else
                                                resp.append("UNKNOWN");

                                        resp.append(":");
                                        

                                        

                                        s = VRTSCommands.getGroupStatus(serverList, group, nodes[i]);

                                
                                        if (s != null)
                                                resp.append(s);
                                        else
                                                resp.append("UNKNOWN");


                                        
                                        
                                        statusMap.put(nodes[i], resp.toString());
                                        
                                }
                                
                                return statusMap;

                        } catch (Exception e) {
                                Log.getInstance().log_error("Could not retrieve Veritas:"+serverList, e);
                        }
                        return null;
                }
        }

        
        
    public static class VRTSStatusModel 
	implements UpdateModel {

	VRTSStatusListener listener = null;
	boolean skip_updates = false;

	public VRTSStatusModel(VRTSStatusListener l)
	{
	    listener = l;
	}

	private void fireStatusEvent(HashMap s1, HashMap s2)
	{
	    if (listener!=null) {
		listener.statusUpdated(new Utils.VRTSStatusEvent(s1,s2));
	    }

	}




	public void Update()
	    throws Exception {
	    
	    if (skip_updates)
		return;
	    java.util.HashMap map = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);
            String group = (String)map.get("VERITAS_GROUP");
	    String serverList1 = new String((String)map.get("PHOST1"));
	    String serverList2 = new String((String)map.get("PHOST2"));

	    String location1 = new String((String)map.get("LOCATION1"));
	    String location2 = new String((String)map.get("LOCATION2"));

		Boolean b1 =  new Boolean(ConfigComm.getBooleanValue(location1
					+"_"+"DSP_USE_VERITAS_COMMANDS",
					Constants.DSP_USE_VERITAS_COMMANDS));
		Boolean b2 =  new Boolean(ConfigComm.getBooleanValue(location2
					+"_"+"DSP_USE_VERITAS_COMMANDS",
					Constants.DSP_USE_VERITAS_COMMANDS));


	    if (!b1.booleanValue()
			&& !b2.booleanValue() )
			skip_updates = true;

	    VRTSStatusThread thread1  = new VRTSStatusThread(group,serverList1);
	    VRTSStatusThread thread2  = new VRTSStatusThread(group,serverList2);
            thread1.start();
            thread2.start();

            HashMap stat1 = (HashMap)thread1.get();
            HashMap stat2 = (HashMap)thread2.get();

	    stat1.put("DSP_USE_VERITAS_COMMANDS", b1);
	    stat2.put("DSP_USE_VERITAS_COMMANDS", b2);

	    fireStatusEvent(stat1,stat2);
	}

    }



        
    public static  class CSModeWorker extends  SwingWorker  {
	int 	mode;
	String 	hostList;

	public CSModeWorker(String hl, int m ) {
	    mode = m;
	    hostList = hl;
	}

	public Object construct() {
	    Integer rstatus;
	    try {
		int r = ConfigComm.modeRequest(hostList,
					       ConfigComm.SET_MODE,
					       mode);
			
		rstatus = new Integer(r);
	    } catch (Exception e) {
		Log.getInstance().log_error("Error in setting mode: "
					    +hostList+" "+mode, e);
		rstatus =  new Integer(-1);
	    }
	    return rstatus;
	    
	}

    }

 
    public static 
	String getDCMProducts(String dcm, String dc)
	throws java.io.IOException 
    {
	StringBuffer reqbuf = new StringBuffer();
	StringBuffer d = new StringBuffer(dcm);
	d.append(ConfigComm.CONF_FS).append(dc);
	
	ConfigComm.getServKey(reqbuf,ConfigComm.GET_DCM_PRODUCTS,
			      d.toString());
	
	byte b[] =   ConfigComm.configRequest(reqbuf);
	String result = new String(b);
	return  result.substring(result.indexOf(ConfigComm.CONF_STX)+1).trim();

    }

    public static int 
	isLineHandlerRunning(String serverList, String id) 
    {
	
	
	String proglist = "dsp_linehand,dcm_linehand";
	
	java.util.StringTokenizer st;
	
	String datastr = null;
	boolean exc=false;
	byte[] respb;
	String response;
	int index;
	
	
	/* Get list of processes */
	try {
	    respb = AdminComm.serviceRequest(serverList,
					     AdminComm.EXEC_COMMAND,
					     AdminComm.LIST_IDS2_PROC_BY_NAME,
					     proglist);
	    
	    response = new String(respb);
	    
	    index = response.indexOf(ConfigComm.CONF_STX)+1;
	    
	    if (index>0) 
		datastr = response.substring(index);
	    
	} catch (Exception e) {
	    exc=true;
	    Log.getInstance().log_warning(
					  "Error in checking if line handler "
					  +id+ " is running on "
					  +serverList,
					  e);
	}
	

	if (exc || (datastr==null))
	    return -1;


	String separator = new String("\n");
	String fldsep    = new String(" \t");
	
	/* 
	** Parse the response from admin servers 
	*/
	
	boolean found = false;


	/* Parse process list */
	st = new java.util.StringTokenizer(datastr,
					   separator);
	
	while (st.hasMoreTokens()) {
	    String s = st.nextToken();
	    java.util.StringTokenizer st1
		= new java.util.StringTokenizer(s,fldsep);
	    String s1 = st1.nextToken();


	    if (Constants.findPattern(proglist,s1)) {
		int inx = s.indexOf("-d");
		String ss = s.substring(inx+2);
		java.util.StringTokenizer st2 = 
		    new java.util.StringTokenizer(ss,fldsep);
		String n1 = (String)st2.nextToken();
		if (n1.equals(id)) {
		    found=true;
		    break;
		}
	    }	
	}
    
	    
	if (found)
	    return 1;
	
	return 0;
    }






   
    public static  Object 
	getRunningListFromHost(final String host) {

      
	final SwingWorker worker = new SwingWorker() {
	  
	    public Object construct() {
		String distList = null;
	    
		try {
		    
		    if (Constants.DEBUG && Constants.Verbose>2)
			System.out.println("Retrieving status  from: "+host);
		    
		    byte[] respb = AdminComm.serviceRequest(host,
					    AdminComm.EXEC_COMMAND,
					    AdminComm.LIST_IDS2_PROC_BY_KEY,
					    "dsp_linehand,dcm_linehand   -d ");

		    distList = new String(respb);
		    int inx = distList.indexOf(ConfigComm.CONF_STX)+1;
		
		    if (inx <= 0)
			distList = null;
		    else
			distList = distList.substring(inx);
		
		
		} catch (Exception e) {
		    distList = null;
		}
	    
		return distList;
	    }
	  
	    //Runs on the event-dispatching thread.
	    public void finished() {
	      
	    }	
	  
	};  // new SwingWorker */
      
	// Start the thread 
	worker.start();
      
	return worker.get();


    }



    static String
        flipHostOrder(String hostList, String separator)
    {

        java.util.StringTokenizer tok
                = new java.util.StringTokenizer(hostList, separator);

        int count = tok.countTokens();
        java.util.Vector v = new java.util.Vector(count);

        for (int i = 0; i < count; i++)
                v.add(i, tok.nextToken());

        StringBuffer flip = new StringBuffer();

        for (int i = count-1; i >=0 ;  i--) {
                String s = (String)v.get(i);
                flip.append(s);
                if (i > 0)
                        flip.append(",");
        }

        return flip.toString();
    }

	
    static void showDialog(java.awt.Component parent, String msg) 
    {
	javax.swing.JOptionPane.showMessageDialog(parent,
				msg, "Message",
				javax.swing.JOptionPane.WARNING_MESSAGE);
    }

	
    static int showConfirmDialog(java.awt.Component parent, String msg) 
    {
	return javax.swing.JOptionPane.showConfirmDialog(parent,
				msg, "Message",
				javax.swing.JOptionPane.YES_NO_OPTION,
				javax.swing.JOptionPane.QUESTION_MESSAGE);
    }



    public static boolean
    	isValidRetransFormat(String format)
    {
	if (!Constants.findPattern(Constants.GLB_RETRANS_FORMAT_LIST,format))
		    return false;
	
	return true;
    }


    public static boolean
    	isHistoricalRetransSupported(String product)
    throws Exception
    {

	ProductTableModel pModel
	    = new ProductTableModel();
	int numProds = pModel.getRowCount();
	for (int np = 0; np < numProds; np++) {
	    String prod = (String)pModel.getValueAt(np,0);
	    if (prod.equals(product)) {
		Boolean history = (Boolean)pModel.getValueAt(np,3);
		return history.booleanValue();
	    }
	}

	return false;


    }


    public static class LoadX25Links 
    extends SwingWorker 
    {

	String hostList = null;
	javax.swing.JComboBox comboBox1 = null;
	javax.swing.JComboBox comboBox2 = null;
	String defaultLink = null;

	String linkList = "Error";
	Exception exc = null;

	private String X25LINK_LIST_COMMAND =
	"( /opt/SUNWconn/bin/x25info | fgrep Link | awk '{ printf(\"%d\\n\", int($2)) }')";

	public LoadX25Links(String hl)
	{
		hostList = new String(hl);
	}


	public LoadX25Links(String hl, 
		javax.swing.JComboBox cb)
	{
		comboBox1 = cb;
		hostList = new String(hl);
	}

	public LoadX25Links(String hl, 
		javax.swing.JComboBox cb1,
		javax.swing.JComboBox cb2)
	{
		comboBox1 = cb1;
		comboBox2 = cb2;
		hostList = new String(hl);
	}

	public LoadX25Links(String hl, 
			    javax.swing.JComboBox cb1,
			    javax.swing.JComboBox cb2,
			    String defLink)
	{
		comboBox1 = cb1;
		comboBox2 = cb2;
		hostList = new String(hl);
		if (defLink!=null) defaultLink = new String(defLink);

	}
	
	private void setupCombo(javax.swing.JComboBox cb)
	{
		cb.setEnabled(false);
		cb.removeAllItems();
		cb.addItem("Loading..");
	}

	public Object construct() 
	{
		if (comboBox1!=null) setupCombo(comboBox1);
		if (comboBox2!=null) setupCombo(comboBox2);

		try {
		    	byte b[] = AdminComm.serviceRequest(hostList,
					    AdminComm.EXEC_COMMAND,
					    AdminComm.RUN_COMMAND,
					    X25LINK_LIST_COMMAND);
    			String l = new String(b);
			int inx = l.indexOf(ConfigComm.CONF_STX)+1;

			Utils.RequestHeader hdr = new Utils.RequestHeader(l);
			//hdr.debugPrint();

			if ((hdr.error_number == 0)
			    && (inx > 0) ) {
			    linkList = l.substring(inx).trim();
			} else {
			    linkList = "Error";
			    Log.getInstance().log_error("Error in retrieving "
				     +"list of X.25 links from host: "
				     +hostList+" ("+hdr.error_number+").", 
							null);
			}

    		} catch (Exception e){
    			linkList = "Error";
			exc = e;
		}

		return linkList;
	}

	public void finished() 
	{

		if ((comboBox1==null) && (comboBox2==null) ) return;
		if (comboBox1!=null) comboBox1.removeAllItems();
		if (comboBox2!=null) comboBox2.removeAllItems();

		boolean defaultLinkFound = false;
		if ( (exc==null) && !linkList.equals("Error")) {
		    java.util.StringTokenizer tok
			= new java.util.StringTokenizer(linkList,"\n");
		    int numLinks = tok.countTokens();

		    
		    for (int i = 0; i < numLinks; i++) {
			String lnk = tok.nextToken();
			if (comboBox1!=null) comboBox1.addItem(lnk);
			if (comboBox2!=null) comboBox2.addItem(lnk);
			if ( (defaultLink!=null)
			     && defaultLink.equals(lnk))
			    defaultLinkFound = true;
		    }
		}

		if (defaultLinkFound) {
		    if (comboBox1!=null) comboBox1.setSelectedItem(defaultLink);
		    if (comboBox2!=null) comboBox2.setSelectedItem(defaultLink);
		} else if (defaultLink != null) {
		    if (comboBox1!=null) {
			comboBox1.addItem(defaultLink);
			comboBox1.setSelectedItem(defaultLink);
		    }
		    if (comboBox2!=null) {
			comboBox2.addItem(defaultLink);
			comboBox2.setSelectedItem(defaultLink);
		    }
		} else {
		    if (comboBox1!=null) {
			String str = "Select";
			if (comboBox1.getItemCount()==0)
			    str = "Enter";
			comboBox1.addItem(str);
			comboBox1.setSelectedItem(str);
		    }
		    if (comboBox2!=null) {
			String str = "Select";
			if (comboBox2.getItemCount()==0)
			    str = "Enter";
			comboBox2.addItem(str);
			comboBox2.setSelectedItem(str);
		    }
		}

		if (comboBox1!=null) comboBox1.setEnabled(true);
		if (comboBox2!=null) comboBox2.setEnabled(true);

	} // finished

    } // End of class LoadX25Links





    public static class RequestHeader {
	
	char sep[] = { ConfigComm.CONF_STX, ConfigComm.CONF_FS, ConfigComm.CONF_SOH };

	private RequestHeader(){}
	
	public RequestHeader(String response)
	throws java.io.IOException
	{
	    int inx = response.indexOf(ConfigComm.CONF_STX);
	    if (inx < 0) {
		throw new java.io.IOException("Cannot parse response from server");
	    }

	    String hdr = response.substring(0,inx);
	    
	    java.util.StringTokenizer tok 
		= new java.util.StringTokenizer(hdr, new String(sep));

	    if (tok.countTokens() < Constants.NUM_HEADER_FIELDS ) {
		throw new java.io.IOException("Incomplete header: Fields expected"
				    +(Constants.NUM_HEADER_FIELDS+2)
				    +". Got "+tok.countTokens());
	    }

	    if (tok.hasMoreTokens()) length = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) checksum = Long.parseLong(tok.nextToken());
	    if (tok.hasMoreTokens()) message_type = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) request_type = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) source = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) host = tok.nextToken();
	    if (tok.hasMoreTokens()) user = tok.nextToken();
	    if (tok.hasMoreTokens()) more_packets = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) error_number = Integer.parseInt(tok.nextToken());
	    if (tok.hasMoreTokens()) log_port = Integer.parseInt(tok.nextToken());
	}

	public void debugPrint()
	{
	    System.out.println("=========================");
	    System.out.println("Length: "+length);
	    System.out.println("Checksum: "+checksum);
	    System.out.println("Message Type: "+message_type);
	    System.out.println("Request Type: "+request_type);
	    System.out.println("Source: "+source);
	    System.out.println("Host: "+host);
	    System.out.println("User: "+user);
	    System.out.println("More packets?: "+more_packets);
	    System.out.println("Error Number: "+error_number);
	    System.out.println("Log Port: "+log_port);
	    System.out.println("=========================");

	}


	public int length;
	public long checksum;
	public int message_type;
	public int request_type;
	public int source;
	public String host;
	public String user;
	public int more_packets;
	public int error_number;
	public int log_port;

    } // End of class RequestHeader



    public static class LoadX25ConfigFile 
    extends SwingWorker 
    {

	String hostList = null;
	String linkFile = null;
	String linkConfig = "Error";
	Exception exc = null;

	public LoadX25ConfigFile(String hl, String filename)
	{
		hostList = new String(hl);
		if (filename!= null)
		    linkFile = new String(filename);
	}


	public Object construct() 
	{
	    
	    try {


		byte b[];

		if (linkFile != null) {
		    b = AdminComm.serviceRequest(hostList,
						 AdminComm.EXEC_COMMAND,
						 AdminComm.RETRIEVE_X25_CONFIGURATION_FILE,
						 linkFile);
		} else {
		    b = AdminComm.serviceRequest(hostList,
						 AdminComm.EXEC_COMMAND,
						 AdminComm.RETRIEVE_DEFAULT_X25_CONFIGURATION_FILE,
						 " ");


		}
		String l = new String(b);
		int inx = l.indexOf(ConfigComm.CONF_STX)+1;

		Utils.RequestHeader hdr = new Utils.RequestHeader(l);
		//hdr.debugPrint();

		if ((hdr.error_number == 0)
		    && (inx > 0) ) {
		    linkConfig = l.substring(inx);
		} else if (hdr.error_number == Constants.FILE_NOT_FOUND) {
		    linkConfig = null;
		} else {
		    if (linkFile != null)
			Log.getInstance().log_error("Error in retrieving "
			   +"X.25 configuration file "+linkFile
			   +" from host: "+hostList+" ("
			   +hdr.error_number+").", null);
		    else
			Log.getInstance().log_error("Error in retrieving "
			   +" default X.25 configuration file "
			   +" from host: "+hostList+" ("
			   +hdr.error_number+").", null);
		}
		
	    } catch (Exception e){
		exc = e;
		if (linkFile!= null) 
		    Log.getInstance().log_error("Error in loading "+linkFile
					    +" from "+hostList, e);
		else
		    Log.getInstance().log_error("Error in loading "
					    +" default X.25 configuration "
					    +"file from "+hostList, e);
	    }
	    
	    return linkConfig;
	}

	public Exception getException() { return exc; }

    } // End of class LoadX25ConfigFile





    public static class SaveX25ConfigFile 
    extends SwingWorker 
    {

	String hostList = null;
	String linkFile = null;
	StringBuffer linkConfig = null;
	Exception exc = null;
	SwingWorker controller = null;

	public SaveX25ConfigFile(String hl, 
				 String filename, 
				 String lc,
				 SwingWorker cont)
	{
	    controller = cont;

	    hostList = new String(hl);
	    linkFile = new String(filename);

	    linkConfig = new StringBuffer(filename);
	    linkConfig.append(ConfigComm.CONF_STX)
		.append(lc)
		.append(ConfigComm.CONF_ETX);
	}


	public Object construct() 
	{
	    if (controller!=null) controller.construct();

	    try {
		byte b[] = AdminComm.serviceRequest(hostList,
				 AdminComm.EXEC_COMMAND,
				 AdminComm.INSTALL_X25_CONFIGURATION_FILE,
				 linkConfig.toString());


		String l = new String(b);
		int inx = l.indexOf(ConfigComm.CONF_STX)+1;

		Utils.RequestHeader hdr = new Utils.RequestHeader(l);
		//hdr.debugPrint();

		if (hdr.error_number != 0) {
		    String errstr = " ";
		    if (inx > 0)
			errstr = l.substring(inx);

		    Log.getInstance().log_error("Error in saving X.25 "
			   +"configuration file "+linkFile
			   +" on host: "+hostList+" ("
			   +hdr.error_number+").\n\t"+errstr, null);

		    exc = new java.io.IOException(errstr);
		}
		
	    } catch (Exception e){
		exc = e;
		Log.getInstance().log_error("Error in saving "+linkFile
					    +" on "+hostList, e);
	    }
	    
	    return exc;
	}

	public void finished() 
	{
	    if (controller!=null) controller.finished();
	}

	public Exception getException() { return exc; }

    } // End of class SaveX25ConfigFile





    public static class x25ConfigParams {
	public x25ConfigParams() {}
	public x25ConfigParams(String mod, String dev, String range, 
			       String descr, String ifc, String ps,
			       String ws, String nl)
	{
	    modifiedBy=mod;
	    device=dev;
	    pvcRange=range;
	    description=descr;
	    iface=ifc;
	    packetSize=ps;
	    windowSize=ws;
	    nsduLength=nl;
	}

	public void debugPrint()
	{
	    System.out.println("=========================");
	    System.out.println("MODIFIED_BY: "+modifiedBy);
	    System.out.println("device: "+device);
	    System.out.println("mode: "+iface);
	    System.out.println("description: "+description);
	    System.out.println("pvc_range: "+pvcRange);
	    System.out.println("packetSize: "+packetSize);
	    System.out.println("windowSize: "+windowSize);
	    System.out.println("nsduLength: "+nsduLength);
	    System.out.println("=========================");

	}

	    
	public String modifiedBy;
	public String device;
	public String pvcRange;
	public String description;
	public String iface;
	public String packetSize;
	public String windowSize;
	public String nsduLength;

    } // End of class x25ConfigParams







    public static String applyX25Configuration(String origConfig,
					       x25ConfigParams params)
    throws NumberFormatException, java.io.IOException					       
    {

	//params.debugPrint();

	java.io.BufferedReader reader 
	    = new java.io.BufferedReader(new java.io.StringReader(origConfig));

	java.io.StringWriter writer = new java.io.StringWriter();
	String line=null;
	int    inx=-1;


	int packet_size = Integer.parseInt(params.packetSize);
	int psz = packet_size;
	int pktsz = 0;
	while ((psz >>= 1) > 0) 
	    pktsz++;


	while ((line = reader.readLine()) != null) {
	    
	    if ((inx = line.indexOf("\tMODIFIED_BY\t")) >= 0) {
		writer.write("\tMODIFIED_BY"+"\t"+params.modifiedBy+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tdevice\t")) >= 0) {
		writer.write("\tdevice"+"\t\t"+params.device+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tmode\t")) >= 0) {
		writer.write("\tmode"+"\t\t"+params.iface+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tdescription\t")) >= 0) {
		writer.write("\tdescription"+"\t"+params.description+"\n");
		continue;
	    }
	    if ((params.pvcRange!=null) 
		&& (inx = line.indexOf("\tpvc_range\t")) >= 0) {
		writer.write("\tpvc_range"+"\t\t"+params.pvcRange+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tlocmaxwinsize\t")) >= 0) {
		writer.write("\tlocmaxwinsize"+"\t\t"+params.windowSize+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tlocdefwinsize\t")) >= 0) {
		writer.write("\tlocdefwinsize"+"\t\t"+params.windowSize+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tremmaxwinsize\t")) >= 0) {
		writer.write("\tremmaxwinsize"+"\t\t"+params.windowSize+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tremdefwinsize\t")) >= 0) {
		writer.write("\tremdefwinsize"+"\t\t"+params.windowSize+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tmax_iframe_len\t")) >= 0) {
		int miflen = (packet_size<=256)?261:packet_size+5;
		writer.write("\tmax_iframe_len"+"\t\t"+miflen+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tmax_frame\t")) >= 0) {
		int mframe = (packet_size<=256)?262:packet_size+6;
		writer.write("\tmax_frame"+"\t\t"+mframe+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tlocmaxpktsize\t")) >= 0) {
		writer.write("\tlocmaxpktsize"+"\t\t"+pktsz+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tlocdefpktsize\t")) >= 0) {
		writer.write("\tlocdefpktsize"+"\t\t"+pktsz+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tremmaxpktsize\t")) >= 0) {
		writer.write("\tremmaxpktsize"+"\t\t"+pktsz+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tremdefpktsize\t")) >= 0) {
		writer.write("\tremdefpktsize"+"\t\t"+pktsz+"\n");
		continue;
	    }
	    if ((inx = line.indexOf("\tmaxnsdulength\t")) >= 0) {
		writer.write("\tmaxnsdulength"+"\t\t"+params.nsduLength+"\n");
		continue;
	    }

	    writer.write(line+"\n");

	} // while line = reader.readLine()


	/*
	*************************
	try {
	    java.io.FileWriter w 
		= new java.io.FileWriter("/tmp/x25config.new");
	    w.write(writer.toString());
	    w.flush();
	    w.close();
	    w = new java.io.FileWriter("/tmp/x25config.old");
	    w.write(origConfig);
	    w.flush();
	    w.close();

	} catch (Exception e) {
	    e.printStackTrace();
	}
	
	*************************
	*/
	return writer.toString();

    } // End of applyX25Configuration() 




    
    public static x25ConfigParams 
	parseX25Configuration(String origConfig)
    throws Exception					       
    {
	java.io.BufferedReader reader 
	    = new java.io.BufferedReader(new java.io.StringReader(origConfig));

	java.io.StringWriter writer = new java.io.StringWriter();
	String line=null;
	int    inx=-1;

	Utils.x25ConfigParams params = new Utils.x25ConfigParams();


	while ((line = reader.readLine()) != null) {
	    
	    if ((inx = line.indexOf("\tMODIFIED_BY\t")) >= 0) {
		params.modifiedBy = line.substring(inx+13).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tdevice\t")) >= 0) {
		params.device = line.substring(inx+8).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tmode\t")) >= 0) {
		params.iface = line.substring(inx+6).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tdescription\t")) >= 0) {
		params.description = line.substring(inx+13).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tpvc_range\t")) >= 0) {
		params.pvcRange = line.substring(inx+11).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tlocmaxwinsize\t")) >= 0) {
		params.windowSize = line.substring(inx+15).trim();
		continue;
	    }
	    if ((inx = line.indexOf("\tlocmaxpktsize\t")) >= 0) {
		String packetSize = line.substring(inx+15).trim();
		int n = Integer.parseInt(packetSize);
		params.packetSize = Integer.toString((int)java.lang.Math.pow((double)2,(double)n));
		continue;
	    }
	    if ((inx = line.indexOf("\tmaxnsdulength\t")) >= 0) {
		params.nsduLength = line.substring(inx+15).trim();
		continue;
	    }

	} // while line = reader.readLine()

	//params.debugPrint();

	return params;

    } // End of parseX25Configuration()




    public static class X25AddrInfo {
	public String type;
	public String link;
	public String dte;
	
	public X25AddrInfo(String t, String l, String d)
	{
	    type = t;
	    link = l;
	    dte = d;
	}
	
    } // End of class X25AddrInfo



    public static X25AddrInfo parseX25Field(String  transport) 
    {

	java.util.StringTokenizer st
	    = new java.util.StringTokenizer(transport," ");

	String typeStr, addrStr;


	if (st.hasMoreTokens())
	    typeStr = st.nextToken();
	else {
	    Log.getInstance().log_error("Error in parsing X25 field: "
					+transport, null);
	    return null;
	}

	if (st.hasMoreTokens())
	    addrStr = st.nextToken();
	else {
	    Log.getInstance().log_error("Error in parsing X25 field: "
					+transport+" ("+typeStr+")", null);
	    return null;
	}

	if (typeStr.startsWith("SVC")) {

	    int inx = addrStr.indexOf(Constants.SVC_SEPARATOR);
	    /* 
	    ** For compatibility with previous config
	    ** where ':' was used as separator for X.25 address
	    */
	    if (inx < 0) 
		inx = addrStr.indexOf(':');

	    if (inx < 0) {
		Log.getInstance().log_error("Can't parse SVC address: "
					    +transport+" ("+typeStr+")"
					    +" : "+addrStr, null);
		return null;
	    }
	    
	    String link = addrStr.substring(0,inx);
	    String dte = addrStr.substring(inx+1);

	    return new X25AddrInfo(typeStr, link, dte);
      
	} else if (typeStr.startsWith("PVC")) {
	    return new X25AddrInfo(typeStr, addrStr, null);
	} 
	
	return null;

    } // End of parseX25Field()






    public static boolean isX25TransportType(String transport)
    {

	if ((transport==null)
	    || (transport.trim().length()==0))
	    return false;

	if ( (transport.indexOf("PVC") >= 0)
	     || (transport.indexOf("SVC") >= 0))
	    return true;

	return false;

    } // End of isX25TransportType()




    public static boolean isX25DCM(String type)
    {
	
	if ((type==null)
	    || (type.trim().length()==0))
	    return false;
	
	if ( (type.indexOf("X25") >= 0)
	     || (type.indexOf("X.25") >= 0))
	    return true;
	
	return false;

    } // End of isX25DCM()


    public static boolean isDJNEWS_DCM(String type)
    {
	
	if ((type==null)
	    || (type.trim().length()==0))
	    return false;
	
	if (type.indexOf("DJN") >= 0)
	    return true;
	
	return false;

    } // End of isDJNEWS_DCM()


    public static java.util.Vector removeX25Types(java.util.Vector fullList)
    {

	if (fullList==null) return null;

	java.util.Vector v = new java.util.Vector(10);

	for (int i=0; i < fullList.size(); i++) {
	    String t = (String)fullList.get(i);
	    if (!isX25TransportType(t)) 
		v.add(t);
	}

	return v;

    } // End of removeX25Types()



    public static  String getShortNameFromHostList(String hlist)
    {
	java.util.StringTokenizer tok
	    = new java.util.StringTokenizer(hlist,", \t");
					    
	String name = null;
	int count = tok.countTokens();

	if (count == 0) return null;

	name = tok.nextToken();

	for (int i = 1; i < count; i++) {
	    String s = tok.nextToken();
	    if (s.length() < name.length())
		name = s;
	}


	return name;

    } // End of getShortNameFromHostList()



    public static class ServiceWorker 
	extends SwingWorker 
    {
	Object[] data = new Object[2];
	String serverList, progList;
	int type = AdminComm.LIST_IDS2_PROC_BY_NAME;

	ServiceWorker(String srvrlist, String proglist) 
	{
	    serverList = srvrlist;
	    progList   = proglist;
	    data[0] = data[1] = null;
	}

	ServiceWorker(String srvrlist, String proglist, int t) 
	{
	    serverList = srvrlist;
	    progList   = proglist;
	    type = t;
	    data[0] = data[1] = null;
	}


	public Object construct() 
	{
	    
	    try {
		String response;
		int index;
		
		byte[] respb = AdminComm.serviceRequest(serverList,
							AdminComm.EXEC_COMMAND,
							type,
							progList);
		
		response = new String(respb);
		
		index = response.indexOf(ConfigComm.CONF_STX)+1;
		
		if (index>0) 
		    data[0] =  response.substring(index);
		
	    } catch (Exception e) {
		Log.getInstance().log_error("Error in retrieving process "
					    +"list from: "+serverList,e);
		data[1] = e;
	    }
	    return data;
	} // End of construct

    } // End of class ServiceWorker


    public static boolean parseBooleanString(String s)
    {
	if ( s.equalsIgnoreCase(Boolean.TRUE.toString())
	     ||s.equalsIgnoreCase("yes")
	     || s.equalsIgnoreCase("true")
	     || s.equalsIgnoreCase("y"))
	    return true;
	
	return false;

    }

    public static boolean
	isValidProductFormat(String product, boolean isContainer, String format)
    {
	boolean isContainerFormat = 
	    format.equals(Constants.GLB_CONTAINER_CONVERSION_FORMAT);

	if (isContainer) {
	    return isContainerFormat;
	} else {
	    return !isContainerFormat;
	}
    }


    public static StringBuffer replaceAll(StringBuffer sb, String from, String to)
    {

	int start, index;
	int len = from.length();
	int length = sb.length();

	index = 0;

	for (;;) {

		String s = sb.substring(index, length);
		start = s.indexOf(from);

		if (start < 0)
			break;

		start += index;


		sb.replace(start,start+len,to);


		index = start+len;
		length = sb.length();

		if (index + len >= length)
			break;
	}

	return sb;

    }



    public static java.util.HashMap getHashMap(String filename)
	throws java.io.IOException, DBException, DBModeException
    {

	char	 COMMENT = '#';

	char b[] = {ConfigComm.CONF_GS };

	java.io.LineNumberReader fileReader
		= new java.io.LineNumberReader(new java.io.FileReader(filename));


	String line = null;

	java.util.HashMap map = new java.util.HashMap(10);

	String conf_gs = new String(b);

	while ( (line = fileReader.readLine()) != null) {

		if (  (line.trim().length()==0) 
			|| (line.charAt(0) == COMMENT) )
			continue;

		int index = line.indexOf("\t");

		if (index > 0) {

			String key = line.substring(0,index).trim();
			String value = line.substring(index+1);

			StringBuffer sb  = replaceAll(new StringBuffer(value),
						"<CONF_GS>", conf_gs);
				
			if (key.length() > 0)
				map.put(key.trim(),sb.toString());
		}

	}

	return map;
    }



    public static java.util.HashMap getHashMap(java.io.InputStream urlStream)
	throws java.io.IOException, DBException, DBModeException
    {

	char	 COMMENT = '#';

	char b[] = {ConfigComm.CONF_GS };

	java.io.LineNumberReader fileReader
		= new java.io.LineNumberReader(
			new java.io.InputStreamReader(urlStream));


	String line = null;

	java.util.HashMap map = new java.util.HashMap(10);

	String conf_gs = new String(b);

	while ( (line = fileReader.readLine()) != null) {

		if (  (line.trim().length()==0) 
			|| (line.charAt(0) == COMMENT) )
			continue;

		int index = line.indexOf("\t");

		if (index > 0) {

			String key = line.substring(0,index).trim();
			String value = line.substring(index+1);

			StringBuffer sb  = replaceAll(new StringBuffer(value),
						"<CONF_GS>", conf_gs);
				
			if (key.length() > 0)
				map.put(key.trim(),sb.toString());
		}

	}

	return map;
    }


        public static void
        loadLocationList(javax.swing.JComboBox locationComboBox,
                          String [] moreOptions,
                          String defaultOption) 
        {
                java.util.Vector locationList = ConfigComm.getLocationList();


                loadLocationList(locationComboBox, locationList,
                                 moreOptions, defaultOption);

                
        }

        public static void
        loadDCMLocationList(javax.swing.JComboBox locationComboBox,
                            java.util.List dcm_list) 
        {
                java.util.Vector locationList = null;

                
                if (dcm_list!=null)
                        locationList = getDCMLocations(dcm_list);


                
                String [] moreOptions = new String[3];

                moreOptions[0] = Constants.PICK_LOCATION;
                moreOptions[1] = Constants.HOME_LOCATION;
                moreOptions[2] = Constants.AWAY_LOCATION;
                
                loadLocationList(locationComboBox, locationList,
                                 moreOptions, moreOptions[0]);


        }

        public static void
        loadDCMLocationList(javax.swing.JComboBox locationComboBox,
                            java.util.List dcm_list,
                            String[] moreOptions, String defaultOption) 
        {
                java.util.Vector locationList = null;

                
                if (dcm_list!=null)
                        locationList = getDCMLocations(dcm_list);


                loadLocationList(locationComboBox, locationList,
                                 moreOptions, defaultOption);

        }
        
        public static void
        loadLocationList(javax.swing.JComboBox locationComboBox,
                         java.util.Vector locationList,
                         String [] moreOptions,
                         String defaultOption )
        {


                String selection =
                        (String)locationComboBox.getSelectedItem();
                
                        
                
                javax.swing.DefaultComboBoxModel cm = null;
                if (locationList != null) {
                        java.util.Vector v = (java.util.Vector)locationList.clone();
                        java.util.Collections.sort(v);
                        cm = new javax.swing.DefaultComboBoxModel(v);
                 } else
                        cm = new javax.swing.DefaultComboBoxModel();



                
                if (moreOptions!=null) 
                        for (int i = 0; i < moreOptions.length; i++) 
                                cm.insertElementAt(moreOptions[i], i);

                boolean changed = false;
                
                int n1 = locationComboBox.getItemCount();
                int n2 = cm.getSize();
                if (n1 == n2) {
                        for  (int i=0; i < n1; i++) 
                        {
                                Object o = locationComboBox.getItemAt(i);
                                if (cm.getIndexOf(o)<0) {
                                        changed = true;
                                        break;
                                }
                        }
                }
                else
                        changed = true;
                
                
                
                if (!changed) 
                        return;
                
                
                
                locationComboBox.setModel(cm);

                
                if ( (selection != null)
                     && (cm.getIndexOf(selection) >= 0) )
                       locationComboBox.setSelectedItem(selection);
                else if (defaultOption != null)
                        locationComboBox.setSelectedItem(defaultOption);


        }
        

        public static void
        loadLocationList(javax.swing.JComboBox locationComboBox) 
        {
                String [] moreOptions = new String[3];

                moreOptions[0] = Constants.PICK_LOCATION;
                moreOptions[1] = Constants.HOME_LOCATION;
                moreOptions[2] = Constants.AWAY_LOCATION;
                
                loadLocationList(locationComboBox, moreOptions,
                                  moreOptions[0]);

        }
        
        
                              
        public static java.util.Vector
        getDCMLocations(java.util.List dcm_list) 
        {
                StringBuffer key =
                        new StringBuffer(Constants.GLB_TAG_DCM_PREFIX);
                int l = key.length();
                java.util.HashSet location_set = new java.util.HashSet();


                
                java.util.ListIterator iter = dcm_list.listIterator();

                
                while (iter.hasNext()) {
                        String dcm = (String) iter.next();

                        if ((dcm==null) || (dcm.length()==0))
                                continue;
                        
                        key.setLength(l);
                        key.append(dcm);
                        
                        
                        try {
                                
                                java.util.HashMap dcm_map =
                                        ConfigComm.getHashMap(key.toString());
                        
                                String location1
                                        = (String)dcm_map.get(Constants.LOCATION1);

                                String location2
                                        = (String)dcm_map.get(Constants.LOCATION2);
                                
                                if ( (location1 != null)
                                     && (location2 != null) )
                                {
                                        location_set.add(location1);
                                        location_set.add(location2);
                                }
                        }
                        catch (Exception e) {
                                Log.getInstance().log_error("getLocations: Exception"+dcm,e);
                        }
                        
                }


                return new java.util.Vector(location_set);
        }


            
        
        

} /***** End of Class Utils *****/

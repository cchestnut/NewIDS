/*
**  SCCS Info :  "@(#)TemplateListModel.java	1.4    01/07/10"
*/
/*
 * TemplateListModel.java
 *
 * Created on March 23, 2000, 10:49 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

public class TemplateListModel extends javax.swing.DefaultListModel {
    //java.util.ArrayList list;
    
    public TemplateListModel(java.awt.Container frame) {
	try { 
	    FilterCodesDataModel model = 
				new FilterCodesDataModel();
	    model.Update();
	    int nrows = model.getRowCount();
		java.util.Vector v = new java.util.Vector(nrows+1);
	    
	    v.add(Constants.FILTER_CODES_NONE);
	    for (int i = 0; i < nrows; i++) 
			v.add((String)model.getValueAt(i,0));

		java.util.Collections.sort(v);

	    for (int i = 0; i < v.size(); i++) 
			addElement(v.get(i));


	} catch (Exception e) {
	    javax.swing.JOptionPane.showMessageDialog(frame,
		      "Error in retrieving Template list ", 
		      "Error", 
		      javax.swing.JOptionPane.ERROR_MESSAGE);
	}
	
    }
}

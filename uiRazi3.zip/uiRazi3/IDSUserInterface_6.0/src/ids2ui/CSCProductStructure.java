/*
**  SCCS Info :  "@(#)CSCProductStructure.java	1.1    02/05/30"
*/
package ids2ui;



public class CSCProductStructure {

	public CSCProductStructure(String id, int t, int l,
				boolean h,
				String hst_key,
				boolean iscont, String cont)
	{
	    ID=id;
	    type = t;
	    lcn = l;
	    history = h;
	    rtp_src_key = hst_key;
	    is_container = iscont;
	    container = cont;
	    
	}
	
	public String ID;
	public int   type;
	public int   lcn;
	public boolean history;
	public String rtp_src_key;
	public boolean is_container;
	public String container;

	public CSCProductStructure() {}
	
}

/*
**  SCCS Info :  "@(#)ProductTableModel.java	1.3    01/05/05"
*/
/*
 * ProductConfigScreen.java
 *
 * Created on February 11, 2000, 10:26 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */  
  public class ProductTableModel 
	extends javax.swing.table.AbstractTableModel 
  {
      final String[] columnNames = {"Product", 
                                      "LCN",
                                      "Type",
                                      "History"};
      

  	  protected int     m_sortCol = 0;
  	  protected boolean m_sortAsc = true;
  	  protected java.util.Vector m_vector = null;
  	  protected int m_columnsCount = columnNames.length;


      
      public ProductTableModel() throws Exception {
 
		m_vector = new java.util.Vector(50);
 
          
          /*try {*/
            StringBuffer reqbuf = new StringBuffer();
            String inbuf, datastr;
            byte [] b;
            
            
            ConfigComm.getKey(reqbuf,Constants.GLB_PRODUCT_LIST);
            b = ConfigComm.configRequest(reqbuf);
            inbuf = new String(b);
            int index = inbuf.indexOf(ConfigComm.CONF_STX)+1;
            datastr = inbuf.substring(index);
            java.util.StringTokenizer prodToken, fieldToken;
            StringBuffer prodSeparator = new StringBuffer();
            StringBuffer fieldSeparator = new StringBuffer();

            prodSeparator.append(ConfigComm.CONF_STX).
                append(ConfigComm.CONF_GS);
            fieldSeparator.append(ConfigComm.CONF_US).
                append(ConfigComm.CONF_ETX);
            
            prodToken = new 
              java.util.StringTokenizer(datastr,prodSeparator.toString());
            while (prodToken.hasMoreTokens()){
            	Object [] rowData = new Object[m_columnsCount];
              
              String fstr = prodToken.nextToken();
              fieldToken = new 
                    java.util.StringTokenizer(fstr,fieldSeparator.toString());
              rowData[0] = fieldToken.nextToken();
              rowData[1] = new Integer(Integer.parseInt(fieldToken.nextToken()));
              rowData[2] = new Integer(Integer.parseInt(fieldToken.nextToken()));
              
              String nstr = fieldToken.nextToken();
              
              if (nstr.equalsIgnoreCase("Y") || nstr.equalsIgnoreCase("true"))
                rowData[3] = new Boolean(true);
              else
                rowData[3] = new Boolean(false);
              
               m_vector.add(rowData);
            }
            
		    java.util.Collections.sort(m_vector, new
                ProductComparator(m_sortCol, m_sortAsc));

   			fireTableDataChanged();

            
          /*} catch (Exception e) {
            exitForm(null);
          }*/
            
          
      }



	public void addRow(Object[] o) {
		m_vector.add(o);
		java.util.Collections.sort(m_vector, new
                ProductComparator(m_sortCol, m_sortAsc));

   		fireTableDataChanged();
	}

	public void removeRow(int row) {
		m_vector.removeElementAt(row);
   		fireTableRowsDeleted(row,row);
	}


	public void setValueAt(Object o, int r, int c) {
		Object rowData[] = (Object[])m_vector.get(r);
		rowData[c] = o;
		java.util.Collections.sort(m_vector, new
                ProductComparator(m_sortCol, m_sortAsc));

   		fireTableDataChanged();

	}

	public boolean isCellEditable(int row, int column) {
		return false;
	}

      public Class getColumnClass(int c) {
            return getValueAt(0, c).getClass();
      }
 
    
    
	public int getRowCount() {
		return m_vector==null ? 0 : m_vector.size();
	}

	public int getColumnCount() { 
		return m_columnsCount;
	}


	public String getColumnName(int column) {
      	String str = columnNames[column];
		if (column==m_sortCol)
			str += m_sortAsc ? " \273" : " \253";
		return str;
	}
 

  public Object getValueAt(int nRow, int nCol) {
    if (nRow < 0 || nRow>=getRowCount())
      return "";

	return ((Object[])m_vector.get(nRow))[nCol];
  }




  class ColumnListener extends java.awt.event.MouseAdapter
  {
    protected javax.swing.JTable m_table;

    public ColumnListener(javax.swing.JTable table) {
      m_table = table;
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
      javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
      int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
      int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

      if (modelIndex < 0)
        return;
      if (m_sortCol==modelIndex)
        m_sortAsc = !m_sortAsc;
      else
        m_sortCol = modelIndex;

      for (int i=0; i < m_columnsCount; i++) {
        javax.swing.table.TableColumn column = colModel.getColumn(i);
        column.setHeaderValue(getColumnName(column.getModelIndex()));    
      }
      m_table.getTableHeader().repaint();  

      java.util.Collections.sort(m_vector, new 
        ProductComparator(modelIndex, m_sortAsc));
      m_table.tableChanged(
        new javax.swing.event.TableModelEvent(ProductTableModel.this)); 
      m_table.repaint();  
    }
  }


class ProductComparator implements java.util.Comparator
{
  protected int     m_sortCol;
  protected boolean m_sortAsc;

  public ProductComparator(int sortCol, boolean sortAsc) {
    m_sortCol = sortCol;
    m_sortAsc = sortAsc;
  }

  public int compare(Object o1, Object o2) {
    //if(!(o1 instanceof java.util.Vector) || !(o2 instanceof java.util.Vector))
      //return 0;
    Object[] v1 = (Object[])o1;
    Object[] v2 = (Object[])o2;

    int result = 0;

    switch (m_sortCol) {
      case 0:    // product
		String s1, s2;
		s1 =  (String)v1[m_sortCol];
		s2 =  (String)v2[m_sortCol];
        result = s1.compareTo(s2);
        break;
      case 1:    // lcn
      case 2:    // type
		try {
			Integer i1,i2;
    		double d1, d2;
			i1 =  (Integer)v1[m_sortCol];
			i2 =  (Integer)v2[m_sortCol];
        	d1 = i1.intValue();
        	d2 = i2.intValue();
        	result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
		} catch (NumberFormatException nfe){}
        break;
      case 3:    // History (boolean)
		Boolean b1, b2;
		b1 =  (Boolean)v1[m_sortCol];
		b2 =  (Boolean)v2[m_sortCol];
        result = b1.toString().compareTo(b2.toString());
        break;
    }

    if (!m_sortAsc)
      result = -result;
    return result;
  }

  public boolean equals(Object obj) {
    return false;
  }
}
  }

/*
**  SCCS Info :  "@(#)TFDocument.java	1.1    00/11/16"
*/
/*
 * TFDocument.java
 *
 * Created on July 7, 2000, 5:12 PM
 */
 
package ids2ui;
import javax.swing.*;
import javax.swing.text.*;

/** 
 *
 * @author  srz
 * @version 
 */


public class TFDocument extends javax.swing.text.PlainDocument {

    public void insertString(int offs, String str, javax.swing.text.AttributeSet a) 
      throws javax.swing.text.BadLocationException {

      if (str == null) {
        return;
        }
      char[] upper = str.toCharArray();
      char[] upper1;
      int l=0;
      for (int i = 0; i < upper.length; i++) {
        if (Character.isWhitespace(upper[i]) 
			|| Character.isIdentifierIgnorable(upper[i]))
          java.awt.Toolkit.getDefaultToolkit().beep();
        else 
          upper[l++] = upper[i];
        
      }
      upper1 = new char [l];
      System.arraycopy(upper, 0, upper1, 0, l);
      super.insertString(offs, new String(upper1), a);
    }
}
  

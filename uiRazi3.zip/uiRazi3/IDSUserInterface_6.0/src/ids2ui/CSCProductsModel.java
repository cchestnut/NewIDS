/*
**  SCCS Info :  "@(#)CSCProductsModel.java	1.4    02/12/05"
*/
/*
 * CSCProductsModel.java
 *
 */

package ids2ui;

import javax.swing.SwingUtilities;
import javax.swing.tree.TreePath;


public class CSCProductsModel 
extends AbstractTreeTableModel 
{

    // Names of the columns.
    static public String[]  cNames = {
	"Product", 
	"LCN/Port", 
	"Type",
	"History",
	"History key",
	"Container",
	"Sub-product"
    };
    

    // Names of the columns.
    static public String[]  cNamesTips = {
	"Product ID", 
	"X.25 LCN or TCP port offset", 
	"Type of product",
	"Is historical data available?.",
	"Key for retrieving the host for historical data",
	"Is the product a container",
	"Is the product also included as sub-product in contents?."
    };

    // Types of the columns.
    static protected Class[]  cTypes = {
	TreeTableModel.class,
	Integer.class, 
	Integer.class,
	Boolean.class,
	String.class,
	Boolean.class,
	Boolean.class 
    };

    
    private java.util.HashMap productMap = new java.util.HashMap(50);

    protected boolean             isValid;
    protected ProductNode		reloadNode;
    int                           reloadCount;
    
    private boolean                dataEdited = false;
    

   

    public CSCProductsModel() 
    throws Exception
    {
	super(null);
	loadProducts();
	root = new ProductNode( new ProductData("Products"));
	isValid=true;
    }

    public CSCProductsModel(java.io.InputStream urlStream) 
    throws Exception
    {
	super(null);
	loadProducts(urlStream);
	root = new ProductNode( new ProductData("Products"));
	isValid=true;
    }
  
    /*
    ** Copy Constructor
    */
       
    public CSCProductsModel(CSCProductsModel x)
    {
	super(null);
	java.util.Iterator iterator =
	    x.productMap.values().iterator();

	while (iterator.hasNext()) {
	    String[] values = (String[]) iterator.next();
	    String [] new_values = new String[values.length];
	    System.arraycopy(values,0,
			     new_values, 0,
			     values.length);
	    productMap.put(new_values[0],new_values);
	}

	isValid=true;
	root = new ProductNode( new ProductData("Products"));   

    }
    

    public  java.util.Set getProductSet() {
	return productMap.keySet();
    }

    public boolean isEdited() {
	return dataEdited;
    }

    /*
     * Load products from the configuration server
     */
    private void loadProducts()
    throws Exception
    {
	StringBuffer reqbuf = new StringBuffer();
	String inbuf, datastr;
	byte [] b;
	

	try {

	    ConfigComm.getKey(reqbuf,Constants.GLB_PRODUCT_LIST);
	    b = ConfigComm.configRequest(reqbuf);

	} catch (DBException dbe) {

	    int errno = dbe.getErrorNo();

	    if (errno != Constants.KEY_NOT_FOUND) {
		throw dbe;
	    } else {
		Log.getInstance().log_error("Products not defined. "
					    +"Creating.",dbe);
		return;
	    }

	} catch (Exception e) {

	    throw e;
	}


	inbuf = new String(b);
	int index = inbuf.indexOf(ConfigComm.CONF_STX)+1;

	if (index <=0) {
	    throw new Utils.DataParsingException("CSCProductsModel: Data index"
						 +" not found: "+index);
	}



	datastr = inbuf.substring(index);


	StringBuffer prodSeparator = new StringBuffer();
	prodSeparator.append(ConfigComm.CONF_STX).
	    append(ConfigComm.CONF_GS);


	StringBuffer fieldSeparator = new StringBuffer();
	fieldSeparator.append(ConfigComm.CONF_US).
	    append(ConfigComm.CONF_ETX);



	java.util.StringTokenizer productTokenizer
	    = new java.util.StringTokenizer(datastr,prodSeparator.toString());


	while (productTokenizer.hasMoreTokens()) {

	    String [] rowData = new String[cNames.length];
	    
	    String fstr = productTokenizer.nextToken().trim();

	    java.util.StringTokenizer  fieldTokenizer
		= new java.util.StringTokenizer(fstr,fieldSeparator.toString());



	    int numTokens = fieldTokenizer.countTokens();
	    
	    if ( numTokens != cNames.length ) {
		StringBuffer errstr = new StringBuffer("CSCProductsModel:");
		
		errstr.append("Parsing Error: '")
		    .append(fstr)
		    .append("' .Expecting ")
		    .append(cNames.length)
		    .append(" tokens. Got ")
		    .append(numTokens);

		Log.getInstance().log_error(errstr.toString(),
					    null);

		throw new Utils.DataParsingException(errstr.toString());
		
	    }

	    

	    rowData[0] = fieldTokenizer.nextToken();
	    rowData[1] = fieldTokenizer.nextToken();
	    rowData[2] = fieldTokenizer.nextToken();
	    rowData[3] = fieldTokenizer.nextToken();
	    rowData[4] = fieldTokenizer.nextToken();
	    rowData[5] = fieldTokenizer.nextToken();
	    rowData[6] = fieldTokenizer.nextToken();
	    
	    productMap.put(rowData[0],rowData);
	}
	
	
	
    }


    /*
     * Load products from file
     */
    private void loadProducts(java.io.InputStream urlStream )
    throws Exception
    {

	char	 COMMENT = '#';

	System.out.println("Loading products from file "+urlStream.toString());


	java.io.LineNumberReader productFile
			= new java.io.LineNumberReader(
				new java.io.InputStreamReader(urlStream));



	String fieldSeparator = new String(" \t");


	String line = null;

	while ( (line = productFile.readLine()) != null)  {

	    if (  (line.trim().length()==0) 
		|| (line.charAt(0) == COMMENT) )
		continue;



	    String [] rowData = new String[cNames.length];
	    
	    String fstr = line.trim();

	    java.util.StringTokenizer  fieldTokenizer
		= new java.util.StringTokenizer(fstr,fieldSeparator);



	    int numTokens = fieldTokenizer.countTokens();
	    
	    if ( numTokens != cNames.length ) {
		StringBuffer errstr = new StringBuffer("CSCProductsModel:");
		
		errstr.append("Parsing Error: Line#"
		+productFile.getLineNumber()+" '")
		    .append(fstr)
		    .append("' .Expecting ")
		    .append(cNames.length)
		    .append(" tokens. Got ")
		    .append(numTokens);

		Log.getInstance().log_error(errstr.toString(),
					    null);

		throw new Utils.DataParsingException(errstr.toString());
		
	    }

	    

	    rowData[0] = fieldTokenizer.nextToken();
	    rowData[1] = fieldTokenizer.nextToken();
	    rowData[2] = fieldTokenizer.nextToken();
	    rowData[3] = fieldTokenizer.nextToken();
	    rowData[4] = fieldTokenizer.nextToken();
	    rowData[5] = fieldTokenizer.nextToken();
	    rowData[6] = fieldTokenizer.nextToken();
	    
	    productMap.put(rowData[0],rowData);
	}

	productFile.close();
	
	
	
    }
    


    //
    // The TreeModel interface
    //

    /**
	* Returns the number of children of <code>node</code>.
	    */
    public int getChildCount(Object node) { 
	Object[] children = getChildren(node); 
	return (children == null) ? 0 : children.length;
    }
    
    /**
	* Returns the child of <code>node</code> at index <code>i</code>.
	    */
    public Object getChild(Object node, int i) { 
	return getChildren(node)[i]; 
    }
    
    /**
    * Returns true if the passed in object represents a leaf, false
    * otherwise.
    */
    public boolean isLeaf(Object node) {
	return ((ProductNode)node).isLeaf();
    }
    
    

    //
    //  The TreeTableNode interface. 
    //
    
    /**
    * Returns the number of columns.
    */
    public int getColumnCount() {
	return cNames.length;
    }
    
    /**
    * Returns the name for a particular column.
    */
    public String getColumnName(int column) {
	return cNames[column];
    }
    
    /**
    * Returns the class for the particular column.
    */
    public Class getColumnClass(int column) {
	return cTypes[column];
    }
    
    /**
    * Returns the value of the particular column.
    */
    public Object getValueAt(Object node, int column) {

        ProductNode     pn = (ProductNode)node;
	ProductData pd = pn.getProduct();
	
       
	switch(column) {
            case 0:
                return pd.getName();
            case 1:
                return new Integer((int)(pd.getLCN()));
            case 2:
                return new Integer((int)(pd.getType()));
            case 3:
                return new Boolean((boolean)(pd.getHistory()));
            case 4:
                return new String(pd.getRTPKey());
            case 5:
                return new Boolean((boolean)pd.isContainer());
            case 6:
                return new Boolean((boolean)pd.isProduct());
	}
        
        return null;
    }


    public void setValueAt(Object value, Object node, int column) {
	if ((column==0) || (column > 6)) return;
	    
	ProductNode productNode = ((ProductNode)node);
	ProductData productData = productNode.getProduct();
	
	dataEdited = true;

	switch(column) {
	    case 1:
		productData.setLCN(value);
		return;
	    case 2:
		productData.setType(value);
		return;
	    case 3:
		productData.setHistory(value);
		return;
	    case 4:
		productData.setRTPKey(value);
		return;
	    case 5:
		productData.setIsContainer(value);
		return;
	    case 6:
		productData.setIsProduct(value);
		return;
	}
    }



     

    public boolean isCellEditable(Object node, int column) {
	ProductNode         pn = (ProductNode)node;
	
	if ((column>0) && pn.getProduct().isRoot()) return false;

	/*
	***
	if ((column==4)
	    && !((Boolean)getValueAt(node,column-1)).booleanValue())
	    return false;
	
	if ((column <5))
	    return true;
	***
	*/

	if (column==0) return true;
	
	return false;
    }
     


  //
    // Some convenience methods. 
    //

    /**
     * Reloads the children of the specified node.
     */
    public void reloadChildren(Object node) {
	ProductNode         pn = (ProductNode)node;

	synchronized(this) {
	    reloadCount++;
	}
	pn.resetSize();
	new Thread(new ProductNodeLoader((ProductNode)node)).start();
    }

    /**
     * Stops and waits for all threads to finish loading.
     */
    public void stopLoading() {
	isValid = false;
	synchronized(this) {
	    while (reloadCount > 0) {
		try {
		    wait();
		} catch (InterruptedException ie) {}
	    }
	}
	isValid = true;
    }


    /**
     * Returns the path <code>node</code> represents.
     */
    public String getPath(Object node) {
	return ((ProductNode)node).getProduct().getPath();
    }

    /**
     * Returns the total size of the receiver.
     */
    public long getTotalSize(Object node) {
	return ((ProductNode)node).totalSize();
    }

    /**
     * Returns true if the receiver is loading any children.
     */
    public boolean isReloading() {
	return (reloadCount > 0);
    }

    /**
     * Returns the path to the node that is being loaded.
     */
    public TreePath getPathLoading() {
	ProductNode      rn = reloadNode;

	if (rn != null) {
	    return new TreePath(rn.getPath());
	}
	return null;
    }

    /**
     * Returns the node being loaded.
     */
    public Object getNodeLoading() {
	return reloadNode;
    }

    protected ProductData getProduct(Object node) {
	ProductNode productNode = ((ProductNode)node); 
	return productNode.getProduct();       
    }

    protected Object[] getChildren(Object node) {
	ProductNode productNode = ((ProductNode)node); 
	return productNode.getChildren(); 
    }


    protected static ProductNode[] EMPTY_CHILDREN = new ProductNode[0];

    

    public java.util.HashMap getProductMap() {
	return productMap;
    }



    /*
    ** Return a string suitable for saving into the configuration database
    */
    public String toString() {

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 StringBuffer result = new StringBuffer();
	 
	 while (iter.hasNext()) {

	     String[]s = (String[])iter.next();

	     result.append(ConfigComm.CONF_GS);

	     for (int j = 0; j < s.length; j++) {
		 result.append(s[j]).append(ConfigComm.CONF_US);
	     }
	     
	 }

	 return result.toString();
    }




    public String[] getContainerProducts() {
	

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 while (iter.hasNext()) {

	     String[]s = (String[])iter.next();
	     String p = s[0];
	     String is_c = s[5];
	     
	     if (Utils.parseBooleanString(is_c))
		 list.add(new String(p));
	 }

	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);

    }




    public String[] getSubProducts(String container) {
	

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 while (iter.hasNext()) {

	     String[]s = (String[])iter.next();
	     String p = s[0];
	     String c = s[6];
	     /*
	     if (container.equals(c)
		 && !container.equals(p) )
		 list.add(new String(p));
	     */
	     if (container.equals(c))
		 list.add(new String(p));
	 }
	 
	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);

    }

    public String getContainer(String product) {
	

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 while (iter.hasNext()) {
	     String[]s = (String[])iter.next();
	     String p = s[0];
	     String c = s[6];
	     
	     if (product.equals(p)
		 && !c.equals("-") )
		 return new String(c);
	 }

	 return null;

    }

    public String[] getProducts() {

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 while (iter.hasNext()) {
	     String[]s = (String[])iter.next();
	     String p = s[0];
	     String c = s[6];
	     
	     if (c.equals("-")
		 || p.equals(c) )
		 list.add(new String(p));
	 }
	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);


    }

    public String[] getProductsWithoutAD() {

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 while (iter.hasNext()) {
	     String[]s = (String[])iter.next();
	     String p = s[0];
	     String c = s[6];
	     
	     if (!p.equals(Constants.ADMIN_PRODUCT_ID)
		 && ( (c.equals("-") || p.equals(c) ) ) )
		 list.add(new String(p));
	 }

	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);


    }

   
    public String[] getAllProducts() {

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 while (iter.hasNext()) {
	     String[]s = (String[])iter.next();
	     String p = s[0];
	     
	     list.add(new String(p));
	 }

	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);


    }


    public int addProduct(CSCProductStructure ps) {
	String [] s = new String[7];

	s[0] = new String(ps.ID);
	s[1] = Integer.toString(ps.lcn);
	s[2] = Integer.toString(ps.type);
	s[3] = new String((ps.history)?"true":"false");
	//s[4] = new String((ps.history)?ps.rtp_src_key:"-");
	if ((ps.history) && !ps.rtp_src_key.equals("-"))
		s[4] = new String(ps.rtp_src_key);
	else
		s[4] = new String("GLB_RTP_SERVERS");
	s[5] = new String((ps.is_container)?"true":"false");
	if (ps.container.equals("NONE"))
		s[6] = new String("-");
	else
		s[6] = new String(ps.container);
		

	productMap.put(s[0],s);

	dataEdited = true;

	return 0;
    }

    public int modifyProduct(CSCProductStructure ps) {
	
	String [] s = (String[])productMap.get(ps.ID);

	if (s==null) {
		return -1;
	}


	s[1] = Integer.toString(ps.lcn);
	s[2] = Integer.toString(ps.type);
	s[3] = new String((ps.history)?"true":"false");
	//s[4] = new String((ps.history)?ps.rtp_src_key:"-");

	if ((ps.history) && !ps.rtp_src_key.equals("-"))
		s[4] = new String(ps.rtp_src_key);
	else
		s[4] = new String("GLB_RTP_SERVERS");

	s[5] = new String((ps.is_container)?"true":"false");
	if (ps.container.equals("NONE"))
		s[6] = new String("-");
	else
		s[6] = new String(ps.container);
		

	dataEdited = true;
	

	return 0;
    }


    public int deleteProduct(String ID ) {
	
	String [] s = (String[])productMap.get(ID);

	if (s==null) {
		return -1;
	}

	productMap.remove(s[0]);

	dataEdited = true;
	return 0;
    }

  
   

    class ProductNode {
	
	protected ProductData        product; 
	/** Parent ProductNode of the receiver. */
	private ProductNode            parent;
	/** Children of the receiver. */
	protected ProductNode[]        children; 
	/** Size of the receiver and all its children. */
	protected long              totalSize;
	/** Valid if the totalSize has finished being calced. */
	protected boolean           totalSizeValid;
	/** Path of the receiver. */
	protected String            canonicalPath;



	protected ProductNode(ProductData prod) {
	    this(null, prod);
	}
	
	protected ProductNode(ProductNode parent, ProductData prod) {
	    this.parent = parent;
	    this.product = prod;
	    canonicalPath = prod.getPath();
	    if (isLeaf()) {
		totalSize = 1;
		totalSizeValid = true;
	    }
	}


	public String toString() {
	    return product.getName();
	}
	
	public ProductData getProduct() {
	    return product;
	}
	
	public boolean isContainer() {
	    return product.isContainer();
	}

	public long totalSize() {
	    return totalSize;
	}

	
	public ProductNode getParent() {
	    return parent;
	}
	
	public boolean isLeaf() {
	    return product.isLeaf();
	}

	/**
	 * Returns true if the total size is valid.
	 */
	public boolean isTotalSizeValid() {
	    return totalSizeValid;
	}

	protected void resetSize() {
	    alterTotalSize(-totalSize);
	}
	
	protected ProductNode[] getChildren() {
	    return children;
	}
	
	protected void loadChildren()
	{
	    totalSize = product.length();
	    children = createChildren();
	    for (int counter = children.length - 1; counter >= 0; counter--) {
		Thread.yield(); // Give the GUI CPU time to draw itself.
		if (!children[counter].isLeaf() ) {
		    children[counter].loadChildren();
		}
		totalSize += children[counter].totalSize();
		
		if (!isValid) {
		    counter = 0;
		}
	    }
	    if (isValid) {
		totalSizeValid = true;
	    }	    
	    
	}  	

	/**
	* Loads the children of of the receiver.
	*/
	protected ProductNode[] createChildren() {
	    ProductNode[]        retArray = null;
	    
	    try {
		String[] subprods = product.getSubProducts();
		if(subprods != null) {
		    
		    retArray = new ProductNode[subprods.length]; 
		    String path = product.getPath();
		    for(int i = 0; i < subprods.length; i++) {
			ProductData subProduct = new ProductData(path, subprods[i]); 
			retArray[i] = new ProductNode(this, subProduct);
		    }
		}
	    } catch (SecurityException se) {}
	    if (retArray == null) {
		retArray = EMPTY_CHILDREN;
	    }
	    return retArray;
	}

	/**
	 * Returns true if the children have been loaded.
	 */
	protected boolean loadedChildren() {
	    return (!product.isContainer() || (children != null));
	}


	/**
	 * Gets the path from the root to the receiver.
	 */
	public ProductNode[] getPath() {
	    return getPathToRoot(this, 0);
	}

	/**
	 * Returns the canonical path for the receiver.
	 */
	public String getCanonicalPath() {
	    return canonicalPath;
	}


	protected ProductNode[] getPathToRoot(ProductNode aNode, int depth) {
	    ProductNode[]              retNodes;

	    if(aNode == null) {
		if(depth == 0)
		    return null;
		else
		    retNodes = new ProductNode[depth];
	    }
	    else {
		depth++;
		retNodes = getPathToRoot(aNode.getParent(), depth);
		retNodes[retNodes.length - depth] = aNode;
	    }
	    return retNodes;
	}


	/**
	 * Sets the children of the receiver, updates the total size,
	 * and if generateEvent is true a tree structure changed event
	 * is created.
	 */
	protected void setChildren(ProductNode[] newChildren,
				   boolean generateEvent) {
	    long           oldSize = totalSize;

	    totalSize = product.length();
	    children = newChildren;
	    for (int counter = children.length - 1; counter >= 0;
		 counter--) {
		totalSize += children[counter].totalSize();
	    }


	    if (generateEvent) {
		ProductNode[]   path = getPath();

		fireTreeStructureChanged(CSCProductsModel.this, path, null,
					 null);

		ProductNode             parent = getParent();

		if (parent != null) {
		    parent.alterTotalSize(totalSize - oldSize);
		}
	    }
	}


	protected synchronized void alterTotalSize(long sizeDelta) {
	    if (sizeDelta != 0 && (parent = getParent()) != null) {
		totalSize += sizeDelta;
		nodeChanged();
		parent.alterTotalSize(sizeDelta);
	    }
	    else {
		// Need a way to specify the root.
		totalSize += sizeDelta;
	    }
	}

	/**
	 * This should only be invoked on the event dispatching thread.
	 */
	protected synchronized void setTotalSizeValid(boolean newValue) {
	    if (totalSizeValid != newValue) {
		nodeChanged();
		totalSizeValid = newValue;

		ProductNode          parent = getParent();

		if (parent != null) {
		    parent.childTotalSizeChanged(this);
		}
	    }
	}

	/**
	 * Marks the receivers total size as valid, but does not invoke
	 * node changed, nor message the parent.
	 */
	protected synchronized void forceTotalSizeValid() {
	    totalSizeValid = true;
	}

	/**
	 * Invoked when a childs total size has changed.
	 */
	protected synchronized void childTotalSizeChanged(ProductNode child) {
	    if (totalSizeValid != child.isTotalSizeValid()) {
		if (totalSizeValid) {
		    setTotalSizeValid(false);
		}
		else {
		    ProductNode[]    children = getChildren();

		    for (int counter = children.length - 1; counter >= 0;
			 counter--) {
			if (!children[counter].isTotalSizeValid()) {
			    return;
			}
		    }
		    setTotalSizeValid(true);
		}
	    }
	    
	}

	/**
	 * Can be invoked when a node has changed, will create the
	 * appropriate event.
	 */
	protected void nodeChanged() {
	    ProductNode        parent = getParent();

	    if (parent != null) {
		ProductNode[]   path = parent.getPath();
		int[]        index = { getIndexOfChild(parent, this) };
		Object[]     children = { this };

		fireTreeNodesChanged(CSCProductsModel.this, path,  index,
				     children);
	    }
	}
    }  /* Class ProductNode */


    class ProductNodeLoader
	implements Runnable 
    {
	/** Node creating children for. */
	ProductNode          node;
	

	ProductNodeLoader(ProductNode node) {
	    this.node = node;
	    node.setChildren(node.createChildren(), true);
	    node.setTotalSizeValid(false);
	}

	public void run() {
	    ProductNode[]      children = node.getChildren();

	    
	    for (int counter = children.length - 1; counter >= 0; counter--) {
		if (!children[counter].isLeaf()) {
		    reloadNode = children[counter];
		    loadChildren(children[counter]);
		    reloadNode = null;
		}
		if (!isValid) {
		    counter = 0;
		}
	    }
	    
	    if (isValid) {
		SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
			node.setChildren(node.getChildren(), true);
			synchronized(CSCProductsModel.this) {
			    reloadCount--;
			    CSCProductsModel.this.notifyAll();
			}
		    }
		});
	    }
	    else {
		synchronized(CSCProductsModel.this) {
		    reloadCount--;
		    CSCProductsModel.this.notifyAll();
		}
	    }
	}

	protected void loadChildren(ProductNode node) {
	    if (!node.isLeaf() ) {
		final ProductNode[]      children = node.createChildren();

		for (int counter = children.length - 1; counter >= 0;
		     counter--) {
		    if (!children[counter].isLeaf()) {
			if ( children[counter].isContainer()) {
			    children[counter].loadChildren();
			}
			else {
			    children[counter].forceTotalSizeValid();
			}
		    }
		    if (!isValid) {
			counter = 0;
		    }
		}
		if (isValid) {
		    final ProductNode       pn = node;

		    // Reset the children 
		    SwingUtilities.invokeLater(new Runnable() {
			public void run() {
			    pn.setChildren(children, true);
			    pn.setTotalSizeValid(true);
			    pn.nodeChanged();
			}
		    });
		}
	    }
	    else {
		node.forceTotalSizeValid();
	    }
	}
    } /* Class ProductNodeLoader */




   


 public class ProductData {

     
     
     
     String	product;
     String	lcn_str;
     String 	type_str;
     String 	history_str;
     String 	history_src_str;
     String 	is_container_str;
     String 	container_str;

     boolean      isRoot=false;
     String        path;



     


     private String getPath(String id) {

	 if (id==null)
	     return null;

	 if (id.equals("Products"))
	     return id;

	 String[] s = (String[])productMap.get(id);

	 if (s==null || s.length<7)
	     return null;

	 if (Utils.parseBooleanString(s[5])
	     || s[6].equals("-")
	     || s[6].equals(id))
	     return "Products/"+id;
	 else  
	     return getPath(s[6])+"/"+id;

	 
     }

     
     

     private void init2(String []s)
     {
	 if (s.length < 7) return;

	 product = new String(s[0]);
	 lcn_str = new String(s[1]);
	 type_str = new String(s[2]);
	 history_str = new String(s[3]);
	 history_src_str = new String(s[4]);
	 is_container_str = new String(s[5]);
	 container_str = new String(s[6]);
     }



     public ProductData(String p) {

	 //System.out.println("ProductData : "+p);

	 if (p.equals("Products")) {
	     isRoot=true;
	     product = new String(p);
	     is_container_str = new String("true");
	     container_str = new String("-");
	     lcn_str = new String("0");
	     type_str = new String("0");
	     history_str = new String("");
	     history_src_str = new String("");
	     path = new  String(p);
	 }
     }
     

     public ProductData(String p, String id) {

	 String[] s = (String[])productMap.get(id);

	 init2(s);
	 String pp = getPath(p);
	 if (pp==null)
	     pp = p;
	 path = new String(pp+"/"+id);
	 //System.out.println("ProductData: "+path);
     }


     public String getName() {
	 return product;
     }


     public boolean isRoot() {
	 return isRoot;
     }

     
     public long  length() { return (isRoot)? 0: 1 ; }


     public String[] getSubProducts() {

	 if (!isContainer())
	     return null;

	 java.util.Iterator iter =
	     productMap.values().iterator();
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 if (isRoot) {
	     
	     while (iter.hasNext()) {
		 String[]s = (String[])iter.next();
		 String p = s[0];
		 String c = s[6];

		 if (p.equals(c)
		     || c.equals("-") )
		     list.add(new String(s[0]));
	     }
	     
	 } else {
	     while (iter.hasNext()) {
		 String[]s = (String[])iter.next();
		 String p = s[0];
		 String c = s[6];
		 
		 if (product.equals(c)
		     && !product.equals(p) )
		     list.add(new String(s[0]));
	     }
	 }

	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);
     }



     public String getPath() {
	 return path;
     }

     
     public boolean isLeaf() {
	 return !Utils.parseBooleanString(is_container_str);
     }

     
     public int getLCN() {

	 try {
	     return Integer.parseInt(lcn_str);
	 } catch (NumberFormatException nfe){
	 }
	 
	 return -1;
     }
     

     public void setLCN( Object value)
     {
	 if (value instanceof Integer) {
	     lcn_str = ((Integer)value).toString();
	     return;
	 }
	 if (value instanceof String) {
	     lcn_str = new String((String)value);
	     return;
	 }
     }
     
     public int getType() {

	 try {
	     return Integer.parseInt(type_str);
	 } catch (NumberFormatException nfe){
	 }

	 return -1;
     }
     

     public void setType(Object value)
     {
	 
	 if (value instanceof Integer) {
	     type_str = ((Integer)value).toString();
	     return;
	 }
	 if (value instanceof String) {
	     type_str = new String((String)value);
	     return;
	 }
	 
     }


     public boolean getHistory() {
	 return Utils.parseBooleanString(history_str);
     }


     public void setHistory(Object value)
     {
	 if (value instanceof Boolean) {
	     history_str = ((Boolean)value).toString();
	     return;
	 }
	 if (value instanceof String) {
	     history_str = new String((String)value);
	     return;
	 }	

     }
     


     public String getRTPKey() {
	 return history_src_str;
     }


     public void setRTPKey(Object value)
     {
	 if (value instanceof String) {
	     history_src_str = new String((String)value);
	     return;
	 }	
     }



     public boolean isContainer() {
	 return Utils.parseBooleanString(is_container_str);
     }

     public void setIsContainer(Object value)
     {
	 if (value instanceof Boolean) {
	     is_container_str = ((Boolean)value).toString();
	     return;
	 }
	 if (value instanceof String) {
	     is_container_str = new String((String)value);
	     return;
	 }	

     }



     public boolean isProduct() {
	 return container_str.equals(product);
     }

     public void setIsProduct(Object value)
     {
	 if (value instanceof String) {
	     container_str = new String((String)value);
	     return;
	 }	
     }



     public String getContainerString() {
	 return container_str;
     }
     
     
 } /* Class ProductData */

}

/*
**  SCCS Info :  "@(#)TransportConfigPanel.java	1.4    04/04/01"
*/
/*
 * TransportConfigPanel.java
 *
 * Created on March 2, 2001, 5:02 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class TransportConfigPanel extends javax.swing.JPanel {

    private java.util.Vector transportList = null;
    private java.util.Vector transportList_nox25 = null;
    
    private String transportString = null;
    private javax.swing.JTable tcpHostTable1 = null;
    private javax.swing.JTable tcpHostTable2 = null;
    private java.awt.Window parentFrame = null;
    
    private String dcmTag = null;
    private String linkDCM = null;
    private String dcmType = null;
    private String distrTag = null;
    private String hostList1 = null;
    private String hostList2 = null;
    private AMQPanel amqPanel = new AMQPanel();
    public javax.swing.JCheckBox lwcHeaderCheckBox = new javax.swing.JCheckBox("LWC header");
  
  /** Creates new form TransportConfigPanel */
  public TransportConfigPanel(java.awt.Window parent, String title,
			      java.util.Vector tl, String dcm, String distr,
			      String ts1 ,String ts2, boolean lwchdr )
  {
    parentFrame = parent;
    transportList = tl;
    transportList_nox25 = Utils.removeX25Types(transportList);

    dcmTag = dcm;
    distrTag = distr;

    lwcHeaderCheckBox.setSelected(lwchdr);
    initComponents ();
    myInitComponents (title);
    
    
   
    if (ts1!=null)
      populateUI(ts1,ts2);

    transportChanged(null);


    final javax.swing.ListSelectionModel selectionModel1
          = tcpHostTable1.getSelectionModel();

    final javax.swing.ListSelectionModel selectionModel2
          = tcpHostTable2.getSelectionModel();
    
    jButton2.setEnabled(false);
    jButton3.setEnabled(false);

    javax.swing.event.ListSelectionListener selectionListener = 
	new javax.swing.event.ListSelectionListener() {
	public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	    boolean modify_enabled = true;
	    boolean delete_enabled = true;
	    if (evt.getValueIsAdjusting())
		return;
	    
	    if (selectionModel1.isSelectionEmpty()
		&& selectionModel2.isSelectionEmpty())
		modify_enabled = delete_enabled = false;
	    
	    int row1[] = tcpHostTable1.getSelectedRows();
	    int row2[] = tcpHostTable2.getSelectedRows();
	    if ((row1.length!=0) && (row2.length!=0)) {
		String h1 = (String)tcpHostTable1.getValueAt(row1[0],0);
		String s1 = (String)tcpHostTable1.getValueAt(row1[0],1);
		String h2 = (String)tcpHostTable2.getValueAt(row2[0],0);
		String s2 = (String)tcpHostTable2.getValueAt(row2[0],1);
		StringBuffer hs1 = new StringBuffer();
		StringBuffer hs2 = new StringBuffer();
		if (h1!=null) hs1.append(h1);
		if (s1!=null) hs1.append(s1);
		if (h2!=null) hs2.append(h2);
		if (s2!=null) hs2.append(s2);

		
		if (hs1.toString().equals(hs2.toString()))
		    modify_enabled = true;
		else
		    modify_enabled = false;
		
	    } else if ((row1.length>0) || (row2.length>0)) 
		modify_enabled = true;

	    jButton2.setEnabled(modify_enabled); //Modify button
	    jButton3.setEnabled(delete_enabled); //Delete button
	    
	}
    };

     selectionModel1.addListSelectionListener(selectionListener);
     selectionModel2.addListSelectionListener(selectionListener);

         
  }


    public void dcmChanged(String dcm)
    {

	dcmTag = dcm;

	transportTypeCombo.setEnabled(false);
	String oldSelection = (String)transportTypeCombo.getSelectedItem();
	java.util.Vector v = transportList_nox25;
	transportTypeCombo.removeAllItems();

        lwcHeaderCheckBox.setVisible(false);
	if (dcmTag != null) {

	    try {
		java.util.HashMap dcmConfig 
		    = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcmTag);
		hostList1 = (String)dcmConfig.get("HOST1");
		hostList2 = (String)dcmConfig.get("HOST2");
		dcmType = (String)dcmConfig.get("TYPE");
		
		if (Utils.isX25DCM(dcmType))
		    v = transportList;
		else if (Utils.isDJNEWS_DCM(dcmType)) {
		    v = ConfigComm.getDJNEWSDCMTransportTypeList();
                    lwcHeaderCheckBox.setVisible(true);
		    if (v == null)
			v = transportList_nox25;
		}
		
		
		
	    } catch (Exception e){
		Log.getInstance().log_error("TransportConfigPanel: Error in retrieving DCM configuration: "+dcmTag, e);
	    }
	    transportTypeCombo.setEnabled(true);	    
	}
	else transportTypeCombo.setEnabled(false);
	    


	for (int i = 0; i < v.size(); i++) {
	    String t = (String)v.get(i);
	    transportTypeCombo.addItem(t);
	    if ( (oldSelection!=null) 
		 && oldSelection.equals(t))
		transportTypeCombo.setSelectedItem(t);
	}
	
	//transportTypeCombo.setEnabled(true);

	transportChanged(null);

    }




    public void loadLinks(String l1, String l2)
    {

	if ((dcmTag==null) 
	    || (hostList1==null) ||(hostList2==null)) {
	    linkComboBox1.removeAllItems();
	    linkComboBox2.removeAllItems();
	    return;
	}

	if ((linkDCM!=null) && linkDCM.equals(dcmTag))
	    return;

	linkDCM  = new String(dcmTag);
    
	Utils.LoadX25Links loader1 = new Utils.LoadX25Links(hostList1,
							    linkComboBox1,
							    null,l1);
	loader1.start();
	Utils.LoadX25Links loader2 = new Utils.LoadX25Links(hostList2,
							    linkComboBox2,
							    null,l2);
	loader2.start();

    }



  public void setTransportConfig(String distr,String ts1, String ts2, boolean lwchdr) {
      distrTag = distr;
      populateUI(ts1,ts2);
      lwcHeaderCheckBox.setSelected(lwchdr);
  }


    private void appendTCPString(StringBuffer buf, 
				 javax.swing.table.DefaultTableModel model)
    {
	int nrows = model.getRowCount();
	
	for ( int i = 0; i < nrows; i++) {
	    String h = (String)model.getValueAt(i,0);
	    String p = (String)model.getValueAt(i,1);
	    
	    if (h!=null && (h.length() > 0))
		buf.append(h).append(":");
	    
	    buf.append(p);
	    if (i < (nrows-1)) buf.append(",");
	}
	
    }


  public int getTransportConfig(StringBuffer transport1, 
	StringBuffer transport2, StringBuffer errstr) 
  {
      int err=0;
      boolean same_config = true;

      if (transportString.startsWith("AM"))
      {
          try {
            String a = amqPanel.getTransportConfig();
          transport1.append(a);
          transport2.setLength(0);
          } catch (Exception e)
          {
              errstr.append(e.getMessage());
              err=1;
          }
          return err;
      }

      transport1.append(transportString).append(" ");
      transport2.append(transportString).append(" ");
    
    
      if (transportString.substring(0,3).equals("FIL") ) {
	  String fname1 = fileTextField1.getText().trim();
	  String fname2 = fileTextField2.getText().trim();
	  if (fname1.length() == 0) {
	      err=1; errstr.append(" Transport-I: filename \n");
	  }
	  if (fname2.length() == 0) {
	      err=1; errstr.append(" Transport-II: filename \n");
	  }

	  transport1.append(fname1);
	  transport2.append(fname2);
      }


      if (transportString.substring(0,3).equals("RBP") ) {
	  String appid = rbpTextField.getText().trim();
	  if (appid.length() == 0) {
	      err=1; errstr.append("  Application ID \n");
	  }
	  transport1.append(appid);
	  transport2.append(appid);
      }



      if (transportString.equals("ASYNC")) {
	  String h1 = tcpHostTextField1.getText().trim();
	  String p1 = tcpPortTextField1.getText().trim();
	  if ( (h1.length()==0) || (p1.length()==0)) {
	      err=1; errstr.append(" Transport-I: Port/Service \n");
	  }

	  String h2 = tcpHostTextField2.getText().trim();
	  String p2 = tcpPortTextField2.getText().trim();

	  if ( (h2.length()==0) || (p2.length()==0)) {
	      err=1; errstr.append(" Transport-II: Port/Service \n");
	  }

	  transport1.append(h1).append(":").append(p1);
	  transport2.append(h2).append(":").append(p2);
      }



      if (transportString.substring(0,3).equals("SVC")) {
	  String l1 = (String)linkComboBox1.getSelectedItem();
	  String d1 = dteTextField1.getText().trim();
	  String l2 = (String)linkComboBox2.getSelectedItem();
	  String d2 = dteTextField2.getText().trim();
      
	  if (!isValidX25Address(transportString, l1,d1)
	      || !isValidX25Address(transportString, l2, d2)) {
	      err=1; errstr.append(" Transport: SVC Link [0-255]/DTE \n");
	  }
	  transport1.append(l1).append(".").append(d1);
	  transport2.append(l2).append(".").append(d2);
	  same_config=false;
      }


      if (transportString.substring(0,3).equals("PVC")){
	  String l1 = (String)linkComboBox1.getSelectedItem();
	  String l2 = (String)linkComboBox2.getSelectedItem();
	  if ( !isValidX25Address(transportString, l1,null)
	       || !isValidX25Address(transportString, l2, null))  {
	      err=1; errstr.append(" Transport: PVC Link [0-255] \n");
	  }
	  transport1.append(l1);
	  transport2.append(l2);
	  same_config=false;
      }



      if (transportString.substring(0,3).equals("TCP")) {
	  javax.swing.table.DefaultTableModel model1 =
	      (javax.swing.table.DefaultTableModel)tcpHostTable1.getModel();
	  javax.swing.table.DefaultTableModel model2 =
	      (javax.swing.table.DefaultTableModel)tcpHostTable2.getModel();

	  int nrows1 = model1.getRowCount();
	  int nrows2 = model2.getRowCount();

	  if (nrows1 <= 0) {
	      err=1; errstr.append(" Transport-I: Host/Service \n");
	  }
	  if (nrows2 <= 0) {
	      err=1; errstr.append(" Transport-II: Host/Service \n");
	  }

      
	  if (transport1.length() < 5 ) {
	      err=1; errstr.append("TCP type \n");
	  }

	  appendTCPString(transport1,model1);
	  appendTCPString(transport2,model2);

      } /* TCPOUT */

      if (transport1.toString().equals(transport2.toString()))
	  transport2.setLength(0);


	  return err;
  }


  private void myInitComponents(String title) {
/*
    setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.TitledBorder(
                  new javax.swing.border.EtchedBorder(), title, 2, 2),
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
  */


  }

    private void populateUI(String transport1, String transport2) 
    {

	java.util.StringTokenizer st1 = null, st2=null;
	String typeStr1=null, addrStr1=null;
	String typeStr2=null, addrStr2=null;


	st1 = new java.util.StringTokenizer(transport1," ");
	if (st1.hasMoreTokens())
	    typeStr1 = st1.nextToken();
	else
	    return;

	if (st1.hasMoreTokens())
	    addrStr1 = st1.nextToken();
	else
	    return;


	if (transport2!=null) {
	    st2 = new java.util.StringTokenizer(transport2," ");
	    if (st2.hasMoreTokens())
		typeStr2 = st2.nextToken();
	    else
		return;
	    
	    if (st2.hasMoreTokens())
		addrStr2 = st2.nextToken();
	    else
		return;

	}


	
        if (typeStr1.startsWith("AM"))
        {
            amqPanel.setTransportConfig(typeStr1, addrStr1);
        }

	

	if  (typeStr1.substring(0,3).equals("FIL")) {
	    fileTextField1.setText(addrStr1);
	    if (transport2==null) {
		fileTextField2.setText(addrStr1);
	    } else {
		fileTextField2.setText(addrStr2);
	    }
		
	}

	if  (typeStr1.substring(0,3).equals("RBP")) {
	    rbpTextField.setText(addrStr1);
	}



	if (typeStr1.equals("ASYNC")) {
	    int inx = addrStr1.indexOf(':');

	    tcpHostTextField1.setText(addrStr1.substring(0,inx));
	    tcpPortTextField1.setText(addrStr1.substring(inx+1));

	    if (transport2==null) {
		tcpHostTextField2.setText(addrStr1.substring(0,inx));
		tcpPortTextField2.setText(addrStr1.substring(inx+1));
	    } else {
		inx = addrStr2.indexOf(':');
		tcpHostTextField2.setText(addrStr2.substring(0,inx));
		tcpPortTextField2.setText(addrStr2.substring(inx+1));
	    }

	}



	if (typeStr1.substring(0,3).equals("SVC")) {
	    int inx = addrStr1.indexOf('.');
	    /* 
	    ** For compatibility with previous config
	    ** where ':' was used as separator for X.25 address
	    */
	    if (inx < 0) 
		inx = addrStr1.indexOf(':');

	    String link1 = addrStr1.substring(0,inx);
	    String link2 = null;

	    linkComboBox1.setSelectedItem(link1);
	    dteTextField1.setText(addrStr1.substring(inx+1));
      
	    
	    int inx2 = addrStr2.indexOf('.');
	    if (inx2 < 0) inx2 = addrStr2.indexOf(':');

	    link2 = addrStr2.substring(0,inx2);
          
	    linkComboBox2.setSelectedItem(link2);
	    dteTextField2.setText(addrStr2.substring(inx2+1));

      
	    loadLinks(link1,link2);

	}
    
    
	if (typeStr1.substring(0,3).equals("PVC")) {
	
	    linkComboBox1.setSelectedItem(addrStr1);
	    
	    linkComboBox2.setSelectedItem(addrStr2);

	    loadLinks(addrStr1, addrStr2);
	}

    

	if (typeStr1.substring(0,3).equals("TCP")) {


	    javax.swing.table.DefaultTableModel model1 =
		(javax.swing.table.DefaultTableModel)tcpHostTable1.getModel();
	    javax.swing.table.DefaultTableModel model2 =
		(javax.swing.table.DefaultTableModel)tcpHostTable2.getModel();


	    model1.setNumRows(0);
	    model2.setNumRows(0);
	    st1 = new java.util.StringTokenizer(addrStr1,",");
	    while (st1.hasMoreTokens()) {
		String hp = st1.nextToken();
		String [] row = new String[2];
		int inx = hp.indexOf(':');
		if (inx != -1) {
		    row[0] = hp.substring(0,inx);
		    row[1] = hp.substring(inx+1);
		} else {
		    row[0] = "";
		    row[1] = hp;
		}
		if (transport2==null) {
		    String [] row2 = new String[2];
		    row2[0] = new String(row[0]);
		    row2[1] = new String(row[1]);
		    model2.addRow(row2);
		}
		model1.addRow(row);
	    }

	    if (transport2!=null) {
		st2 = new java.util.StringTokenizer(addrStr2,",");
		while (st2.hasMoreTokens()) {
		    String hp = st2.nextToken();
		    String [] row = new String[2];
		    int inx = hp.indexOf(':');
		    if (inx != -1) {
			row[0] = hp.substring(0,inx);
			row[1] = hp.substring(inx+1);
		    } else {
			row[0] = "";
			row[1] = hp;
		    }
		    
		    model2.addRow(row);
		}
		
	    }

	    model1.fireTableDataChanged();
	    model2.fireTableDataChanged();
	}



	java.awt.CardLayout l = (java.awt.CardLayout)transportPanel.getLayout();

        /*
	if (typeStr.substring(0,3).equals("TCP") )
	    l.show((java.awt.Container)transportPanel,"TransportTCP");
	else if (typeStr.equals("ASYNC"))
	    l.show((java.awt.Container)transportPanel,"TransportTCPHost");
	else if (typeStr.substring(0,3).equals("PVC"))
	    l.show((java.awt.Container)transportPanel,"TransportPVC");
	else if (typeStr.substring(0,3).equals("SVC"))
	    l.show((java.awt.Container)transportPanel,"TransportSVC");
	else if (typeStr.substring(0,3).equals("FIL"))
	    l.show((java.awt.Container)transportPanel,"TransportFile");
	else if (typeStr.substring(0,3).equals("RBP"))
	    l.show((java.awt.Container)transportPanel,"TransportRBP");
	else
	    l.show((java.awt.Container)transportPanel,"TransportBlank");
            */
	transportString = new String(typeStr1);
	transportTypeCombo.setSelectedItem(transportString);



	transportPanel.invalidate();
        transportPanel.validate();
        validate();


    } // End of populateUI







    /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
    private void initComponents () {//GEN-BEGIN:initComponents
      jPanel1 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      transportTypeCombo = new javax.swing.JComboBox(new java.util.Vector(transportList_nox25));

      transportPanel = new javax.swing.JPanel ();
      jPanel3 = new javax.swing.JPanel ();
      jPanel4 = new javax.swing.JPanel ();
      jPanel5 = new javax.swing.JPanel ();
      jLabel2 = new javax.swing.JLabel ();
      fileTextField1 = new javax.swing.JTextField ();
      jPanel6 = new javax.swing.JPanel ();
      jLabel3 = new javax.swing.JLabel ();
      fileTextField2 = new javax.swing.JTextField ();
      jPanel19 = new javax.swing.JPanel ();
      jButton10 = new javax.swing.JButton ();
      jPanel20 = new javax.swing.JPanel ();
      jButton9 = new javax.swing.JButton ();
      jPanel7 = new javax.swing.JPanel ();
      jPanel15 = new javax.swing.JPanel ();
      jLabel6 = new javax.swing.JLabel ();
      tcpHostTextField1 = new javax.swing.JTextField ();
      jLabel7 = new javax.swing.JLabel ();
      tcpPortTextField1 = new javax.swing.JTextField ();
      jPanel16 = new javax.swing.JPanel ();
      jLabel4 = new javax.swing.JLabel ();
      tcpHostTextField2 = new javax.swing.JTextField ();
      jLabel9 = new javax.swing.JLabel ();
      tcpPortTextField2 = new javax.swing.JTextField ();
      jPanel17 = new javax.swing.JPanel ();
      jButton7 = new javax.swing.JButton ();
      jPanel18 = new javax.swing.JPanel ();
      jButton8 = new javax.swing.JButton ();
      jPanel8 = new javax.swing.JPanel ();
      jPanel9 = new javax.swing.JPanel ();

      tcpHostTable1 = new javax.swing.JTable(new javax.swing.table.DefaultTableModel(Constants.TCPColumnNames,0) );
      tcpHostTable1.setPreferredScrollableViewportSize(new java.awt.Dimension(50,50));
      jScrollPane1 = new javax.swing.JScrollPane(tcpHostTable1);

      jPanel14 = new javax.swing.JPanel ();

      tcpHostTable2 = new javax.swing.JTable(new javax.swing.table.DefaultTableModel(Constants.TCPColumnNames,0) );
      tcpHostTable2.setPreferredScrollableViewportSize(new java.awt.Dimension(50,50));
      jScrollPane2 = new javax.swing.JScrollPane(tcpHostTable2);

      jPanel10 = new javax.swing.JPanel ();
      jButton4 = new javax.swing.JButton ();
      jPanel11 = new javax.swing.JPanel ();
      jButton5 = new javax.swing.JButton ();
      jPanel12 = new javax.swing.JPanel ();
      jButton1 = new javax.swing.JButton ();
      jButton2 = new javax.swing.JButton ();
      jButton3 = new javax.swing.JButton ();
      jPanel13 = new javax.swing.JPanel ();
      jLabel8 = new javax.swing.JLabel ();
      rbpTextField = new javax.swing.JTextField ();
      jPanel2 = new javax.swing.JPanel ();
      jPanel26 = new javax.swing.JPanel ();
      jButton6 = new javax.swing.JButton ();
      jPanel28 = new javax.swing.JPanel ();
      jPanel29 = new javax.swing.JPanel ();
      jLabel5 = new javax.swing.JLabel ();
      jLabel14 = new javax.swing.JLabel ();
      dteTextField1 = new javax.swing.JTextField ();
      linkComboBox1 = new javax.swing.JComboBox ();
      jPanel30 = new javax.swing.JPanel ();
      jLabel15 = new javax.swing.JLabel ();
      jLabel16 = new javax.swing.JLabel ();
      dteTextField2 = new javax.swing.JTextField ();
      linkComboBox2 = new javax.swing.JComboBox ();
      jPanel21 = new javax.swing.JPanel ();
      jButton11 = new javax.swing.JButton ();
      jPanel22 = new javax.swing.JPanel ();
      jButton12 = new javax.swing.JButton ();
      setLayout (new java.awt.BorderLayout ());

      jPanel1.setLayout (new java.awt.FlowLayout (0, 10, 5));
      jPanel1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 5, 2)));

        jLabel1.setText ("Protocol");
  
        jPanel1.add (jLabel1);
  
        transportTypeCombo.setActionCommand ("transportChanged");
        transportTypeCombo.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            transportChanged (evt);
          }
        }
        );
  
        jPanel1.add (transportTypeCombo);

        jPanel1.add(lwcHeaderCheckBox);

      add (jPanel1, java.awt.BorderLayout.NORTH);

      transportPanel.setLayout (new java.awt.CardLayout ());
      transportPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)));

  
        transportPanel.add (jPanel3, "TransportBlank");
  
        jPanel4.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints1;
  
          jPanel5.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
          jPanel5.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Home configuration", 2, 2),
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
    
            jLabel2.setText ("File name");
      
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.insets = new java.awt.Insets (0, 0, 0, 5);
            gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
            jPanel5.add (jLabel2, gridBagConstraints2);
      
      
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints2.weightx = 1.0;
            jPanel5.add (fileTextField1, gridBagConstraints2);
      
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridheight = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 0.5;
          gridBagConstraints1.weighty = 1.0;
          jPanel4.add (jPanel5, gridBagConstraints1);
    
          jPanel6.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints3;
          jPanel6.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Away configuration", 2, 2),
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
    
            jLabel3.setText ("File name");
      
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.insets = new java.awt.Insets (0, 0, 0, 5);
            gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
            jPanel6.add (jLabel3, gridBagConstraints3);
      
      
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints3.weightx = 1.0;
            jPanel6.add (fileTextField2, gridBagConstraints3);
      
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 2;
          gridBagConstraints1.gridy = 0;
          gridBagConstraints1.gridheight = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 0.5;
          gridBagConstraints1.weighty = 1.0;
          jPanel4.add (jPanel6, gridBagConstraints1);
    
    
            jButton10.setToolTipText ("Copy DC-I configuration to DC-II");
            jButton10.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton10.setText (">>>");
            jButton10.setActionCommand ("FileCopy1-2");
            jButton10.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel19.add (jButton10);
      
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 0;
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.SOUTH;
          gridBagConstraints1.weighty = 0.5;
          jPanel4.add (jPanel19, gridBagConstraints1);
    
    
            jButton9.setToolTipText ("Copy DC-II configuration to DC-I");
            jButton9.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton9.setText ("<<<");
            jButton9.setActionCommand ("FileCopy2-1");
            jButton9.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel20.add (jButton9);
      
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.NORTH;
          gridBagConstraints1.weighty = 0.5;
          jPanel4.add (jPanel20, gridBagConstraints1);
    
        transportPanel.add (jPanel4, "TransportFile");
  
        jPanel7.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints4;
  
          jPanel15.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints5;
          jPanel15.setBorder (new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Home configuration", 2, 2));
    
            jLabel6.setText ("Host name");
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.insets = new java.awt.Insets (0, 0, 3, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            jPanel15.add (jLabel6, gridBagConstraints5);
      
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (0, 0, 3, 0);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints5.weightx = 0.5;
            jPanel15.add (tcpHostTextField1, gridBagConstraints5);
      
            jLabel7.setText ("Service/Port");
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 0;
            gridBagConstraints5.gridy = 1;
            gridBagConstraints5.insets = new java.awt.Insets (3, 0, 0, 5);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            jPanel15.add (jLabel7, gridBagConstraints5);
      
      
            gridBagConstraints5 = new java.awt.GridBagConstraints ();
            gridBagConstraints5.gridx = 1;
            gridBagConstraints5.gridy = 1;
            gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints5.insets = new java.awt.Insets (3, 0, 0, 0);
            gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints5.weightx = 0.25;
            jPanel15.add (tcpPortTextField1, gridBagConstraints5);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridheight = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints4.weightx = 0.5;
          gridBagConstraints4.weighty = 1.0;
          jPanel7.add (jPanel15, gridBagConstraints4);
    
          jPanel16.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints6;
          jPanel16.setBorder (new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Away configuration", 2, 2));
    
            jLabel4.setText ("Host name");
      
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.insets = new java.awt.Insets (0, 0, 3, 5);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            jPanel16.add (jLabel4, gridBagConstraints6);
      
      
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints6.insets = new java.awt.Insets (0, 0, 3, 0);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints6.weightx = 0.5;
            jPanel16.add (tcpHostTextField2, gridBagConstraints6);
      
            jLabel9.setText ("Service/Port");
      
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.gridx = 0;
            gridBagConstraints6.gridy = 1;
            gridBagConstraints6.insets = new java.awt.Insets (3, 0, 0, 5);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            jPanel16.add (jLabel9, gridBagConstraints6);
      
      
            gridBagConstraints6 = new java.awt.GridBagConstraints ();
            gridBagConstraints6.gridx = 1;
            gridBagConstraints6.gridy = 1;
            gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints6.insets = new java.awt.Insets (3, 0, 0, 0);
            gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
            gridBagConstraints6.weightx = 0.25;
            jPanel16.add (tcpPortTextField2, gridBagConstraints6);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 2;
          gridBagConstraints4.gridy = 0;
          gridBagConstraints4.gridheight = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints4.weightx = 0.5;
          gridBagConstraints4.weighty = 1.0;
          jPanel7.add (jPanel16, gridBagConstraints4);
    
    
            jButton7.setToolTipText ("Copy DC-I configuration to DC-II");
            jButton7.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton7.setText (">>>");
            jButton7.setActionCommand ("TCPHostCopy1-2");
            jButton7.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel17.add (jButton7);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 0;
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.SOUTH;
          gridBagConstraints4.weighty = 0.5;
          jPanel7.add (jPanel17, gridBagConstraints4);
    
    
            jButton8.setToolTipText ("Copy DC-II configuration to DC-I");
            jButton8.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton8.setText ("<<<");
            jButton8.setActionCommand ("TCPHostCopy2-1");
            jButton8.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel18.add (jButton8);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 1;
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.NORTH;
          gridBagConstraints4.weighty = 0.5;
          jPanel7.add (jPanel18, gridBagConstraints4);
    
        transportPanel.add (jPanel7, "TransportTCPHost");
  
        jPanel8.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints7;
  
          jPanel9.setLayout (new javax.swing.BoxLayout (jPanel9, 0));
          jPanel9.setBorder (new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Home configuration", 2, 2));
    
      
            jPanel9.add (jScrollPane1);
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridheight = 2;
          gridBagConstraints7.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints7.weightx = 0.5;
          gridBagConstraints7.weighty = 1.0;
          jPanel8.add (jPanel9, gridBagConstraints7);
    
          jPanel14.setLayout (new javax.swing.BoxLayout (jPanel14, 0));
          jPanel14.setBorder (new javax.swing.border.TitledBorder(
          new javax.swing.border.EtchedBorder(), "Away configuration", 2, 2));
    
      
            jPanel14.add (jScrollPane2);
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 2;
          gridBagConstraints7.gridy = 0;
          gridBagConstraints7.gridheight = 2;
          gridBagConstraints7.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints7.weightx = 0.5;
          gridBagConstraints7.weighty = 1.0;
          jPanel8.add (jPanel14, gridBagConstraints7);
    
    
            jButton4.setToolTipText ("Copy DC-I configuration to DC-II");
            jButton4.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton4.setText (">>>");
            jButton4.setActionCommand ("TCPListCopy1-2");
            jButton4.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel10.add (jButton4);
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 1;
          gridBagConstraints7.gridy = 0;
          gridBagConstraints7.anchor = java.awt.GridBagConstraints.SOUTH;
          gridBagConstraints7.weighty = 0.5;
          jPanel8.add (jPanel10, gridBagConstraints7);
    
    
            jButton5.setToolTipText ("Copy DC-II configuration to DC-I");
            jButton5.setMargin (new java.awt.Insets(2, 2, 2, 2));
            jButton5.setText ("<<<");
            jButton5.setActionCommand ("TCPListCopy2-1");
            jButton5.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                copyHandler (evt);
              }
            }
            );
      
            jPanel11.add (jButton5);
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 1;
          gridBagConstraints7.gridy = 1;
          gridBagConstraints7.anchor = java.awt.GridBagConstraints.NORTH;
          gridBagConstraints7.weighty = 0.5;
          jPanel8.add (jPanel11, gridBagConstraints7);
    
    
            jButton1.setText ("Add");
            jButton1.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                tcpHostAction (evt);
              }
            }
            );
      
            jPanel12.add (jButton1);
      
            jButton2.setText ("Modify");
            jButton2.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                tcpHostAction (evt);
              }
            }
            );
      
            jPanel12.add (jButton2);
      
            jButton3.setText ("Delete");
            jButton3.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                tcpHostAction (evt);
              }
            }
            );
      
            jPanel12.add (jButton3);
      
          gridBagConstraints7 = new java.awt.GridBagConstraints ();
          gridBagConstraints7.gridx = 0;
          gridBagConstraints7.gridy = 2;
          gridBagConstraints7.gridwidth = 3;
          gridBagConstraints7.fill = java.awt.GridBagConstraints.BOTH;
          jPanel8.add (jPanel12, gridBagConstraints7);
    
        transportPanel.add (jPanel8, "TransportTCP");

        transportPanel.add(amqPanel, "TransportAMQ");
  
          jLabel8.setText ("Application ID");
    
          jPanel13.add (jLabel8);
    
          rbpTextField.setColumns (8);
          rbpTextField.setText ("0");
    
          jPanel13.add (rbpTextField);
    
        transportPanel.add (jPanel13, "TransportRBP");
  
        jPanel2.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints8;
  
    
            jButton6.setText ("Configure X.25 parameters");
            jButton6.setActionCommand ("SVC");
            jButton6.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                x25ActionHandler (evt);
              }
            }
            );
      
            jPanel26.add (jButton6);
      
          gridBagConstraints8 = new java.awt.GridBagConstraints ();
          gridBagConstraints8.gridx = 0;
          gridBagConstraints8.gridy = 1;
          gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints8.weightx = 1.0;
          jPanel2.add (jPanel26, gridBagConstraints8);
    
          jPanel28.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints9;
    
            jPanel29.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints10;
            jPanel29.setBorder (new javax.swing.border.CompoundBorder(
            new javax.swing.border.TitledBorder(
            new javax.swing.border.EtchedBorder(), "Home configuration", 2, 2),
            new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
      
              jLabel5.setText ("Link");
        
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.insets = new java.awt.Insets (0, 0, 3, 5);
              gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
              jPanel29.add (jLabel5, gridBagConstraints10);
        
              jLabel14.setText ("DTE Address");
        
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.gridx = 0;
              gridBagConstraints10.gridy = 1;
              gridBagConstraints10.insets = new java.awt.Insets (3, 0, 0, 5);
              gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
              jPanel29.add (jLabel14, gridBagConstraints10);
        
              dteTextField1.setColumns (16);
              dteTextField1.setText ("39990000000100");
        
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.gridx = 1;
              gridBagConstraints10.gridy = 1;
              gridBagConstraints10.insets = new java.awt.Insets (3, 0, 0, 0);
              gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
              jPanel29.add (dteTextField1, gridBagConstraints10);
        
              linkComboBox1.setEditable (true);
        
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.insets = new java.awt.Insets (0, 0, 3, 0);
              gridBagConstraints10.anchor = java.awt.GridBagConstraints.WEST;
              jPanel29.add (linkComboBox1, gridBagConstraints10);
        
            gridBagConstraints9 = new java.awt.GridBagConstraints ();
            gridBagConstraints9.gridheight = 2;
            gridBagConstraints9.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints9.weightx = 0.5;
            gridBagConstraints9.weighty = 1.0;
            jPanel28.add (jPanel29, gridBagConstraints9);
      
            jPanel30.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints11;
            jPanel30.setBorder (new javax.swing.border.CompoundBorder(
            new javax.swing.border.TitledBorder(
            new javax.swing.border.EtchedBorder(), "Away configuration", 2, 2),
            new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
      
              jLabel15.setText ("Link");
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.insets = new java.awt.Insets (0, 0, 3, 5);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
              jPanel30.add (jLabel15, gridBagConstraints11);
        
              jLabel16.setText ("DTE Address");
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.gridx = 0;
              gridBagConstraints11.gridy = 1;
              gridBagConstraints11.insets = new java.awt.Insets (3, 0, 0, 5);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
              jPanel30.add (jLabel16, gridBagConstraints11);
        
              dteTextField2.setColumns (16);
              dteTextField2.setText ("39990000000100");
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.gridx = 1;
              gridBagConstraints11.gridy = 1;
              gridBagConstraints11.insets = new java.awt.Insets (3, 0, 0, 0);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
              jPanel30.add (dteTextField2, gridBagConstraints11);
        
              linkComboBox2.setEditable (true);
        
              gridBagConstraints11 = new java.awt.GridBagConstraints ();
              gridBagConstraints11.insets = new java.awt.Insets (0, 0, 3, 0);
              gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
              jPanel30.add (linkComboBox2, gridBagConstraints11);
        
            gridBagConstraints9 = new java.awt.GridBagConstraints ();
            gridBagConstraints9.gridx = 2;
            gridBagConstraints9.gridy = 0;
            gridBagConstraints9.gridheight = 2;
            gridBagConstraints9.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints9.weightx = 0.5;
            gridBagConstraints9.weighty = 1.0;
            jPanel28.add (jPanel30, gridBagConstraints9);
      
      
              jButton11.setToolTipText ("Copy DC-I configuration to DC-II");
              jButton11.setMargin (new java.awt.Insets(2, 2, 2, 2));
              jButton11.setText (">>>");
              jButton11.setActionCommand ("X25Copy1-2");
              jButton11.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  copyHandler (evt);
                }
              }
              );
        
              jPanel21.add (jButton11);
        
            gridBagConstraints9 = new java.awt.GridBagConstraints ();
            gridBagConstraints9.gridx = 1;
            gridBagConstraints9.gridy = 0;
            gridBagConstraints9.anchor = java.awt.GridBagConstraints.SOUTH;
            gridBagConstraints9.weighty = 0.5;
            jPanel28.add (jPanel21, gridBagConstraints9);
      
      
              jButton12.setToolTipText ("Copy DC-II configuration to DC-I");
              jButton12.setMargin (new java.awt.Insets(2, 2, 2, 2));
              jButton12.setText ("<<<");
              jButton12.setActionCommand ("X25Copy2-1");
              jButton12.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  copyHandler (evt);
                }
              }
              );
        
              jPanel22.add (jButton12);
        
            gridBagConstraints9 = new java.awt.GridBagConstraints ();
            gridBagConstraints9.gridx = 1;
            gridBagConstraints9.gridy = 1;
            gridBagConstraints9.anchor = java.awt.GridBagConstraints.NORTH;
            gridBagConstraints9.weighty = 0.5;
            jPanel28.add (jPanel22, gridBagConstraints9);
      
          gridBagConstraints8 = new java.awt.GridBagConstraints ();
          gridBagConstraints8.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints8.weightx = 1.0;
          jPanel2.add (jPanel28, gridBagConstraints8);
    
        transportPanel.add (jPanel2, "TransportX25");
  

      add (transportPanel, java.awt.BorderLayout.CENTER);

    }//GEN-END:initComponents

private void copyHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyHandler
// Add your handling code here:

    String action = evt.getActionCommand();
    if (action.startsWith("File")) {
	javax.swing.JTextField src = fileTextField1;
	javax.swing.JTextField dst = fileTextField2;
	
	if (action.endsWith("2-1")) {
	    src = fileTextField2;
	    dst = fileTextField1;
	}

	dst.setText(src.getText());
    }

    if (action.startsWith("TCPHost")) {
	javax.swing.JTextField src1 = tcpHostTextField1;
	javax.swing.JTextField src2 = tcpPortTextField1;
	javax.swing.JTextField dst1 = tcpHostTextField2;
	javax.swing.JTextField dst2 = tcpPortTextField2;
	if (action.endsWith("2-1")) {
	    src1 = tcpHostTextField2;
	    src2 = tcpPortTextField2;
	    dst1 = tcpHostTextField1;
	    dst2 = tcpPortTextField1;
	}
	dst1.setText(src1.getText());
	dst2.setText(src2.getText());
    }

    if (action.startsWith("X25")) {
	javax.swing.JComboBox src1 = linkComboBox1;
	javax.swing.JTextField src2 = dteTextField1;
	javax.swing.JComboBox dst1 = linkComboBox2;
	javax.swing.JTextField dst2 = dteTextField2;
	if (action.endsWith("2-1")) {
	    src1 = linkComboBox2;
	    src2 = dteTextField2;
	    dst1 = linkComboBox1;
	    dst2 = dteTextField1;
	}
	dst1.setSelectedItem(src1.getSelectedItem());
	dst2.setText(src2.getText());
    }

    if (action.startsWith("TCPListCopy")) {
	javax.swing.table.DefaultTableModel src =
	    (javax.swing.table.DefaultTableModel)tcpHostTable1.getModel();
	javax.swing.table.DefaultTableModel dst =
	    (javax.swing.table.DefaultTableModel)tcpHostTable2.getModel();

	if (action.endsWith("2-1")) {
	    src = (javax.swing.table.DefaultTableModel)tcpHostTable2.getModel();
	    dst = (javax.swing.table.DefaultTableModel)tcpHostTable1.getModel();;
	}

	int nrows = src.getRowCount();
	//dst.setRowCount(0);
	dst.setNumRows(0);
	for (int i = 0; i < nrows; i++) {
	    String h = (String)src.getValueAt(i,0);
	    String p = (String)src.getValueAt(i,1);
	    String row[] = new String[2];
	    if (h!=null) row[0] = new String(h);
	    if (p!=null) row[1] = new String(p);
	    dst.addRow(row);
	} 
	dst.fireTableDataChanged();

    }   
	
  }//GEN-LAST:event_copyHandler





    public boolean isValidX25Address(String type, String l1, String d1)
    {

	if (type.startsWith("SVC")) {
	    if ((l1!=null)&&(d1!=null)&&(!l1.equals("Select"))
		&&(!l1.equals("Enter"))&&(l1.length()>0)&&(d1.length()>0)) {
		
		try {
		    int lnk = Integer.parseInt(l1);
		    if ( (lnk < Constants.MIN_X25_LINKID)
			 || (lnk > Constants.MAX_X25_LINKID) )
			return false;
		    Long.parseLong(d1);
		    return true;
		} catch (NumberFormatException nfe){

		}

	    }

	} else if (type.startsWith("PVC")){
	    
	    if ((l1!=null)&&(!l1.equals("Select"))&&(!l1.equals("Enter"))
		&&(l1.length()>0)) {
		
		try {
		    int lnk = Integer.parseInt(l1);
		    if ( (lnk < Constants.MIN_X25_LINKID)
			 || (lnk > Constants.MAX_X25_LINKID) )
			return false;
		    return true;
		} catch (NumberFormatException nfe){

		}
	    }
	}

	return false;

    }





private void x25ActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_x25ActionHandler
// Add your handling code here:
    String action = (String)transportTypeCombo.getSelectedItem();
    String link1 = null, link2 = null;

    String l1=null, l2=null, d1=null, d2=null;

    if (action.startsWith("SVC")) {
	l1 = (String)linkComboBox1.getSelectedItem();
	d1 = dteTextField1.getText().trim();
	l2 = (String)linkComboBox2.getSelectedItem();
	d2 = dteTextField2.getText().trim();
	
	
	if (isValidX25Address(action,l1,d1))
	    link1 = l1+"."+d1;
	
	if (isValidX25Address(action,l2,d2))
	    link2 = l2+"."+d2;

	if ((link1==null)&&(link2==null)){
	    Utils.showDialog(this,"Please enter link[0-255]/DTE.");
	    return;
	}
	  
    } else if (action.startsWith("PVC")) {
	l1 = (String)linkComboBox1.getSelectedItem();
	l2 = (String)linkComboBox2.getSelectedItem();
	
	if (isValidX25Address(action, l1, null))
	    link1 = l1;
	
	if (isValidX25Address(action, l2, null))
	    link2 = l2;
	
	if ((link1==null) && (link2==null)) {
	    Utils.showDialog(this,"Please enter a link[0-255].");
	    return;
	}
    } else
      return;
    
    

    
    try {
	javax.swing.JFrame pfrm = new javax.swing.JFrame();
	javax.swing.JDialog pdlg = new javax.swing.JDialog();
	if (parentFrame instanceof javax.swing.JDialog)
	    pdlg = (javax.swing.JDialog)parentFrame;
	else if (parentFrame instanceof javax.swing.JFrame)
	    pfrm = (javax.swing.JFrame)parentFrame;
	
	

      new X25LinkDialog(pfrm, true, 
                  distrTag, dcmTag, hostList1,hostList2,link1, link2, 
                  action).show();

    } catch (Exception e) {
	Utils.showDialog(parentFrame, "Error in creating X25 dialog: \n"
			+e.getMessage());
	Log.getInstance().log_error("Error in creating X25 dialog: \n"
				    +distrTag+","+dcmTag+","
				    +hostList1+","+hostList2+","
				    +link1+","+link2+","+action, e);
    }

    
  }//GEN-LAST:event_x25ActionHandler




    private void deleteSelection(javax.swing.JTable table)
    {
	javax.swing.table.DefaultTableModel model =
	    (javax.swing.table.DefaultTableModel)table.getModel();
	int nrows = model.getRowCount();

	int srows[] = table.getSelectedRows();
	if (srows.length == 0) return;
	
	if (srows.length==1) {
	    model.removeRow(srows[0]);
	} else {
	    String hosts[] = new String[srows.length];
	    String ports[] = new String[srows.length];
	    for (int i = 0; i < srows.length; i++) {
		hosts[i] = new String((String)model.getValueAt(srows[i],0));
		ports[i] = new String((String)model.getValueAt(srows[i],1));        
	    }
	    
	    for (int i=0; i< srows.length; i++) {
		for (int r = 0; r < model.getRowCount(); r++) {
		    String h = (String)model.getValueAt(r,0);
		    String p = (String)model.getValueAt(r,1);
		    
		    if (h.equals(hosts[i]) && p.equals(ports[i])) {            
			model.removeRow(r);
			//model.fireTableRowsDeleted(r,r);
			break;
		    }
		}
	    }
	}
	model.fireTableDataChanged();
	
    }

    
    String[] createHostServiceList(javax.swing.JTable table)
    {
	javax.swing.table.DefaultTableModel model =
	    (javax.swing.table.DefaultTableModel)table.getModel();
	int nrows = model.getRowCount();

	if (nrows == 0) return null;


	String[] validateList = new String[nrows];
	for (int i=0; i < nrows; i++) {
	    StringBuffer s = new StringBuffer();
	    String h = (String)model.getValueAt(i,0);
	    String p = (String)model.getValueAt(i,1);
	    
	    if (h!=null && (h.length()>0))
		s.append(h).append(":");
	    
	    s.append(p);
	    validateList[i] = s.toString();
	}

	return validateList;

    }




    private void tcpHostAction (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcpHostAction
	// Add your handling code here:

	String action = evt.getActionCommand();

	javax.swing.table.DefaultTableModel model1 =
	    (javax.swing.table.DefaultTableModel)tcpHostTable1.getModel();
	int nrows1 = model1.getRowCount();
	javax.swing.table.DefaultTableModel model2 =
	    (javax.swing.table.DefaultTableModel)tcpHostTable2.getModel();
	int nrows2 = model2.getRowCount();

	TCPHostServiceDialog dlg;
	javax.swing.JDialog pdlg = null;
	javax.swing.JFrame pfrm = null;

	if (parentFrame instanceof javax.swing.JDialog)
	    pdlg = (javax.swing.JDialog)parentFrame;
	else if (parentFrame instanceof javax.swing.JFrame)
	    pfrm = (javax.swing.JFrame)parentFrame;
		
	if (action.equals("Add")) {

	    if ( (nrows1 == Constants.MAX_TCP_ADDRESS)
		 && (nrows2 == Constants.MAX_TCP_ADDRESS) ){
		javax.swing.JOptionPane.showMessageDialog(this,
				  "Only "+Constants.MAX_TCP_ADDRESS
				  +" hosts are allowed","Error",
				  javax.swing.JOptionPane.ERROR_MESSAGE);
		return;
	    }


	    String [] validateList1 = createHostServiceList(tcpHostTable1);
	    String [] validateList2 = createHostServiceList(tcpHostTable2);

	    int scope = 0;
	    if (nrows1==Constants.MAX_TCP_ADDRESS) scope = 2;
	    if (nrows2==Constants.MAX_TCP_ADDRESS) scope = 1;


	    if (pdlg!=null)
		dlg = new TCPHostServiceDialog(pdlg,true,
					       validateList1,
					       validateList2,
					       null,scope);
	    else
		dlg = new TCPHostServiceDialog(pfrm,true,
					       validateList1,
					       validateList2,
					       null,scope);
			
	   

	    dlg.show();
	    String addr = dlg.getHostAddress();
	    scope = dlg.getScope();
	    if (addr == null) 
		return;

	    int index = addr.indexOf(":");
	    String h = addr.substring(0,index);
	    String s = addr.substring(index+1);
	    
	    if ( (scope==0) || (scope==1)) {

		if  (model1.getRowCount() == Constants.MAX_TCP_ADDRESS) {
		    javax.swing.JOptionPane.showMessageDialog(this,
				  "DC-I:Only "+Constants.MAX_TCP_ADDRESS
				  +" hosts are allowed","Error",
				  javax.swing.JOptionPane.ERROR_MESSAGE);
		} else {
		    
		    String [] a = new String[2];
		    a[0] = h;
		    a[1] = s;
		    model1.addRow(a);
		    model1.fireTableDataChanged();
		}
	    }
	    
	    if ( (scope==0) || (scope==2)) {

		if  (model2.getRowCount() == Constants.MAX_TCP_ADDRESS) {
		    javax.swing.JOptionPane.showMessageDialog(this,
				  "DC-II:Only "+Constants.MAX_TCP_ADDRESS
				  +" hosts are allowed","Error",
				  javax.swing.JOptionPane.ERROR_MESSAGE);
		} else {

		    String [] a = new String[2];
		    a[0] = new String(h);
		    a[1] = new String(s);
		    model2.addRow(a);
		    model2.fireTableDataChanged();
		}
	    }

	} /* Add*/



	if (action.equals("Modify")) {
	    int srows1[] = tcpHostTable1.getSelectedRows();
	    int srows2[] = tcpHostTable2.getSelectedRows();
	    if ((srows1.length == 0)
		&& (srows2.length == 0) )
		return;

	    int srow1=-1,srow2=-1;

	    if (srows1.length >0) srow1= srows1[0];
	    if (srows2.length >0) srow2= srows2[0];

	    String [] validateList1 = createHostServiceList(tcpHostTable1);
	    String [] validateList2 = createHostServiceList(tcpHostTable2);

	    int scope = 0;
	    if (srows1.length==0) scope = 2;
	    if (srows2.length==0) scope = 1;




	    StringBuffer hstr = new StringBuffer();
	    String h=null,p=null;

	    if (scope==2) {
		h = (String)model2.getValueAt(srow2,0);
		p = (String)model2.getValueAt(srow2,1);
	    } else {
		h = (String)model1.getValueAt(srow1,0);
		p = (String)model1.getValueAt(srow1,1);
	    }

	    if (h!=null && (h.length()>0))
		hstr.append(h).append(":");

	    hstr.append(p);

	    
	    if (pdlg!=null)
		dlg = new TCPHostServiceDialog(pdlg,true,
					       validateList1,
					       validateList2,
					       hstr.toString(),
					       scope);
	    else
		dlg = new TCPHostServiceDialog(pfrm,true,
					       validateList1,
					       validateList2,
					       hstr.toString(),
					       scope);

	    dlg.show();
	    String addr = dlg.getHostAddress();
	    if (addr == null) 
		return;

	    scope = dlg.getScope();
	    
	    int index = addr.indexOf(":");
	    String h1 = addr.substring(0,index);
	    String s1 = addr.substring(index+1);
	    
	    if ( (srow1!=-1) && ((scope==0) || (scope==1)) ) {
		model1.setValueAt(h1,srow1,0);
		model1.setValueAt(s1,srow1,1);
		model1.fireTableDataChanged();
	    }
	    if ( (srow2!=-1) && ((scope==0) || (scope==2)) ) {
		model2.setValueAt(h1,srow2,0);
		model2.setValueAt(s1,srow2,1);
		model2.fireTableDataChanged();
	    }
	    
	} /* Modify */

	if (action.equals("Delete")) {

	    deleteSelection(tcpHostTable1);
	    deleteSelection(tcpHostTable2);
	}


    }//GEN-LAST:event_tcpHostAction




    private void transportChanged (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transportChanged
	// Add your handling code here:

	java.awt.CardLayout l = (java.awt.CardLayout)transportPanel.getLayout();
	
	
	String selectstr = (String)transportTypeCombo.getSelectedItem();
	if (selectstr==null) return;


        if (selectstr.startsWith("TCP")) {
          l.show((java.awt.Container)transportPanel,"TransportTCP");
        } else if (selectstr.startsWith("ASYNC")) {
          l.show((java.awt.Container)transportPanel,"TransportTCPHost");
        } else if (selectstr.startsWith("PVC")) {
          l.show((java.awt.Container)transportPanel,"TransportX25");
          jLabel14.setEnabled(false);
          dteTextField1.setEnabled(false);
          jLabel16.setEnabled(false);
          dteTextField2.setEnabled(false);
        } else if (selectstr.startsWith("SVC")) {
          l.show((java.awt.Container)transportPanel,"TransportX25");
          jLabel14.setEnabled(true);
          dteTextField1.setEnabled(true);
          jLabel16.setEnabled(true);
          dteTextField2.setEnabled(true);          
        } else if (selectstr.startsWith("FILE")) {
          l.show((java.awt.Container)transportPanel,"TransportFile");
        } else if (selectstr.startsWith("RBP")) {
          l.show((java.awt.Container)transportPanel,"TransportRBP");
        } else if (selectstr.startsWith("AM")) {
            l.show((java.awt.Container)transportPanel,"TransportAMQ");            
        }else {
          l.show((java.awt.Container)transportPanel,"TransportBlank");
        }

        transportString = new String(selectstr);


        if (Utils.isX25TransportType(transportString)) {
          loadLinks(null, null);
        }

    }//GEN-LAST:event_transportChanged

  
  public static void main (String args[]) {
    
    try {
      ConfigComm.initLogin("test","dist-c1q1,dist-c1q2","/ids2");
      java.util.Vector tl = ConfigComm.getTransportTypeList();
      
      javax.swing.JFrame frame = new javax.swing.JFrame();
      TransportConfigPanel panel 
        = new TransportConfigPanel(frame,"Data center-I",
            tl,"DCMQ3","X25T","SVCIN 5.399", "SVCIN 10.5646456", true);
      frame.getContentPane().add(panel);
      frame.pack();
      frame.show ();
     } catch (Exception e) {e.printStackTrace();}
  }

  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel1;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JComboBox transportTypeCombo;
  private javax.swing.JPanel transportPanel;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JTextField fileTextField1;
  private javax.swing.JPanel jPanel6;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JTextField fileTextField2;
  private javax.swing.JPanel jPanel19;
  private javax.swing.JButton jButton10;
  private javax.swing.JPanel jPanel20;
  private javax.swing.JButton jButton9;
  private javax.swing.JPanel jPanel7;
  private javax.swing.JPanel jPanel15;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JTextField tcpHostTextField1;
  private javax.swing.JLabel jLabel7;
  private javax.swing.JTextField tcpPortTextField1;
  private javax.swing.JPanel jPanel16;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JTextField tcpHostTextField2;
  private javax.swing.JLabel jLabel9;
  private javax.swing.JTextField tcpPortTextField2;
  private javax.swing.JPanel jPanel17;
  private javax.swing.JButton jButton7;
  private javax.swing.JPanel jPanel18;
  private javax.swing.JButton jButton8;
  private javax.swing.JPanel jPanel8;
  private javax.swing.JPanel jPanel9;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JPanel jPanel14;
  private javax.swing.JScrollPane jScrollPane2;
  private javax.swing.JPanel jPanel10;
  private javax.swing.JButton jButton4;
  private javax.swing.JPanel jPanel11;
  private javax.swing.JButton jButton5;
  private javax.swing.JPanel jPanel12;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel13;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JTextField rbpTextField;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JPanel jPanel26;
  private javax.swing.JButton jButton6;
  private javax.swing.JPanel jPanel28;
  private javax.swing.JPanel jPanel29;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JLabel jLabel14;
  private javax.swing.JTextField dteTextField1;
  private javax.swing.JComboBox linkComboBox1;
  private javax.swing.JPanel jPanel30;
  private javax.swing.JLabel jLabel15;
  private javax.swing.JLabel jLabel16;
  private javax.swing.JTextField dteTextField2;
  private javax.swing.JComboBox linkComboBox2;
  private javax.swing.JPanel jPanel21;
  private javax.swing.JButton jButton11;
  private javax.swing.JPanel jPanel22;
  private javax.swing.JButton jButton12;
  // End of variables declaration//GEN-END:variables

}

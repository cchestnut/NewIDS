/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author srz
 */
public class ApplyPremiumCodes {

    static void addKeyValue(StringBuffer p, String key, String value, char sep) {
        p.append(key).append(sep).append(value).append(sep);
    }

    static void addStrKeyValue(StringBuffer p, String key, String value) {
        addKeyValue(p, key, value, CONF_FS);
    }

    static void addRecordKeyValue(StringBuffer p, String key, String value) {
        addKeyValue(p, key, value, CONF_RS);
    }

    public static String convertHashMap(StringBuffer ib, String config_key, int config_type,
            java.util.HashMap map,
            String null_value, boolean ignore_empty) {

        StringBuffer buf = ib;


        if (buf == null) {
            buf = new StringBuffer();
        }


        java.util.Iterator key_iterator = map.keySet().iterator();

        int count = map.size();


        for (int i = 0; i < count; i++) {
            String key = (String) key_iterator.next();
            String value = (String) map.get(key);

            if (value == null) {
                if (null_value != null) {
                    value = null_value;
                } else {
                    continue;
                }
            }



            if ((value.length() == 0)
                    && ignore_empty) {
                continue;
            }


            addRecordKeyValue(buf, key, value);
        }




        return buf.toString();

    }

    public static ByteBuffer applyCodes(CodesConfig codescfg,
            HashMap<String, String> wholesaleDCMs,
            String skey,
            ByteBuffer content)
            throws FileNotFoundException, IOException, ParseException, Exception {


        final String glbprfx = "GLB_TAG_DISTR_";
        if (!skey.startsWith(glbprfx)) {
            return null;
        }

        String did = skey.substring(glbprfx.length());
        if ((codescfg != null) && !codescfg.isValid(did)) {
            return null;
        }


        HashMap map = load(content);
        String tag = (String) map.get("TAG");

        if (!tag.startsWith("GLB_TAG_DCM")) {
            return null;
        }
        boolean is_wholesale = (wholesaleDCMs!=null)?wholesaleDCMs.containsKey(tag):false;

        updateProducts(did, "PRODUCTS_1", map, is_wholesale, codescfg);
        updateProducts(did, "PRODUCTS_2", map, is_wholesale, codescfg);



        StringBuffer reqbuf = new StringBuffer();

        int db_req = Config.SAVE_DISTRIBUTOR_KEY;


        convertHashMap(reqbuf, skey, db_req, map, null, true);

        ByteBuffer bb = content.duplicate();
        byte[] bt = new byte[content.capacity()];
        bb.flip();
        bb.get(bt);

        //System.out.println(skey+" Before Ser: "+new String(bt)+"\n");
        //System.out.println(skey+" After Ser: "+reqbuf.toString()+"\n");
        ByteBuffer ncontent = ByteBuffer.allocateDirect(reqbuf.length());
        ncontent.put(reqbuf.toString().getBytes());
        ncontent.flip();
        return ncontent;

    }
    static final char CONF_RS = '\u001E';
    static final char CONF_FS = '\u001F';
    static final char CONF_ETX = '\u0003';

    public static HashMap load(ByteBuffer buf) {

        byte b[] = new byte[buf.capacity()];
        buf.get(b);
        String databuf = new String(b);

//System.out.println("IN LOAD "+buf.capacity()+"'"+databuf+"'");

        StringBuilder separator = new StringBuilder();
        separator.append(CONF_ETX).
                append(CONF_RS);

        java.util.StringTokenizer st =
                new java.util.StringTokenizer(databuf,
                separator.toString());
        HashMap map = new java.util.HashMap(10);

        String key, value;

        while (st.hasMoreTokens()) {

            key = st.nextToken();
            key.trim();

            if (st.hasMoreTokens()) {
                value = st.nextToken();
                value.trim();
            } else {
                continue;
            }

            if (key.length() > 0) {
                //System.out.println("Adding key:'"+key+"' Value:'"+value+"'");
                map.put(key, value);
            }
        } /*
         * while
         */



        return map;
    }

    private static void updateProducts(String skey,
            String key, HashMap map,
            boolean is_wholesale, CodesConfig codescfg) {
        String products = (String) map.get(key);
        if (products != null) {


            List<DistributorProductConfiguration> plist = DistributorProductConfiguration.parse(skey, products, is_wholesale, codescfg);

//            for (DistributorProductConfiguration dpc : plist) {
//                dpc.print(System.out);
//            }

            String nproducts = DistributorProductConfiguration.pack(plist);

            System.out.println("<====" + skey + "===== " + key);
            System.out.println("\nBEFORE: " + products);
            System.out.println("\nAFTER : " + nproducts);
            System.out.println(key + " ====" + skey + "=====>\n");
            map.put(key, nproducts);
        }

    }
}

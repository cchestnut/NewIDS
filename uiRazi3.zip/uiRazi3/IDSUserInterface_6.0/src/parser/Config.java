/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class Config {

    public static final char CONF_SOH = '\u0001';
    public static final char CONF_STX = '\u0002';
    public static final char CONF_ETX = '\u0003';
    public static final char CONF_RS = '\u001E';
    public static final char CONF_FS = '\u001F';
    public static final char CONF_GS = '\u001D';
    public static final char CONF_US = '\u0009';
    public static final int SAVE_DISTRIBUTOR_KEY = 1008;
    public static String DerivedDataOptions[] = {/*
         * "No"
         */"NONE", "Word Count (Full)", "Word Count (No Text)", "Word Count (Full with positions)", "Word Count (No Text with positions)"};
    public static String DefaultDerivedDataDictOptions[] = {"NONE", "ND_Total", "ND_Custom", "ALP2", "ALP3"};
    public static String OutputLanguageOptions[] = {"Default", "Auto"};
    public static String OutputEncodingOptions[] = {"Default", "Auto", "UTF-8"};
    public static int DISTR_PRODUCT_FLAG_DERIVED_ONLY = 4;
    public static int DISTR_PRODUCT_FLAG_DERIVED_FULL = 8;
    public static int DISTR_PRODUCT_FLAG_DERIVED_POSITIONS = 16;
    //public static String DEFAULT_PREMIUM_CODES_LIST = "<P/PRT ,Premium RT><P/PRD ,Premium Delayed>";
    public static String DEFAULT_PREMIUM_CODES_LIST = "<P/PRE ,Premium RT><P/STD ,Premium Delayed>";
    public static String GLB_TAG_PREMIUM_FILTER_CODES = "GLB_TAG_PREMIUM_FILTER_CODES";

    public static String getDerivedDataDictionary(String s) {
        if (s != null) {
            int inx = s.indexOf("|");
            if (inx > 0) {
                String s1 = s.substring(inx + 1);
                return s1;
            }
        }
        return "NONE";
    }

    public static int getDerivedDataOptionFlag(String s) {
        if (s != null) {
            int inx = s.indexOf("|");
            if (inx > 0) {
                String s1 = s.substring(0, inx + 1);
                s = s1;
            }
            if (s.equals(DerivedDataOptions[1])) {
                return DISTR_PRODUCT_FLAG_DERIVED_FULL;
            } else if (s.equals(DerivedDataOptions[2])) {
                return DISTR_PRODUCT_FLAG_DERIVED_ONLY;
            } else if (s.equals(DerivedDataOptions[3])) {
                return DISTR_PRODUCT_FLAG_DERIVED_FULL | DISTR_PRODUCT_FLAG_DERIVED_POSITIONS;
            } else if (s.equals(DerivedDataOptions[4])) {
                return DISTR_PRODUCT_FLAG_DERIVED_ONLY | DISTR_PRODUCT_FLAG_DERIVED_POSITIONS;
            }
        }
        return 0;
    }

    public static String getDerivedDataOptionString(long o) {

        if (((o & DISTR_PRODUCT_FLAG_DERIVED_ONLY) > 0)
                && ((o & DISTR_PRODUCT_FLAG_DERIVED_POSITIONS) > 0)) {
            return DerivedDataOptions[4];
        } else if (((o & DISTR_PRODUCT_FLAG_DERIVED_FULL) > 0)
                && ((o & DISTR_PRODUCT_FLAG_DERIVED_POSITIONS) > 0)) {
            return DerivedDataOptions[3];
        } else if ((o & DISTR_PRODUCT_FLAG_DERIVED_ONLY) > 0) {
            return DerivedDataOptions[2];
        } else if ((o & DISTR_PRODUCT_FLAG_DERIVED_FULL) > 0) {
            return DerivedDataOptions[1];
        }

        return DerivedDataOptions[0];
    }
}

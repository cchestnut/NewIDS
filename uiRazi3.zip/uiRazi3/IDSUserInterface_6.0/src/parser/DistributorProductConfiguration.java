/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

//import ids2ui.Config;
//import ids2ui.Config;
//import ids2ui.DistrProductStructure;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import model.DistributorProductFlagOptions;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class DistributorProductConfiguration {

    
    
    public static List<DistributorProductConfiguration> parse(String prod_str) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    String productID;
    String format;
    int delay;
    boolean freewheel;
    boolean removeLinks;
    boolean sigAbout;
    String lexiconType;
    String lexiconDictionary;
    String entitlementCodesTag;
    String language;
    String encoding;
    String premiumCodes;
    public static int DISTR_PROD_FREEWHEEL = 1;
    public static int DISTR_PROD_NEWSPLUS = 2;

    
    
    

    

    public static final HashMap<String,String> pcMap
            = new HashMap<String,String>();
    
    static {
	 
	pcMap.put("AD","NONE");
	pcMap.put("RT","NONE");
	pcMap.put("SY","NONE");
	pcMap.put("TL","NONE");
	pcMap.put("AE","( P/STD )");
	pcMap.put("AN","( P/STD )");
	pcMap.put("BT","( P/STD )");
	pcMap.put("CM","( P/STD )");
	pcMap.put("CS","( P/STD )");
	pcMap.put("DI","( P/STD )");
	pcMap.put("DN","( P/STD )");
	pcMap.put("DS","( P/STD )");
	pcMap.put("EM","( P/STD )");
	pcMap.put("ES","( P/STD )");
	pcMap.put("FF","( P/STD )");
	pcMap.put("FX","( P/STD )");
	pcMap.put("GM","( P/STD )");
	pcMap.put("IB","( P/STD )");
	pcMap.put("MD","( P/STD )");
	pcMap.put("ON","( P/STD )");
	pcMap.put("QA","( P/STD )");
	pcMap.put("QB","( P/STD )");
	pcMap.put("TC","( P/STD )");
	pcMap.put("TT","( P/STD )");
	pcMap.put("AR","( P/PRE | P/STD )");
	pcMap.put("CH","( P/PRE | P/STD )");
	pcMap.put("DU","( P/PRE | P/STD )");
	pcMap.put("FR","( P/PRE | P/STD )");
	pcMap.put("GE","( P/PRE | P/STD )");
	pcMap.put("GK","( P/PRE | P/STD )");
	pcMap.put("IT","( P/PRE | P/STD )");
	pcMap.put("JA","( P/PRE | P/STD )");
	pcMap.put("KR","( P/PRE | P/STD )");
	pcMap.put("LL","( P/PRE | P/STD )");
	pcMap.put("PE","( P/PRE | P/STD )");
	pcMap.put("PT","( P/PRE | P/STD )");
	pcMap.put("RX","( P/PRE | P/STD )");
	pcMap.put("SF","( P/PRE | P/STD )");
	pcMap.put("SW","( P/PRE | P/STD )");
	pcMap.put("TU","( P/PRE | P/STD )");
	pcMap.put("BA","( P/PRE | P/STD )");
	pcMap.put("FE","( P/PRE | P/STD )");
	pcMap.put("LA","( P/PRE | P/STD )");
	pcMap.put("NF","( P/PRE | P/STD )");
	pcMap.put("PB","( P/PRE | P/STD )");
	pcMap.put("SJ","( P/PRE | P/STD )");
	pcMap.put("SM","( P/PRE | P/STD )");
	pcMap.put("WA","( P/PRE | P/STD )");
	pcMap.put("WE","( P/PRE | P/STD )");
	pcMap.put("WJ","( P/PRE | P/STD )");
	pcMap.put("CD","( P/PRE | P/STD )");
	pcMap.put("DW","( P/PRE | P/STD )");
	pcMap.put("MS","( P/PRE | P/STD )");
	pcMap.put("MW","( P/PRE | P/STD )");
	pcMap.put("ND","( P/PRE | P/STD )");
	pcMap.put("PD","( P/PRE | P/STD )");
	pcMap.put("PI","( P/PRE | P/STD )");
	pcMap.put("PR","( P/PRE | P/STD )");
	pcMap.put("RN","( P/PRE | P/STD )");
	pcMap.put("SN","( P/PRE | P/STD )");
	pcMap.put("TG","( P/PRE | P/STD )");
	pcMap.put("WM","( P/PRE | P/STD )");
	pcMap.put("ZW","( P/PRE | P/STD )");
}
    
    
    public static String getDefaultPremiumCode(String product)
    {
        return pcMap.get(product);
    }
    
    
    public final static String NONE = "NONE";
    public final static String DEFAULT = "Default";
    public final static String PREMIUM = "( P/PRE )";
    public final static String STANDARD = "( P/STD )";
    public final static String BOTH = "( P/PRE | P/STD )";
    
            
    public DistributorProductConfiguration() {
        productID = "";
        format = "";
        delay = 0;
        freewheel = false;
        removeLinks = false;
        sigAbout = false;
        lexiconType = DistributorProductFlagOptions.getDerivedDataOption(0);
        lexiconDictionary = NONE;
        entitlementCodesTag = NONE;
        language = DEFAULT;
        encoding = DEFAULT;        
        premiumCodes = STANDARD;
    }

    public static boolean compareStrings(String a, String b)
    {
        if ((a == null) && (b == null)) {
            return true;
        }
        if ((a != null) && (b != null)) {
            return a.equals(b);
        }
        
        return false;
    }
    
    public boolean equals(DistributorProductConfiguration other) {

        if (compareStrings(productID,other.productID) 
                && compareStrings(format, other.format)
                && (delay == other.delay) 
                && (freewheel == other.freewheel)
                && (removeLinks == other.removeLinks)
                && (sigAbout == other.sigAbout)
                && compareStrings(lexiconType, other.lexiconType)
                && compareStrings(lexiconDictionary, other.lexiconDictionary)
                && compareStrings(entitlementCodesTag, other.entitlementCodesTag)
                && compareStrings(language, other.language)
                && compareStrings(encoding, other.encoding)
                && compareStrings(premiumCodes, other.premiumCodes) ) {
            return true;
        }

        return false;
    }

    public static String pack(List<DistributorProductConfiguration> list) {
        StringBuilder savebuf = new StringBuilder();


        for (DistributorProductConfiguration dpc : list) {

            Long flags = DistributorProductFlagOptions.getFlag(dpc.freewheel,
                    dpc.removeLinks,
                    dpc.lexiconType, dpc.sigAbout);

//System.out.println("#Product: "+dpc.productID+" FW:"+dpc.freewheel
//        +" RL: "+dpc.removeLinks+" LT: "+dpc.lexiconType
//        +" Flags: "+flags);

            savebuf.append("<");
            savebuf.append(Config.CONF_US).append(dpc.productID);
            savebuf.append(Config.CONF_US).append(dpc.format);
            savebuf.append(Config.CONF_US).append(Integer.toString(dpc.delay));
            savebuf.append(Config.CONF_US).append(flags.toString());
            savebuf.append(Config.CONF_US).append(dpc.entitlementCodesTag);
            savebuf.append(Config.CONF_US).append(dpc.lexiconDictionary);
            savebuf.append(Config.CONF_US).append(dpc.language);
            savebuf.append(Config.CONF_US).append(dpc.encoding);
            savebuf.append(Config.CONF_US).append(dpc.premiumCodes);
            savebuf.append("/>");
            savebuf.append(Config.CONF_US);
        }
        
        return savebuf.toString();

    }
     
    private static List<DistributorProductConfiguration> _parse(String did,
            String prod_str, 
            boolean is_wholesale,
            CodesConfig codescfg) 
    {
    
        List<DistributorProductConfiguration> list = new ArrayList<DistributorProductConfiguration>();


        java.util.HashMap pmap = new java.util.HashMap(20);
        StringBuilder separator = new StringBuilder();

        separator.append(Config.CONF_US).append(Config.CONF_ETX);

        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(prod_str, separator.toString());

        while (tokenizer.hasMoreTokens()) {

            DistributorProductConfiguration dpc = new DistributorProductConfiguration();

            dpc.productID = tokenizer.nextToken();
            dpc.format = tokenizer.nextToken();
            dpc.delay = new Integer(Integer.parseInt(tokenizer.nextToken()));
            dpc.premiumCodes = pcMap.get(dpc.productID);
            
            if (!is_wholesale && 
                    (dpc.format.equalsIgnoreCase("DJI")
                        || dpc.format.equalsIgnoreCase("DJU")
                        || dpc.format.equalsIgnoreCase("RAW")) 
                    )
            {
                dpc.premiumCodes = "NONE";
            }
            
             

            String nstr = tokenizer.nextToken();
            if (nstr.startsWith("Y") || nstr.startsWith("y")
                    || nstr.startsWith("T") || nstr.startsWith("t")) 
            {
                if (nstr.equalsIgnoreCase("Y") || nstr.equalsIgnoreCase("true")) 
                {
                    dpc.freewheel = true;
                }
            } else {
                Long flags = 0L;
                try {
                    flags = Long.parseLong(nstr);
                } catch (NumberFormatException nfe) {
                }
                dpc.freewheel = DistributorProductFlagOptions.getFreewheel(flags);
                dpc.removeLinks = DistributorProductFlagOptions.getNewsplusOff(flags);
                dpc.lexiconType = DistributorProductFlagOptions.getDerivedDataOption(flags);
                dpc.sigAbout = DistributorProductFlagOptions.getSigAbout(flags);

            }

            dpc.entitlementCodesTag = tokenizer.nextToken();

            if (codescfg != null) {   
                dpc.premiumCodes = codescfg.getProductCode(did, dpc.productID, null);
            }
            
            list.add(dpc);



        }
//        System.out.println("<^^^^^^^^^^^");
//        System.out.println(prod_str);
//        System.out.println(pack(list));
//        System.out.println("^^^^^^^^^^^^>");
        
        return list;
    }

    public static List<DistributorProductConfiguration> parse(String did,
            String prod_str, 
            boolean is_wholesale, CodesConfig codescfg) 
    {
        
        List<DistributorProductConfiguration> list = new ArrayList<DistributorProductConfiguration>();



        if ((prod_str.indexOf("<") < 0)
                || (prod_str.indexOf("/>") < 0)) {
            return _parse(did, prod_str, is_wholesale, codescfg);
        }


        StringBuilder separator = new StringBuilder();
        StringBuilder rowseparator = new StringBuilder("<");

        separator.append(Config.CONF_US).append(Config.CONF_ETX);

        java.util.StringTokenizer rowtokenizer = new java.util.StringTokenizer(prod_str, rowseparator.toString());



        while (rowtokenizer.hasMoreTokens()) {            

            DistributorProductConfiguration dpc = new DistributorProductConfiguration();

            String rowString = rowtokenizer.nextToken();
            System.out.println("ROW STR" + rowString);
            int inx = rowString.indexOf("/>");
            rowString = rowString.substring(0, inx);

            java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(rowString, separator.toString());


            dpc.productID = tokenizer.nextToken();
            dpc.format = tokenizer.nextToken();
            dpc.delay = new Integer(Integer.parseInt(tokenizer.nextToken()));
            dpc.premiumCodes = pcMap.get(dpc.productID);
           
            if (!is_wholesale && 
                    (dpc.format.equalsIgnoreCase("DJI")
                        || dpc.format.equalsIgnoreCase("DJU")
                        || dpc.format.equalsIgnoreCase("RAW")) 
                    )
            {
                dpc.premiumCodes = "NONE";
            }
            
            String nstr = tokenizer.nextToken();
            if (nstr.startsWith("Y") || nstr.startsWith("y")
                    || nstr.startsWith("T") || nstr.startsWith("t")) 
            {
                if (nstr.equalsIgnoreCase("Y") || nstr.equalsIgnoreCase("true")) {
                    dpc.freewheel = true;
                }
            } else {
                Long flags = 0L;
                try {
                    flags = Long.parseLong(nstr);
                } catch (NumberFormatException nfe) {
                }
                dpc.freewheel = DistributorProductFlagOptions.getFreewheel(flags);
                dpc.removeLinks = DistributorProductFlagOptions.getNewsplusOff(flags);
                dpc.lexiconType = DistributorProductFlagOptions.getDerivedDataOption(flags);
                dpc.sigAbout = DistributorProductFlagOptions.getSigAbout(flags);


            }

            dpc.entitlementCodesTag = tokenizer.nextToken();

            if (tokenizer.hasMoreTokens()) {
                dpc.lexiconDictionary = tokenizer.nextToken();
            }
            if (tokenizer.hasMoreTokens()) {
                dpc.language = tokenizer.nextToken();
            }
            if (tokenizer.hasMoreTokens()) {
                dpc.encoding = tokenizer.nextToken();
            }
            if (tokenizer.hasMoreTokens()) {
                dpc.premiumCodes = tokenizer.nextToken();
            }
            
            if (codescfg != null) {
                String x = dpc.premiumCodes;
                dpc.premiumCodes = codescfg.getProductCode(did, dpc.productID, x);
                System.out.println(did+" :Setting from cfg: "+dpc.premiumCodes
                        +":'"+dpc.premiumCodes+"' Old code: '"+x+"'");
            }
            
            list.add(dpc);




        }

//        System.out.println("<----------");
//        System.out.println(prod_str);
//        System.out.println();
//        System.out.println(pack(list));
//        System.out.println("---------->");


        return list;
    }
    
    public PrintStream print(PrintStream ps)
    {        
        ps.print("+");
        ps.print(" ");
        ps.print(productID);
        ps.print(" ");
        ps.print(format);
        ps.print(" ");
        ps.print(delay);
        ps.print(" ");
        ps.print(DistributorProductFlagOptions.getFlag(freewheel, removeLinks, lexiconType, sigAbout));
        
        ps.print("[");
        ps.print(freewheel);
        ps.print(" ");
        ps.print(removeLinks);
        ps.print(" \"");
        ps.print(lexiconType);
        ps.print("\" ");
        ps.print(sigAbout);
        ps.print("] ");
        //ps.print(" ");
        ps.print(lexiconDictionary);
        ps.print(" ");
        ps.print(entitlementCodesTag);
        ps.print(" ");
        ps.print(language);
        ps.print(" ");
        ps.print(encoding);
        ps.print(" \"");        
        ps.print(premiumCodes);
        ps.println("\"");
        return ps;
    }

    public String getProduct() {
        return productID;
    }

    public Integer getDelay() {
        return delay;
    }

    public Boolean isFreewheel() {
        return freewheel;
    }

    public String getFilter() {
        return entitlementCodesTag;
    }

    
}

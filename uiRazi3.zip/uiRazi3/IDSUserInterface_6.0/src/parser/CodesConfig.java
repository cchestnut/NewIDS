/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.io.*;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class CodesConfig {

    public boolean isValid(String did) {
        return map.containsKey(did);
    }
    
    public int size()
    {
        return map.size();
    }

    
    public Collection<String> getFeedIDs()
    {
        Set<String> dset = map.keySet();
        return Collections.unmodifiableCollection(dset);
    }

    private String[] resizeArray(String[] array1, String[] array2) {
        String[] b = new String[array1.length + array2.length];
        if (array2.length > 0) {
            System.arraycopy(array2, 0, b, 0, array2.length);
        }
        if (array1.length > 0) {
            System.arraycopy(array1, 0, b, array2.length, array1.length);
        }
        Arrays.sort(b);
        return b;
    }
    
    
    class ProductCodes {
        String[] EMPTY = new String[0];
        public ProductCodes()
        {
            premium = EMPTY;
            standard = EMPTY;
            both = EMPTY;
        }
        String[] premium;
        String[] standard;
        String[] both;
    }
    
    
    HashMap<String, ProductCodes> map;

    
    public void print(PrintStream ps) {
        Set<Map.Entry<String, ProductCodes>> entries = map.entrySet();
        for (Map.Entry<String, ProductCodes> entry : entries) {
            System.out.println("Feed: " + entry.getKey());
            ProductCodes pc = entry.getValue();
            
            System.out.println("\tPremium:" + Arrays.toString(pc.premium));
            System.out.println("\tStandard:" + Arrays.toString(pc.standard));
            System.out.println("\tBoth:" + Arrays.toString(pc.both));

        }
    }

    
    private static String[] parseProducts(String plist, String pat)
            throws ParseException
    {

        if (plist.length() > 0) {
            if (!plist.startsWith(pat)) {
                throw new ParseException(plist, 0);
            }
            int inx1 = plist.indexOf("(");
            int inx2 = plist.indexOf(")");
            String p = plist.substring(inx1+1, inx2);
            String a[] = p.split(" ");
            Arrays.sort(a);
            return a;
        }
        return new String[0];
    }

    
    
    public String getProductCode(String did, String pid, String dflt_value) {
        ProductCodes pc = map.get(did);
        if (pc == null) {
            return (dflt_value!=null)?dflt_value:DistributorProductConfiguration.pcMap.get(pid);            
        }

        int inx = Arrays.binarySearch(pc.premium, pid);
        if (inx >= 0) {
            return DistributorProductConfiguration.PREMIUM;
        }

        inx = Arrays.binarySearch(pc.standard, pid);
        if (inx >= 0) {
            return DistributorProductConfiguration.STANDARD;
        }

        inx = Arrays.binarySearch(pc.both, pid);
        if (inx >= 0) {
            return DistributorProductConfiguration.BOTH;
        }

        return (dflt_value!=null)?dflt_value:DistributorProductConfiguration.pcMap.get(pid);

    }

    
    
    public CodesConfig(String file)
            throws FileNotFoundException,
            IOException,
            ParseException,
            Exception 
    {
        
        FileReader fr = new FileReader(file);
        LineNumberReader lnr = new LineNumberReader(fr);

        map = new HashMap<String, ProductCodes>();

        String line;
        while ((line = lnr.readLine()) != null) {
            
            line = line.trim();
            
            if (line.startsWith("#"))
                continue;
            
            String[] fields = line.split(",");

            if (fields.length < 2) {
                throw new ParseException(line, lnr.getLineNumber());
            }

            String did = null;
            if (fields.length > 0) {
                did = fields[0];
            }


            ProductCodes pc = new ProductCodes();

            for (int i = 1; i < fields.length; i++) {
                String s = fields[i].trim();
                if (s.startsWith("P(")) {
                    try {
                        pc.premium = parseProducts(s, "P(");
                    } catch (ParseException ex) {
                        Logger.getLogger(CodesConfig.class.getName()).log(Level.SEVERE, null, ex);
                        throw new Exception("Premium:"+lnr.getLineNumber(), ex);
                    }

                } else if (s.startsWith("S(")) {
                    try {
                        pc.standard = parseProducts(s, "S(");
                    } catch (ParseException ex) {
                        Logger.getLogger(CodesConfig.class.getName()).log(Level.SEVERE, null, ex);
                        throw new Exception("Standard:"+lnr.getLineNumber(), ex);
                    }

                } else if (s.startsWith("B(")) {
                    try {
                        pc.both = parseProducts(s, "B(");
                    } catch (ParseException ex) {
                        Logger.getLogger(CodesConfig.class.getName()).log(Level.SEVERE, null, ex);
                        throw new Exception("Both:"+lnr.getLineNumber(), ex);
                    }


                } else {
                    throw new ParseException(s,lnr.getLineNumber());
                }
            }

            ProductCodes npc = map.get(did);
            if (npc == null)
            {
                npc = pc;
            }
            else
            {                               
                if (pc.both.length>0) {
                    npc.both = resizeArray(npc.both, pc.both);
                }                
                if (pc.standard.length>0) {
                    npc.standard = resizeArray(npc.standard, pc.standard);
                }                
                if (pc.premium.length>0) {
                    npc.premium = resizeArray(npc.premium, pc.premium);
                }
            }
            
            map.put(did, npc);

        }

        lnr.close();
    }


}

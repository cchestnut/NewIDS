/* Header for class JGDBM */
#include "jgdbm_JGDBM.h"
#include <gdbm.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdio.h>

#define CONFDB_HDRSIZE 64
#define CONF_FS '\x1F'

/*
 ** Insert header information
 */

void*
dbh_prepend_hdr(char* user, void *value) {
    struct tm tstmp;
    datum dbval;
    time_t clk = time(NULL);

    memset(&tstmp, '\0', sizeof (struct tm));

    localtime_r(&clk, &tstmp);


    snprintf(value, CONFDB_HDRSIZE - 1, "%4d%02d%02d%02d%02d%02d%c%.16s",
            tstmp.tm_year + 1900, tstmp.tm_mon + 1, tstmp.tm_mday,
            tstmp.tm_hour, tstmp.tm_min, tstmp.tm_sec, CONF_FS,
            user);

    return value;
}

/*
 * Class:     JGDBM
 * Method:    gdbm_open
 * Signature: (Ljava/lang/String;)Ljava/lang/Object;
 */
JNIEXPORT jlong JNICALL Java_jgdbm_JGDBM_gdbm_1open
(JNIEnv *jenv, jobject jthis, jstring jdbfile) {

    GDBM_FILE dbf = NULL;
    const char *dbfile = (*jenv)->GetStringUTFChars(jenv, jdbfile, 0);

    if (dbfile == NULL) {
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                "GDBM file name is required");
		return 0;
    }

    dbf = gdbm_open((char*) dbfile, 1024, GDBM_WRITER | GDBM_SYNC, 0644, NULL);

    (*jenv)->ReleaseStringUTFChars(jenv, jdbfile, dbfile);

    if (dbf == NULL) {
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                gdbm_strerror(gdbm_errno));
		return 0;
    }

    return (jlong) dbf;
}

/*
 * Class:     JGDBM
 * Method:    gdbm_close
 * Signature: (Ljava/lang/Object;)V
 */
JNIEXPORT void JNICALL Java_jgdbm_JGDBM_gdbm_1close
(JNIEnv *jenv, jobject jthis, jlong dbf) {
    gdbm_close((GDBM_FILE) dbf);
}

/*
 * Class:     JGDBM
 * Method:    gdbm_fetch
 * Signature: (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jobject JNICALL Java_jgdbm_JGDBM_gdbm_1fetch
(JNIEnv *jenv, jobject jthis, jlong dbf, jstring jkey) {



    if (jkey == NULL) {

        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                "DB Key is required");
		return NULL;
    }



    const char *str = (*jenv)->GetStringUTFChars(jenv, jkey, 0);

    if (str == NULL) {

        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                "Error in DB Key");
		return NULL;
    }

    datum dbkey, content = {0, 0};


    dbkey.dptr = (char*) str;
    dbkey.dsize = strlen(str);

    content = gdbm_fetch((GDBM_FILE) dbf, dbkey);

    (*jenv)->ReleaseStringUTFChars(jenv, jkey, str);

    if (content.dptr) {
        jobject jret = NULL;

        if (content.dsize > CONFDB_HDRSIZE) {
            size_t csize = content.dsize - CONFDB_HDRSIZE;

            char *buf = malloc(csize);
            if (buf) {
                memcpy(buf, content.dptr + CONFDB_HDRSIZE, csize);
                jret = (*jenv)->NewDirectByteBuffer(jenv, buf, csize);
            }
        }
        free(content.dptr);
        return jret;
    } else {
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "Key %s does not exist in DB", str);
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);
		return NULL;
    }




}

/*
 * Class:     JGDBM
 * Method:    gdbm_firstkey
 * Signature: (J)Ljava/nio/ByteBuffer;
 */
JNIEXPORT jobject JNICALL Java_jgdbm_JGDBM_gdbm_1firstkey
(JNIEnv *jenv, jobject jthis, jlong dbf) {
    datum dbkey;

    dbkey = gdbm_firstkey((GDBM_FILE) dbf);
    if (dbkey.dptr && (dbkey.dsize > 0)) {
        jobject jret = (*jenv)->NewDirectByteBuffer(jenv, dbkey.dptr, dbkey.dsize);
        return jret;
    }

    return NULL;
}

/*
 * Class:     JGDBM
 * Method:    gdbm_nextkey
 * Signature: (JLjava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
 */
JNIEXPORT jobject JNICALL Java_jgdbm_JGDBM_gdbm_1nextkey
(JNIEnv *jenv, jobject jthis, jlong dbf, jobject jkey) {



    if (jkey == NULL)
        return NULL;

    datum pkey;

    pkey.dptr = (*jenv)->GetDirectBufferAddress(jenv, jkey);
    if (pkey.dptr == NULL)
        return NULL;

    pkey.dsize = (*jenv)->GetDirectBufferCapacity(jenv, jkey);
    if (pkey.dsize <= 0)
        return NULL;


    datum dkey = gdbm_nextkey((GDBM_FILE) dbf, pkey);
    if (dkey.dptr && (dkey.dsize > 0)) {
        jobject jret = (*jenv)->NewDirectByteBuffer(jenv, dkey.dptr, dkey.dsize);
        return jret;
    }
    return NULL;
}

/*
 * Class:     premiumcodesupdater_JGDBM
 * Method:    gdbm_store
 * Signature: (JLjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;I)I
 */
JNIEXPORT jint JNICALL Java_jgdbm_JGDBM_gdbm_1store
(JNIEnv *jenv, jobject jthis, jlong dbf, jobject jkey, jobject jcontent, jint jflag) {

    datum key, content;
    int rv = -1;
    
    if ((jkey == NULL) || (jcontent == NULL)) {
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "DB does not allow empty Key and/or value");
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);
		return rv;
    }
        
    key.dptr = (*jenv)->GetDirectBufferAddress(jenv, jkey);
    key.dsize = (*jenv)->GetDirectBufferCapacity(jenv, jkey);

    if (!key.dptr || (key.dsize <= 0)){
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "DB does not allow empty keys");
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);
		return rv;
    }
        


    size_t dsize = (*jenv)->GetDirectBufferCapacity(jenv, jcontent);
    if (dsize <= 0){
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "DB does not allow empty values");
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);
		return rv;
    }
        

    content.dsize = dsize + CONFDB_HDRSIZE;
    content.dptr = malloc(content.dsize);
    if (!content.dptr)
    {
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "Cannot allocate memory");
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);
        
		return rv;
    }
        

    char *ptr = (*jenv)->GetDirectBufferAddress(jenv, jcontent);
    if (!ptr) {
        free(content.dptr);
        char ebuf[128];
        snprintf(ebuf, sizeof (ebuf) - 1, "Cannot retrieve value");
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                ebuf);        
		return rv;
    }

    dbh_prepend_hdr("JGDBM_update", content.dptr);
    memcpy(content.dptr + CONFDB_HDRSIZE, ptr, dsize);


    rv = gdbm_store((GDBM_FILE) dbf, key, content, jflag);
    gdbm_sync((GDBM_FILE) dbf);
    free(content.dptr);

    if (rv != 0) {
        (*jenv)->ThrowNew(jenv,
                (*jenv)->FindClass(jenv, "java/io/IOException"),
                gdbm_strerror(gdbm_errno));
    }


    return rv;

}



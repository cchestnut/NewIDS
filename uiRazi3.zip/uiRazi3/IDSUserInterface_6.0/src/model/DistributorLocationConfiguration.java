/*
 * DistributorLocationConfiguration.java
 *
 * Created on June 16, 2006, 5:19 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import parser.DistributorProductConfiguration;

/**
 *
 * @author SyedR
 */
public class DistributorLocationConfiguration {
    //String location;
    private String keySuffix;
    private String statistics;
    private String keepalive;
    private List<DistributorProductConfiguration> products;
    private DistributorTransportConfiguration dtc;
    
    
    public PrintStream  print(PrintStream ps) {
        System.out.println("Key suffix: "+keySuffix);
        System.out.println("Statistics: "+statistics);
        System.out.println("Keep alive: "+keepalive);
        System.out.println("<====== Products ======>");
        for (DistributorProductConfiguration dpc: products) {
            dpc.print(ps);
        }
        
        System.out.println("<====== Communication settings ======>");
        dtc.print(ps);
        
            return ps;
    }
      
    /** Creates a new instance of DistributorLocationConfiguration */
    public DistributorLocationConfiguration() {
    }
    
    public static DistributorLocationConfiguration 
            parse(HashMap map, String keySuffix)
    {
        DistributorLocationConfiguration dlc = new DistributorLocationConfiguration();
        dlc.setKeySuffix(keySuffix);
        dlc.setKeepalive((String)map.get("KEEPALIVE_"+keySuffix));
        dlc.setStatistics((String)map.get("STATISTICS_"+keySuffix));
        String prod_str = (String)map.get("PRODUCTS_"+keySuffix);
        
        dlc.setProducts(DistributorProductConfiguration.parse(null, prod_str, false, null));
        
        String transport = (String)map.get("TRANSPORT_"+keySuffix);
        if (transport == null) {
            transport = (String)map.get("TRANSPORT");
        }
        
        dlc.setDtc(DistributorTransportConfiguration.parse(transport, null));
        
        return dlc;
    }

    public String getKeySuffix() {
        return keySuffix;
    }

    public void setKeySuffix(String keySuffix) {
        this.keySuffix = keySuffix;
    }

    public String getStatistics() {
        return statistics;
    }

    public void setStatistics(String statistics) {
        this.statistics = statistics;
    }

    public String getKeepalive() {
        return keepalive;
    }

    public void setKeepalive(String keepalive) {
        this.keepalive = keepalive;
    }

    public List<DistributorProductConfiguration> getProducts() {
        return products;
    }

    public void setProducts(List<DistributorProductConfiguration> products) {
        this.products = products;
    }

    public DistributorTransportConfiguration getDtc() {
        return dtc;
    }

    public void setDtc(DistributorTransportConfiguration dtc) {
        this.dtc = dtc;
    }

  
}

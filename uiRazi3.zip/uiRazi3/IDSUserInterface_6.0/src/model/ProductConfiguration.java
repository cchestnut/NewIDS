package model;
/*
 * ProductConfiguration.java
 *
 * Created on May 16, 2006, 11:27 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/*
**  SCCS Info :  "%W%    %E%"
*/
/**
 *
 * @author SyedR
 */
public class ProductConfiguration {
    public String productID;
    public boolean isContainer;
    public String containerID;
    public String description;
    public boolean supportsRetransmissions;
    public String  retransmissionHostTag;
    public boolean enabled;
    public int     productUID;
    
    /**
     * Creates a new instance of ProductConfiguration
     */
    public ProductConfiguration() {
    }
    
    
    public boolean isContainer()
    {
        return isContainer;
    }
    
    
}

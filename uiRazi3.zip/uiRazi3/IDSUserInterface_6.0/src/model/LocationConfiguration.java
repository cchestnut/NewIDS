/*
 * LocationConfiguration.java
 *
 * Created on May 23, 2006, 7:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;
import ids2ui.ConfigComm;
import java.util.List;

/**
 *
 * @author SyedR
 */
public class LocationConfiguration {
    
    
    private String location;
    private boolean useVeritas;
    private String hostname;
    private String dataInterfaces;
    private String configurationInterfaces;
    private String statusInterfaces;
    private List<FeedDescription> inputFeeds;
    
    /** Creates a new instance of LocationConfiguration */
    public LocationConfiguration(){
        
        inputFeeds = new java.util.ArrayList<FeedDescription>();
       
    }

    
    /** Creates a new instance of LocationConfiguration */
    public LocationConfiguration(java.util.HashMap map, String location_suffix){
        
        
        hostname = (String)map.get("PHOST"+location_suffix);
        dataInterfaces = (String)map.get("HOST"+location_suffix);
        configurationInterfaces = (String)map.get("HOST"+location_suffix);
        statusInterfaces = (String)map.get("HOST"+location_suffix);
        location  = (String)map.get("LOCATION"+location_suffix);
          
        setUseVeritas(ids2ui.Utils.parseBooleanString((String)map.get("USE_VERITAS_COMMANDS"+location_suffix)));
        
        
        StringBuffer separator = new StringBuffer();
        separator.append(ConfigComm.CONF_GS).append(ConfigComm.CONF_ETX);
     
        String ifstr = (String)map.get("INPUT_FEED"+location_suffix);
        java.util.StringTokenizer st
                = new java.util.StringTokenizer(ifstr,separator.toString());
        
        Object [] rowData = new Object[6];
        String fldsep = new String(",");
        
        inputFeeds = new java.util.ArrayList<FeedDescription>();
        
        while (st.hasMoreTokens()) {
            String s = st.nextToken();
            
            java.util.StringTokenizer fst
                    = new java.util.StringTokenizer(s,",");
            
            FeedDescription fd = new FeedDescription();
            
            fd.setName(fst.nextToken());
            if (fst.hasMoreTokens())
                fd.setFormat(fst.nextToken());
            if (fst.hasMoreTokens())
                fd.setProtocol(fst.nextToken());
            if (fst.hasMoreTokens())
                fd.setTransport(fst.nextToken());            
            if (fst.hasMoreTokens())
                fd.setProducts(fst.nextToken());
                        
            String pct = (String)map.get(fd.getName()+
                                    "_PRODUCT_CONVERSION_TABLE"+location_suffix);
            fd.setConversion_formats(pct);
            String reader = (String)map.get(fd.getName()+
                                    "_READER"+location_suffix);
            fd.setReader(reader);
            String msgmgr = (String)map.get(fd.getName()+
                                    "_MESSAGE_MANAGER"+location_suffix);
            fd.setMessageManager(msgmgr);
            
            inputFeeds.add(fd);
            
        }
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isUseVeritas() {
        return useVeritas;
    }

    public void setUseVeritas(boolean useVeritas) {
        this.useVeritas = useVeritas;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getDataInterfaces() {
        return dataInterfaces;
    }

    public void setDataInterfaces(String dataInterfaces) {
        this.dataInterfaces = dataInterfaces;
    }

    public String getConfigurationInterfaces() {
        return configurationInterfaces;
    }

    public void setConfigurationInterfaces(String configurationInterfaces) {
        this.configurationInterfaces = configurationInterfaces;
    }

    public String getStatusInterfaces() {
        return statusInterfaces;
    }

    public void setStatusInterfaces(String statusInterfaces) {
        this.statusInterfaces = statusInterfaces;
    }

    public List<FeedDescription> getInputFeeds() {
        return inputFeeds;
    }

    public void setInputFeeds(List<FeedDescription> inputFeeds) {
        this.inputFeeds = inputFeeds;
    }
    
}
    
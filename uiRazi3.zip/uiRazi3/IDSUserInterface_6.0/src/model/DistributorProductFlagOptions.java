/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class DistributorProductFlagOptions {

    public static int DISTR_PRODUCT_FLAG_FREEWHEEL = 1;
    public static int DISTR_PRODUCT_FLAG_WSJURL = 2;
    public static int DISTR_PRODUCT_FLAG_DERIVED_ONLY = 4;
    public static int DISTR_PRODUCT_FLAG_DERIVED_FULL = 8;
    public static int DISTR_PRODUCT_FLAG_DERIVED_POSITIONS = 16;
    public static int DISTR_PRODUCT_FLAG_SIGABOUT = 32;
    public static String DerivedDataOptions[] = {/*"No"*/"NONE", "Word Count (Full)", "Word Count (No Text)", "Word Count (Full with positions)", "Word Count (No Text with positions)"};
    public static String DefaultDerivedDataDictOptions[] = {"NONE", "ND_Total", "ND_Custom", "ALP2", "ALP3"};

    public static String getDerivedDataDictionary(String s) {
        if (s != null) {
            int inx = s.indexOf("|");
            if (inx > 0) {
                String s1 = s.substring(inx + 1);
                return s1;
            }
        }
        return "NONE";
    }

    public static int getDerivedDataOptionFlag(String s) {
        if (s != null) {
            int inx = s.indexOf("|");
            if (inx > 0) {
                String s1 = s.substring(0, inx + 1);
                s = s1;
            }
            if (s.equals(DerivedDataOptions[1])) {
                return DISTR_PRODUCT_FLAG_DERIVED_FULL;
            } else if (s.equals(DerivedDataOptions[2])) {
                return DISTR_PRODUCT_FLAG_DERIVED_ONLY;
            } else if (s.equals(DerivedDataOptions[3])) {
                return DISTR_PRODUCT_FLAG_DERIVED_FULL | DISTR_PRODUCT_FLAG_DERIVED_POSITIONS;
            } else if (s.equals(DerivedDataOptions[4])) {
                return DISTR_PRODUCT_FLAG_DERIVED_ONLY | DISTR_PRODUCT_FLAG_DERIVED_POSITIONS;
            }
        }
        return 0;
    }

    public static String getDerivedDataOptionString(long o) {

        if (((o & DISTR_PRODUCT_FLAG_DERIVED_ONLY) > 0)
                && ((o & DISTR_PRODUCT_FLAG_DERIVED_POSITIONS) > 0)) {
            return DerivedDataOptions[4];
        } else if (((o & DISTR_PRODUCT_FLAG_DERIVED_FULL) > 0)
                && ((o & DISTR_PRODUCT_FLAG_DERIVED_POSITIONS) > 0)) {
            return DerivedDataOptions[3];
        } else if ((o & DISTR_PRODUCT_FLAG_DERIVED_ONLY) > 0) {
            return DerivedDataOptions[2];
        } else if ((o & DISTR_PRODUCT_FLAG_DERIVED_FULL) > 0) {
            return DerivedDataOptions[1];
        }

        return DerivedDataOptions[0];
    }

    public static Long getFlag(boolean fw, boolean np, String dd, boolean sig) {
        long flags = 0;
        if (fw) {
            flags |= DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_FREEWHEEL;
        }
        if (np) {
            flags |= DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_WSJURL;
        }

        flags |= DistributorProductFlagOptions.getDerivedDataOptionFlag(dd);

        if (sig) {
            flags |= DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_SIGABOUT;
        }

        return new Long(flags);
    }

    public static boolean getFreewheel(long flags) {
        if ((flags & DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_FREEWHEEL) > 0) {
            return true;
        }
        return false;
    }

    public static boolean getNewsplusOff(long flags) {
        if ((flags & DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_WSJURL) > 0) {
            return true;
        }
        return false;
    }

    public static boolean getSigAbout(long flags) {
        if ((flags & DistributorProductFlagOptions.DISTR_PRODUCT_FLAG_SIGABOUT) > 0) {
            return true;
        }
        return false;
    }

    public static String getDerivedDataOption(long flags) {
        return DistributorProductFlagOptions.getDerivedDataOptionString(flags);
    }
}

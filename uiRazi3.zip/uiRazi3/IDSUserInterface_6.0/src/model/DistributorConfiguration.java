/*
 * DistributorConfiguration.java
 *
 * Created on June 16, 2006, 5:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;

//import ids2.ui.DistributorConfigurationPanel_proto;
import ids2ui.ConfigComm;
import ids2ui.Constants;
import ids2ui.DBException;
import ids2ui.DBModeException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import javax.swing.JFrame;

/**
 *
 * @author SyedR
 */
public class DistributorConfiguration {
    private String dbtag;
    private String id;
    private String type;
    private String hostTag;
    private String description="";
    private String checkpoint;
    private boolean autoFailover;
    private boolean hiresTimestamp;
    private String  homeIndex;
    private boolean acknowledgeReutersKeepalive=false;
    private boolean addFunctionCodes=false;
    private String  functionCodes="";
    
    private List<DistributorLocationConfiguration> locations;
    
    private DistributorLocationConfiguration home;
    private DistributorLocationConfiguration away;
    
    private WholesaleTransportConfiguration wtc;
    
    
    public PrintStream print(PrintStream ps)
    {
        ps.println("=== Distributor Configuration ===");
        ps.println("ID: "+id);
        ps.println("Host ID: "+hostTag);
        ps.println("Description: "+description);
        ps.println("Checkpoint:"+checkpoint);
        ps.println("Auto failover:"+autoFailover);
        ps.println("High resolution timestamps: "+hiresTimestamp);
        ps.println("Home location index: "+homeIndex);
        ps.println("Reuters keepalive ack: "+acknowledgeReutersKeepalive);
        ps.println("Add function codes:"+addFunctionCodes);
        if (addFunctionCodes && ( functionCodes.length() > 0)  ) {
            ps.println("\tFunction codes: "+functionCodes);
        }
        ps.println("<--- Home location configuration -->");
        home.print(ps);
        
        ps.println("<---------------------------------->");
        
        ps.println("<--- Away location configuration -->");
        away.print(ps);
        ps.println("<---------------------------------->");
        
        
        return ps;
    }
     
     
     
    /** Creates a new instance of DistributorConfiguration */
    public DistributorConfiguration() {
    }
    
    public static DistributorConfiguration parse(String dbt, String id, HashMap map)
    {
        DistributorConfiguration dc = new DistributorConfiguration();
        dc.dbtag = dbt;
        dc.id = (String)map.get("ID");
        if (dc.id == null)dc.id = id;
        dc.description = (String)map.get("DESCRIPTION");
        
        dc.autoFailover = true;
        String autoFailStr =   (String)map.get("AUTO_FAILOVER");        
        if (autoFailStr != null) {
            dc.autoFailover = Boolean.valueOf(autoFailStr).booleanValue();
        }
      
        dc.hiresTimestamp = false;
        String hiresTSStr =   (String)map.get("HIGH_RESOLUTION_TIMESTAMPS");        
        if (hiresTSStr != null) {
            dc.hiresTimestamp = Boolean.valueOf(hiresTSStr).booleanValue();
        }
        
        
        dc.checkpoint = (String)map.get("CHECKPOINT");        
        dc.homeIndex = (String)map.get("HOME_LOCATION");
        
        dc.hostTag = (String)map.get("TAG");
        dc.type = (String)map.get("CONFIGURATION_TYPE");

         
        dc.home = DistributorLocationConfiguration.parse(map, dc.getHomeIndex());
        dc.away = DistributorLocationConfiguration.parse(map, 
                                    dc.getHomeIndex().equals("1")?"2":"1" );
        
        
                


        return dc;
    }
    
       /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws Exception{
        //ConfigComm.initLogin("Test","dist-c1d1,dist-c1d2", "/ids2");
        ConfigComm.initLogin("Test","distc1d1,distc2d1", "/ids2");
        
        
        java.util.HashMap distrConfig =
                    ConfigComm.getHashMapDirect("GLB_TAG_DISTR_SIG2");
        DistributorConfiguration dc =  DistributorConfiguration.parse(Constants.GLB_TAG_DISTR_PREFIX+"SIG1", "SIG1",distrConfig);
        dc.print(System.out);
        System.exit(0);
                    
        //ConfigComm.initLogin("Test","172.26.82.120,172.26.82.121","/ids2");
        //ConfigComm.initLogin("Test","un1d1,un1d2","/ids2");
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    
                    java.util.HashMap dspConfig =
                    ConfigComm.getHashMapDirect("GLB_TAG_DCM_DCMN3");
            
            String buf = null;
            
            try {
                buf = ConfigComm.getStringValue("DSP_USE_VERITAS_COMMANDS");
                dspConfig.put("USE_VERITAS_COMMANDS", buf);
            } catch (Exception e1){e1.printStackTrace();}
            
            try {
                String l = (String)dspConfig.get("LOCATION1");
                buf = ConfigComm.getStringValue(l+"_DSP_USE_VERITAS_COMMANDS");
                dspConfig.put("USE_VERITAS_COMMANDS1", buf);
            } catch (Exception e1){e1.printStackTrace();}
            
            try {
                String l = (String)dspConfig.get("LOCATION2");
                buf = ConfigComm.getStringValue(l+"_DSP_USE_VERITAS_COMMANDS");
                dspConfig.put(l+"USE_VERITAS_COMMANDS2", buf.toString());
            } catch (Exception e1){e1.printStackTrace();}
            
            HostModuleConfiguration hmc = new HostModuleConfiguration(dspConfig);
                    
                    
                    
                    
                    HashMap map = ConfigComm.getHashMapDirect(Constants.GLB_TAG_DISTR_PREFIX+"NRTR");
                    DistributorConfiguration dc =  DistributorConfiguration.parse(Constants.GLB_TAG_DISTR_PREFIX+"LWC1", "LWC1",map);
                    System.out.println("Success");
                    JFrame f = new JFrame("TEST");
                 //   DistributorConfigurationPanel_proto dcp = new DistributorConfigurationPanel_proto(f, dc, hmc);
                   // f.getContentPane().add(dcp);
                    f.pack();
                    f.setVisible(true);
                } catch (DBModeException ex) {
                    ex.printStackTrace();
                } catch (DBException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                
            }
        });
    }

    public String getDbtag() {
        return dbtag;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getHostTag() {
        return hostTag;
    }

    public String getDescription() {
        return description;
    }

    public String getCheckpoint() {
        return checkpoint;
    }

    public boolean isAutoFailover() {
        return autoFailover;
    }

    public boolean isHiresTimestamp() {
        return hiresTimestamp;
    }

    public String getHomeIndex() {
        return homeIndex;
    }

    public DistributorLocationConfiguration getHome() {
        return home;
    }

    public DistributorLocationConfiguration getAway() {
        return away;
    }

    public WholesaleTransportConfiguration getWtc() {
        return wtc;
    }
    
    
   
}

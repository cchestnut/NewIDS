/*
 * HostModuleConfiguration.java
 *
 * Created on May 23, 2006, 6:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;
import ids2ui.ConfigComm;
import ids2ui.Constants;
import ids2ui.DBException;
import ids2ui.Log;
import ids2ui.SwingWorker;
import ids2ui.Utils;
import java.util.*;
/**
 *
 * @author SyedR
 */
public class HostModuleConfiguration {
    private String dbkey;
    
    private String moduleType;
    private String _type;
    private String ID;
    private String softwareVersion;
    private String description;
    private String veritasGroup;    
    private String systemServices;
    private LocationConfiguration location1;
    private LocationConfiguration location2;
    private String dcmID;
    private int feedsLimit;
    
    /**
     * Creates a new instance of HostModuleConfiguration
     */
    public HostModuleConfiguration() {     
        location1 = new LocationConfiguration();
        location2 = new LocationConfiguration();
    }

      /**
     * Creates a new instance of HostModuleConfiguration
     */
    public HostModuleConfiguration(java.util.HashMap map) {
        
        ID = (String)map.get("ID");
        if (ID.startsWith("DCMN"))
            dcmID = ID.substring("DCMN".length());
        description= (String)map.get("DESCRIPTION");
        softwareVersion = (String)map.get("SOFTWARE_VERSION");
        veritasGroup = (String)map.get("VERITAS_GROUP");
        systemServices = (String)map.get("SYSTEM_SERVICES");          
        
        location1 = new LocationConfiguration(map,"1");
        location2 = new LocationConfiguration(map,"2");
       
        _type = (String) map.get("TYPE");
        dbkey = (String) map.get("DBKEY");
        
    }

    public String getConfiguredProducts(int location_index) {
        return getConfiguredProducts(Integer.toString(location_index));
    }

    public String getMgrProducts(String mgr_name, int location_index) {       
            throw new UnsupportedOperationException("Not yet implemented");                
    }

       public String getModuleType() {
        return moduleType;
    }

       public boolean isDSP()
       {          
           if ((dbkey != null) && dbkey.startsWith(Constants.GLB_TAG_DSP)) {
               return true;
           } else if ((ID != null) && ID.startsWith("DSP")) {
               return true;
           }
           return false;
       }
       
       public boolean isDCM()
       {        
           if ((dbkey != null) && dbkey.startsWith(Constants.GLB_TAG_DCM_PREFIX)) {
               return true;
           } else if ((ID != null) && ID.startsWith("DCM")) {
               return true;
           }
           return false;
       }
       
       
    public String getSystemServices() {
        return systemServices;
    }

    public void setModuleType(String moduleType) {
        this.moduleType = moduleType;
    }

    public String getID() {
        return ID;
    }

    public void setID(String name) {
        this.ID = name;
        
        if (ID.startsWith("DCMN"))
            dcmID = ID.substring("DCMN".length());
    }

    public String getSoftwareVersion() {
        return softwareVersion;
    }

    public void setSoftwareVersion(String software_version) {
        this.softwareVersion = software_version;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVeritasGroup() {
        return veritasGroup;
    }

    public void setSystemServices(String s) {
        systemServices = s;
    }

    public void setVeritasGroup(String veritasGroup) {
        this.veritasGroup = veritasGroup;
    }
    

    public LocationConfiguration getLocation1() {
        return location1;
    }

    public void setLocation1(LocationConfiguration location1) {
        this.location1 = location1;
    }

    public LocationConfiguration getLocation2() {
        return location2;
    }

    public void setLocation2(LocationConfiguration location2) {
        this.location2 = location2;
    }

    
    public boolean isDJNewsType()
    {
        return Utils.isDJNEWS_DCM(_type);	    
    }
    
    
    public static int
            validateProdFmt(LocationConfiguration location,
            StringBuilder errstr) {
        
        /*
         ** If only one feed is configured and products are not explictly assigned,
         ** assume all products are assigned to it
         */
        
        int numFeeds = location.getInputFeeds().size();
        if (numFeeds == 1) {
            String prods = location.getInputFeeds().get(0).getProductString(null);
            if ((prods==null) || (prods.trim().length()==0))
                return 0;
        }
        
        StringBuilder err = new StringBuilder();
        
        boolean  errflag = false;
        boolean product_assigned = false;
        for (ProductConfiguration product: Globals.getProductsModel().getTopLevelProducts()) {
            
            String feed_name=null;
            for (FeedDescription feed: location.getInputFeeds()) {
                
                String prods = feed.getProductString(null);
                
                if ( (prods!=null)
                && ids2ui.Constants.findPattern(prods, product.productID)) {
                    
                    feed_name=feed.getName();
                    product_assigned = true;
                }
            }
            
            if (feed_name==null){
                err.append(" ").append(product.productID);
                errflag = true;
            }
            
        }
        
        if ( errflag && ( ((numFeeds==1) && product_assigned)
        || (numFeeds>1) ) ) {
            errstr.append("        The following products are not ");
            errstr.append("mapped to any reader :\n ");
            errstr.append(err);
            return 1;
        }
        
        if (numFeeds == 1) return 0;
        
        
        err.setLength(0);
        for (FeedDescription feed: location.getInputFeeds()) {
            String prods = feed.getProductString(null);
            
            if ( (prods==null) || (prods.trim().length()==0)) {
                err.append(" ").append(feed.getName());
                errflag = true;
            }
        }
        
        if (errflag ) {
            errstr.append("        Please assign products to following reader(s) :\n ");
            errstr.append( err );
            return -1;
        }
        
        
        
        return 0;
        
    } /* End of validateProdFmt() */

    
    private int buildFeedString(LocationConfiguration location, 
            String dfltstr,
            StringBuilder feedstr, 
            HashMap convMap,String suffix,
            StringBuilder errstr)
    {
        
        String l = location.getLocation();
        if (l == null) l = dfltstr;
        int rc = 0;
        StringBuilder convstr;
        
        if (location.getInputFeeds().size() <=0) {           
            errstr.append(l)
            .append(":Input feed is required.\n"); 
            return -1;
        }
        
        StringBuilder sb = new StringBuilder();
        if ((rc = validateProdFmt(location,sb))!=0) {            
            
            errstr.append(l)
            .append(": Product configuration.\n")
            .append(sb).append("\n");
            if (rc < 0) return rc;
        }
        
        for (FeedDescription feed: location.getInputFeeds()) {            
            String prods = feed.getProductString(null);
            
            feedstr.append(ids2ui.ConfigComm.CONF_GS).append(",")
            .append(feed.getName()).append(",")
            .append(feed.getFormat()).append(",")
            .append(feed.getProtocol()).append(",")
            .append(feed.getTransport());
            
            if (prods!=null)
                feedstr.append(",").append(prods);   
            
            convMap.put(feed.getName()+"_PRODUCT_CONVERSION_TABLE"+suffix,
                    feed.getConversion_formats());
            
            convMap.put(feed.getName()+"_READER"+suffix,
                    feed.getReader());
            
            convMap.put(feed.getName()+"_MESSAGE_MANAGER"+suffix,
                    feed.getMessageManager());
        }
        
        
        return 0;
    }
    
    
    
    public java.util.HashMap toHashMap() {
        
        
        
        StringBuilder errstr = new StringBuilder();
        boolean errflag=false;
        
        
        
        if (ID.trim().length() == 0) {
            errflag = true;
            errstr.append(" ID \n");
        }
        
        String swver = softwareVersion;
        if ((swver != null)
                && swver.equals(ids2ui.Constants.DEFAULT_SW_VERSION_LABEL))
            swver = ids2ui.Constants.DEFAULT_SW_VERSION;
        
        if (swver.length() == 0) {
            errflag = true;
            errstr.append(" Software Version \n");
        }
        
        
        
        int rc = 0;
        StringBuilder feedstr1 = new StringBuilder();
        HashMap convMap1 = new HashMap();
        StringBuilder sb = new StringBuilder();
        if ((rc = buildFeedString(location1, "Location - I",
                feedstr1, convMap1, "1", sb)) < 0)
        {
            errflag = true;              
            errstr.append(sb).append("\n");            
        }
        sb.setLength(0);
        
        StringBuilder feedstr2 = new StringBuilder();
        HashMap convMap2 = new HashMap();
        if ((rc = buildFeedString(location2, "Location - II",
                feedstr2, convMap2, "2", sb)) <  0)
        {
            errflag = true;              
            errstr.append(sb).append("\n");            
        }
        sb.setLength(0);
        
        
         
        
        
        
        if (location1.getHostname().trim().length() == 0) {
            errflag = true;
            errstr.append(" Location - I: Hostname \n"); 
        }
        if (location2.getHostname().trim().length() == 0) {
            errflag = true;
            errstr.append(" Location - II: Hostname \n"); 
        }
        if (location1.getDataInterfaces().trim().length() == 0) {
            errflag = true;
            errstr.append(" Location - I: Data interfaces \n"); 
        }
        if (location2.getDataInterfaces().trim().length() == 0) {
            errflag = true;
            errstr.append(" Location - II: Data interfaces \n"); 
        }
        
        if (errflag) {
            System.out.println("Error:"+errstr.toString());
            return null;
        }            
            java.util.HashMap map = new java.util.HashMap();
            if (dbkey != null)
                map.put("DBKEY", dbkey);
            
            if (dcmID != null)
                map.put("DCMID", dcmID);
            
            map.put("ID",ID);
            if (description != null)
                map.put("DESCRIPTION",description);
            map.put("SOFTWARE_VERSION",swver);
            map.put("INPUT_FEED1",feedstr1.toString());
            map.put("INPUT_FEED2",feedstr2.toString());
            map.putAll(convMap1);
            map.putAll(convMap2);
            map.put("HOST1",location1.getDataInterfaces());
            map.put("HOST2",location2.getDataInterfaces());
            map.put("PHOST1",location1.getHostname());
            map.put("PHOST2",location2.getHostname());
            
            if (systemServices != null)
                map.put("SYSTEM_SERVICES", systemServices);
            
            if (veritasGroup!=null && (veritasGroup.trim().length()>0))
            {
                map.put("VERITAS_GROUP", veritasGroup.trim());            
                map.put("USE_VERITAS_COMMANDS1",Boolean.toString(location1.isUseVeritas()));
                map.put("USE_VERITAS_COMMANDS2",Boolean.toString(location2.isUseVeritas()));
            }
            
            map.put("LOCATION1", location1.getLocation());
            map.put("LOCATION2", location2.getLocation());
            
            
        return map;
    }

    
    /*
     * ** Find the Line handler feeding this host and get the list of products
     * If line handler is not found return all standalone products
     * */
    public String getConfiguredProducts(String locid)
    {
        if (!dbkey.startsWith(Constants.GLB_TAG_DCM_PREFIX))
            return null;
        
        String id = getDbkey().substring(Constants.GLB_TAG_DCM_PREFIX.length());
        ProductWorker pw = new ProductWorker(id, locid);
        String products = null;
        pw.start();

        String[] proddata = (String[]) (Object[]) pw.get();

        if (proddata[1] == null) {
            products = proddata[0];
        } else {
            String prodList[] = ConfigComm.getCSCProductsModel().getContainerProducts();
            products = Utils.productArrayToString(prodList);
        }
        return products;
    }

    public String getDbkey() {
        return dbkey;
    }

    public void setDbkey(String dbkey) {
        this.dbkey = dbkey;
    }

    /**
     * @return the feedsLimit
     */
    public int getFeedsLimit() {
        return feedsLimit;
    }

    /**
     * @param feedsLimit the feedsLimit to set
     */
    public void setFeedsLimit(int feedsLimit) {
        this.feedsLimit = feedsLimit;
    }
		
    
    
    private class ProductWorker extends SwingWorker {

        ProductWorker(String dcm, String s) {
            dcmName = dcm;
            dc = s;
            data[0] = data[1] = null;
        }
        Object data[] = new Object[2];
        String dc = null;
        String dcmName = null;

        public Object construct() {
            try {
                data[0] = Utils.getDCMProducts(dcmName, dc);
            } catch (Exception e) {
                data[1] = e;
                if (e instanceof DBException) {
                    DBException dbe = (DBException) e;

                    if (dbe.getErrorNo() == Constants.KEY_NOT_FOUND) {
                        data[0] = null;
                        data[1] = null;
                    }
                }
                Log.getInstance().log_error("Error in retrieving product list for DCM:" + dcmName + " " + dc, e);
            }

            return data;
        }
    }
	    


}

/*
 * DistributorTransportConfiguration.java
 *
 * Created on June 16, 2006, 3:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author SyedR
 */
public class DistributorTransportConfiguration {

    public PrintStream print(PrintStream ps) {
        
        System.out.println("Transport: "+transport);
        System.out.println("Protocol:"+protocol);
        for (HostPort hp: hostList) {
            hp.print(ps);
        }
        return ps;
    }
    
    private static class HostPort {
        String host;
        String port;
        public HostPort(){}
        public HostPort(String h, String p) {
            host = h;
            port = p;
        }

        private void print(PrintStream ps) {
            System.out.println("Host:"+host+" Port:"+port);
        }
    }
    
    
    String transport;
    String protocol;
    String configuration;
    
    List<HostPort> hostList;
    String         filename;
    
    
    /** Creates a new instance of DistributorTransportConfiguration */
    public DistributorTransportConfiguration() {
    }
    
    public static DistributorTransportConfiguration
            parse(String transport, String proto)
    {
        DistributorTransportConfiguration dtc = new DistributorTransportConfiguration();
        
         
	java.util.StringTokenizer st = null;
	String typeStr=null, addrStr=null;
	
        dtc.configuration = transport;
        if (proto == null)
            proto = "IDS2";
        
        dtc.protocol = proto;

	st = new java.util.StringTokenizer(transport," ");
	if (st.hasMoreTokens())
	    typeStr = st.nextToken();
        if (st.hasMoreTokens())
	    addrStr = st.nextToken();
	
	if ((typeStr == null)
            || (addrStr == null) )
            return null;

            
        dtc.transport = typeStr;
        

	if  (typeStr.substring(0,3).equals("FIL")) {
            dtc.filename = addrStr;	 
	}
        else if (typeStr.equals("ASYNC")) {
	    int inx = addrStr.indexOf(':');
	    String h = addrStr.substring(0,inx);
	    String p = addrStr.substring(inx+1);

	    dtc.hostList = new ArrayList<HostPort>();
            HostPort hp = new HostPort(h, p);
            dtc.hostList.add(hp);

	}
        else if (typeStr.substring(0,3).equals("TCP")) {
            dtc.hostList = new ArrayList<HostPort>();
            
	    
	    st = new java.util.StringTokenizer(addrStr,",");
	    while (st.hasMoreTokens()) {
		String hpstr = st.nextToken();
		HostPort hp = new HostPort();
                
		int inx = hpstr.indexOf(':');
		if (inx != -1) {
		    hp.host = hpstr.substring(0,inx);
		    hp.port = hpstr.substring(inx+1);
		} else {
		    hp.host = "";
		    hp.port = hpstr;
		}
		dtc.hostList.add(hp);		
	    }
        }
        else
        {
            //throw exception here
        }
	
        
        
        return dtc;
    }
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
                
        sb.append(transport).append(" ");
                        
        if (transport.startsWith("FILE") ) {
            sb.append(filename);            
        } else if (transport.equals("ASYNC") 
                    || transport.startsWith("TCP")) {            
            for (HostPort hp : hostList ) {                            
                sb.append(hp.host)
                    .append(":")
                    .append(hp.port)
                    .append(",");
            }
            if (sb.toString().endsWith(","))
                sb.setLength(sb.length()-1);
        }
        return sb.toString();
    }
    
    
}

cc -g -KPIC -m64 -G -olibJGDBM.so jgdbm_JGDBM.c -I/usr/local/include -I/usr/java/include -I/usr/java/include/solaris -lgdbm
cp libJGDBM.so $IDSDIR/lib


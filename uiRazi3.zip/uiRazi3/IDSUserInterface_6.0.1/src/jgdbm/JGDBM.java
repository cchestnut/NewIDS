/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jgdbm;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * SVN  Info :  "$Id$"
 * SCCS Info :  "%W%    %E%"
 * @author srz
 */
public class JGDBM {


    static {
        System.loadLibrary("gdbm");
        System.loadLibrary("JGDBM");
        //System.load("/usr/local/lib/libgdbm.so");
        //System.load("/home/srz/ids2/iab/rel/lib/libJGDBM.so");
    }

    public native long  gdbm_open(String dbfile) throws IOException;
    public native void gdbm_close(long handle) throws IOException;

    public native ByteBuffer gdbm_fetch(long handle, String key) throws IOException;
    public native ByteBuffer gdbm_firstkey(long handle) throws IOException;
    public native ByteBuffer gdbm_nextkey(long handle, ByteBuffer key) throws IOException;
    public native int gdbm_store(long handle, ByteBuffer key, ByteBuffer content, int flag);
  

}

package model;
/*
 * ProductConfigurationModel.java
 *
 * Created on May 16, 2006, 11:37 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/*
**  SCCS Info :  "%W%    %E%"
*/
/**
 *
 * @author SyedR
 */

import java.util.*;

public class ProductConfigurationModel {
    
    List<ProductConfiguration> dbProdList;
    
    /** Creates a new instance of ProductConfigurationModel */
    public ProductConfigurationModel(List<ProductConfiguration> prodList) {
        dbProdList = prodList;
    }
    
    public void addModelListener()
    {
        
    }
    
    public void removeModelListener()
    {
        
    }
    
    public List<ProductConfiguration> getContainerProducts()
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if (dbpi.isContainer())
                l.add(dbpi);
        }
        return l;
    }

    public boolean isContainerProduct(String prodID)
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if (dbpi.productID.equals(prodID) && dbpi.isContainer())
                return true;
        }
        return false;
    }
     public List<ProductConfiguration> getTopLevelProducts()
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if (dbpi.isContainer() || (dbpi.containerID.equals("-")))
                l.add(dbpi);
        }
        return l;
    }
    
     public boolean isTopLevelProduct(String prodID)
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if (prodID.equals(dbpi.productID)
                && (dbpi.isContainer() || (dbpi.containerID.equals("-"))) )
                return true;
        }
        return false;
    }
     
     public List<ProductConfiguration> getLeafProducts(ProductConfiguration parent)
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if ( (!dbpi.isContainer() && !dbpi.containerID.equals("-")) 
                || ( dbpi.isContainer() && dbpi.productID.equals(dbpi.containerID)))
                l.add(dbpi);
        }
        return l;
    }
    
     public boolean isLeafProduct(String prodID)
    {
        List<ProductConfiguration> l = new ArrayList<ProductConfiguration>();
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if ( prodID.equals(dbpi.productID)
                && ( (!dbpi.isContainer() && !dbpi.containerID.equals("-")) 
                || !( dbpi.isContainer() && dbpi.productID.equals(dbpi.containerID))) )
                return true;
        }
        return false;
    }
    public List<ProductConfiguration> getAllProducts()
    {
        return getLeafProducts(null);
    }
    
    public String getContainer(String subProdID)
    {
        
        for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);
            if (dbpi.productID.equals(subProdID) && 
                        !dbpi.containerID.equals("-"))
                return dbpi.containerID;
        }
        return null;
    }

    String[] getSubProducts(String container) {
        
	 
	 java.util.ArrayList list = new java.util.ArrayList(50);
	 
	 for (int i = 0; i < dbProdList.size(); i++) {
            ProductConfiguration dbpi = dbProdList.get(i);            
	     
	     if (container.equals(dbpi.containerID))
		 list.add(new String(dbpi.productID));
	 }
	 
	 java.util.Collections.sort(list);
	 return (list.size()==0)?null:(String[])list.toArray(new String[0]);
    }
    
    
}

/*
 * FeedDescription.java
 *
 * Created on May 23, 2006, 7:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 *
 * @author SyedR
 */
public class FeedDescription {
    private String name;
    private String format;
    private String protocol;
    private String transport;
    private List<String> products;
    private String conversion_formats;
    private String reader;
    private String messageManager;
    
    
    
    /** Creates a new instance of FeedDescription */
    public FeedDescription() {
      setProducts(new ArrayList<String>());
    }
    
    
    class FeedDescriptionComparator
            implements java.util.Comparator<FeedDescription>
    {
        public int compare(FeedDescription o1,
                FeedDescription o2) {
            return o1.getName().compareTo(o2.getName());
        }
        
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public List<String> getProducts() {
        return products;
    }

    public String getProductString(String separator)
    {
        if (separator == null) separator = " ";
        StringBuilder sb = new StringBuilder();
        for (String product: products) {
            sb.append(product).append(separator);
        }
        
        return sb.toString();
    }
    
    
    public void setProducts(List<String> products) {
        this.products = products;
    }

    public String getConversion_formats() {
        return conversion_formats;
    }

    public void setConversion_formats(String conversion_formats) {
        this.conversion_formats = conversion_formats;
    }

     public static List<String> productStringToList(String prodList)
    {
        ArrayList<String> als = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer(prodList," ,   ");
        while (st.hasMoreTokens()) {
            als.add(st.nextToken());
        }
	

	return  als;
    }
    public void setProducts(String string) {
        setProducts(/*ids2ui.Utils.*/productStringToList(string));        
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    final static String NO_MSGMGR = "NONE";
    public String getNoMessageManagerString()
    {
        return NO_MSGMGR;
    }
    public boolean hasMessageManager()
    {
        if ( (messageManager == null) || 
                (messageManager.equals(NO_MSGMGR)) )
                return false;
        return true;
    }
    
    
    public String getMessageManager() {
        return messageManager;
    }

    public void setMessageManager(String messageManager) {
        this.messageManager = messageManager;
    }
}
 
    
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * SVN  Info :  "$Id$"
 * SCCS Info :  "%W%    %E%"
 * @author srz
 */
public class PremiumCodesList {
    
    HashMap<String, String> codesMap;
    
    
    
    public static PremiumCodesList parse(String dbvalue)
    {
        HashMap<String,String> m = new HashMap<String, String>();
        
        String rows[] = dbvalue.split("[<>]");
        for (String row:rows)
        {            
            if (row.length() > 0)
            {                
                String [] values = row.split(",");
                if ((values.length == 2) 
                        && (values[0].trim().length() > 0 )
                        && (values[1].trim().length() > 0 ) )
                {
                    m.put(values[0].trim(), values[1]);                   
                }                
            }
        }
        return new PremiumCodesList(m);
    }

    public PremiumCodesList(HashMap<String, String> m) {
        codesMap = m;        
    }

    public String lookup(String token)
    {
        String v = codesMap.get(token);
        return ( v!=null)?v:"";
    }
    
    public Set<String> getTokens()
    {
        return codesMap.keySet();
    }
    
    public Set<Map.Entry<String,String>> getEntries()
    {
        return codesMap.entrySet();
    }
    
    
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        Set<Map.Entry<String,String>> entries = codesMap.entrySet();
        for (Map.Entry entry:entries)
        {
            sb.append("<")
                    .append(entry.getKey())
                    .append(",")
                    .append(entry.getValue())
                    .append(">");
        }
        return sb.toString();
    }
}

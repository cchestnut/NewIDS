/*
 * WholesaleTransportConfiguration.java
 *
 * Created on June 16, 2006, 4:37 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;

import ids2ui.Constants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author SyedR
 */
public class WholesaleTransportConfiguration {
    
    private static class FTPparams {
        String server;
        String port;
        String username;
        String password;
        String transferMode;
        String remoteDir;
        boolean passiveMode;        
        boolean statistics;        
        boolean renameFile;     

        
        
    }
    
    String type;
    List<FTPparams> ftpList;
    
    /** Creates a new instance of WholesaleTransportConfiguration */
    public WholesaleTransportConfiguration() {
    }
    
    
    
    public static WholesaleTransportConfiguration
            parse(HashMap map) {
        WholesaleTransportConfiguration wtc = new WholesaleTransportConfiguration();
        
        
        int n = -1;
        
        String np = (String)map.get(Constants.FTP_NUM_ENTRIES);
        
        n = Integer.parseInt(np);
        
        wtc.ftpList = new ArrayList<FTPparams>(n);
        
        
        for (int i = 0; i < n; i++) {
            FTPparams p = new FTPparams();
            p.server = (String)map.get(Constants.FTP_SERVER_PREFIX+i);
            p.port = (String)map.get(Constants.FTP_PORT_PREFIX+i);
            p.username = (String)map.get(Constants.FTP_USERNAME_PREFIX+i);
            p.password = (String)map.get(Constants.FTP_PASSWORD_PREFIX+i);
            
            p.passiveMode = Boolean.valueOf((String)map.get(Constants.FTP_PASSIVE_MODE_PREFIX+i)).booleanValue();
            p.transferMode = (String)map.get(Constants.FTP_TRANSFER_MODE_PREFIX+i);
            p.statistics = Boolean.valueOf((String)map.get(Constants.FTP_STATISTICS_FILE_PREFIX+i)).booleanValue();
            p.remoteDir = (String)map.get(Constants.FTP_REMOTE_DIR_PREFIX+i);
            p.renameFile = Boolean.valueOf((String)map.get(Constants.FTP_RENAME_FILE_PREFIX+i)).booleanValue();
            wtc.ftpList.add(p);
        }
        
        return wtc;
    }
    
    public java.util.HashMap getFTPParams() {
        
        
        int num = ftpList.size();
        
        
        java.util.HashMap map = new java.util.HashMap(5);
        int count = 0;
        for (FTPparams p:ftpList) {
        
            map.put(Constants.FTP_SERVER_PREFIX+count,p.server);
            map.put(Constants.FTP_PORT_PREFIX+count,p.port);
            map.put(Constants.FTP_USERNAME_PREFIX+count,p.username);
            map.put(Constants.FTP_PASSWORD_PREFIX+count,p.password);
            
   
            
            
            Boolean b;
            if (p.passiveMode)
                b = Boolean.TRUE;
            else
                b = Boolean.FALSE;            
            String passive_mode = b.toString();
            map.put(Constants.FTP_PASSIVE_MODE_PREFIX+count,passive_mode);
             
            
            
            if (p.statistics)
                b = Boolean.TRUE;
            else
                b = Boolean.FALSE;  
            String statistics = b.toString();            
            map.put(Constants.FTP_STATISTICS_FILE_PREFIX+count,statistics);
            
            
            
            if (p.renameFile)
                b = Boolean.TRUE;
            else
                b = Boolean.FALSE;             
            String rename_file = b.toString();
            map.put(Constants.FTP_RENAME_FILE_PREFIX+count,rename_file);
            
            
            
            String xfer_mode = p.transferMode;            
            if ( (xfer_mode!=null)
            && (xfer_mode.trim().length() > 0) )
                map.put(Constants.FTP_TRANSFER_MODE_PREFIX+count,xfer_mode);
            
            
            
            String remote_dir = p.remoteDir;
            if ( (remote_dir!=null)
            && (remote_dir.trim().length() > 0) )
                map.put(Constants.FTP_REMOTE_DIR_PREFIX+count,remote_dir);
            
            
            
            count++;
            
        }
        
        if (count>0)
            map.put(Constants.FTP_NUM_ENTRIES,Integer.toString(count));
        
        return map;
    }
    
    
    
}

/*
 * Globals.java
 *
 * Created on May 24, 2006, 5:06 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
 
/*
 **  SCCS Info :  "%W%    %E%"
 */

package model;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author SyedR
 */
public class Globals {
    
    
    public static ExecutorService backgroundExec = Executors.newCachedThreadPool();
    
    /** Don't allow instances of Globals */
    private Globals() {
    }
    
    
      
    private static ProductConfigurationModel productsModel;
    private static String formatConversionString;
    private static List<String> readerProtocolList;
    private static List<String> productFormatList;
    private static List<String> transportTypesList;
    private static List<String> locationsList;
    private static List<String> statisticsList;
    private static List<String> dcmList;
    
    
    public static ProductConfigurationModel getProductsModel() {
        return productsModel;
    }

    public static void setProductsModel(ProductConfigurationModel aProductsModel) {
        productsModel = aProductsModel;
    }

    public static String getFormatConversionString() {
        return formatConversionString;
    }

    public static void setFormatConversionString(String aFormatConversionString) {
        formatConversionString = aFormatConversionString;
    }

    public static List<String> getReaderProtocolList() {
        return readerProtocolList;
    }

    public static void setReaderProtocolList(List<String> aReaderProtocolList) {
        readerProtocolList = aReaderProtocolList;
    }

    public static List<String> getProductFormatList() {
        return productFormatList;
    }

    public static void setProductFormatList(List<String> aProductFormatList) {
        productFormatList = aProductFormatList;
    }

    public static List<String> getTransportTypesList() {
        return transportTypesList;
    }

    public static void setTransportTypesList(List<String> aTransportTypesList) {
        transportTypesList = aTransportTypesList;
    }
    
    
    public static class ProgramDesc {
        String type;  /* Reader,Message Manager, Line Handler*/
        String label;
        String name;  /* DSP_READER, DCM_READER, DSP_LINEHAND, ..*/
        String execName; /* dsp_reader,dcm_reader,...*/ 
 
        
        public ProgramDesc(String t, String l, String n, String e){
            type = t;
            label = l;
            name = n;
            execName = e;
        }
    }
    
    public static String READER = "READER";
    public static String READER_LABEL = "Reader";
    public static String MESSAGE_MANAGER = "MESSAGE_MANAGER";
    public static String MESSAGE_MANAGER_LABEL = "Message Manager";
    public static String LINEHANDLER = "LINEHANDLER";
    public static String LINEHANDLER_LABEL = "Line Handler";
    public static String SYSTEM_SERVICE = "SYSTEM_SERVICE";
    public static String CONFIGURATION_SERVER = "CONFIGURATION_SERVER";
    public static String CONFIGURATION_SERVER_LABEL = "Configuration server";
    public static String WATCHDOG = "WATCHDOG";
    public static String WATCHDOG_LABEL = "Watchdog";
    public static String ADMINISTRATION_SERVER = "ADMINISTRATION_SERVER";
    public static String ADMINISTRATION_SERVER_LABEL = "Administration server";
    public static String MESSAGE_FILTER = "MESSAGE_FILTER";
    public static String MESSAGE_FILTER_LABEL = "Message filter";
    public static String RETRANS_SERVER = "RETRANS_SERVER";    
    public static String RETRANS_SERVER_LABEL = "Retransmission server";
    public static String STATUS_MULTIPLEXER = "STATUS_MULTIPLEXER";    
    public static String STATUS_MULTIPLEXER_LABEL = "Status multiplexer";
    public static String STATUS_SERVER = "STATUS_SERVER";
    public static String STATUS_SERVER_LABEL = "Status server";        
    
    public static ProgramDesc ProgramDescriptions[] = {
        new ProgramDesc(READER,          READER_LABEL,          "DSP_READER",      "dsp_reader"),
        new ProgramDesc(READER,          READER_LABEL,          "DCM_READER",      "dcm_reader"),
        new ProgramDesc(READER,          READER_LABEL,          "SY_READER",       "sy_reader"),
        new ProgramDesc(MESSAGE_MANAGER, MESSAGE_MANAGER_LABEL, "MESSAGE_MANAGER", "msgmgr"),
        new ProgramDesc(LINEHANDLER,     LINEHANDLER_LABEL,     "DSP_LINEHANDLER", "dsp_linehand"),
        new ProgramDesc(LINEHANDLER,     LINEHANDLER_LABEL,     "DCM_LINEHANDLER", "dcm_linehand"),        
        new ProgramDesc(SYSTEM_SERVICE,  WATCHDOG_LABEL,        WATCHDOG, "watchdog"),
        new ProgramDesc(SYSTEM_SERVICE,  CONFIGURATION_SERVER_LABEL, CONFIGURATION_SERVER, "configserver"),
        new ProgramDesc(SYSTEM_SERVICE,  STATUS_SERVER_LABEL,   STATUS_SERVER, "status_server"),
        new ProgramDesc(SYSTEM_SERVICE,  ADMINISTRATION_SERVER_LABEL, ADMINISTRATION_SERVER, "adminserver"),
        new ProgramDesc(SYSTEM_SERVICE,  MESSAGE_FILTER_LABEL,  MESSAGE_FILTER, "msgfilter"),
        new ProgramDesc(SYSTEM_SERVICE,  STATUS_MULTIPLEXER_LABEL, STATUS_MULTIPLEXER, "status_mux"),
        new ProgramDesc(SYSTEM_SERVICE,  RETRANS_SERVER_LABEL,  RETRANS_SERVER, "rtp")
                
    };
    
    static List<String> readerList = null;
    static List<String> lhList = null;
    static List<String> msgmgrList = null;
    static List<String> systemServicesList = null;
    
    private synchronized
            static List<String> getPlist(String type, List<String> list)
    {
        if (list==null) {
            list = new ArrayList<String>();
            for (int i = 0; i < ProgramDescriptions.length; i++) {
                if (ProgramDescriptions[i].type.equals(type))
                    list.add(ProgramDescriptions[i].name);
            }
        }
        return list;
    }
    
    public static List<String> getReaders()
    {
        return getPlist(READER, readerList);        
    }
    public static List<String> getMessageManagers()
    {
        return getPlist(MESSAGE_MANAGER, msgmgrList);        
    }
    public static List<String> getLinehandlers()
    {
        return getPlist(LINEHANDLER, lhList);         
    }

    
    public static List<String> getSystemServices()
    {
        return getPlist(SYSTEM_SERVICE, systemServicesList);         
    }
    
            
    public static String getExecName(String s) {
        for (int i = 0; i < ProgramDescriptions.length; i++) {
            if (ProgramDescriptions[i].type.equals(s)
                || ProgramDescriptions[i].name.equals(s))
                return(ProgramDescriptions[i].execName);
        }
        return null;
    }

    public static String getProgramLabel(String progname) {
        for (int i = 0; i < ProgramDescriptions.length; i++) {
            if (ProgramDescriptions[i].execName.equals(progname))
                return(ProgramDescriptions[i].label);
        }        
        return null;
    }
    
    public static String getProgramName(String progname) {
        for (int i = 0; i < ProgramDescriptions.length; i++) {
            if (ProgramDescriptions[i].execName.equals(progname))
                return(ProgramDescriptions[i].name);
        }        
        return null;
    }
    
    
    public static String getProgramType(String name) {
        for (int i = 0; i < ProgramDescriptions.length; i++) {
            if (ProgramDescriptions[i].name.equals(name))
                return(ProgramDescriptions[i].type);
        }        
        return null;
    }
    
    public static class PlatformDescription {
        String name;
        String label;
        String basedir;
        List <String> hostTypes;
        String login_logo_filename;
        String platform_logo_filename;
        
        public PlatformDescription(String n, String l, String basedir, 
                String login_image, String platform_image, String ... args)
        {
            name = n;
            label = l;
            this.basedir = basedir;
            this.login_logo_filename = login_image;
            this.platform_logo_filename = platform_image;
           
            hostTypes = new ArrayList<String>();
            
            if (args != null && args.length > 0) {                
                for (int i = 0; i < args.length; i++) 
                    hostTypes.add(args[i]);                
            }
        }
    }
    
    public static PlatformDescription PlatformDescriptions[] = {
        new PlatformDescription("IDS2","ids2","/ids2", "ids2a.gif", "dj_newswires.gif", "DSP", "DCM"),
        new PlatformDescription("FIDS2","fids2","/ids2", "ids2a.gif", "dj_newswires.gif", "DSP", "DCM"),
        new PlatformDescription("IAB","IDS in a box","/iab", "ids2a.gif", "dj_newswires.gif", "IAB"),
        new PlatformDescription("ULL","Ultra Low Latency","/ull", "ids2a.gif", "dj_newswires.gif", "IAB")
    };

    public static List<String> getLocationsList() {
        return locationsList;
    }

    public static void setLocationsList(List<String> aLocationsList) {
        locationsList = aLocationsList;
    }

    public static List<String> getStatisticsList() {
        return statisticsList;
    }

    public static void setStatisticsList(List<String> aStatisticsList) {
        statisticsList = aStatisticsList;
    }
    
    
    public static List<String> getDCMList() {
        return dcmList;
    }
    
    public static void setDCMList(List<String> aDCMList) {
        dcmList = aDCMList;
    }
}

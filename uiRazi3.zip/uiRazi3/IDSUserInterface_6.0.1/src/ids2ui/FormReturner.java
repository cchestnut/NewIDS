/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ids2ui;

/**
 *
 * @author ChestnutC
 */
public interface FormReturner {
    javax.swing.JPanel getForm();
}

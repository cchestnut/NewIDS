/*
**  SCCS Info :  "@(#)StatusHandler.java	1.6    08/12/05"
*/
/*
 * StatusHandler.java
 *
 * Created on June 15, 2000, 9:50 AM
 */
 
package ids2ui;

import javax.swing.JOptionPane;

/** 
 *
 * @author  srz
 * @version 
 */
public class StatusHandler extends Object {
        private static StatusHandler _instance = null;
        private static StatusTabHandler statFrame;
        private static StatusTabHandler DCMreadFrame;
        private static StatusTabHandler DSPreadFrame;
        private static StatusTabHandler MSGreadFrame;
        
            /** Creates new StatusHandler */
        private StatusHandler() {
        }
  
        public static StatusHandler getInstance() {
                if (_instance == null) {
                        synchronized(StatusHandler.class) {
                                if (_instance == null) {
                                        _instance  = new StatusHandler();
                                }
                        }
                }
                return _instance;
        }
  
        public int 
        displayStatus(java.awt.Component parent, int type, 
		      int which, String host, String tag, String name )
                throws Exception
        {
                        

                javax.swing.JFrame status_win = null;
                
                String title;
                switch (type) {
                    case Constants.DSP_READER:
                            title = "DSP Reader Status Tabs";                                      
                            if(DSPreadFrame == null)
                                DSPreadFrame = new StatusTabHandler(title, parent, type, which, name, tag);
                            else
                                DSPreadFrame.addTab(parent, type, which, name, tag);
                            break;
                    case Constants.DCM_READER:
                            title = "DCM Reader Status Tabs";                                      
                            if(DCMreadFrame == null)
                                DCMreadFrame = new StatusTabHandler(title, parent, type, which, name, tag);
                            else
                                DCMreadFrame.addTab(parent, type, which, name, tag);
                            break;
                    case Constants.MSGMGR:
                            title = "Message Manager Status Tabs";                                      
                            if(MSGreadFrame == null)
                                MSGreadFrame = new StatusTabHandler(title, parent, type, which, name, tag);
                            else
                                MSGreadFrame.addTab(parent, type, which, name, tag);
                            break;
                    case Constants.DSP_BROADCASTER:
                    case Constants.DCM_LINEHANDLER:
                            /*try {
                                
                                    status_win    = new DistributorStatusForm(type,which,name);
                            } catch (Utils.DuplicateWindowException dwe) {
                            } */
                            
                            if(type == Constants.DSP_BROADCASTER)
                                title = "DSP Line Handler Status Tabs";
                            else
                                title = "DCM Line Handler Status Tabs";
                            if(statFrame == null)
                                statFrame = new StatusTabHandler(title,parent, type, which, name);
                            else
                                statFrame.addTab(parent, type, which, name);
                            break;
                    default:
                            Log.getInstance().show_error(parent,"Error",
                                                         "Request to display status"
                                                         +"of unknown type:"+type,
                                                         null);
                }


                if (status_win!=null)
                        status_win.show();


                return 0;             
        }
  
}

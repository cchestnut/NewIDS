/*
**  SCCS Info :  "@(#)ReaderStatusModel.java	1.12    08/12/05"
*/
/*
 * ReaderStatusModel.java
 *
 * Created on October 16, 2000, 3:37 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */



  
public class ReaderStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements Utils.UpdateEventModel 
{
    
    
    protected int     m_sortCol = 0;
    protected boolean m_sortAsc = true;

    protected java.util.Vector m_vector = null;

    protected int m_columnsCount 
	= Constants.ReaderStatusTableColumnNames.length;

    String Tag = null;
    String ConfigKey  = null;
    String HostKey = null;
    String PHostKey = null;
    String FeedKey = null;
    String NameKey = null;
  
    String ProgramName = null;



    /** Creates new ReaderStatusModel */
   
    ReaderStatusModel(int type,int which, String tag, String name) 
	throws Exception 
    {
	this(type,which,tag,name, null);
    }

    ReaderStatusModel(int type,int which, String tag, String name,
			ReaderStatusEvent evt) 
	throws Exception 
    {
 
	m_vector = new java.util.Vector(50);

	if (tag!=null)Tag = new String(tag);
	if (name!=null) NameKey = new String(name);
    
	if (type==Constants.DSP_READER) {
	    ConfigKey = Constants.GLB_TAG_DSP;      
	    ProgramName="dsp_reader";      
	} else if (type==Constants.DCM_READER) {
	    ConfigKey = Constants.GLB_TAG_DCM_PREFIX+tag;
	    ProgramName="dcm_reader";
	} else if (type == Constants.MSGMGR) {
	    ConfigKey = Constants.GLB_TAG_DCM_PREFIX+tag;
	    ProgramName="msgmgr";
   	} 
	if (which == 1) {
	    FeedKey = "INPUT_FEED1";
	    HostKey = "HOST1";
	    PHostKey = "PHOST1";
	} else if (which == 2)  {
	    FeedKey = "INPUT_FEED2";
	    HostKey = "HOST2";
	    PHostKey = "PHOST2";
	}
    
    
	ReaderStatusEvent e = (ReaderStatusEvent)Update();
	if (evt != null) {
		evt.copy(e);
	} else {
		int err = e.getStatus();
                if (err == Constants.KEY_NOT_FOUND) {
                        throw new DBException(e.getError(), Constants.KEY_NOT_FOUND);
                } else if  (err!=0) {
                        throw new Exception(e.getError()); 
                }
	}
    
    }
  



    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("ReaderStatusModel:Error in update",
					e);
	}
    }
  
    synchronized public String getName() {
	return NameKey;
    }
  
    public void stop() {
	
    }
  
    
    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int column) {
      	String str = Constants.ReaderStatusTableColumnNames[column];
	if (column==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 
    public boolean isCellEditable(int nRow, int nCol) {
	return false;
    }

    synchronized public Object getValueAt(int nRow, int nCol) {
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }

   

    public  java.util.EventObject 
	Update() 
    {

	java.util.HashMap map = null;
	String host=null,lhost=null, phost=null,hostName=null;
	String ifstr=null;
	String readerMode=null, timeStamp=null;
	StringBuffer statusHostKey = new StringBuffer();
	java.util.Vector u_vector = new java.util.Vector(50);

	/* Get Configuration */
	try {
	    map = ConfigComm.getHashMap(ConfigKey);

	    if (ConfigKey.equals(Constants.GLB_TAG_DSP))
		ifstr = (String)map.get(FeedKey);

	    lhost = (String)map.get(HostKey);
	    phost = (String)map.get(PHostKey);
	    if (phost!=null) {
		host = phost;
	    } else {
		host = lhost;
	    }

	    String sep = new String(" ,\t");
	    java.util.StringTokenizer st =
      		new java.util.StringTokenizer(host,sep);
      
	    while (st.hasMoreTokens()) {
		hostName = st.nextToken();
		statusHostKey.append(hostName).append(" ");
	    }

	    boolean found = false;

	    if (ConfigKey.equals(Constants.GLB_TAG_DSP)) {

		StringBuffer separator=new StringBuffer();

		separator.append(ConfigComm.CONF_GS)
		    .append(ConfigComm.CONF_ETX);

		st = new java.util.StringTokenizer(ifstr,
						   separator.toString());
    
		String fldsep = new String(",");

		while (st.hasMoreTokens()) {

		    String s = st.nextToken();
		    java.util.StringTokenizer fst
			= new java.util.StringTokenizer(s,
							fldsep.toString());
		    String programId;     
		    programId = fst.nextToken();
		    if (NameKey==null) {
			NameKey = new String(programId);
			found = true;
			break;
		    } else {          
			if (programId.equals(NameKey)) {
			    found = true;
			    break;
			}
		    }
		}

	    } else {
		if (NameKey==null) 
		    NameKey = new String(Constants.GLB_DCM_INPUT_NAME);
		found = true;
	    }


	    if (statusHostKey.length()==0) {
		synchronized (this) {
		    m_vector.removeAllElements();
		}
   		fireTableDataChanged();
		return new ReaderStatusEvent(this,-1,"Error in parsing hosts");
	    }


	    if (!found) {
		synchronized (this) {
		    m_vector.removeAllElements();
		}
   		fireTableDataChanged();
		return new ReaderStatusEvent(this,-1,"Reader: "+NameKey
					     +" not found in configuration.");
	    }
      


	} catch (DBException dbe ) {

	    Log.getInstance().log_error("ReaderStatusModel:Update:Error "
					+"retrieving configuration: ",dbe);
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();

	    if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND) {
		return new ReaderStatusEvent(this,Constants.KEY_NOT_FOUND,
                                             Tag+" is not configured");
	    }

	    return new ReaderStatusEvent(this,-1,"Error in retrieving"
					 +"configuration");


	} catch (Exception e) {      

	    Log.getInstance().log_error("ReaderStatusModel:Update:Error"
					+"retrieving configuration: ",e);
	    
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();
	    return new ReaderStatusEvent(this,-1,"Error in retrieving "
					 +"configuration");
	}


	/* Get Status */

	try {
	    String statusBuf
		= StatusRequest.getInstance().statusQuery(statusHostKey.toString().trim(),
						 ProgramName,NameKey);

	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Status: "+statusBuf);
        

	    String separator = new String(",\0\n");
	    String type=null,format=null;
	    String prognm=null,progid=null;

	    java.util.StringTokenizer tokenizer 
		= new java.util.StringTokenizer(statusBuf,separator);

	    if (tokenizer.hasMoreTokens()) {
		String t = tokenizer.nextToken();
		int i = t.indexOf('\t');
		if (i > 0)
		    timeStamp = t.substring(0,i);
		else
		    timeStamp = t;
	    }


	    if (tokenizer.hasMoreTokens())
		type = tokenizer.nextToken();

	    if (tokenizer.hasMoreTokens())
		hostName = tokenizer.nextToken();

	    if (tokenizer.hasMoreTokens())
		prognm = tokenizer.nextToken();

	    if (tokenizer.hasMoreTokens())
		progid = tokenizer.nextToken();


	    if (type.equalsIgnoreCase("error")) {
		String errorstr=null;
		if (tokenizer.hasMoreTokens()) {
		    errorstr = tokenizer.nextToken();
		    Log.getInstance().log_warning("Error in retrieving status:"
						  +hostName+","+prognm+","
						  +progid+" :"+errorstr,
						  null);
		}

		synchronized (this) {
		    m_vector.removeAllElements();
		}
   		fireTableDataChanged();

		return new ReaderStatusEvent(this,-2,errorstr);	
	    }


	    String mode = null;
	    if (tokenizer.hasMoreTokens())
		mode = tokenizer.nextToken();

	    if (mode!=null) {
		if (mode.startsWith("RT"))
		    readerMode = new String ("Real Time");
		else if (mode.startsWith("SY"))
		    readerMode = new String("Synchronizing");
		else 
		    readerMode = new String("Unknown");
	    }
                
	    if (tokenizer.hasMoreTokens())
		format = tokenizer.nextToken();

	    
	    while (tokenizer.hasMoreTokens()) {
		String pstatus = tokenizer.nextToken();
		int inx = pstatus.indexOf("|");
		if (inx < 0)
			continue;
		String prod = pstatus.substring(0,inx);
		String seqno = pstatus.substring(inx+1);

		String [] rowData = 
		    new String[m_columnsCount];
	
		rowData[0] = prod;
		rowData[1] = format;
		rowData[2] = seqno;

		u_vector.add(rowData);

	    }

	} catch (Exception e) {        

	    Log.getInstance().log_error("ReaderStatusModel:Error retrieving"
					+"status: Host: "
					+statusHostKey.toString()
					+" Program: "+ProgramName
					+" ProgID: "+NameKey,e);
		synchronized (this) {
		    m_vector.removeAllElements();
		}
	    fireTableDataChanged();
	    return new ReaderStatusEvent(this,-1,"Error in retrieving status.");
	}


	if ((timeStamp==null)||(readerMode==null)) {
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();
	    return new ReaderStatusEvent(this,-1,"Empty Status Record");
	}

	
	java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));

	synchronized (this) {
	    if (m_vector!=null) m_vector.clear();
	    m_vector = null;
	    m_vector = u_vector;
	}
	fireTableDataChanged();
	return new ReaderStatusEvent(this,NameKey,hostName,timeStamp,readerMode);


    }







    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    
	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }


	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;

	    for (int i=0; i < Constants.ReaderStatusTableColumnNames.length; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }
	    m_table.getTableHeader().repaint();  

	    synchronized (ReaderStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, m_sortAsc));
	    }

	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(ReaderStatusModel.this)); 
	    m_table.repaint();  
	    rwLock.writeLock().release();

	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;
	    double d1, d2;
	    switch (m_sortCol) {
	    case 0:    // product
	    case 1:    // format
		result = s1.compareTo(s2);
		break;
	    case 2:    // sequence
		try {
		    d1 = Double.parseDouble(s1);
		    d2 = Double.parseDouble(s2);
		    result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
		} catch (NumberFormatException nfe){}
		break;
	    }

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }
}

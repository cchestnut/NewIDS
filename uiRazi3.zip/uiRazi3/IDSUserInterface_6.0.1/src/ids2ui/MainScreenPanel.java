/*
**  SCCS Info :  "@(#)MainScreenPanel.java	1.29    05/04/11"
*/
/*
 * MainScreenPanel.java
 *
 * Created on April 18, 2000, 11:18 AM
 */
package ids2ui;

import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

 
/** 
 *
 * @author  srz
 * @version 
 */
public class MainScreenPanel extends javax.swing.JPanel {


        private static javax.swing.JFrame mainFrame=null;
        private static javax.swing.JApplet mainApplet = null;

        private static MainScreenPanel instance;

        public static javax.swing.JTextArea logTextArea=null;


        private java.awt.CardLayout layoutManager = null;
        private java.util.Properties props = null;
  
            /** Creates new form MainScreenPanel */

        public MainScreenPanel() {
                this((javax.swing.JApplet)null);
        }


        public MainScreenPanel(javax.swing.JApplet applet) {
                super(true); // Turn double buffering ON

                mainApplet = applet;
                init();
        }

        public MainScreenPanel(javax.swing.JFrame frame) {
                super(true); // Turn double buffering ON

                mainFrame = frame;
                init();
        }

        
        
        private void init()
        {
                instance = this;


                initComponents ();
             
		StringBuffer title 
				= new StringBuffer(Release.PLATFORM_STRING);

                if (AccessLevel.MENU_ACCESS_LEVEL==1)
                        title.append(" Operator Interface");
                else if (AccessLevel.MENU_ACCESS_LEVEL==2)
                        title.append(" Interface");
		else
                	title.append(" Administration Interface");

                
                javax.swing.JLabel ids2Label = new javax.swing.JLabel(title.toString(),
                                                                      javax.swing.SwingConstants.CENTER);               
                labelPanel.add(ids2Label);              
                
                javax.swing.ImageIcon icon = IDS_SwingUtils.createImageIcon(Release.GIF1_STRING,
                                                               "IDS image");

                ids2Label = new javax.swing.JLabel( icon, 
                                                                                          javax.swing.SwingConstants.CENTER);               
                djIconPanel.add(ids2Label);

                
                icon = IDS_SwingUtils.createImageIcon(Release.GIF2_STRING,
                                                      "IDS image");

                 ids2Label = new javax.swing.JLabel(icon, javax.swing.SwingConstants.CENTER);
                
                ids2Label.setOpaque(false);
                loginLabelPanel.add(ids2Label);
                

                javax.swing.JSeparator separator
                        = new javax.swing.JSeparator();
                
                java.awt.GridBagConstraints gridBagConstraints
                        = new java.awt.GridBagConstraints ();
                gridBagConstraints.gridx = 0;
                gridBagConstraints.gridy = 4;
                gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints.insets = new java.awt.Insets (10, 10, 10, 10);
                
                jPanel23.add (separator, gridBagConstraints);

                
                separator = new javax.swing.JSeparator();
                
                gridBagConstraints = new java.awt.GridBagConstraints ();
                gridBagConstraints.gridx = 0;
                gridBagConstraints.gridy = 7;
                gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints.insets = new java.awt.Insets (10, 10, 10, 10);
                
                jPanel23.add (separator, gridBagConstraints);
                
                separator = new javax.swing.JSeparator();
                
                gridBagConstraints = new java.awt.GridBagConstraints ();
                gridBagConstraints.gridx = 0;
                gridBagConstraints.gridy = 12;
                gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints.insets = new java.awt.Insets (10, 10, 10, 10);
                
                jPanel23.add (separator, gridBagConstraints);


                
                
                ((javax.swing.JTextField) (dcmComboBox.getEditor()).getEditorComponent()).setDocument( new UCDocument(32));

                ((javax.swing.JTextField) (distrComboBox.getEditor()).getEditorComponent()).setDocument( new UCDocument(Constants.DISTRIBUTOR_ID_SIZE));



                if (Constants.SHOW_PORTS_BUTTON) {
                        javax.swing.JButton b = new javax.swing.JButton("Server ports");
                        b.addActionListener(new java.awt.event.ActionListener() {
                                public void actionPerformed(java.awt.event.ActionEvent evt) {
                                        showPortsDialog(evt);
                                } 
                        }
                                            );
                        jPanel14.add(b);
                }

                ActionHandlers.ActionHandler ah = new ActionHandlers.ActionHandler(
                        mainFrame, null, null, null, null)
                        {
                                public void handler(javax.swing.JButton cmdButton, String command) {


                                        String item = (String)distrComboBox.getSelectedItem();
                                        if ((item==null) || (item.trim().length()==0) ) {
                                                Utils.showDialog(frame,"Please enter a distributor ID.");
                                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                                return;
                                        }
                                        try {
                                                DistrRetransRequestDialog dlg 
                                                        = new DistrRetransRequestDialog(frame,
                                                                                        item,
                                                                                        null,-1,
                                                                                        null,null);
                                                dlg.show();
                                        } catch (Exception e) {
                                                Log.getInstance().show_error(frame,"Error",
                                                                             "Error in displaying retransmission dialog.", e);
                                        }
                                
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                
                                }
                        };

                retransRequestButton.addActionListener(ah);

        
                ah = new ActionHandlers.ActionHandler(
                        mainFrame, null, null, null, null)
                        {
                                public void handler(javax.swing.JButton cmdButton, String command) {


                                        String item = (String)distrComboBox.getSelectedItem();
                                        if ((item==null) || (item.trim().length()==0) ) {
                                                Utils.showDialog(frame,"Please enter a distributor ID.");
                                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                                return;
                                        }
                                        try {
                                                DistrRetransStatusForm dlg 
                                                        = new DistrRetransStatusForm(item,null,
                                                                                     null,null);
                                                dlg.show();
                                        }
                                        catch ( DBException dbe ) {
                                                String errmsg = null;
                                                
                                                if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND) {
                                                        StringBuffer errmsg1 =
                                                                new StringBuffer("Distributor ");
                                                        errmsg1.append(item)
                                                                .append(" is not configured.");
                                                        errmsg = errmsg1.toString();
                                                        
                                                }
                                                if (errmsg == null) {
                                                        StringBuffer errmsg1 =
                                                                new StringBuffer("Error displaying retransmission status: \n");
                                                        errmsg1.append(dbe.getMessage());
                                                        errmsg = errmsg1.toString();
                                                }
                                                
                                                Log.getInstance().show_error(frame,"Error",
                                                                             errmsg, dbe);
                                                
                                        }
                                        catch (Exception e) {
                                                Log.getInstance().show_error(frame,"Error",
                                                                             "Error in displaying retransmission status.", e);
                                        }
                                
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                
                                }
                        };
                retransStatusButton.addActionListener(ah);


         
                    /*
                    **distrComboBox.addItem("ENTER ID");
                    **dcmComboBox.addItem("ENTER/SELECT DCM");
                    */

                if ( AccessLevel.MENU_ACCESS_LEVEL != 0 ) {
                        jButton1.setEnabled(false); // DSP Menu
                        
                        saveStateButton.setEnabled(false); // Save State
                        
                        jButton8.setEnabled(false);	// Products
                        dcmFormatsButton.setEnabled(false); //Product formats

                        
                        jButton15.setEnabled(false);	// System configuration

                        
                        distrConfigButton.setEnabled(false);	//Distributor configuration

                        
                        dcmConfigButton.setEnabled(false); // DCM Configuration

                        jButton4.setEnabled(false); // DSP Configuration

                        jButton3.setEnabled(false);  // DSP distributors
                        
                        
                            //jPanel4.remove(distrConfigButton); //Distr. Config
                        
                            //jPanel10.remove(jPanel24); // DSP shortcuts
                            //jPanel10.remove(jPanel25); // System Panel
                        
                            //jPanel21.remove(dcmConfigButton);  // DCM Configuration



                        if (AccessLevel.MENU_ACCESS_LEVEL>1) {
                                jPanel23.setVisible(false);
                                


                                jPanel4.remove (distrConfigButton);
                                jPanel1.remove (jButton4); // DSP Config
                                jPanel22.remove (dcmConfigButton);
                                
                                retransRequestButton.setEnabled(false); 
                                dcmServicesButton.setEnabled(false);	// DCM Services

                                jPanel4.remove (retransRequestButton);

                                jPanel22.remove (dcmServicesButton); // DCM Services
                                jPanel1.remove (jButton3);           // DSP distributors
                                

                        }
                }


                if (!isApplet()) {
                        javax.swing.JButton cancelBtn = new javax.swing.JButton("Quit");
                        cancelBtn.setActionCommand("Login_Cancel");
                        cancelBtn.addActionListener (new java.awt.event.ActionListener () {
                                public void actionPerformed (java.awt.event.ActionEvent evt) {
                                        screenActionHandler (evt);
                                }
                        } );
        
                        jPanel11.add(cancelBtn);
                }
                if (logTextArea!= null)
                        logTextArea.setEditable(false);

    
                try {
                        String unm = System.getProperty("user.name");
                        userNameTF.setText(unm);
                } catch (Exception e) {}

                idsdirTF.setText(Constants.DEFAULT_IDSDIR);

                try {
      
                        props = new java.util.Properties();
                        java.io.FileInputStream in 
                                = new java.io.FileInputStream(".ids2UIProperties");
                        props.load(in);
                        in.close();
                        if (!props.isEmpty()) {
                                java.util.Enumeration enm = props.keys();
                                while (enm.hasMoreElements()) {
                                        String s = (String)enm.nextElement();
                                        if (s.startsWith("DSPLIST-"))
                                                dspHostComboBox.addItem((String)props.get(s));          
                                }
        
                                String s = (String)props.get("LASTSELECTION");
                                if (s != null) {
                                        String s1 = (String)props.get(s);
                                        if (s1!=null) dspHostComboBox.setSelectedItem(s1);
                                }
                                s = (String)props.get("IDSROOT");
                                if (s != null) {
                                        String s1 = (String)props.get(s);
                                        if (s1!=null) idsdirTF.setText(s1);
                                }
	
        
                        }
      
                } catch (Exception e) {
                }
    
    
                layoutManager = (java.awt.CardLayout) getLayout();
    
                layoutManager.show(this,"LoginPane");
    
        
   

        }



        public static MainScreenPanel getSharedInstance() {
                return instance;
        }

        public java.applet.Applet getApplet() {
                return mainApplet;
        }

        public boolean isApplet() {
                return (mainApplet != null);
        }

        public java.awt.Container getRootComponent() {
                if(isApplet())
                        return mainApplet;
                else
                        return mainFrame;
        }

        public java.awt.Component getGlassPane() {
                if(isApplet())
                        return mainApplet.getRootPane().getGlassPane();
                else
                        return mainFrame.getGlassPane();

        }

    
        public java.awt.Frame getFrame() {
                if(isApplet()) {
                        java.awt.Container parent;
                        for(parent = getApplet(); parent != null && !(parent instanceof java.awt.Frame) ; parent = parent.getParent());
                        if(parent != null)
                                return (java.awt.Frame)parent;
                        else
                                return null;
                } else
                        return mainFrame;
        }

        private void addToList(javax.swing.JComboBox combo, String item) {

                int n = combo.getItemCount();
                for (int i = 0; i < n; i++)
                        if (item.equals(combo.getItemAt(i).toString()))
                                return;

                combo.addItem(item);
        }


            /** This method is called from within the constructor to
             * initialize the form.
             * WARNING: Do NOT modify this code. The content of this method is
             * always regenerated by the FormEditor.
             */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel15 = new javax.swing.JPanel ();
          jPanel11 = new javax.swing.JPanel ();
          jButton13 = new javax.swing.JButton ();
          jPanel13 = new javax.swing.JPanel ();
          jPanel12 = new javax.swing.JPanel ();
          jLabel1 = new javax.swing.JLabel ();
          jLabel2 = new javax.swing.JLabel ();
          dspHostComboBox = new javax.swing.JComboBox ();
          userNameTF = new javax.swing.JTextField ();
          jLabel4 = new javax.swing.JLabel ();
          idsdirTF = new javax.swing.JTextField ();
          jPanel14 = new javax.swing.JPanel ();
          loginLabelPanel = new javax.swing.JPanel ();
          jPanel9 = new javax.swing.JPanel ();
          jPanel6 = new javax.swing.JPanel ();
          jPanel23 = new javax.swing.JPanel ();
          favoritesButton = new javax.swing.JButton ();
          saveStateButton = new javax.swing.JButton ();
          distrMenuButton = new javax.swing.JButton ();
          dcmMenuButton = new javax.swing.JButton ();
          dcmFormatsButton = new javax.swing.JButton ();
          jButton1 = new javax.swing.JButton ();
          jButton8 = new javax.swing.JButton ();
          jButton9 = new javax.swing.JButton ();
          jButton15 = new javax.swing.JButton ();
          jButton7 = new javax.swing.JButton ();
          premiumCodesButton = new javax.swing.JButton ();
          jLabel6 = new javax.swing.JLabel ();
          jPanel10 = new javax.swing.JPanel ();
          jPanel18 = new javax.swing.JPanel ();
          jPanel4 = new javax.swing.JPanel ();
          distrStatusButton = new javax.swing.JButton ();
          distrConfigButton = new javax.swing.JButton ();
          retransStatusButton = new javax.swing.JButton ();
          retransRequestButton = new javax.swing.JButton ();
          jPanel19 = new javax.swing.JPanel ();
          jLabel3 = new javax.swing.JLabel ();
          distrComboBox = new javax.swing.JComboBox ();
          jPanel24 = new javax.swing.JPanel ();
          jPanel1 = new javax.swing.JPanel ();
          jButton2 = new javax.swing.JButton ();
          jButton3 = new javax.swing.JButton ();
          jButton4 = new javax.swing.JButton ();
          jPanel21 = new javax.swing.JPanel ();
          jPanel3 = new javax.swing.JPanel ();
          jLabel5 = new javax.swing.JLabel ();
          dcmComboBox = new javax.swing.JComboBox ();
          jPanel22 = new javax.swing.JPanel ();
          dcmStatusButton = new javax.swing.JButton ();
          dcmServicesButton = new javax.swing.JButton ();
          dcmConfigButton = new javax.swing.JButton ();
          jPanel5 = new javax.swing.JPanel ();
          jLabel7 = new javax.swing.JLabel ();
          jButton11 = new javax.swing.JButton ();
          labelPanel1 = new javax.swing.JPanel ();
          labelPanel = new javax.swing.JPanel ();
          infoPanel = new javax.swing.JPanel ();
          jLabel8 = new javax.swing.JLabel ();
          configServerLabel = new javax.swing.JLabel ();
          jLabel10 = new javax.swing.JLabel ();
          userIDLabel = new javax.swing.JLabel ();
          djIconPanel = new javax.swing.JPanel ();
          setLayout (new java.awt.CardLayout ());
          UIManager.put("Button.defaultButtonFollowsFocus", Boolean.TRUE);
          
          jPanel15.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;

            jPanel11.setLayout (new java.awt.FlowLayout (1, 25, 5));
            jPanel11.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
  
              jButton13.setText ("Login");
              jButton13.setActionCommand ("Login_OK");
              jButton13.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  screenActionHandler (evt);
                }
              }
              );
    
              jPanel11.add (jButton13);
    
            gridBagConstraints1 = new java.awt.GridBagConstraints ();
            gridBagConstraints1.gridx = 0;
            gridBagConstraints1.gridy = 2;
            gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints1.weightx = 1.0;
            jPanel15.add (jPanel11, gridBagConstraints1);
  
            jPanel13.setLayout (new java.awt.FlowLayout (1, 25, 5));
            jPanel13.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
  
              jPanel12.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints2;
              jPanel12.setBorder (new javax.swing.border.CompoundBorder(
              new javax.swing.border.TitledBorder(
              new javax.swing.border.EtchedBorder(), "Please enter login information", 2, 2),
              new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
    
                jLabel1.setText ("User Name");
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.insets = new java.awt.Insets (10, 5, 10, 5);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                jPanel12.add (jLabel1, gridBagConstraints2);
      
                jLabel2.setText ("DSP host(s)");
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.gridx = 0;
                gridBagConstraints2.gridy = 2;
                gridBagConstraints2.insets = new java.awt.Insets (10, 5, 10, 5);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                jPanel12.add (jLabel2, gridBagConstraints2);
      
                dspHostComboBox.setToolTipText ("Enter DSP hosts (',' separated) for retrieving configuration.");
                dspHostComboBox.setEditable (true);
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.gridx = 1;
                gridBagConstraints2.gridy = 2;
                gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints2.insets = new java.awt.Insets (0, 5, 0, 15);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints2.weightx = 0.5;
                jPanel12.add (dspHostComboBox, gridBagConstraints2);
      
                userNameTF.setColumns (16);
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints2.insets = new java.awt.Insets (0, 5, 0, 15);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints2.weightx = 0.5;
                jPanel12.add (userNameTF, gridBagConstraints2);
      
                jLabel4.setText ("IDS dir.");
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.gridx = 0;
                gridBagConstraints2.gridy = 3;
                gridBagConstraints2.insets = new java.awt.Insets (10, 5, 10, 5);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                jPanel12.add (jLabel4, gridBagConstraints2);
      
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.gridx = 1;
                gridBagConstraints2.gridy = 3;
                gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints2.insets = new java.awt.Insets (0, 5, 0, 15);
                gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints2.weightx = 0.5;
                jPanel12.add (idsdirTF, gridBagConstraints2);
      
      
                gridBagConstraints2 = new java.awt.GridBagConstraints ();
                gridBagConstraints2.gridx = 0;
                gridBagConstraints2.gridy = 4;
                gridBagConstraints2.gridwidth = 2;
                gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints2.weightx = 1.0;
                gridBagConstraints2.weighty = 1.0;
                jPanel12.add (jPanel14, gridBagConstraints2);
      
              jPanel13.add (jPanel12);
    
            gridBagConstraints1 = new java.awt.GridBagConstraints ();
            gridBagConstraints1.gridx = 0;
            gridBagConstraints1.gridy = 1;
            gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints1.weightx = 1.0;
            jPanel15.add (jPanel13, gridBagConstraints1);
  
  
            gridBagConstraints1 = new java.awt.GridBagConstraints ();
            gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints1.weightx = 1.0;
            jPanel15.add (loginLabelPanel, gridBagConstraints1);
  

          add (jPanel15, "LoginPane");

          jPanel9.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints3;

            jPanel6.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints4;
  
              jPanel23.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints5;
              jPanel23.setBorder (new javax.swing.border.SoftBevelBorder(0));
    
                favoritesButton.setToolTipText ("Summary status of favorite distributors");
                favoritesButton.setPreferredSize (new java.awt.Dimension(107, 27));
                favoritesButton.setMinimumSize (new java.awt.Dimension(120, 27));
                favoritesButton.setText ("Favorites");
                favoritesButton.setActionCommand (Constants.MAIN_DISTRIBUTOR_SUMMARY_MENU);
                favoritesButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 5;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (favoritesButton, gridBagConstraints5);
      
                saveStateButton.setText ("Save State");
                saveStateButton.setActionCommand (Constants.DCM_DISTRIBUTOR_SAVE_STATE);
                saveStateButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 6;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (saveStateButton, gridBagConstraints5);
      
                distrMenuButton.setText ("Distributor Menu");
                distrMenuButton.setActionCommand (Constants.MAIN_DISTRIBUTOR_MENU);
                distrMenuButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 1;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (distrMenuButton, gridBagConstraints5);
      
                dcmMenuButton.setText ("DCM Menu");
                dcmMenuButton.setActionCommand (Constants.MAIN_DCM_MENU);
                dcmMenuButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 2;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (dcmMenuButton, gridBagConstraints5);
      
                dcmFormatsButton.setText ("Product formats");
                dcmFormatsButton.setActionCommand (Constants.MAIN_DCM_MESSAGE_FORMATS);
                dcmFormatsButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 11;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (dcmFormatsButton, gridBagConstraints5);
      
                jButton1.setToolTipText ("DSP services");
                jButton1.setPreferredSize (new java.awt.Dimension(112, 27));
                jButton1.setMaximumSize (new java.awt.Dimension(119, 27));
                jButton1.setMinimumSize (new java.awt.Dimension(120, 27));
                jButton1.setText ("DSP Menu");
                jButton1.setActionCommand (Constants.SERVICES_DSP);
                jButton1.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 3;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints5.weightx = 1.0;
                jPanel23.add (jButton1, gridBagConstraints5);
      
                jButton8.setText ("Products");
                jButton8.setActionCommand (Constants.CONFIGURATION_PRODUCTS);
                jButton8.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 10;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (jButton8, gridBagConstraints5);
      
                jButton9.setText ("Options");
                jButton9.setActionCommand (Constants.CONFIGURATION_OPTIONS);
                jButton9.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 14;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (jButton9, gridBagConstraints5);
      
                jButton15.setText ("Configuration");
                jButton15.setActionCommand (Constants.CONFIGURATION_SYSINFO);
                jButton15.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 13;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (jButton15, gridBagConstraints5);
      
                
                
                premiumCodesButton.setText ("Premium codes");
                premiumCodesButton.setActionCommand (Constants.CONFIGURATION_PREMIUMCODES);
                premiumCodesButton.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 8;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (premiumCodesButton, gridBagConstraints5);
      
                
                
                
                jButton7.setText ("Filter codes");
                jButton7.setActionCommand (Constants.CONFIGURATION_FILTERCODES);
                jButton7.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 9;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel23.add (jButton7, gridBagConstraints5);
      
                
                
                
                
                
                
                jLabel6.setText ("Menu options");
                jLabel6.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
                jLabel6.setFont (new java.awt.Font ("Dialog", 1, 12));
      
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (0, 0, 10, 0);
                gridBagConstraints5.anchor = java.awt.GridBagConstraints.NORTH;
                jPanel23.add (jLabel6, gridBagConstraints5);
      
              gridBagConstraints4 = new java.awt.GridBagConstraints ();
              gridBagConstraints4.gridx = 0;
              gridBagConstraints4.gridy = 0;
              gridBagConstraints4.gridheight = 3;
              gridBagConstraints4.fill = java.awt.GridBagConstraints.VERTICAL;
              gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints4.weighty = 1.0;
              jPanel6.add (jPanel23, gridBagConstraints4);
    
              jPanel10.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints6;
              jPanel10.setBorder (new javax.swing.border.BevelBorder(0));
    
                jPanel18.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints7;
                jPanel18.setBorder (new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder("Distributor shortcuts"),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2))));
      
                  jPanel4.setLayout (new java.awt.GridLayout (2, 2, 10, 10));
                  jPanel4.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
        
                    distrStatusButton.setToolTipText ("Distributor services");
                    distrStatusButton.setPreferredSize (new java.awt.Dimension(120, 27));
                    distrStatusButton.setMaximumSize (new java.awt.Dimension(120, 27));
                    distrStatusButton.setMinimumSize (new java.awt.Dimension(120, 27));
                    distrStatusButton.setText ("Status");
                    distrStatusButton.setActionCommand (Constants.MAIN_DISTRIBUTOR_STATUS);
                    distrStatusButton.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel4.add (distrStatusButton);
          
                    distrConfigButton.setToolTipText ("Distributor configuration ");
                    distrConfigButton.setPreferredSize (new java.awt.Dimension(120, 27));
                    distrConfigButton.setMinimumSize (new java.awt.Dimension(120, 27));
                    distrConfigButton.setText ("Configuration");
                    distrConfigButton.setActionCommand (Constants.MAIN_DISTRIBUTOR_CONFIGURATION);
                    distrConfigButton.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel4.add (distrConfigButton);
          
                    retransStatusButton.setText ("Retransmission status");
          
                    jPanel4.add (retransStatusButton);
          
                    retransRequestButton.setText ("Retransmission request");
          
                    jPanel4.add (retransRequestButton);
          
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 0;
                  gridBagConstraints7.gridy = 1;
                  gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints7.weightx = 1.0;
                  jPanel18.add (jPanel4, gridBagConstraints7);
        
        
                    jLabel3.setText ("ID");
          
                    jPanel19.add (jLabel3);
          
                    distrComboBox.setEditable (true);
          
                    jPanel19.add (distrComboBox);
          
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 0;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
                  jPanel18.add (jPanel19, gridBagConstraints7);
        
                gridBagConstraints6 = new java.awt.GridBagConstraints ();
                gridBagConstraints6.gridx = 0;
                gridBagConstraints6.gridy = 0;
                gridBagConstraints6.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints6.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints6.weightx = 1.0;
                gridBagConstraints6.weighty = 0.6;
                jPanel10.add (jPanel18, gridBagConstraints6);
      
                jPanel24.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints8;
                jPanel24.setBorder (new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder("DSP shortcuts"),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2))));
      
                  jPanel1.setLayout (new java.awt.GridLayout (1, 3, 10, 10));
        
                    jButton2.setText ("Status");
                    jButton2.setActionCommand (Constants.MAIN_DSP_STATUS);
                    jButton2.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel1.add (jButton2);
          
                    jButton3.setText ("Distributors");
                    jButton3.setActionCommand (Constants.CONFIGURATION_DSP_DISTRIBUTORS);
                    jButton3.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel1.add (jButton3);
          
                    jButton4.setToolTipText ("DSP configuration");
                    jButton4.setMinimumSize (new java.awt.Dimension(120, 27));
                    jButton4.setText ("Configuration");
                    jButton4.setActionCommand (Constants.CONFIGURATION_DSP);
                    jButton4.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel1.add (jButton4);
          
                  gridBagConstraints8 = new java.awt.GridBagConstraints ();
                  gridBagConstraints8.fill = java.awt.GridBagConstraints.BOTH;
                  gridBagConstraints8.weightx = 1.0;
                  jPanel24.add (jPanel1, gridBagConstraints8);
        
                gridBagConstraints6 = new java.awt.GridBagConstraints ();
                gridBagConstraints6.gridx = 0;
                gridBagConstraints6.gridy = 2;
                gridBagConstraints6.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints6.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints6.weightx = 1.0;
                gridBagConstraints6.weighty = 0.2;
                jPanel10.add (jPanel24, gridBagConstraints6);
      
                jPanel21.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints9;
                jPanel21.setBorder (new javax.swing.border.CompoundBorder(
                new javax.swing.border.TitledBorder("DCM shortcuts"),
                new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2))));
      
        
                    jLabel5.setText ("ID");
          
                    jPanel3.add (jLabel5);
          
                    dcmComboBox.setEditable (true);
          
                    jPanel3.add (dcmComboBox);
          
                  gridBagConstraints9 = new java.awt.GridBagConstraints ();
                  gridBagConstraints9.anchor = java.awt.GridBagConstraints.WEST;
                  jPanel21.add (jPanel3, gridBagConstraints9);
        
                  jPanel22.setLayout (new java.awt.GridLayout (1, 3, 10, 10));
                  jPanel22.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
        
                    dcmStatusButton.setText ("Status");
                    dcmStatusButton.setActionCommand (Constants.MAIN_DCM_STATUS);
                    dcmStatusButton.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel22.add (dcmStatusButton);
          
                    dcmServicesButton.setText ("Services");
                    dcmServicesButton.setActionCommand (Constants.MAIN_DCM_SERVICES_MENU);
                    dcmServicesButton.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel22.add (dcmServicesButton);
          
                    dcmConfigButton.setText ("Configuration");
                    dcmConfigButton.setActionCommand (Constants.MAIN_DCM_CONFIGURATION);
                    dcmConfigButton.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        screenActionHandler (evt);
                      }
                    }
                    );
          
                    jPanel22.add (dcmConfigButton);
          
                  gridBagConstraints9 = new java.awt.GridBagConstraints ();
                  gridBagConstraints9.gridx = 0;
                  gridBagConstraints9.gridy = 1;
                  gridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints9.weightx = 1.0;
                  jPanel21.add (jPanel22, gridBagConstraints9);
        
                gridBagConstraints6 = new java.awt.GridBagConstraints ();
                gridBagConstraints6.gridx = 0;
                gridBagConstraints6.gridy = 1;
                gridBagConstraints6.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints6.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints6.weightx = 1.0;
                gridBagConstraints6.weighty = 0.3;
                jPanel10.add (jPanel21, gridBagConstraints6);
      
              gridBagConstraints4 = new java.awt.GridBagConstraints ();
              gridBagConstraints4.gridx = 1;
              gridBagConstraints4.gridy = 1;
              gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints4.weightx = 1.0;
              gridBagConstraints4.weighty = 0.3;
              jPanel6.add (jPanel10, gridBagConstraints4);
    
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.gridx = 0;
            gridBagConstraints3.gridy = 1;
            gridBagConstraints3.gridwidth = 2;
            gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints3.weightx = 1.0;
            gridBagConstraints3.weighty = 0.6;
            jPanel9.add (jPanel6, gridBagConstraints3);
  
            jPanel5.setLayout (new java.awt.FlowLayout (1, 50, 10));
  
              jLabel7.setPreferredSize (new java.awt.Dimension(50, 0));
              jLabel7.setMaximumSize (new java.awt.Dimension(10, 0));
              jLabel7.setMinimumSize (new java.awt.Dimension(10, 0));
    
              jPanel5.add (jLabel7);
    
              jButton11.setText ("Quit");
              jButton11.setActionCommand ("Main_Close");
              jButton11.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  screenActionHandler (evt);
                }
              }
              );
    
              jPanel5.add (jButton11);
    
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.gridx = 0;
            gridBagConstraints3.gridy = 2;
            gridBagConstraints3.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints3.weightx = 1.0;
            jPanel9.add (jPanel5, gridBagConstraints3);
  
            labelPanel1.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints10;
  
              labelPanel.setBorder (new javax.swing.border.SoftBevelBorder(0));
    
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints10.weightx = 1.0;
              labelPanel1.add (labelPanel, gridBagConstraints10);
    
              infoPanel.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints11;
              infoPanel.setBorder (new javax.swing.border.TitledBorder(""));
    
                jLabel8.setText ("Configuration host(s) :");
      
                gridBagConstraints11 = new java.awt.GridBagConstraints ();
                gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
                infoPanel.add (jLabel8, gridBagConstraints11);
      
                configServerLabel.setFont (new java.awt.Font ("Dialog", 3, 11));
      
                gridBagConstraints11 = new java.awt.GridBagConstraints ();
                gridBagConstraints11.insets = new java.awt.Insets (0, 5, 0, 0);
                gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints11.weightx = 0.5;
                infoPanel.add (configServerLabel, gridBagConstraints11);
      
                jLabel10.setText ("User ID  :");
      
                gridBagConstraints11 = new java.awt.GridBagConstraints ();
                gridBagConstraints11.gridx = 2;
                gridBagConstraints11.gridy = 0;
                gridBagConstraints11.insets = new java.awt.Insets (0, 5, 0, 0);
                infoPanel.add (jLabel10, gridBagConstraints11);
      
                userIDLabel.setFont (new java.awt.Font ("Dialog", 3, 11));
      
                gridBagConstraints11 = new java.awt.GridBagConstraints ();
                gridBagConstraints11.gridx = 3;
                gridBagConstraints11.gridy = 0;
                gridBagConstraints11.insets = new java.awt.Insets (0, 5, 0, 0);
                gridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints11.weightx = 0.5;
                infoPanel.add (userIDLabel, gridBagConstraints11);
      
              gridBagConstraints10 = new java.awt.GridBagConstraints ();
              gridBagConstraints10.gridx = 0;
              gridBagConstraints10.gridy = 1;
              gridBagConstraints10.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints10.insets = new java.awt.Insets (5, 0, 2, 0);
              gridBagConstraints10.weightx = 1.0;
              labelPanel1.add (infoPanel, gridBagConstraints10);
    
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.gridwidth = 2;
            gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints3.weightx = 1.0;
            jPanel9.add (labelPanel1, gridBagConstraints3);
  
  
            gridBagConstraints3 = new java.awt.GridBagConstraints ();
            gridBagConstraints3.gridx = 1;
            gridBagConstraints3.gridy = 2;
            gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
            jPanel9.add (djIconPanel, gridBagConstraints3);
  

          add (jPanel9, "MainPane");

        }//GEN-END:initComponents

        private void showPortsDialog (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPortsDialog
                    // Add your handling code here:
                new PortsDialog(getFrame(),true).show();
  
        }//GEN-LAST:event_showPortsDialog

        private void clearLog (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearLog
                    // Add your handling code here:
                if (logTextArea!= null)
                        logTextArea.setText("");
        }//GEN-LAST:event_clearLog


        private void loginOK() {
                int err=0;
                String errstr= new String();
  
  
                
                String unm = (String)userNameTF.getText();
                if ((unm==null)||(unm.trim().length()==0)) {
                        errstr += "Please enter user name.\n";
                        err=1;
                }
    
                if (unm!=null) unm.trim();
    
                String sl = (String)dspHostComboBox.getSelectedItem();
                if ((sl==null)||(sl.length()==0)) {
                        err=1;
                        errstr+= "Please enter DSP hosts\n";
                } else {
    
                        StringBuffer unknownHosts = new StringBuffer("Hosts not in hosts database: \n");
                        boolean valid = true;
                        java.util.StringTokenizer tok = new java.util.StringTokenizer(sl,",");
                        while (tok.hasMoreTokens()) {
                                String s = tok.nextToken();
                                try {
                                        java.net.InetAddress inet = java.net.InetAddress.getByName(s);
                                } catch (Exception e) {
                                            //} catch (java.net.UnknownHostException e) {
                                        unknownHosts.append(s).append(" ");
                                        valid=false;
                                }
                        }

	
                        if (!valid) {
                                err=1;
                                errstr+= " The following hostnames are not valid:\n";
                                errstr += unknownHosts.toString();
                                errstr += "\n\n";
      
                        }
                } 
   
    
                String idir = idsdirTF.getText();
                if (idir !=null) idir.trim();
                if ((idir==null)||(idir.trim().length()==0)) {
                        errstr+="Please enter IDS directory.\n";
                        err=1;
                }
    

    
                if (err!=0) {
                        Log.getInstance().show_error(this,"Invalid login fields",
                                                     errstr,null);  		
                        return;
                }

     
                    //getFrame().setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));



                javax.swing.ProgressMonitor progressMonitor =
                        new javax.swing.ProgressMonitor(this,
                                                        "Please wait",
                                                        "Loading configuration...", 1,50);
                

                
                
                progressMonitor.setMillisToPopup(0);
                progressMonitor.setMillisToDecideToPopup(0);
                
                progressMonitor.setProgress(0);
                ConfigComm.setProgressMonitor(progressMonitor);
                        
                try {
                        ConfigComm.initLogin(unm,sl,idir);
			configServerLabel.setText(sl);
			userIDLabel.setText(unm);
                        progressMonitor.setProgress(100);
                        
                } catch (DBException dbex) {
                        
                        int errno = ((DBException)dbex).getErrorNo();
                        switch (errno) {
                            case Constants.MODE_ERR:
                                    Log.getInstance().show_error(this,
                                                                 "Mode Error", 
                                                                 "Could not retrieve startup configuration.\n"
                                                                 +"Configuration server(s) not in primary mode.",
                                                                 dbex);
                                    return ;
                            case Constants.SYNC_ERR:
                                    Log.getInstance().show_error(this,
                                                                 "Sync Error", 
                                                                 "Could not retrieve startup configuration.\n"
                                                                 +"Configuration servers are currently syncing.\n",
                                                                 dbex);
                                    return ;
                            case Constants.COMM_ERR:
                                    Log.getInstance().show_error(this,
                                                                 "Communication Error",  
                                                                 "Could not connect to configuration server.",
                                                                 dbex);
                                    return ;
                            default:
                                    Log.getInstance().show_error(this,
                                                                 "Configuration Error", 
                                                                 "Could not retrieve startup configuration.\n",
                                                                 dbex);
                                    return ;
                        }
				
                } catch (InterruptedException ie) {
                        Log.getInstance().show_error(this,"Login message",
                                                     "Login canceled", ie);
                        return ; 
                }  catch (Exception e) {
                        Log.getInstance().show_error(this,"Error",
                                                     "Could not retrieve startup configuration.\n",
                                                     e);
                        return ; 
                } finally {
                            //getFrame().setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
                        progressMonitor.setProgress(100);
                }


                if (Constants.DCM_VECTOR != null) {
                        for (int v = 0; v < Constants.DCM_VECTOR.size(); v++)
                                dcmComboBox.addItem((String)Constants.DCM_VECTOR.get(v));
                }
                    //userTextField.setText(unm);
                    //configHostsTextField.setText(sl);
                    //statusHostsTextField.setText(sl);
                layoutManager.show(this,"MainPane");
                //repaint();




                StatusRequest.init(sl);
                Constants.idsdir = new String(idir);


                try {
                        int b = 1;
                        java.io.FileOutputStream out = new java.io.FileOutputStream(".ids2UIProperties");
                        String key=null;
                        if (!props.containsValue(sl)) {
                                String last = (String)props.get("NEXTNUMBER");
                                boolean put = false;
                                if (last!=null) b = Integer.parseInt(last)+1;

                                for (int i = b; i < 10; i++) {
                                        if (!props.containsKey("DSPLIST-"+i)) {
                                                key = "DSPLIST-"+i;
                                                props.put(key,sl);
                                                props.put("NEXTNUMBER",Integer.toString(i));
                                                b=i;
                                                put=true;
                                                break;
                                        }
                                }

                                if (!put) {
                                        if (b>10) b=1;
                                        key = "DSPLIST-"+b;
                                        props.put(key,sl);
                                        props.put("NEXTNUMBER",Integer.toString(b));
                                }
                        } else {
                                java.util.Enumeration enm = props.keys();
                                while (enm.hasMoreElements()) {
                                        String s = (String)enm.nextElement();
                                        String v = (String)props.get(s);
                                        if (v.equals(sl)) {
                                                key=s;
                                                break;
                                        }
                                }
                        }

                        props.put("LASTSELECTION",key);
                        props.put("IDSROOT",idsdirTF.getText().trim());
                        props.store(out,"UI Properties");
                        out.close();

                } catch (Exception e){
                        Log.getInstance().log_error("Error in saving preferences",e);
                }
                return;
  
  


        }



        private void loginCancel() {
                if (isApplet()) {
                        setVisible(false);
                        mainApplet.stop();
                } else
                        System.exit(0);    
                return;
        }


        private void _screenActionHandler(String command) {

                if (command.equals("Login_OK")) {
                        loginOK();
                        return;
                }
	
                if (command.equals("Login_Cancel")) {   
                        loginCancel();   
                        return;
                }
  
                if (command.equals("Main_Close")) {
                        int resp = javax.swing.JOptionPane.showConfirmDialog(this,"Are you sure you want to quit ?");
			
                        if (resp==javax.swing.JOptionPane.YES_OPTION) {  
                                WindowEventAdapter.getInstance().closeAll();
                                layoutManager.show(this,"LoginPane");
                                ConfigComm.resetLogin();
                                StatusRequest.resetLogin();
                                distrComboBox.removeAllItems();
                                dcmComboBox.removeAllItems();
                                clearLog(null);
				loginCancel();
                        }
                        return;
                }
  

                if (command.equals(Constants.MAIN_DISTRIBUTOR_CONFIGURATION)) {
                        String item = (String)distrComboBox.getSelectedItem();
                        if ((item==null) || (item.trim().length()==0) ) {
                                Utils.showDialog(this,"Please enter a distributor ID.");
                                return;
                        }
                        String distr = item.trim().toUpperCase();
                        addToList(distrComboBox, distr);
                        javax.swing.JFrame f = null;
                        f =(javax.swing.JFrame)WindowEventAdapter.getInstance()
                                .findWindow(Constants.CONFIGURATION_DISTRIBUTOR_PREFIX+distr);
                        if (f==null) {
                                try {
                                        f = new DistributorConfigurationForm(distr,null,false);
                                } catch (Exception e) {
                                }
                        }
                        if (f != null) f.show();
                        return;
                }

                if (command.equals(Constants.MAIN_DISTRIBUTOR_STATUS)) {
                        String item = (String)distrComboBox.getSelectedItem();
                        if ((item==null) || (item.trim().length()==0) ) {
                                Utils.showDialog(this,"Please enter a distributor ID.");
                                return;
                        }
                        String distr = item.trim().toUpperCase();
                        addToList(distrComboBox, distr);

                        try { 
                                StatusHandler statusHandler = StatusHandler.getInstance();

                                Object[] possibleValues = { "Home ", 
                                                            "Away ",
                                                            "Both"
                                };
                                Object selectedValue = RadioOptionsDialog.showRadioOptionsDialog(mainFrame, true,
                                                                                                 "Please choose a location to view status",
                                                                                                 "Distributor status options",
                                                                                                 possibleValues, possibleValues[2]);
                                int home_index = 1;
                                int away_index = 2;
                                try {
                                        java.util.HashMap
                                                m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+distr);
                                
                                        String pl = (String)m.get("HOME_LOCATION");
                                        if (pl!=null && !pl.equals("1")) {
                                                home_index = 2;
                                                away_index = 1;
                                        }
                                }
                                catch (Exception ex){
                                }

                                boolean config_err = false;
                                
                                if ((selectedValue==possibleValues[2])
                                    || (selectedValue==possibleValues[0])) {
                                        try {
                                                statusHandler.displayStatus(getRootComponent(),
                                                                            Constants.DCM_LINEHANDLER,
                                                                            home_index,null,null,distr);
                                        }
                                        catch (Exception e) {
                                                Log.getInstance().show_error(getRootComponent(),"Error",
                                                                             e.getMessage(),e);

                                                if (e instanceof DBException){
                                                        DBException dbe = (DBException)e;
                                                        if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND)
                                                                config_err = true;
                                                }
                                        }
                                }
                                
                                        
                                if (!config_err && ((selectedValue==possibleValues[2])
                                                    ||(selectedValue==possibleValues[1]) ) ) {
                                        try {
                                                statusHandler.displayStatus(getRootComponent(),
                                                                            Constants.DCM_LINEHANDLER,
                                                                            away_index,null,null,distr);
                
                                        }
                                        catch (Exception e) {
                                                Log.getInstance().show_error(getRootComponent(),"Error",
                                                                             e.getMessage(),e);
                                                
                                                if (e instanceof DBException){
                                                        DBException dbe = (DBException)e;
                                                        if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND)
                                                                config_err = true;
                                                }
                                        }
                                }
                        } catch (Exception e) {
                        }
                        
                        return;
                }

                if (command.equals(Constants.MAIN_DCM_SERVICES_MENU)) {
                        String item = (String)dcmComboBox.getSelectedItem();
                        if ((item==null) 
                            || (item.trim().length()==0) 
                            || item.trim().startsWith("ENTER-DCM") ) {
                                Utils.showDialog(this,"Please enter a DCM ID.");
                                return;
                        }
                        String dcm = item.trim().toUpperCase();
                        addToList(dcmComboBox, dcm);

                        try { 
                                javax.swing.JFrame f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.SERVICES_DCM_PREFIX+dcm);
                                if (f == null)
                                        f = new DCMServicesForm(dcm);
                                if (f!=null) f.show();
                        } catch (Exception e) {
                        }
                        return;
                }
	




                if (command.equals(Constants.MAIN_DCM_CONFIGURATION)) {
                        String item = (String)dcmComboBox.getSelectedItem();
                        if ((item==null) 
                            || (item.trim().length()==0) 
                            || item.trim().startsWith("ENTER-DCM") ) {
                                Utils.showDialog(this,"Please enter a DCM ID.");
                                return;
                        }
                        String dcm = item.trim().toUpperCase();
                        addToList(dcmComboBox, dcm);

                        try { 
                                javax.swing.JFrame f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.CONFIGURATION_DCM_PREFIX+dcm);
                                if (f == null) {
                                        f = new DCMConfigForm(dcm);
                                }
                                if (f!=null) f.show();
                        } catch (Exception e) {
                        }

                        return;
                }
	

                if (command.equals(Constants.MAIN_DCM_STATUS)) {
                        String item = (String)dcmComboBox.getSelectedItem();
                        if ((item==null) 
                            || (item.trim().length()==0) 
                            || item.trim().startsWith("ENTER-DCM") ) {
                                Utils.showDialog(this,"Please enter a DCM ID.");
                                return;
                        }
                        String dcm = item.trim().toUpperCase();
                        addToList(dcmComboBox, dcm);

                        try {

                                Object[] possibleValues = new Object[3];
                                possibleValues[2] = "Both";
                                possibleValues[0] = "Status from data center -I";
                                possibleValues[1] = "Status from data center -II";
                    
                                try {
                                        java.util.HashMap
                                                m = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                                
                                        String l1 = (String)m.get("LOCATION1");
                                        String h1 = (String)m.get("PHOST1");
                                        String l2 = (String)m.get("LOCATION2");
                                        String h2 = (String)m.get("PHOST2");
                                        StringBuffer sb = new StringBuffer("Status from ");
                                        sb.append(h1);
                                        if (l1!=null)
                                                sb.append(" [").append(l1)
                                                        .append("]");
                                        possibleValues[0] = sb.toString();
                            
                                        sb = new StringBuffer("Status from ");
                                        sb.append(h2);
                                        if (l2!=null)
                                                sb.append(" [").append(l2)
                                                        .append("]");
                                        possibleValues[1] = sb.toString();
                                }
                                catch (Exception ex){
                                }
                
                                StatusHandler statusHandler = StatusHandler.getInstance();
		

                
                                Object selectedValue = RadioOptionsDialog.showRadioOptionsDialog(mainFrame,true, 
                                                                                                 "Please pick a host/location to view status.",
                                                                                                 "DCM status option",
                                                                                                 possibleValues, possibleValues[2]);


                                boolean config_err = false;
                                if ((selectedValue==possibleValues[2])
                                    || (selectedValue==possibleValues[0])) {
                                        try {     
                                                statusHandler.displayStatus(getRootComponent(),
                                                                    Constants.DCM_READER,
                                                                    1,null,dcm,null);
                                        }
                                        catch (Exception e) {
                                                Log.getInstance().show_error(getRootComponent(),"Error",
                                                                             e.getMessage(),e);

                                                
                                                if (e instanceof DBException){
                                                        DBException dbe = (DBException)e;
                                                        if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND)
                                                                config_err = true;
                                                }
                                        }
                                }
                                
                                if (!config_err && ((selectedValue==possibleValues[2])
                                                    ||selectedValue==possibleValues[1]) ) {
                                        try {
                                        
                                                statusHandler.displayStatus(getRootComponent(),
                                                                    Constants.DCM_READER,
                                                                    2,null,dcm,null);

                                        }
                                        catch (Exception e) {
                                                Log.getInstance().show_error(getRootComponent(),"Error",
                                                                             e.getMessage(),e);
                                                
                                                if (e instanceof DBException){
                                                        DBException dbe = (DBException)e;
                                                        if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND)
                                                                config_err = true;
                                                }
                                        }
                                }       
                        } catch (Exception e) {
                        }
			
                        return;
                }




                if (command.equals(Constants.MAIN_DSP_STATUS)) {
	    

                        try {

                                Object[] possibleValues = new Object[3];
                                possibleValues[2] = "Both";
                                possibleValues[0] = "Status from data center -I";
                                possibleValues[1] = "Status from data center -II";
                    
                                try {
                                        java.util.HashMap
                                                m = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);
                                
                                        String l1 = (String)m.get("LOCATION1");
                                        String h1 = (String)m.get("PHOST1");
                                        String l2 = (String)m.get("LOCATION2");
                                        String h2 = (String)m.get("PHOST2");
                                        StringBuffer sb = new StringBuffer("Status from ");
                                        sb.append(h1);
                                        if (l1!=null)
                                                sb.append(" [").append(l1)
                                                        .append("]");
                                        possibleValues[0] = sb.toString();
                            
                                        sb = new StringBuffer("Status from ");
                                        sb.append(h2);
                                        if (l2!=null)
                                                sb.append(" [").append(l2)
                                                        .append("]");
                                        possibleValues[1] = sb.toString();
                                }
                                catch (Exception ex){
                                }
                
                                StatusHandler statusHandler = StatusHandler.getInstance();
		

                
                                Object selectedValue = RadioOptionsDialog.showRadioOptionsDialog(mainFrame,true, 
                                                                                                 "Please pick a host/location to view status.",
                                                                                                 "DSP status option",
                                                                                                 possibleValues, possibleValues[2]);


                                if ((selectedValue==possibleValues[2])
                                    || (selectedValue==possibleValues[0]))      
                                        statusHandler.displayStatus(getRootComponent(),
                                                                    Constants.DSP_READER,
                                                                    1,null,Constants.GLB_TAG_DSP,
                                                                    null);
                                if ((selectedValue==possibleValues[2])
                                    ||selectedValue==possibleValues[1])
                                        statusHandler.displayStatus(getRootComponent(),
                                                                    Constants.DSP_READER,
                                                                    2,null,Constants.GLB_TAG_DSP,
                                                                    null);
                        } catch (Exception e) {
                        }
			
                        return;
                }










        
	
                if (command.equals(Constants.MAIN_DCM_MESSAGE_FORMATS)) {
                        javax.swing.JDialog f = (javax.swing.JDialog)WindowEventAdapter.getInstance()
                                .findWindow(command);
                        if (f == null)
                                f = new CSCSparseMatrixDialog(null,false);          
                        if (f!=null) f.show();
                        return;
                }
	
        
                if (command.equals(Constants.CONFIGURATION_PRODUCTS)) {
                        javax.swing.JDialog f = (javax.swing.JDialog)WindowEventAdapter.getInstance()
                                .findWindow(command);
                        if (f == null) {
                                try {
                                        f = new ProductConfigurationDialog(null,false);          
                                } catch (Exception e){}
                        }
                        if (f!=null) f.show();
                        return;
                }
        
                    /*
*************************************************
if (command.equals(Constants.MAIN_ALL_DCM_STATUS)) {
try { 
javax.swing.JFrame f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
.findWindow(command);
if (f == null)
f = new DCMInputStatusForm();
if (f!=null) f.show();
} catch (Exception e) {
}
return;
}
*************************************************
*/
	
                javax.swing.JFrame f = 
                        (javax.swing.JFrame)WindowEventAdapter.getInstance().findWindow(command);
  
                if (Constants.DEBUG && Constants.Verbose>2)
                        System.out.println("Action "+command);
  
                if (f == null) {    
                        try {
                                Class c = Constants.getActionClass(command);
                                if (c != null) 
                                        f = (javax.swing.JFrame) c.newInstance();
                        } catch (Exception e) {
                                e.printStackTrace();
                        }
                }
  
                if (f != null) {
                        f.show();
                }
    

        }



            private void screenActionHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_screenActionHandler
                    // Add your handling code here:
                final java.awt.event.ActionEvent actionEvent = evt;

                SwingWorker worker = new SwingWorker() {
                        java.awt.Component button;
                        public Object construct() {
	 			
                                button = (java.awt.Component)actionEvent.getSource();
                                    //button.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
                                button.setEnabled(false);
                                _screenActionHandler(actionEvent.getActionCommand());
                                return new Integer(0);
                        }

                            //Runs on the event-dispatching thread.
                        public void finished() {
                                button.setEnabled(true);
                                    //button.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
                        }

                };  

                worker.start();

    
  
        }//GEN-LAST:event_screenActionHandler


        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JPanel jPanel15;
        private javax.swing.JPanel jPanel11;
        private javax.swing.JButton jButton13;
        private javax.swing.JPanel jPanel13;
        private javax.swing.JPanel jPanel12;
        private javax.swing.JLabel jLabel1;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JComboBox dspHostComboBox;
        private javax.swing.JTextField userNameTF;
        private javax.swing.JLabel jLabel4;
        private javax.swing.JTextField idsdirTF;
        private javax.swing.JPanel jPanel14;
        private javax.swing.JPanel loginLabelPanel;
        private javax.swing.JPanel jPanel9;
        private javax.swing.JPanel jPanel6;
        private javax.swing.JPanel jPanel23;
        private javax.swing.JButton favoritesButton;
        private javax.swing.JButton saveStateButton;
        private javax.swing.JButton distrMenuButton;
        private javax.swing.JButton dcmMenuButton;
        private javax.swing.JButton dcmFormatsButton;
        private javax.swing.JButton jButton1;
        private javax.swing.JButton jButton8;
        private javax.swing.JButton jButton9;
        private javax.swing.JButton jButton15;
        private javax.swing.JButton jButton7;
        private javax.swing.JButton premiumCodesButton;
        private javax.swing.JLabel jLabel6;
        private javax.swing.JPanel jPanel10;
        private javax.swing.JPanel jPanel18;
        private javax.swing.JPanel jPanel4;
        private javax.swing.JButton distrStatusButton;
        private javax.swing.JButton distrConfigButton;
        private javax.swing.JButton retransStatusButton;
        private javax.swing.JButton retransRequestButton;
        private javax.swing.JPanel jPanel19;
        private javax.swing.JLabel jLabel3;
        private javax.swing.JComboBox distrComboBox;
        private javax.swing.JPanel jPanel24;
        private javax.swing.JPanel jPanel1;
        private javax.swing.JButton jButton2;
        private javax.swing.JButton jButton3;
        private javax.swing.JButton jButton4;
        private javax.swing.JPanel jPanel21;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JLabel jLabel5;
        private javax.swing.JComboBox dcmComboBox;
        private javax.swing.JPanel jPanel22;
        private javax.swing.JButton dcmStatusButton;
        private javax.swing.JButton dcmServicesButton;
        private javax.swing.JButton dcmConfigButton;
        private javax.swing.JPanel jPanel5;
        private javax.swing.JLabel jLabel7;
        private javax.swing.JButton jButton11;
        private javax.swing.JPanel labelPanel1;
        private javax.swing.JPanel labelPanel;
        private javax.swing.JPanel infoPanel;
        private javax.swing.JLabel jLabel8;
        private javax.swing.JLabel configServerLabel;
        private javax.swing.JLabel jLabel10;
        private javax.swing.JLabel userIDLabel;
        private javax.swing.JPanel djIconPanel;
        // End of variables declaration//GEN-END:variables



}

/*
**  SCCS Info :  "@(#)ProductConfigurationDialog.java	1.5    05/10/13"
*/
/*
 * ProductConfigurationDialog.java
 *
 * Created on April 24, 2002, 4:14 PM
 */
 
package ids2ui;


import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;


/** 
 *
 * @author  srz
 * @version 
 */
public class ProductConfigurationDialog 
    extends javax.swing.JDialog  
    implements javax.swing.event.ListSelectionListener
{

    private ProductConfigurationDialog myDialog = null;

    private JTreeTable productTable;
    private CSCProductsModel productModel;
    
    private boolean productsAdded = false;
    private boolean productsDeleted = false;
    
   
    /** Row the is being reloaded. */
    protected int                reloadRow;
    /** TreePath being reloaded. */
    protected TreePath           reloadPath;
    /** A counter increment as the Timer fies and the same path is
     * being reloaded. */
    protected int                reloadCounter;
    /** Timer used to update reload state. */
    protected Timer              timer;
   
   

    private MutexLock   mLock = new MutexLock();

    volatile private boolean isExiting = false;

    private java.util.HashSet old_product_set = new java.util.HashSet();



  /** Creates new form ProductConfigurationDialog */
    public ProductConfigurationDialog(java.awt.Frame parent,boolean modal) 
	throws Exception 
    {
	
	super (parent, modal);
	
	initComponents ();

        
        
	setTitle("Product Configuration");
	myDialog = this;

	WindowEventAdapter.getInstance()
	    .registerWindow(Constants.CONFIGURATION_PRODUCTS,this);


	/* Create Model to represent products */
	try {
	    productModel = new CSCProductsModel(ConfigComm.getCSCProductsModel());
	} catch (Exception e) {
	    Log.getInstance().show_error(null,"Error",
					 "Error in retrieving "
					 +"product configuration",e);

	    exitForm(null);
	    throw new Exception();
	}
	

	old_product_set.addAll(productModel.getProductSet());

	/* Create the tree table and add to a scroll pane*/
	productTable = createTreeTable();
	
	productTable.setSelectionMode(javax.swing
				      .ListSelectionModel.SINGLE_SELECTION);
	

	IDS_SwingUtils.IntegerCellEditor integerEditor = 
	    new IDS_SwingUtils.IntegerCellEditor(8);
	
	
	productTable.setDefaultEditor(Integer.class,integerEditor);

	TableColumnModel tcModel = productTable.getColumnModel();

	int lcnCol = tcModel.getColumnIndex(CSCProductsModel.cNames[1]);
	int typeCol = tcModel.getColumnIndex(CSCProductsModel.cNames[2]);
	int rtpSrcCol = tcModel.getColumnIndex(CSCProductsModel.cNames[4]);

	tcModel.getColumn(lcnCol).setCellEditor(integerEditor);

	tcModel.getColumn(typeCol).setCellEditor(new javax.swing
	    .DefaultCellEditor(
	    new JComboBox(ConfigComm.getProductTypes())));

	tcModel.getColumn(rtpSrcCol)
	    .setCellEditor(new javax.swing
			   .DefaultCellEditor(
			   new JComboBox(ConfigComm.getRTPHostKeys())));
	

       

	for (int i = 0; i < CSCProductsModel.cNames.length; i++) {

	    TableCellRenderer tch = tcModel.getColumn(i).getHeaderRenderer();
	    
	    if (tch instanceof DefaultTableCellRenderer)
		((DefaultTableCellRenderer)tch).setToolTipText(CSCProductsModel.cNamesTips[i]);

	    /*
	    tcModel.getColumn(i)
	    .setHeaderRenderer(new IDS_SwingUtils.MultilineHeaderRenderer(CSCProductsModel.cNames[i]));
	    **
	    */
	}


	javax.swing.JScrollPane treeScrollPane 
	    = new javax.swing.JScrollPane(productTable);

	//treeScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	jPanel3.add(treeScrollPane);
	
	reloadRow = -1;


	
	SwingUtilities.invokeLater(new Runnable() {
	    public void run() {
		reload(productModel.getRoot());
	    }
	});

	idTextField.setDocument(new UCDocument(Constants.PRODUCT_ID_SIZE));

	idTextField.getDocument().addDocumentListener( docListener );   

	productTable.getSelectionModel().addListSelectionListener(this);

	jButton3.setEnabled(false);
	jButton2.setEnabled(false);



	FontMetrics metrics = null;

	Graphics g = getGraphics();

	if ((g==null) && (parent!=null) )
	    g = parent.getGraphics();

	if (g == null) {
	    MainScreenPanel p = MainScreenPanel.getSharedInstance();
	    if (p != null)
		g = p.getRootComponent().getGraphics();
	}

	if (g!=null)
	    metrics = g.getFontMetrics();

 	int w = 0;
	
	//productTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        productTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
	if (metrics != null) {
	    
	    
	    for (int i = 0; i < productTable.getColumnCount(); i++) {
		String txt = productTable.getColumnName(i);
		
		w = metrics.stringWidth(txt) +
		    (2*productTable.getColumnModel().getColumnMargin());


              
                 productTable.getColumnModel().getColumn(i).setMinWidth(w); 

		if (i==0) w*=4;
                if (i==4) w*=2;
		
		productTable.getColumnModel().getColumn(i).setPreferredWidth(w);
		
	    }
	}
	else {
	    w = 100+(2*productTable.getColumnModel().getColumnMargin());
	    productTable.getColumnModel().getColumn(0).setWidth(w);
 	}


	

	//productTable.getTableHeader().resizeAndRepaint();


	setSize(600,600);

	//productTable.getTableHeader().invalidate();
	//productTable.invalidate();
	//invalidate();

	//productTable.validate();
        
        
	//validate();
        pack();

	//productTable.getTableHeader().invalidate();
	//invalidate();
	//validate();

	setSize(600,600);
	//productTable.getTableHeader().resizeAndRepaint();
	repaint();
    }



    
    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;
	int srows[] = productTable.getSelectedRows();
	
	idTextField.getDocument().removeDocumentListener( docListener);
	

	boolean modify_state = false;
	boolean delete_state = false;
	// Ignore first row (Root node) and multi selections
	if ( (srows.length!=1) 
	     || ((srows.length>0) && (srows[0]==0)) ) {
	    idTextField.setText("");
	} else {
	    modify_state = true;
	    String id = (String)productTable.getValueAt(srows[0],0);
	    idTextField.setText(id);
	    String[] subprods = productModel.getSubProducts(id);
	    if (  (subprods==null)
	       || ( (subprods.length==1) && id.equals(subprods[0])) ) 
		delete_state = true;
	    else
		delete_state = false;
	}
       
	jButton2.setEnabled(modify_state);
	jButton3.setEnabled(delete_state);
	idTextField.getDocument().addDocumentListener( docListener);
	
	
    }
    
    javax.swing.event.DocumentListener docListener = 
	new javax.swing.event.DocumentListener() {
	
	public void changedUpdate(javax.swing.event.DocumentEvent evt) {
	    processEvent();
	}
	public void insertUpdate(javax.swing.event.DocumentEvent evt) {
	    processEvent();
	}
	public void removeUpdate(javax.swing.event.DocumentEvent evt) {
	    processEvent();
	}
	
	private  void processEvent(){        
	    String id1 = idTextField.getText();
	    int l1 = id1.length();
	    
	    productTable.getSelectionModel()
		.removeListSelectionListener(myDialog);
	    
	    for (int i = 0; i < productTable.getRowCount(); i++) {
		String id2
		    = (String)productTable.getValueAt(i,0);
		int l2 = id2.length();	  
		if (l1<=l2 && l1>0  && (id2.substring(0,l1).equals(id1))){
		    productTable.addRowSelectionInterval(i,i);
		    break;
		    
		} else
		    productTable.removeRowSelectionInterval(i,i);
	    }



	    if (!productTable.getSelectionModel().isSelectionEmpty()) {
		int row = productTable.getSelectionModel()
		    .getMinSelectionIndex();

		java.awt.Rectangle rowRect = productTable.getCellRect(row, 
								      0, true);

		if (rowRect!=null) {
		    rowRect.setSize( Integer.MAX_VALUE,
				     (int)rowRect.getHeight());

		    productTable.scrollRectToVisible(rowRect);
		}

	    }
	    
	    productTable.getSelectionModel()
		.addListSelectionListener(myDialog);
	    
	} // processEvent()
	
    }; // new docListener  


    /**
     * Invoked to reload the children of a particular node. This will
     * also restart the timer.
     */
    protected void reload(Object node) {
	productModel.reloadChildren(node);
	if (!timer.isRunning()) {
	    timer.start();
	}
    }

    /**
     * Updates the status label based on reloadRow.
     */
    protected void updateStatusLabel() {
	if (reloadPath != null) {
	    statusLabel.setText("Reloading: " + productModel.getPath
				(reloadPath.getLastPathComponent()));
	    if ((reloadCounter % 4) < 2) {
		statusLabel.setForeground(Color.red);
	    }
	    else {
		statusLabel.setForeground(Color.blue);
	    }
	}
	else if (!productModel.isReloading()) {
	    statusLabel.setText("Total Products: " + NumberFormat.getInstance().
				format(productModel.getTotalSize(productModel.getRoot())));
	    statusLabel.setForeground(Color.black);
	}
    }



    JTreeTable createTreeTable() {
	JTreeTable       treeTable = new JTreeTable(productModel);
	
	treeTable.getColumnModel().getColumn(1).setCellRenderer
	    (new IndicatorRenderer());

	Reloader rl = new Reloader();

	timer = new Timer(700, rl);
	timer.setRepeats(true);
	treeTable.getTree().addTreeExpansionListener(rl);
	return treeTable;
	
    }



  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
    private void initComponents () {//GEN-BEGIN:initComponents
      jPanel3 = new javax.swing.JPanel ();
      jPanel1 = new javax.swing.JPanel ();
      jPanel4 = new javax.swing.JPanel ();
      jPanel6 = new javax.swing.JPanel ();
      jLabel1 = new javax.swing.JLabel ();
      idTextField = new javax.swing.JTextField ();
      jPanel7 = new javax.swing.JPanel ();
      statusLabel = new javax.swing.JLabel ();
      jPanel5 = new javax.swing.JPanel ();
      jButton1 = new javax.swing.JButton ();
      jButton2 = new javax.swing.JButton ();
      jButton3 = new javax.swing.JButton ();
      statusPanel = new ids2ui.StatusPanel ();
      jPanel2 = new javax.swing.JPanel ();
      jButton4 = new javax.swing.JButton ();
      jButton5 = new javax.swing.JButton ();
      getContentPane ().setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;
      addWindowListener (new java.awt.event.WindowAdapter () {
        public void windowClosing (java.awt.event.WindowEvent evt) {
          closeDialog (evt);
        }
      }
      );

      jPanel3.setLayout (new java.awt.BorderLayout ());
      jPanel3.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("")));

        jPanel1.setLayout (new javax.swing.BoxLayout (jPanel1, 1));
  
          jPanel4.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
    
      
              jLabel1.setText ("ID");
        
              jPanel6.add (jLabel1);
        
              idTextField.setColumns (5);
        
              jPanel6.add (idTextField);
        
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
            jPanel4.add (jPanel6, gridBagConstraints2);
      
            jPanel7.setLayout (new java.awt.FlowLayout (2, 5, 5));
      
        
              jPanel7.add (statusLabel);
        
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.weightx = 1.0;
            jPanel4.add (jPanel7, gridBagConstraints2);
      
            jPanel5.setLayout (new java.awt.FlowLayout (1, 15, 5));
      
              jButton1.setText ("Add");
              jButton1.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  addProduct (evt);
                }
              }
              );
        
              jPanel5.add (jButton1);
        
              jButton2.setText ("Modify");
              jButton2.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  modifyProduct (evt);
                }
              }
              );
        
              jPanel5.add (jButton2);
        
              jButton3.setText ("Delete");
              jButton3.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  deleteProduct (evt);
                }
              }
              );
        
              jPanel5.add (jButton3);
        
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 1;
            gridBagConstraints2.gridwidth = 2;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.weightx = 1.0;
            jPanel4.add (jPanel5, gridBagConstraints2);
      
          jPanel1.add (jPanel4);
    
        jPanel3.add (jPanel1, java.awt.BorderLayout.SOUTH);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints1.weightx = 1.0;
      gridBagConstraints1.weighty = 1.0;
      getContentPane ().add (jPanel3, gridBagConstraints1);

      statusPanel.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("")));


      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 2;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (statusPanel, gridBagConstraints1);

      jPanel2.setLayout (new java.awt.FlowLayout (1, 20, 5));
      jPanel2.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("")));

        jButton4.setText ("Save");
        jButton4.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            saveProducts (evt);
          }
        }
        );
  
        jPanel2.add (jButton4);
  
        jButton5.setText ("Close");
        jButton5.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            exitForm (evt);
          }
        }
        );
  
        jPanel2.add (jButton5);
  

      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 1;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints1.weightx = 1.0;
      getContentPane ().add (jPanel2, gridBagConstraints1);

    }//GEN-END:initComponents

private void saveProducts (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveProducts
// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;



	if (javax.swing.JOptionPane.YES_OPTION
	    != Log.getInstance().show_confirm(this, "Please confirm",
					      "Data services have to be "
					      +"restarted to use new "
					      +"configuration."
					      +"\nAre you sure you want"
					      +" to save?.")) {
	    return;
	}


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, 
							     command) {
	    public Object construct() {
		_saveProducts(cmdButton, action);
		return null;
	    }
	};

	sw.start();

  }//GEN-LAST:event_saveProducts



    private void _saveProducts(javax.swing.JButton cmdButton, 
				    String command)
    {
	
	int nrows = productTable.getRowCount();
	int ncols = productTable.getColumnCount();

	boolean exit_form = true;

	try {
	    mLock.acquire();
	} catch (InterruptedException ie) {
	    Log.getInstance().log_error("Service handler interrupted",ie);
	    if (cmdButton != null ) 
		cmdButton.setEnabled(true);
	    return;
	}
	statusPanel.start("Saving products. Please wait ...");
	
	StringBuffer outb = new StringBuffer();

  
	java.util.HashSet new_product_set = new java.util.HashSet();
	new_product_set.addAll(productModel.getProductSet());

	

	outb.append(productModel.toString());
	
	StringBuffer reqbuf = new StringBuffer();

	if ( productsAdded || productsDeleted ) {
	    ConfigComm.saveProducts(reqbuf,Constants.GLB_PRODUCT_LIST,
				    outb.toString());
	} else  {
	    ConfigComm.saveKeyValue(reqbuf,Constants.GLB_PRODUCT_LIST,
				    outb.toString());
	}

	try {

	    /* Send request to save products*/
	    byte[] b = ConfigComm.configRequest(reqbuf);
	    

	    ConfigComm.setCSCProductsModel(productModel);
	    ConfigComm.getCSCSparseMatrixModel().setProductModel(productModel);
	    


	    if ( productsAdded || productsDeleted ) {

	    	javax.swing.JDialog f =
		    (javax.swing.JDialog)WindowEventAdapter.getInstance()
			.findWindow(Constants.MAIN_DCM_MESSAGE_FORMATS);

		
    		if (f!=null)
		    ((CSCSparseMatrixDialog)f).exitForm(null);
		

		

		CSCSparseMatrixModel convModel =
		    ConfigComm.getCSCSparseMatrixModel();

		
		
		


		java.util.HashSet added_set = new java.util.HashSet(new_product_set);
		java.util.HashSet deleted_set = new java.util.HashSet(old_product_set);
		
		java.util.HashSet common_set = new java.util.HashSet(new_product_set);
		common_set.retainAll(old_product_set);
		
		added_set.removeAll(common_set);
		deleted_set.removeAll(common_set);
		
		
		
		if (!added_set.isEmpty()) {
		    java.util.Iterator iter = added_set.iterator();
		    while (iter.hasNext()) {
			String p = (String)iter.next();
			//ConfigComm.addProduct(p);
			
			convModel.addProduct(p);
		    }
		}
		
		if (!deleted_set.isEmpty()) {
		    java.util.Iterator iter = deleted_set.iterator();
		    while (iter.hasNext()) {
			String p = (String)iter.next();
			//ConfigComm.deleteProduct(p);
			
			convModel.deleteProduct(p);
		    }
		}
		
		
		String str = convModel.toString();
		

		reqbuf.setLength(0);
		
		//Update DCM product conversion table 
		ConfigComm.saveKeyValue(reqbuf,
					Constants.GLB_DCM_PRODUCT_CONVERSION_TABLE,
					str);
		
		b = ConfigComm.configRequest(reqbuf);
		 
	    } // if (productsAdded || productsDeleted)
 
	    
	    
	} catch (DBException dbex) {
	    int errno = dbex.getErrorNo();
	    switch (errno) {
	    case Constants.MODE_ERR:
		Log.getInstance().show_error(this,
					     "Mode Error", 
					     "Could not save products configuration.\n"
					     +"Configuration server(s) not in primary mode.",
					     dbex);
		break ;
	    case Constants.SYNC_ERR:
		Log.getInstance().show_error(this,
					     "Sync Error", 
					     "Could not save products configuration.\n"
					     +"Configuration servers are currently syncing.\n",
					     dbex);
		break ;
	    case Constants.COMM_ERR:
		Log.getInstance().show_error(this,
					     "Communication Error",  
					     "Could not connect to configuration server.",
					     dbex);
		break ;
	    case Constants.PROD_CACHE_ERR:
		Log.getInstance().show_error(this,
					     "Error",  
					     "Can't add more products. Out of product cache space.",
					     dbex);
		break ;
	    default:
		Log.getInstance().show_error(this,
					     "Configuration Error", 
					     "Could not save configuration.\n",
					     dbex);
		break ;
	    }
	    
	    exit_form = false;
	} catch (Exception e) {
	    
	    Log.getInstance().show_error(this,"Error",
					 "Error in saving products."
					 +"\nPlease check log.",
					 e);
	    
	    exit_form = false;
	}
	
	mLock.release();
	statusPanel.stop();
	statusPanel.clear();
	
	if (cmdButton != null ) 
	    cmdButton.setEnabled(true);
	
	
	if (exit_form) {
	    if (productsAdded) {
		if (javax.swing.JOptionPane.YES_NO_OPTION 
		    == Utils.showConfirmDialog(this, 
				"Would you like to define "
				+"DCM conversion formats for the new/modified "
				+"product(s).") ) {
		    javax.swing.JDialog f = new CSCSparseMatrixDialog(null,false);
		    if (f!=null)
			f.show();
	    	}
	    }
	    exitForm(null);
	}
	
    }







private void deleteProduct (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteProduct
// Add your handling code here:
	int srows[] = productTable.getSelectedRows();

    
	if (srows.length == 0){
	    javax.swing.JOptionPane.showMessageDialog(this,
						      "Please select product"
						      +"to be deleted.",
						      "Error",
				    javax.swing.JOptionPane.ERROR_MESSAGE);
	    return;
      
	} 

	int row = srows[0];
	String product =  (String)productTable.getValueAt(row,0);
	
	if (javax.swing.JOptionPane.YES_OPTION !=
	    Log.getInstance().show_confirm(this,"Confirm delete",
					   "Are you sure you want to delete "
					   +"product: "+product+" ?."))
            return;
	
	Object src = evt.getSource();
        javax.swing.JButton source = null;

	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, 
							     product) {
	    public Object construct() {
		_deleteProduct(cmdButton, action);
		return null;
	    }
	};

	sw.start();
  }//GEN-LAST:event_deleteProduct




    private void _deleteProduct(javax.swing.JButton cmdButton, 
				    String product)
    {
	

	try {
	    mLock.acquire();
	} catch (InterruptedException ie) {
	    Log.getInstance().log_error("Service handler interrupted",ie);
	    if (cmdButton != null ) 
		cmdButton.setEnabled(true);
	    return;
	}

	statusPanel.start("Checking if product is in use...");
	/*
	** Check if product is in use
	*/
	if (!productInUse(product)) {
	    productsDeleted = true;
	    productModel.deleteProduct(product);
	    reload(productModel.getRoot());
	    
	}

	mLock.release();

	if (cmdButton != null ) 
	    cmdButton.setEnabled(true);
	statusPanel.stop();
	statusPanel.clear();
    
    }


    private boolean productInUse(String product) {

	boolean ret_status = false;
	boolean got_exception  = false;
	StringBuffer errstr = new StringBuffer();
	StringBuffer errbuf = new StringBuffer("Cannot delete product.\nIt is in use by distributors:\n");

	try {

          java.util.HashMap dspConfig 
		= ConfigComm.getHashMap(Constants.GLB_TAG_DSP);


	  javax.swing.JTable dummy = new javax.swing.JTable();
	  java.util.HashMap productMap = new java.util.HashMap();

	  String ifstr = (String)dspConfig.get("INPUT_FEED1");
	  DSPConfigForm.loadProductTable(dummy, productMap, ifstr);

	  java.util.Iterator iter = productMap.keySet().iterator();
	  while (iter.hasNext()) {
		Object key = iter.next();
		String p = (String)productMap.get(key);
		if (Constants.matchPattern(p," ",product)) {
			ret_status = true;
			errstr.append("\t'"+key.toString()+ "' DC-I DSP "
			+"reader/msgmgr.\n");

			break;
		}
	  }

    	  ifstr = (String)dspConfig.get("INPUT_FEED2");
	  productMap.clear();
	  DSPConfigForm.loadProductTable(dummy, productMap, ifstr);
	  iter = productMap.keySet().iterator();
	  while (iter.hasNext()) {
		Object key = iter.next();
		String p = (String)productMap.get(key);
		if (Constants.matchPattern(p," ",product)) {
			ret_status = true;
			errstr.append("\t'"+key.toString()+ "' DC-II DSP "
				+"reader/msgmgr.\n");
			break;
		}
	  }

	} catch (DBException dbe ) {
		int errno = dbe.getErrorNo();
		if (errno != Constants.KEY_NOT_FOUND) {
	    		Log.getInstance().log_error("Could not verify "
					+"if product "+product+" is in use "
					+"by DSP reader.",
					 dbe);
			ret_status = true;
			got_exception  = true;
		}
	} catch (Exception e ) {
		Log.getInstance().log_error( "Could not verify if product "
					 +product+" is in use by DSP reader.",
					 e);
		ret_status = true;
		got_exception  = true;
	}

	StringBuffer reqbuf = new StringBuffer();
		
	ConfigComm.getServKey(reqbuf,
			      ConfigComm.GET_DISTRIBUTORS_USING_PRODUCT,
			      product);

	try { 
	    byte[] b = ConfigComm.configRequest(reqbuf);

	} catch (DBException dbe ) {

		
                if (dbe.getErrorNo() == Constants.KEY_NOT_FOUND) {
                        ret_status = false;
                        got_exception = false;
                }
                else if (dbe.getErrorNo() == Constants.KEY_IN_USE) {
                        ret_status = true;
                        byte[] b = dbe.getServerBytes();

		    if (b != null) {

			String respbuf = new String(b);
			int index = respbuf.indexOf(ConfigComm.CONF_STX)+1;
			String databuf = respbuf.substring(index);

			StringBuffer sep = new StringBuffer("|");
			sep.append(ConfigComm.CONF_STX)
			    .append(ConfigComm.CONF_ETX)
			    .append(ConfigComm.CONF_FS);

			java.util.StringTokenizer tokenizer
			    = new java.util.StringTokenizer(databuf,sep.toString());

			errstr.append("\nDistributors: \n\t");
			int knt = tokenizer.countTokens();
			for (int k = 0; k < knt; k++) {
			    errstr.append(tokenizer.nextToken());
			    if (k < (knt-1)) errstr.append(",");
			}
			errstr.append("\n");

		    }

		    Log.getInstance().log_error( "Product is in use by distributors: "+product, dbe);

		} else {
                        ret_status = true;
			got_exception = true;
	    		Log.getInstance().log_error("Could not verify if "
					+"product " +product
					+" is in use by LH.",
					 dbe);
		}


	} catch (Exception e) {
		got_exception = true;

	    	Log.getInstance().log_error( "Could not verify if product "
					 +product+" is in use by LH.",
					 e);
	}

	if (got_exception) {
		Log.getInstance().show_error(this,"Error in delete",
					 "Could not verify if product "
					 +product+" is in use.",
					 null);
	} else if (errstr.length()>0) {
		errstr.insert(0,"Product is in use:\n");
		Log.getInstance().show_error(this,"Can't delete "+product,
					 errstr.toString(),
					 null);
	}

	return ret_status;
    }




private void modifyProduct (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifyProduct
// Add your handling code here:
	int srows[] = productTable.getSelectedRows();
    
	if (srows.length==0) {
	    javax.swing.JOptionPane.showMessageDialog(this,
			   "Please select the product to be modified.",
			   "Error",
  		            javax.swing.JOptionPane.ERROR_MESSAGE);
	    return;
      
	}

	int srow = srows[0];
	String id = (String)productTable.getValueAt(srow,0);
	int lcn = ((Integer)productTable.getValueAt(srow,1)).intValue();
	int type = ((Integer)productTable.getValueAt(srow,2)).intValue();
	boolean history = ((Boolean)productTable.getValueAt(srow,3)).booleanValue();
	String r_key = (String)productTable.getValueAt(srow,4);
	boolean is_container = ((Boolean)productTable.getValueAt(srow,5)).booleanValue();
	boolean is_product = ((Boolean)productTable.getValueAt(srow,6)).booleanValue();
	String container = productModel.getContainer(id);
	if(container == null)
	    container = "NONE";
	
	
	CSCProductStructure _ps = 
	    new CSCProductStructure(id,type,lcn,history,
				    r_key,is_container, container);
	
	ProductDetailsDialog dlg =
	    new ProductDetailsDialog(this,true,productModel,_ps);
	dlg.show();
	CSCProductStructure ps = dlg.getProduct();
	if (ps != null) {
	    if (  (is_container != ps.is_container)
		  || ((container!=null) && !container.equals(ps.container)) ) {
		
		productsAdded = true;
	    }
	    productModel.modifyProduct(ps);
	    reload(productModel.getRoot());
	}

  }//GEN-LAST:event_modifyProduct

    private void addProduct (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProduct
	// Add your handling code here:
	ProductDetailsDialog dlg =
	    new ProductDetailsDialog(this,true,productModel);
	dlg.show();
	CSCProductStructure ps = dlg.getProduct();
	if (ps != null) {
	    productsAdded = true;
	    productModel.addProduct(ps);
	    reload(productModel.getRoot());
	}
    }//GEN-LAST:event_addProduct
    




    

  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
    
      
      exitForm(new java.awt.event.ActionEvent(this,
			     java.awt.event.ActionEvent.ACTION_PERFORMED,
					      "Close"));
      
  }//GEN-LAST:event_closeDialog


    /** Exit the Application */
    private void exitForm(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitForm
	
	if (isExiting)
	    return;


	
	if ((evt!=null)&&(evt.getActionCommand().equals("Close"))
	    && productModel.isEdited()) {
	    if (javax.swing.JOptionPane.YES_OPTION
		!= Log.getInstance().show_confirm(this, "Please confirm",
					  "Modifications will be "
					  +"lost.\nAre you sure you want"
					  +" to close window?.")) {
		return;
	    }
	}



	isExiting = true;

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final ProductConfigurationDialog This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    mLock.acquire();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();		
    }//GEN-LAST:event_exitForm




  /**
  * @param args the command line arguments
  */
  public static void main (String args[]) {
      try {
	  ConfigComm.initLogin("test","dist-c1d1,dist-c1d2","/ids2");
	  new ProductConfigurationDialog (new javax.swing.JFrame (), true).show ();
      } catch (Exception e) {
	  e.printStackTrace();
      }

  }


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel3;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JPanel jPanel6;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JTextField idTextField;
  private javax.swing.JPanel jPanel7;
  private javax.swing.JLabel statusLabel;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private ids2ui.StatusPanel statusPanel;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton jButton4;
  private javax.swing.JButton jButton5;
  // End of variables declaration//GEN-END:variables






    class Reloader implements ActionListener, TreeExpansionListener {
	public void actionPerformed(ActionEvent ae) {
	    if (!productModel.isReloading()) {
		// No longer loading.
		timer.stop();
		if (reloadRow != -1) {
		    generateChangeEvent(reloadRow);
		}
		reloadRow = -1;
		reloadPath = null;
	    }
	    else {
		// Still loading, see if paths changed.
		TreePath       newPath = productModel.getPathLoading();

		if (newPath == null) {
		    // Hmm... Will usually indicate the reload thread
		    // completed between time we asked if reloading.
		    if (reloadRow != -1) {
			generateChangeEvent(reloadRow);
		    }
		    reloadRow = -1;
		    reloadPath = null;
		}
		else {
		    // Ok, valid path, see if matches last path.
		    int        newRow = productTable.getTree().getRowForPath
			                          (newPath);

		    if (newPath.equals(reloadPath)) {
			reloadCounter = (reloadCounter + 1) % 8;
			if (newRow != reloadRow) {
			    int             lastRow = reloadRow;

			    reloadRow = newRow;
			    generateChangeEvent(lastRow);
			}
			generateChangeEvent(reloadRow);
		    }
		    else {
			int          lastRow = reloadRow;

			reloadCounter = 0;
			reloadRow = newRow;
			reloadPath = newPath;
			if (lastRow != reloadRow) {
			    generateChangeEvent(lastRow);
			}
			generateChangeEvent(reloadRow);
		    }
		}
	    }
	    updateStatusLabel();
	}

	/**
	 * Generates and update event for the specified row. CSCProductsModel
	 * could do this, but it would not know when the row has changed
	 * as a result of expanding/collapsing nodes in the tree.
	 */
	protected void generateChangeEvent(int row) {
	    if (row != -1) {
		AbstractTableModel     tModel = (AbstractTableModel)productTable.
		                                 getModel();

		tModel.fireTableChanged(new TableModelEvent
				       (tModel, row, row, 1));
	    }
	}

	//
	// TreeExpansionListener
	//

	/**
	 * Invoked when the tree has expanded.
	 */
	public void treeExpanded(TreeExpansionEvent te) {
	    updateRow();
	}

	/**
	 * Invoked when the tree has collapsed.
	 */
	public void treeCollapsed(TreeExpansionEvent te) {
	    updateRow();
	}

	/**
	 * Updates the reloadRow and path, this does not genernate a
	 * change event.
	 */
	protected void updateRow() {
	    reloadPath = productModel.getPathLoading();

	    if (reloadPath != null) {
		reloadRow = productTable.getTree().getRowForPath(reloadPath);
	    }
	}
    }


    /**
     * A renderer that will give an indicator when a cell is being reloaded.
     */
    class IndicatorRenderer extends DefaultTableCellRenderer {
	/** Makes sure the number of displayed in an internationalized
	 * manner. */
	protected NumberFormat       formatter;
	/** Row that is currently being painted. */
	protected int                lastRow;
	

	IndicatorRenderer() {
	    setHorizontalAlignment(JLabel.RIGHT);
	    formatter = NumberFormat.getInstance();
	}

	/**
	 * Invoked as part of DefaultTableCellRenderers implemention. Sets
	 * the text of the label.
	 */
	public void setValue(Object value) { 
	    setText((value == null) ? "---" : formatter.format(value)); 
	}

	/**
	 * Returns this.
	 */
	public Component getTableCellRendererComponent(JTable table,
			    Object value, boolean isSelected, boolean hasFocus,
			    int row, int column) {
	    super.getTableCellRendererComponent(table, value, isSelected,
						hasFocus, row, column);
	    lastRow = row;
	    return this;
	}

	/**
	 * If the row being painted is also being reloaded this will draw
	 * a little indicator.
	 */
	public void paint(Graphics g) {
	    if (lastRow == reloadRow) {
		int       width = getWidth();
		int       height = getHeight();

		g.setColor(getBackground());
		g.fillRect(0, 0, width, height);
		g.setColor(getForeground());

		int       diameter = Math.min(width, height);

		if (reloadCounter < 5) {
		    g.fillArc((width - diameter) / 2, (height - diameter) / 2,
			      diameter, diameter, 90, -(reloadCounter * 90));
		}
		else {
		    g.fillArc((width - diameter) / 2, (height - diameter) / 2,
			      diameter, diameter, 90,
			      (4 - reloadCounter % 4) * 90);
		}
	    }
	    else {
		super.paint(g);
	    }
	}
    }












}

#!/bin/ksh
#/*
#**  SCCS Info :  "@(#)ConfigDistr.sh	1.1    04/10/06"
#*/
#
#
#/home/srz/ids2/tools/forte4j/system
#ids2ui/ConfigDistr.sh ids2ui/DistrTemplate.txt
#


if [ $# -lt 2 ];
then
	echo "Usage: $0 dsp_host_list template_file [ base port ] [ xreader start script name] "
	exit 1
fi

DSP_HOSTS=$1
TEMPLATE_FILE=$2
BASEPORT=${3:-40000}
XRCMD_FILE=${4:-startxr.sh}

CFG_DIR=/tmp/distrcfg/_$$_xx_

echo "#!/bin/ksh" > ${XRCMD_FILE}
IDP="P"
set -A formats  CF5 CF5 CF5 NML CF5 NML CF5  ANP CF5 NML
let MAXKNT=100
let knt=0

mkdir -p ${CFG_DIR}

while [ ${knt} -lt ${MAXKNT} ];
do
	let knt=knt+1
	let port=BASEPORT+knt*100
	let index=knt%4

	case ${index} in 
		0) T="TCPSA";;
		1) T="TCPSU";; 
		2) T="TCPMA";;
		3) T="TCPMU";;
	esac

	let index=knt%10
	format=${formats[${index}]}

	products="DN	${format}	0	false	NONE	LL	${format}	0	false	NONE	PB	${format}	0	false	NONE	SN	${format}	0	false	NONE"


	printf "%03d" ${knt} | read num
	ID=${IDP}${num}
	transport="${T} dist-c1d2:${port}"
	description="${ID}: ${format} ${transport}: Performance testing"


	echo "xreader -f ${format} -t ${T} -a *:${port}" >>  ${XRCMD_FILE}


	CFG_FILE="${CFG_DIR}/${ID}.cfg"
	/bin/rm -f ${CFG_FILE}

	cat ${TEMPLATE_FILE} | sed "s/DDDD/${ID}/" |  sed "s/products/${products}/" | sed "s/format/${format}/" | sed "s/transport/${transport}/" | sed "s/description/${description}/"  > ${CFG_FILE}


done
	java -jar ConfigDistr.jar  ${DSP_HOSTS}  ${CFG_DIR}/*.cfg

	/bin/rm -rf ${CFG_DIR}

echo Created ${XRCMD_FILE}

/*
**  SCCS Info :  "@(#)DCMServicesSelectForm.java	1.29    04/12/08"
*/
/*
 * DCMServicesSelectForm.java
 *
 * Created on April 5, 2000, 2:46 PM
 */
 
package ids2ui;
import java.util.Arrays;

/** 
 *
 * @author  srz
 * @version 
 */
public class DCMServicesSelectForm 
        extends javax.swing.JFrame 
        implements TaskListener , javax.swing.event.ListSelectionListener {

        private javax.swing.JTable dcmTable;
        private DCMServicesSelectForm myFrame;
        private javax.swing.JRadioButton noneRB = null;
        
        private StringBuffer DataServicesList = null;

        private Utils.UpdateTimer updateTimer = null;
        private FIFOReadWriteLock rwLock = new FIFOReadWriteLock(); 
        private volatile boolean isExiting = false;
        javax.swing.event.DocumentListener docListener = null;
        String moreOptions[] = new String[3];

        
            /** Creates new form DCMServicesSelectForm */
        public DCMServicesSelectForm() {

                myFrame = this;

                setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

    
                initComponents ();
                myInitComponents ();

                pack ();


                WindowEventAdapter.getInstance().
                        registerWindow(Constants.SERVICES_DCM,this);
	
                updateTimer.start();

        }

    
        private void myInitComponents() 
        {
      
                DataServicesList = new StringBuffer();
                for ( int i = 0; i < Constants.DCMServicesTable.length; i++)  {
                        DataServicesList.append(Constants.DCMServicesTable[i][1]);
                        if (i < (Constants.DCMServicesTable.length-1))
                                DataServicesList.append(",");
                }
    
                DataServicesList.append(",dcm_linehand");

                noneRB = new javax.swing.JRadioButton();
               
    
                javax.swing.ButtonGroup group;
                group = new javax.swing.ButtonGroup();
                group.add(normalRB);
                group.add(hotRB);
                group.add(coldRB);
                group.add(dormantRB);
                group.add(noneRB);
                            
               noneRB.setSelected(true);
                
               

               moreOptions[0] = Constants.PICK_LOCATION;
               moreOptions[1] = Constants.DC1_LOCATION;
               moreOptions[2] = Constants.DC2_LOCATION;
               
               Utils.loadLocationList(dataLocationComboBox, moreOptions,
                                      moreOptions[0]);
               boolean addLocationOptions = true;
               Utils.loadLocationList(distrLocationComboBox, addLocationOptions);
              
                DCMStatusDataModel dcmModel 
                        = new DCMStatusDataModel();
    
                dcmTable = new javax.swing.JTable( dcmModel) ;

                dcmTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200,120));

	
                javax.swing.table.JTableHeader header = dcmTable.getTableHeader();
                header.addMouseListener(dcmModel.new ColumnListener(dcmTable, rwLock));


                dcmTable.getSelectionModel().addListSelectionListener(this);
      
                Utils.UpdateListener updater = new Utils.UpdateListener(rwLock, this,
                                                                        dcmModel);

                updateTimer = new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, updater);
	

                javax.swing.JScrollPane jScrollPane1 
                        = new javax.swing.JScrollPane(dcmTable);
      
                tablePanel.add(jScrollPane1, java.awt.BorderLayout.CENTER);
	
                docListener = new ActionHandlers.IDFieldListener(this, dcmTable, idTextF);

                idTextF.getDocument().addDocumentListener( docListener );
        

                selectAllButton.addActionListener(
                        new ActionHandlers.SelectAllActionHandler(dcmTable));


                servicesButton.addActionListener(
                        new ActionHandlers.SelectActionHandler(this, this,
                                                               rwLock,
                                                               updateTimer,
                                                               dcmTable,
                                                               "Please select a DCM.")
                        {
                                
                                public void
                                        handler(javax.swing.JButton cmdButton,
                                                String command)  {
                                        int row = selected_rows[0];
                                        
                                        String dcmName = (String)table.getValueAt(row,0);
                                        javax.swing.JFrame f =
                                                (javax.swing.JFrame)WindowEventAdapter
                                                .getInstance()
                                                .findWindow(Constants.SERVICES_DCM_PREFIX
                                                            +dcmName);
                                        if (f == null) 
                                                f = new DCMServicesForm(dcmName);
                                        
                                        if (f!=null) f.show();
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                }
                        }
                        );
                
                
                
                addButton.addActionListener(
                        new ActionHandlers.ActionHandler(this,
                                                         this, rwLock,
                                                         updateTimer,dcmTable) 
                        {
                                public void
                                        handler(javax.swing.JButton cmdButton,
                                                String command) {
                                        try {
                                                javax.swing.JFrame f
                                                        = new DCMConfigForm();
                                                f.show();
                                        } catch (Exception e) {
                                                Log.getInstance().show_error(frame,"Error",
                                                                             "Error in creating DCM window.",e);
                                                
                                        }
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                } 
                        }
                        );
                
                
                
                modifyButton.addActionListener(
                        new ActionHandlers.SelectActionHandler(this,
                                                               this, rwLock,
                                                               updateTimer,
                                                               dcmTable,
                                                               "Please select a DCM to modify.") 
                        {
                                public void
                                        handler(javax.swing.JButton cmdButton,
                                                String command) 
                                        {
                                                int row = selected_rows[0];
                                                String dcmTag = (String)table.getValueAt(row,0);
                                                
                                                javax.swing.JFrame f
                                                        = (javax.swing.JFrame)WindowEventAdapter.getInstance().findWindow(
                                                                Constants.CONFIGURATION_DCM_PREFIX+dcmTag);
                                                if (f == null) {
                                                        try {
                                                                f = new DCMConfigForm(dcmTag );
                                                        } catch (Exception e) {
                                                                Log.getInstance().show_error(frame,"Error",
                                                                                             "Error in creating DCM window."+dcmTag,e);
                                                                
                                                        }
                                                }
                                                if (f!=null)
                                                        f.show();
                                                
                                                if (cmdButton!=null)
                                                        cmdButton.setEnabled(true);
                                        } 
                        }
                        );
        

                
                deleteButton.addActionListener(
                        new ActionHandlers.DeleteDCMActionHandler(this, this,
                                                                  rwLock,
                                                                  updateTimer,
                                                                  dcmTable,
                                                                  "Please select a DCM to delete.",
                                                                  DataServicesList));
                
                
                
                
                
                
                
                
                
                ActionHandlers.SelectActionHandler statusHandler = 

                        new ActionHandlers.SelectActionHandler(this, this,
                                                               rwLock,
                                                               updateTimer,
                                                               dcmTable,
                                                               "Please select a DCM to view status.") 
                        {
                                public void
                                        handler(javax.swing.JButton cmdButton, String command) {
                                        DCMStatusDataModel model = 
                                                (DCMStatusDataModel)dcmTable.getModel();

	

                                        int row   = selected_rows[0];
                                        String dcm = (String)dcmTable.getValueAt(row,0);

                                        
                                        String host = null;
                                        int col = 0;

                                        String location = (String)dataLocationComboBox.getSelectedItem();
                                        String location1 = null, location2 = null;
                                        
                                        try {
                                                
                                                java.util.HashMap hostmap
                                                        = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                                                location1 = (String)hostmap.get("LOCATION1");
                                                location2 = (String)hostmap.get("LOCATION2");
                                        }
                                        catch (Exception e) {
                                        }
                                        String host1 = (String)model.getHost1(row);
                                        String host2 = (String)model.getHost2(row);
                                                
                                        if ( (location1!=null)
                                             && (location.equals(Constants.DC1_LOCATION_LABEL)
                                                 || location.equals(location1)) ) {
                                                col = 1;
                                                host = host1;
                                        } else if ( (location2!=null)
                                                    && (location.equals(Constants.DC2_LOCATION_LABEL)
                                                        || location.equals(location2)) ){
                                                col = 2;
                                                host = host2;
                                        }
                                        
                                        
                                        if (col != 0) {
                                                StatusHandler shandler = StatusHandler.getInstance();
                                                int type = Constants.DCM_READER;
                                                try {
                                                        
                                                        shandler.displayStatus(myFrame,type,col,
                                                                               host,dcm,null);
                                                }
                                                catch (Exception e){
                                                }
                                                
                                        }
                                        
                                        
                                        if (cmdButton != null) cmdButton.setEnabled(true);
                                        
                                } 
                        };
                
                
                
                
                dataStatusButton.addActionListener(statusHandler);
               
                
                
                ActionHandlers.DCMDataServicesActionHandler
                        dataServiceHandler =
                        new ActionHandlers.DCMDataServicesActionHandler(this,
                                                                        this,
                                                                        rwLock,
                                                                        updateTimer,
                                                                        dcmTable,
                                                                        dataLocationComboBox,
                                                                        normalRB,
                                                                        hotRB,
                                                                        coldRB,
                                                                        dormantRB,
                                                                        noneRB,
                                                                        -1);

                


                dataStartButton.addActionListener(dataServiceHandler);
                dataStopButton.addActionListener(dataServiceHandler);

                ActionHandlers.DCMDistrServicesActionHandler
                        distrServiceHandler =
                        new ActionHandlers.DCMDistrServicesActionHandler(this,
                                                                         this,
                                                                         rwLock,
                                                                         updateTimer,
                                                                         dcmTable,
                                                                         distrLocationComboBox,
                                                                         normalRB,
                                                                         hotRB,
                                                                         coldRB,
                                                                         dormantRB,
                                                                         noneRB,
                                                                         -1);


                
                distrStartButton.addActionListener(distrServiceHandler);
                distrStopButton.addActionListener(distrServiceHandler);
                distrModeButton.addActionListener(distrServiceHandler);

                dataLocationComboBox.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {  updateUIState(1); }
                }
                                                   );


                distrLocationComboBox.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {  updateUIState(1); }
                }
                                                   );

                dataLocationComboBox.setRenderer( new IDS_SwingUtils.LocationComboBoxRenderer());
                distrLocationComboBox.setRenderer( new IDS_SwingUtils.LocationComboBoxRenderer());

              ActionHandlers.ExitHandler exitHandler =
                                                  new ActionHandlers.ExitHandler(this,this, rwLock, 
                                                                  updateTimer, dcmTable);
                                                  
                closeButton.addActionListener(exitHandler);
                addWindowListener(exitHandler); 


        }



        







        public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                
                if (evt.getValueIsAdjusting()) return;
                updateUIState(0);

                int srows[] = dcmTable.getSelectedRows();

                idTextF.getDocument().removeDocumentListener( docListener);

                if (srows.length!=1)
                        idTextF.setText("");
                else
                        idTextF.setText((String)dcmTable.getValueAt(srows[0],0));

                idTextF.getDocument().addDocumentListener( docListener);

        } /* End of valueChanged() */




        public void Refresh() {
                try {
                        DCMStatusDataModel mdl
                                = (DCMStatusDataModel)dcmTable.getModel();
                        mdl.Refresh(); 
                } catch (Exception e) {}
        }


        private void updateUIState(int flags) {

                int srows[] = dcmTable.getSelectedRows();

                boolean validDataLocation = true,
                        validDistrLocation = true,
                        enable=true;

                
                String dataLocation =
                        (String)dataLocationComboBox.getSelectedItem();
                if (dataLocation.equals(Constants.PICK_LOCATION))
                        validDataLocation = false;

                
                String distrLocation =
                        (String)distrLocationComboBox.getSelectedItem();
                if (distrLocation.equals(Constants.PICK_LOCATION))
                        validDistrLocation = false;
            
                dataStatusButton.setEnabled(false);
                
                if (srows.length==1) {
                        if (validDataLocation)
                                dataStatusButton.setEnabled(true);
                        servicesButton.setEnabled(true); // Services

                        if (AccessLevel.MENU_ACCESS_LEVEL == 0) {
                                modifyButton.setEnabled(true); // Modify
                                deleteButton.setEnabled(true); // Delete
                        }

                } else {

                        dataStatusButton.setEnabled(false);  

                        deleteButton.setEnabled(false); // Delete
                        modifyButton.setEnabled(false); // Modify
                        servicesButton.setEnabled(false); // Services
                }

                

                
                if (srows.length<=0) 
                        enable = false;
                
                if ( (flags != 1 )
                     && (srows.length > 0)  ) {
                        String dcms[] = new String[srows.length];
                        for (int i = 0; i < srows.length; i++) 
                                dcms[i] = (String)dcmTable.getValueAt(srows[i], 0);
                        
                        
                        Utils.loadDCMLocationList(distrLocationComboBox,
                                                  Arrays.asList(dcms),
                                                  moreOptions, moreOptions[0]);

                        Utils.loadDCMLocationList(dataLocationComboBox,
                                                  Arrays.asList(dcms),
                                                  moreOptions, moreOptions[0]);
                        
                }
                

                dataStartButton.setEnabled(enable && validDataLocation);
                dataStopButton.setEnabled(enable && validDataLocation);
	    
                distrStartButton.setEnabled(enable && validDistrLocation);
                distrStopButton.setEnabled(enable && validDistrLocation);
                distrModeButton.setEnabled(enable && validDistrLocation);



                if (AccessLevel.MENU_ACCESS_LEVEL != 0) {
                        addButton.setEnabled(false); // Add
                        modifyButton.setEnabled(false); // Modify
                        deleteButton.setEnabled(false); // Delete
                }

                
        }



        public void taskStarted(java.util.EventObject evt) {
                taskStarted("Updating status...");
        }

        public void taskStarted() {
                taskStarted((String)null);	
        }

        public void taskStarted(final String s) {

                if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                        Runnable callMe = new Runnable() {
                                public void run() {
                                        taskStarted(s);
                                }
                        };	
                        javax.swing.SwingUtilities.invokeLater(callMe);

                } else {
                        if (s==null)
                                statusPanel1.start();
                        else
                                statusPanel1.start(s);
                }
        }


        public void taskEnded() {
                taskEnded((String)null);
        }

        public void taskEnded(java.util.EventObject evt) {	
                taskEnded("Status updated @ "+new java.util.Date().toString());
        }

        public void taskEnded(final String s) {
                if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                        Runnable callMe = new Runnable() {
                                public void run() {
                                        taskEnded(s);
                                }
                        };	
                        javax.swing.SwingUtilities.invokeLater(callMe);

                } else {
                        statusPanel1.stop();
                        if (s!=null)
                                statusPanel1.showStatus(s);
                        updateUIState(0);
                        //repaint();
                }
        }
    
    

            /** This method is called from within the constructor to
             * initialize the form.
             * WARNING: Do NOT modify this code. The content of this method is
             * always regenerated by the FormEditor.
             */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel1 = new javax.swing.JPanel ();
          tablePanel = new javax.swing.JPanel ();
          jPanel6 = new javax.swing.JPanel ();
          jPanel7 = new javax.swing.JPanel ();
          jLabel1 = new javax.swing.JLabel ();
          idTextF = new ids2ui.UCTextField ();
          jPanel4 = new javax.swing.JPanel ();
          selectAllButton = new javax.swing.JButton ();
          servicesButton = new javax.swing.JButton ();
          jTabbedPane1 = new javax.swing.JTabbedPane ();
          jPanel36 = new javax.swing.JPanel ();
          dataStartButton = new javax.swing.JButton ();
          dataStopButton = new javax.swing.JButton ();
          dataStatusButton = new javax.swing.JButton ();
          jLabel2 = new javax.swing.JLabel ();
          dataLocationComboBox = new javax.swing.JComboBox ();
          jPanel11 = new javax.swing.JPanel ();
          optionPanel12 = new javax.swing.JPanel ();
          dormantRB = new javax.swing.JRadioButton ();
          normalRB = new javax.swing.JRadioButton ();
          hotRB = new javax.swing.JRadioButton ();
          coldRB = new javax.swing.JRadioButton ();
          jLabel3 = new javax.swing.JLabel ();
          jPanel30 = new javax.swing.JPanel ();
          distrStartButton = new javax.swing.JButton ();
          distrStopButton = new javax.swing.JButton ();
          distrModeButton = new javax.swing.JButton ();
          jLabel4 = new javax.swing.JLabel ();
          distrLocationComboBox = new javax.swing.JComboBox ();
          jPanel8 = new javax.swing.JPanel ();
          jPanel9 = new javax.swing.JPanel ();
          addButton = new javax.swing.JButton ();
          modifyButton = new javax.swing.JButton ();
          deleteButton = new javax.swing.JButton ();
          jPanel3 = new javax.swing.JPanel ();
          closeButton = new javax.swing.JButton ();
          statusPanel1 = new ids2ui.StatusPanel ();
          getContentPane ().setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;
          setTitle ("DCM Main Screen");

          jPanel1.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
          jPanel1.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));

            tablePanel.setLayout (new java.awt.BorderLayout ());
            tablePanel.setBorder (new javax.swing.border.TitledBorder(""));
  
              jPanel6.setLayout (new java.awt.BorderLayout ());
    
      
                  jLabel1.setText ("ID");
        
                  jPanel7.add (jLabel1);
        
                  idTextF.setColumns (5);
        
                  jPanel7.add (idTextF);
        
                jPanel6.add (jPanel7, java.awt.BorderLayout.WEST);
      
                jPanel4.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints3;
      
                  selectAllButton.setMargin (new java.awt.Insets(2, 7, 2, 7));
                  selectAllButton.setText ("Select all");
        
                  gridBagConstraints3 = new java.awt.GridBagConstraints ();
                  gridBagConstraints3.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel4.add (selectAllButton, gridBagConstraints3);
        
                  servicesButton.setText ("DCM Services");
                  servicesButton.setActionCommand ("Services");
        
                  gridBagConstraints3 = new java.awt.GridBagConstraints ();
                  gridBagConstraints3.insets = new java.awt.Insets (5, 5, 5, 10);
                  gridBagConstraints3.weightx = 0.25;
                  jPanel4.add (servicesButton, gridBagConstraints3);
        
                jPanel6.add (jPanel4, java.awt.BorderLayout.EAST);
      
              tablePanel.add (jPanel6, java.awt.BorderLayout.SOUTH);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.weightx = 1.0;
            gridBagConstraints2.weighty = 1.0;
            jPanel1.add (tablePanel, gridBagConstraints2);
  
  
              jPanel36.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints4;
    
                dataStartButton.setToolTipText ("Start all data and system services");
                dataStartButton.setText ("Start");
                dataStartButton.setForeground (new java.awt.Color (0, 150, 50));
                dataStartButton.setActionCommand ("START_IS_1");
                dataStartButton.setLabel ("START");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 2;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel36.add (dataStartButton, gridBagConstraints4);
      
                dataStopButton.setToolTipText ("Stop all data and system services");
                dataStopButton.setText ("Stop");
                dataStopButton.setForeground (java.awt.Color.red);
                dataStopButton.setActionCommand ("STOP_IS_1");
                dataStopButton.setLabel ("STOP");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 3;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel36.add (dataStopButton, gridBagConstraints4);
      
                dataStatusButton.setToolTipText ("DCM Reader status");
                dataStatusButton.setText ("STATUS");
                dataStatusButton.setForeground (java.awt.Color.blue);
                dataStatusButton.setActionCommand ("STATUS_IS_1");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 4;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints4.insets = new java.awt.Insets (5, 5, 5, 5);
                jPanel36.add (dataStatusButton, gridBagConstraints4);
      
                jLabel2.setText ("Location");
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 0;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.insets = new java.awt.Insets (0, 0, 0, 5);
                jPanel36.add (jLabel2, gridBagConstraints4);
      
      
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 1;
                gridBagConstraints4.gridy = 0;
                gridBagConstraints4.insets = new java.awt.Insets (0, 0, 0, 15);
                jPanel36.add (dataLocationComboBox, gridBagConstraints4);
      
              jTabbedPane1.addTab ("Data services", jPanel36);
    
              jPanel11.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints5;
    
                optionPanel12.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints6;
      
                  dormantRB.setText ("Dormant");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 4;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 5, 0, 0);
                  optionPanel12.add (dormantRB, gridBagConstraints6);
        
                  normalRB.setText ("Normal");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 1;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 5);
                  optionPanel12.add (normalRB, gridBagConstraints6);
        
                  hotRB.setText ("Hot");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 2;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 5);
                  optionPanel12.add (hotRB, gridBagConstraints6);
        
                  coldRB.setText ("Cold");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 3;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 5);
                  optionPanel12.add (coldRB, gridBagConstraints6);
        
                  jLabel3.setText ("Mode");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 0;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 10);
                  optionPanel12.add (jLabel3, gridBagConstraints6);
        
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 0;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints5.insets = new java.awt.Insets (2, 0, 10, 0);
                gridBagConstraints5.weightx = 0.5;
                jPanel11.add (optionPanel12, gridBagConstraints5);
      
                jPanel30.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints7;
      
                  distrStartButton.setToolTipText ("Start all distributors");
                  distrStartButton.setForeground (new java.awt.Color (0, 150, 50));
                  distrStartButton.setActionCommand ("START_LH_1");
                  distrStartButton.setLabel ("START");
        
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 2;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints7.insets = new java.awt.Insets (5, 5, 5, 5);
                  gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
                  jPanel30.add (distrStartButton, gridBagConstraints7);
        
                  distrStopButton.setToolTipText ("Stop all distributors");
                  distrStopButton.setText ("Stop");
                  distrStopButton.setForeground (java.awt.Color.red);
                  distrStopButton.setActionCommand ("STOP_LH_1");
                  distrStopButton.setLabel ("STOP");
        
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 3;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints7.insets = new java.awt.Insets (5, 5, 5, 5);
                  gridBagConstraints7.anchor = java.awt.GridBagConstraints.WEST;
                  jPanel30.add (distrStopButton, gridBagConstraints7);
        
                  distrModeButton.setText ("SET MODE");
                  distrModeButton.setForeground (java.awt.Color.red);
                  distrModeButton.setActionCommand ("MODE_LH_1");
        
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 4;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints7.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel30.add (distrModeButton, gridBagConstraints7);
        
                  jLabel4.setText ("Location");
        
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 0;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.insets = new java.awt.Insets (0, 0, 0, 5);
                  jPanel30.add (jLabel4, gridBagConstraints7);
        
        
                  gridBagConstraints7 = new java.awt.GridBagConstraints ();
                  gridBagConstraints7.gridx = 1;
                  gridBagConstraints7.gridy = 0;
                  gridBagConstraints7.insets = new java.awt.Insets (0, 0, 0, 10);
                  jPanel30.add (distrLocationComboBox, gridBagConstraints7);
        
                gridBagConstraints5 = new java.awt.GridBagConstraints ();
                gridBagConstraints5.gridx = 0;
                gridBagConstraints5.gridy = 1;
                gridBagConstraints5.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints5.weightx = 0.5;
                gridBagConstraints5.weighty = 1.0;
                jPanel11.add (jPanel30, gridBagConstraints5);
      
              jTabbedPane1.addTab ("Distributor services", jPanel11);
    
              jPanel8.setLayout (new javax.swing.BoxLayout (jPanel8, 0));
              jPanel8.setBorder (new javax.swing.border.TitledBorder(""));
    
                jPanel9.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints8;
      
                  addButton.setToolTipText ("Add a new DCM pair");
                  addButton.setPreferredSize (new java.awt.Dimension(101, 27));
                  addButton.setText ("Add");
        
                  gridBagConstraints8 = new java.awt.GridBagConstraints ();
                  gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                  gridBagConstraints8.weightx = 0.25;
                  jPanel9.add (addButton, gridBagConstraints8);
        
                  modifyButton.setToolTipText ("Modify configuration");
                  modifyButton.setPreferredSize (new java.awt.Dimension(101, 27));
                  modifyButton.setText ("Modify ");
        
                  gridBagConstraints8 = new java.awt.GridBagConstraints ();
                  gridBagConstraints8.gridx = 1;
                  gridBagConstraints8.gridy = 0;
                  gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                  gridBagConstraints8.weightx = 0.25;
                  jPanel9.add (modifyButton, gridBagConstraints8);
        
                  deleteButton.setToolTipText ("Delete DCM pair from database");
                  deleteButton.setPreferredSize (new java.awt.Dimension(101, 27));
                  deleteButton.setText ("Delete");
        
                  gridBagConstraints8 = new java.awt.GridBagConstraints ();
                  gridBagConstraints8.gridx = 2;
                  gridBagConstraints8.gridy = 0;
                  gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                  gridBagConstraints8.weightx = 0.25;
                  jPanel9.add (deleteButton, gridBagConstraints8);
        
                jPanel8.add (jPanel9);
      
              jTabbedPane1.addTab ("Configuration", jPanel8);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 1;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.weightx = 1.0;
            jPanel1.add (jTabbedPane1, gridBagConstraints2);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 1.0;
          gridBagConstraints1.weighty = 1.0;
          getContentPane ().add (jPanel1, gridBagConstraints1);

          jPanel3.setLayout (new java.awt.FlowLayout (1, 20, 5));

            closeButton.setText ("Close");
  
            jPanel3.add (closeButton);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (jPanel3, gridBagConstraints1);

          statusPanel1.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));


          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (statusPanel1, gridBagConstraints1);

        }//GEN-END:initComponents





   




   



           
        


            /** Exit the Application */

        
            /**
             * @param args the command line arguments
             */
        public static void main (String args[]) {
                new DCMServicesSelectForm ().show ();
        }


        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JPanel jPanel1;
        private javax.swing.JPanel tablePanel;
        private javax.swing.JPanel jPanel6;
        private javax.swing.JPanel jPanel7;
        private javax.swing.JLabel jLabel1;
        private ids2ui.UCTextField idTextF;
        private javax.swing.JPanel jPanel4;
        private javax.swing.JButton selectAllButton;
        private javax.swing.JButton servicesButton;
        private javax.swing.JTabbedPane jTabbedPane1;
        private javax.swing.JPanel jPanel36;
        private javax.swing.JButton dataStartButton;
        private javax.swing.JButton dataStopButton;
        private javax.swing.JButton dataStatusButton;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JComboBox dataLocationComboBox;
        private javax.swing.JPanel jPanel11;
        private javax.swing.JPanel optionPanel12;
        private javax.swing.JRadioButton dormantRB;
        private javax.swing.JRadioButton normalRB;
        private javax.swing.JRadioButton hotRB;
        private javax.swing.JRadioButton coldRB;
        private javax.swing.JLabel jLabel3;
        private javax.swing.JPanel jPanel30;
        private javax.swing.JButton distrStartButton;
        private javax.swing.JButton distrStopButton;
        private javax.swing.JButton distrModeButton;
        private javax.swing.JLabel jLabel4;
        private javax.swing.JComboBox distrLocationComboBox;
        private javax.swing.JPanel jPanel8;
        private javax.swing.JPanel jPanel9;
        private javax.swing.JButton addButton;
        private javax.swing.JButton modifyButton;
        private javax.swing.JButton deleteButton;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JButton closeButton;
        private ids2ui.StatusPanel statusPanel1;
        // End of variables declaration//GEN-END:variables




   
    
}

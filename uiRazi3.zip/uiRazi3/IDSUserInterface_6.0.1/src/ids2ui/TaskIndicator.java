/*
**  SCCS Info :  "@(#)TaskIndicator.java	1.1    00/11/16"
*/
/*
 * TaskIndicator.java
 *
 * Created on October 3, 2000, 3:37 PM
 */
 
package ids2ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/** 
 *
 * @author  srz
 * @version 
 */
public class TaskIndicator extends javax.swing.JComponent 
            implements java.awt.event.ActionListener 
{
    public static final int DELAY = 50;
    public static final int ANGLE = 36;

    private final Timer timer = new Timer(DELAY, this);
    private int startAngle;
    private int endAngle;

    /** Starts the animation timer. */
    public void start() {
        timer.start();
    }

    /** Stops the animation timer. */
    public void stop() {
        timer.stop();
        startAngle = endAngle = 0;
        repaint();
    }

    /** Advances animation to next frame. Called by timer. */
    public void actionPerformed(ActionEvent e) {
        endAngle += ANGLE;
        if (endAngle > 360) {
            endAngle = 360;
            startAngle += ANGLE;
            if (startAngle > 360) {
                startAngle = endAngle = 0;
            }
        }
        repaint();
    }

    /** Paints the current frame. */
    public void paintComponent(Graphics g) {
        int w = getWidth();
        int h = getHeight();
        if (isOpaque()) {
            g.setColor(getBackground());
            g.fillRect(0, 0, w, h);
            g.setColor(getForeground());
        }
        Insets ins = getInsets();
        w -= (ins.left + ins.right);
        h -= (ins.top + ins.bottom);
        g.fillArc(ins.left, ins.top, w, h,
            90 - startAngle, startAngle - endAngle);
    }


}

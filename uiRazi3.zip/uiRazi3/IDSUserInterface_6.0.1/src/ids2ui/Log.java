/*
**  SCCS Info :  "@(#)Log.java	1.11    04/04/14"
*/
/*
 * Log.java
 *
 * Created on April 18, 2000, 4:39 PM
 */
 
package ids2ui;
import java.util.*;

/** 
 *
 * @author  srz
 * @version 
 */
public class Log extends Object {
        final static int ERROR_MESSAGE = javax.swing.JOptionPane.ERROR_MESSAGE;
        final static int WARNING_MESSAGE = javax.swing.JOptionPane.WARNING_MESSAGE;
        static private volatile Calendar oldDate = null;
  
        static private volatile String log_file_name=null;
        static private volatile javax.swing.JTextArea textArea=null;
        static private volatile java.io.PrintWriter log_writer = null;
        static private volatile Log _instance = null;
  




        
        private static class DebugStream 
                extends java.io.PrintStream
        {
                public DebugStream(java.io.OutputStream out) {
                        super(out);
                }
           
                public DebugStream(java.io.OutputStream out, boolean autoFlush) {
                        super(out,autoFlush);
                }
           
                public void  println(String x) 
                        {
                                if (Constants.DEBUG)
                                        super.println(x);
                        }

                public void  printStackTrace(Exception e) 
                        {
                                if (Constants.DEBUG)
                                        e.printStackTrace(this);
                        }
        }

        static private DebugStream  debug = new DebugStream(System.err);
        static public Log  uilog = getInstance();

        private Log() {}
  
        public static Log getInstance() {
                if (_instance == null ) {
                        synchronized(Log.class){
                                if (_instance == null) {
                                        _instance = new Log();
	  
                                }
                        }
                }

                initialize(null);

                return _instance;
    
        }
  
  
 
        private synchronized static void
        initialize(javax.swing.JTextArea area) {
       
       
                int oyear,omonth,oday;
                int nyear,nmonth,nday;
                boolean switchDay = false;

       
                Calendar newDate = Calendar.getInstance();
                if (oldDate == null) {
                        oldDate = newDate;
                        switchDay = true;
                }

                oyear = oldDate.get(Calendar.YEAR);
                omonth = oldDate.get(Calendar.MONTH)+1;
                oday = oldDate.get(Calendar.DAY_OF_MONTH);
                nyear = newDate.get(Calendar.YEAR);
                nmonth = newDate.get(Calendar.MONTH)+1;
                nday = newDate.get(Calendar.DAY_OF_MONTH);
                if (nday!=oday)
                        switchDay = true;
	   

                if (!switchDay) return;

                String idsdir
                        = (String)UnixEnvironment.getInstance().get("IDSDIR");


                StringBuffer log_dir = new StringBuffer();

                if (idsdir != null)
                        log_dir.append(idsdir)
                                .append(java.io.File.separator);
                

                log_dir.append("log");

                java.io.File f = new java.io.File(log_dir.toString());
                if (f.isDirectory()) {
                        log_dir.append(java.io.File.separator)
                                .append("uilog.");
                        log_file_name=log_dir.toString();
                } else
                        log_file_name="uilog.";
                

                log_file_name+=nyear;
                if (nmonth < 10)
                        log_file_name+="0";
                log_file_name+=nmonth;
                if (nday < 10)
                        log_file_name+="0";
                log_file_name+=nday;

                textArea  = area;


                try {
                        if (log_writer!=null) {
                                log_writer.close();
                        }

                        java.io.FileOutputStream fos
                                = new java.io.FileOutputStream(log_file_name,true);
                        
                        java.io.PrintStream ps = new java.io.PrintStream(fos, true);
                        System.setOut(ps);
                        System.setErr(ps);

                        log_writer = new java.io.PrintWriter(new java.io.BufferedWriter(
                                new java.io.OutputStreamWriter(ps, "UTF-8"), 1024));
                        

                        
                } catch (Exception e) {
                        log_writer = new java.io.PrintWriter(System.err);
                        System.out.println("Error in initializing log");
                        e.printStackTrace();
                }

                
                
        }
  
  
        public  void log(int type, String s, Exception exception) {
                StringBuffer message = new StringBuffer();
    
                if (type == ERROR_MESSAGE)
                        message.append("ERROR");
                else if (type == WARNING_MESSAGE)
                        message.append("WARNING");
                else
                        message.append("LOG");
    
                message.append(" ").append(new java.util.Date().toString());
                message.append(" : \n\t").append(s);
	
	
                if (exception != null) {
                        String m = exception.getMessage();
                        if (m!=null)
                                message.append(":").append(m);
                }

                message.append("\n");
    
                try {
                        if (log_writer != null) {
                                log_writer.write(message.toString(),0,message.length());
                                //if (Constants.DEBUG && Constants.Verbose>1) {
                                        if (exception != null) {
                                                log_writer.write("=======Exception Stack Trace BEGIN======\n");
                                                log_writer.write(exception.getMessage()+"\n");
                                                exception.printStackTrace(log_writer);
                                                log_writer.write("=======Exception Stack Trace END======\n");
                                        }
                                //}
                                log_writer.flush();
                        }
                } catch (Exception e) {
      
                }
    
                if (textArea != null) {
                        synchronized (this) {
                                int length = textArea.getText().length();
                                if (length > 20480) { // 20480 = 256 * 80
                                        textArea.replaceRange(null, 0, 20480);
                                }
                                try {
                                        textArea.append(message.toString());
                                } catch (ArrayIndexOutOfBoundsException aioobe) { }

                                textArea.setCaretPosition(textArea.getText().length());
                        }

                }
    
        }
  
        public void debug_println(String message) {

                if (message==null) return;

                if (Constants.DEBUG && Constants.Verbose>0) {
                        try {
                                if (log_writer != null) {
                                        log_writer.write("=======DEBUG MESSAGE BEGIN======\n");
                                        log_writer.write(message+"\n",0,message.length()+1);
                                        log_writer.write("=======DEBUG MESSAGE END======\n");          
                                        log_writer.flush();
                                }
                        } catch (Exception e) {
     	 
                        }
                }

        }
        public void debug_printStackTrace(Exception e) {
	
	
	
                if (Constants.DEBUG && Constants.Verbose>2) {
                        try {
                                if (log_writer != null) {
                                        log_writer.write("=======DEBUG STACK TRACE START======\n");
                                        e.printStackTrace(log_writer);
                                        log_writer.write("=======DEBUG STACK TRACE END======\n");          
                                        log_writer.flush();
                                }
                        } catch (Exception e1) {
	    
                        }
                }
	
        }
    

        public void log_error(String s, Exception e) {
                log(ERROR_MESSAGE,s,e);
        }
  
        public void log_message(String s, Exception e) {
                log(-1,s,e);
        }
  
        public void log_warning(String s, Exception e) {
                log(WARNING_MESSAGE,s,e);
        }
  
  
        public void show_error(final java.awt.Component parent, final String title, 
                               final String s, final Exception e) {


                    /*if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                      Runnable callMe = new Runnable() {
                      public void run() {
                      show_error(parent,title,s,e);
                      }	
                      };		
                      javax.swing.SwingUtilities.invokeLater(callMe);

                      } else */{ 
                              StringBuffer b = new StringBuffer(title);
                              b.append(":").append(s);
    
                              log_error(b.toString(),e);
    
    
                              java.awt.Component p = parent;
                              if ((p==null) || (!p.isShowing()))
                                      p = MainScreenPanel.getSharedInstance().getRootComponent();

                              javax.swing.JOptionPane.showMessageDialog(p,s,title,ERROR_MESSAGE);
                      }
  
        }
  
        public void show_warning(final java.awt.Component parent, final String title, 
                                 final String s, final Exception e) {

                    /*if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                      Runnable callMe = new Runnable() {
                      public void run() {
                      show_warning(parent,title,s,e);
                      }	
                      };		
                      javax.swing.SwingUtilities.invokeLater(callMe);

                      } else*/ {
                              StringBuffer b = new StringBuffer(title);
                              b.append(":").append(s);
   
                              log_warning(b.toString(),e);
                              java.awt.Component p = parent;
                              if ((p==null) || (!p.isShowing()))
                                      p = MainScreenPanel.getSharedInstance().getRootComponent();

                              javax.swing.JOptionPane.showMessageDialog(p,s,title,WARNING_MESSAGE);
                      }
 
        }
  

        public void show_fatal(final java.awt.Component parent, final String title, 
                               final String s, final Exception e) {

                    /*if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                      Runnable callMe = new Runnable() {
                      public void run() {
                      show_fatal(parent,title,s,e);
                      }		
                      };			
                      javax.swing.SwingUtilities.invokeLater(callMe);

                      } else*/ {
                              StringBuffer b = new StringBuffer(title);
                              b.append(":").append(s).append("\n");
    
                              log(ERROR_MESSAGE,b.toString(),e);
                              java.awt.Component p = parent;
                              if ((p==null) || (!p.isShowing()))
                                      p = MainScreenPanel.getSharedInstance().getRootComponent();

                              javax.swing.JOptionPane.showMessageDialog(p,s,title,ERROR_MESSAGE);
                      }
                          //System.exit(1);
     
        }
  
        public int show_confirm(java.awt.Component parent, String title, String s) {
    
                java.awt.Component p = parent;
                if ((p==null) || (!p.isShowing()))
                        p = MainScreenPanel.getSharedInstance().getRootComponent();
   
                int i = javax.swing.JOptionPane.showConfirmDialog(p,s,title,
                                                                  javax.swing.JOptionPane.YES_NO_OPTION);
    
                if ( Constants.DEBUG && Constants.Verbose>3 ) {
                        StringBuffer b = new StringBuffer(title);
                        b.append(":").append(s).append(" "+i).append("\n");
    
                        log(ERROR_MESSAGE,b.toString(),null);
                }
    
                return i;
        }



	/*
	** Thread to switch I/O streams 
	*/
        private static Thread switchLogThread = new Thread(
                new Runnable() {
                int milliSecondSleepTime = 300000; // Every 5 minutes
                                
                public void run()  {
                        
                        while (true)
                        {
                                //Force date switch for I/O streams
                                
                                Log.getInstance();
                                
                                try  {
                                        Thread.sleep(milliSecondSleepTime);
                                }
                                catch (InterruptedException ie)
                                { //Ignore
                                }
                                
                        } // while true
                } // run 
        }); 

        
        static
        {
                try
                {
                        switchLogThread.setPriority(Thread.MIN_PRIORITY);
                        switchLogThread.start();
                }
                catch(Exception e)
                {
                            //Ignore but log
                        Log.getInstance().log_error("switchLogThread:Static Block failed",e);
                }
        } 





        
} /* End of class Log() */

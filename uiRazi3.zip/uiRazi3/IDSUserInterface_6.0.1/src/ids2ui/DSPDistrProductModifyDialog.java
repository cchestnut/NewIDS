/*
**  SCCS Info :  "@(#)DSPDistrProductModifyDialog.java	1.2    04/12/03"
*/
/*
 * DSPDistrProductModifyDialog.java
 *
 * Created on April 3, 2001, 3:40 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DSPDistrProductModifyDialog extends javax.swing.JDialog {

  private javax.swing.DefaultComboBoxModel formatComboModel;
  private javax.swing.DefaultComboBoxModel templateComboModel;

  private javax.swing.JList productList1, productList2;
  
  private String Action = null;
  private boolean okflag = false;
  
  
  /** Creates new form DSPDistrProductModifyDialog */
  public DSPDistrProductModifyDialog(java.awt.Frame parent,boolean modal,
			String distrid,String action,
			javax.swing.DefaultComboBoxModel fModel,
			String dps1[], 
                        String dps2[],
			DistrProductStructure defaults)
  {
    super (parent, modal);

    if (parent != null)
      setLocationRelativeTo(parent);
    


    if (fModel == null) {
		java.util.Vector formatList = ConfigComm.getProductFormatList();
		formatComboModel = new javax.swing.DefaultComboBoxModel(formatList);
	} else {
		formatComboModel = fModel;
	}


    TemplateListModel tModel = new TemplateListModel(this);
    templateComboModel = new javax.swing.DefaultComboBoxModel(tModel.toArray());
    for (int i = 0; i < templateComboModel.getSize(); i++) {
      Object o = templateComboModel.getElementAt(i);
      if (((String)o).equals(Constants.FILTER_CODES_NONE)) {
        templateComboModel.setSelectedItem(o);
        break;
      }
    }





    initComponents ();

    java.awt.CardLayout card = (java.awt.CardLayout) optionsPanel.getLayout();  
    if (action.equalsIgnoreCase("Modify")) {     
      if (distrid!=null)
        setTitle("Edit products: "+distrid);
      else
        setTitle("Edit products");
	  if (defaults!=null) {
		formatCheckBox.setSelected(true);
		formatComboBox.setSelectedItem(defaults.format);

		filterCodesCheckBox.setSelected(true);
		filterCodesComboBox.setSelectedItem(defaults.permTemplate);

		delayCheckBox.setSelected(true);
		delayTextField.setText(Integer.toString(defaults.delay));

		fwCheckBox.setSelected(true);
		freeWheelCheckBox.setSelected(defaults.freewheel);
		setState();
	  }

    } else {      
      if (distrid!=null)
        setTitle("Delete products: "+distrid);
      else
        setTitle("Delete products");
    }
    
    card.show(optionsPanel,action);
    Action = new String(action);
    
    
    javax.swing.JScrollPane scroller;

    if (dps1!=null) {
      int num_prods = dps1.length;          
      String[] plist = new String[num_prods];
      for (int i = 0; i < num_prods; i++)
        plist[i] = new String(dps1[i]);
      
      productList1 = new javax.swing.JList(plist);      
      scroller = new javax.swing.JScrollPane(productList1);
      prodPanel1.add(scroller);
      productList1.setSelectionInterval(0,num_prods-1);
    } else {     
      productList1=null;
      selectButton1.setEnabled(false);
      unselectButton1.setEnabled(false);
      prodPanel1.setEnabled(false);
    }
    


    if (dps2!=null) {
      int num_prods = dps2.length;
      String[] plist = new String[num_prods];
      for (int i = 0; i < num_prods; i++)
        plist[i] = new String(dps2[i]);
      
      productList2 = new javax.swing.JList(plist);      
      scroller = new javax.swing.JScrollPane(productList2);            
      prodPanel2.add(scroller);
      productList2.setSelectionInterval(0,num_prods-1);
    } else {   
      productList2=null;
      selectButton2.setEnabled(false);
      unselectButton2.setEnabled(false);
      prodPanel2.setEnabled(false);
    }


    pack ();




  }


  public boolean isOK() {
	return okflag;
  }

  public String[] getProducts(int dc){
	javax.swing.JList list = null;
	
	if (!okflag) return null;

	if (dc == 1) {
		if ( productList1==null) return null;
		list = productList1;
	} else if (dc == 2) {
		if ( productList2==null) return null;
		list = productList2;
	} else 
		return null;
        
	if (list.isSelectionEmpty())
          return null;
        
        Object sv[] = list.getSelectedValues();
        
        String[] products = new String[sv.length];
        for (int i = 0; i < sv.length; i++)
          products[i] = new String((String)sv[i]);
        
	return products;	
  }

  public Object getAttribute(String name) {
	
	if (!okflag || !Action.equalsIgnoreCase("Modify")) return null;

	if (name.equalsIgnoreCase("Format")) {
		if (!formatCheckBox.isSelected()) return null;
		return new String((String)formatComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("FilterCodes")) {
		if (!filterCodesCheckBox.isSelected()) return null;
		return new String((String)filterCodesComboBox.getSelectedItem());
	} else if (name.equalsIgnoreCase("Delay")) {
		if (!delayCheckBox.isSelected()) return null;
		return new Integer(delayTextField.getText());
	} else if (name.equalsIgnoreCase("FreeWheel")) {
		if (!fwCheckBox.isSelected()) return null;
		return new Boolean(freeWheelCheckBox.isSelected());
	} else
		return null;

  }


  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
  private void initComponents () {//GEN-BEGIN:initComponents
    jPanel2 = new javax.swing.JPanel ();
    jButton2 = new javax.swing.JButton ();
    jButton3 = new javax.swing.JButton ();
    productPanel = new javax.swing.JPanel ();
    prodPanel1 = new javax.swing.JPanel ();
    prodPanel2 = new javax.swing.JPanel ();
    jPanel3 = new javax.swing.JPanel ();
    selectButton1 = new javax.swing.JButton ();
    unselectButton1 = new javax.swing.JButton ();
    jPanel4 = new javax.swing.JPanel ();
    selectButton2 = new javax.swing.JButton ();
    unselectButton2 = new javax.swing.JButton ();
    optionsPanel = new javax.swing.JPanel ();
    jPanel1 = new javax.swing.JPanel ();
    formatComboBox = new javax.swing.JComboBox(formatComboModel);
    delayTextField = new ids2ui.IntTextField ();
    freeWheelCheckBox = new javax.swing.JCheckBox ();
    filterCodesComboBox = new javax.swing.JComboBox((javax.swing.ComboBoxModel)templateComboModel);
    formatCheckBox = new javax.swing.JCheckBox ();
    delayCheckBox = new javax.swing.JCheckBox ();
    fwCheckBox = new javax.swing.JCheckBox ();
    filterCodesCheckBox = new javax.swing.JCheckBox ();
    jPanel5 = new javax.swing.JPanel ();
    jLabel1 = new javax.swing.JLabel ();
    getContentPane ().setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints1;
    addWindowListener (new java.awt.event.WindowAdapter () {
      public void windowClosing (java.awt.event.WindowEvent evt) {
        closeDialog (evt);
      }
    }
    );

    jPanel2.setLayout (new java.awt.FlowLayout (1, 15, 5));

      jButton2.setText ("OK");
      jButton2.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          dialogActionHandler (evt);
        }
      }
      );
  
      jPanel2.add (jButton2);
  
      jButton3.setText ("Cancel");
      jButton3.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          dialogActionHandler (evt);
        }
      }
      );
  
      jPanel2.add (jButton3);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 2;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (jPanel2, gridBagConstraints1);

    productPanel.setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints2;
    productPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 10, 10)));

      prodPanel1.setLayout (new javax.swing.BoxLayout (prodPanel1, 0));
      prodPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 5, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("Data center-I: products"))));
  
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 0;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      gridBagConstraints2.weighty = 1.0;
      productPanel.add (prodPanel1, gridBagConstraints2);
  
      prodPanel2.setLayout (new javax.swing.BoxLayout (prodPanel2, 0));
      prodPanel2.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 5, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("Data center-II:products"))));
  
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 1;
      gridBagConstraints2.gridy = 0;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      gridBagConstraints2.weighty = 1.0;
      productPanel.add (prodPanel2, gridBagConstraints2);
  
      jPanel3.setLayout (new java.awt.FlowLayout (1, 10, 5));
  
        selectButton1.setMargin (new java.awt.Insets(2, 7, 2, 7));
        selectButton1.setText ("Select all");
        selectButton1.setActionCommand ("Select all 1");
        selectButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel3.add (selectButton1);
    
        unselectButton1.setMargin (new java.awt.Insets(2, 7, 2, 7));
        unselectButton1.setText ("Unselect all");
        unselectButton1.setActionCommand ("Unselect all 1");
        unselectButton1.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel3.add (unselectButton1);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      productPanel.add (jPanel3, gridBagConstraints2);
  
      jPanel4.setLayout (new java.awt.FlowLayout (1, 10, 5));
  
        selectButton2.setMargin (new java.awt.Insets(2, 7, 2, 7));
        selectButton2.setText ("Select all");
        selectButton2.setActionCommand ("Select all 2");
        selectButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel4.add (selectButton2);
    
        unselectButton2.setMargin (new java.awt.Insets(2, 7, 2, 7));
        unselectButton2.setText ("Unselect all");
        unselectButton2.setActionCommand ("Unselect all 2");
        unselectButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            selectActionHandler (evt);
          }
        }
        );
    
        jPanel4.add (unselectButton2);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 1;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 0.5;
      productPanel.add (jPanel4, gridBagConstraints2);
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
    gridBagConstraints1.weightx = 1.0;
    gridBagConstraints1.weighty = 1.0;
    getContentPane ().add (productPanel, gridBagConstraints1);

    optionsPanel.setLayout (new java.awt.CardLayout ());

      jPanel1.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints3;
      jPanel1.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 10, 10, 10)),
      new javax.swing.border.CompoundBorder(
      new javax.swing.border.TitledBorder("Select attributes to edit"),
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)))));
  
        formatComboBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (formatComboBox, gridBagConstraints3);
    
        delayTextField.setColumns (10);
        delayTextField.setText ("0");
        delayTextField.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (delayTextField, gridBagConstraints3);
    
        freeWheelCheckBox.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
        freeWheelCheckBox.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
        freeWheelCheckBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 3;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (freeWheelCheckBox, gridBagConstraints3);
    
        filterCodesComboBox.setEnabled (false);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 5, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (filterCodesComboBox, gridBagConstraints3);
    
        formatCheckBox.setText ("Format");
        formatCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 0, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (formatCheckBox, gridBagConstraints3);
    
        delayCheckBox.setText ("Delay (mins.)");
        delayCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.insets = new java.awt.Insets (0, 25, 10, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (delayCheckBox, gridBagConstraints3);
    
        fwCheckBox.setText ("Free Wheel");
        fwCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.insets = new java.awt.Insets (0, 25, 0, 0);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (fwCheckBox, gridBagConstraints3);
    
        filterCodesCheckBox.setText ("Filter codes");
        filterCodesCheckBox.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            cbActionHandler (evt);
          }
        }
        );
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add (filterCodesCheckBox, gridBagConstraints3);
    
      optionsPanel.add (jPanel1, "Modify");
  
      jPanel5.setLayout (new java.awt.FlowLayout (1, 5, 25));
  
        jLabel1.setText ("The selected products will be deleted.");
    
        jPanel5.add (jLabel1);
    
      optionsPanel.add (jPanel5, "Delete");
  

    gridBagConstraints1 = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 1;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gridBagConstraints1.weightx = 1.0;
    getContentPane ().add (optionsPanel, gridBagConstraints1);

  }//GEN-END:initComponents

private void selectActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectActionHandler
// Add your handling code here:
    javax.swing.JList list = productList1;
    String command = evt.getActionCommand();
    if (command.endsWith("2"))
      list = productList2;
    int num_prods = list.getModel().getSize();
    if (command.startsWith("Select"))
      list.setSelectionInterval(0,num_prods-1);
    else
      list.clearSelection();
    
  }//GEN-LAST:event_selectActionHandler

private void dialogActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dialogActionHandler
// Add your handling code here:
  if (evt.getActionCommand().equals("OK")) {
	okflag = true;
  }        
    closeDialog(null);
  }//GEN-LAST:event_dialogActionHandler

private void cbActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbActionHandler
// Add your handling code here:

	setState();

  }

private void setState() {
	
	
	if (formatCheckBox.isSelected())
		formatComboBox.setEnabled(true);
	else
		formatComboBox.setEnabled(false);
		
	if (filterCodesCheckBox.isSelected())
		filterCodesComboBox.setEnabled(true);
	else
		filterCodesComboBox.setEnabled(false);

	if (delayCheckBox.isSelected())
		delayTextField.setEnabled(true);
	else
		delayTextField.setEnabled(false);

	if (fwCheckBox.isSelected())
		freeWheelCheckBox.setEnabled(true);
	else
		freeWheelCheckBox.setEnabled(false);


  }//GEN-LAST:event_cbActionHandler

  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
    setVisible (false);
    dispose ();
  }//GEN-LAST:event_closeDialog



  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel productPanel;
  private javax.swing.JPanel prodPanel1;
  private javax.swing.JPanel prodPanel2;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JButton selectButton1;
  private javax.swing.JButton unselectButton1;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JButton selectButton2;
  private javax.swing.JButton unselectButton2;
  private javax.swing.JPanel optionsPanel;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JComboBox formatComboBox;
  private ids2ui.IntTextField delayTextField;
  private javax.swing.JCheckBox freeWheelCheckBox;
  private javax.swing.JComboBox filterCodesComboBox;
  private javax.swing.JCheckBox formatCheckBox;
  private javax.swing.JCheckBox delayCheckBox;
  private javax.swing.JCheckBox fwCheckBox;
  private javax.swing.JCheckBox filterCodesCheckBox;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JLabel jLabel1;
  // End of variables declaration//GEN-END:variables

}

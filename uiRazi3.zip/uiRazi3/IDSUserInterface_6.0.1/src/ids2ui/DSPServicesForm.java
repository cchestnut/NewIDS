/*
**  SCCS Info :  "@(#)DSPServicesForm.java	1.30    05/03/28"
*/
/*
 * DSPServicesForm.java
 *
 * Created on April 4, 2000, 2:47 PM
 */
 
package ids2ui;


import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;



/** 
 *
 * @author  srz
 * @version 
 */
public class DSPServicesForm 
    extends javax.swing.JFrame 
    implements TaskListener, javax.swing.event.ListSelectionListener {

        

    private javax.swing.JTable dataServicesTable;
    private DSPDataServicesStatusModel dataServicesModel;

    private javax.swing.JTable distrTable;
    private DSPDistributorStatusModel distrModel;

    private javax.swing.JTable systemServicesTable;
    private SystemServicesStatusModel systemServicesModel;

        private String dspHostList1 = null,dspPHostList1 = null;
        private String dspHostList2 = null,dspPHostList2 = null;
    private javax.swing.JRadioButton noneRB12=null;
    private javax.swing.JRadioButton noneRB22=null;


    private javax.swing.table.TableCellRenderer serviceCellRenderer = null;

    private DSPServicesForm myFrame;


    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();

    private volatile boolean isExiting = false;

        private final String[] vrtsStatusColumnNames = {
                "Cluster Node",
                "Veritas Status",
                "System Status" 
        };
        
        private javax.swing.table.DefaultTableModel  vrtsStatusModel1
        = new javax.swing.table.DefaultTableModel(vrtsStatusColumnNames,0) 
        {
                public boolean isCellEditable(int r, int c)
                        { return false; }
        };
        
                                
        
        private javax.swing.table.DefaultTableModel  vrtsStatusModel2
         = new javax.swing.table.DefaultTableModel(vrtsStatusColumnNames,0) 
        {
                public boolean isCellEditable(int r, int c)
                        { return false; }
        };


        private javax.swing.JTable vrtsStatusTable1 = new javax.swing.JTable(vrtsStatusModel1);
        private javax.swing.JTable vrtsStatusTable2 = new javax.swing.JTable(vrtsStatusModel2);

    /** Creates new form DSPServicesScreen */
    public DSPServicesForm() 
	throws Exception 
    {

	try {
		serviceCellRenderer = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultServiceCellColorMap);
	} catch (Exception e) {
		Log.getInstance().log_error("DSPServicesForm:Error in "
						+"creating cell renderer.",e);
	}

	myFrame=this;
        
	initComponents ();
	myInitComponents();

        

	setVRTSGuiState(Constants.DSP_USE_VERITAS_COMMANDS, 
				Constants.DSP_USE_VERITAS_COMMANDS);


        java.awt.event.ActionListener warnHandler =
                new ActionListener() 
                {
                        public void actionPerformed(ActionEvent ae)
                                {
                                        javax.swing.JCheckBox cb;

                                        Object o = ae.getSource();
                                        if (!(o instanceof javax.swing.JCheckBox))
                                                return;
                                        
                                        cb = (javax.swing.JCheckBox)o;

                                        if (!cb.isSelected())
                                        {
                                                Log.getInstance()
                                                        .show_warning(myFrame, "Warning",
                                                                      "Not using Veritas commands when Veritas is running can cause a cluster failover.", null);
                                        }
                                        
                                }
                        
                        
                };
        
        vrtsCheckBox11.addActionListener(warnHandler);
        vrtsCheckBox12.addActionListener(warnHandler);
        vrtsCheckBox21.addActionListener(warnHandler);
        vrtsCheckBox22.addActionListener(warnHandler);

        
        
	pack ();
        WindowEventAdapter.getInstance().registerWindow(Constants.SERVICES_DSP,this);

	updateTimer.start();


    }


        
	private void setVRTSGuiState(boolean use_vrts1, boolean use_vrts2)
	{
		vrtsCheckBox11.setSelected(use_vrts1);
		vrtsCheckBox12.setSelected(use_vrts1);
		vrtsCheckBox21.setSelected(use_vrts2);
		vrtsCheckBox22.setSelected(use_vrts2);

		vrtsCheckBox11.setVisible(use_vrts1);
		vrtsCheckBox12.setVisible(use_vrts1);
		vrtsCheckBox21.setVisible(use_vrts2);
		vrtsCheckBox22.setVisible(use_vrts2);

		int inx = jTabbedPane1.indexOfTab("Veritas services");
		if (!use_vrts1 && !use_vrts2) 
		{
			if (inx != -1)
				jTabbedPane1.remove(inx);	
		}
		else if (inx == -1)
		{
			jTabbedPane1.insertTab("Veritas services", null,
							jPanel6, null, 0);
		}

	}

    /*Interface ListSelectionListener */
    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;
	updateUIState(0);

        int srows[] = distrTable.getSelectedRows();

        idTextF.getDocument().removeDocumentListener( docListener);

        if (srows.length!=1)
                idTextF.setText("");
        else
                idTextF.setText((String)distrTable.getValueAt(srows[0],0));

        idTextF.getDocument().addDocumentListener( docListener);


    } /* End of valueChanged() */


   
    public void Refresh() {
	taskStarted(new java.util.EventObject(this));
	try {
	    rwLock.writeLock().acquire();
	} catch (Exception e){
		taskEnded();
		return;
	}
	try {
	    dataServicesModel.Refresh();
	    distrModel.Refresh();
	    systemServicesModel.Refresh();
	} catch (Exception e){
	    Log.getInstance().log_error("DSPServicesForm: Status update failed:",
					e);
	}
   	rwLock.writeLock().release();     
	taskEnded();
    }
    
    
    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }


    public void taskStarted() {
	taskStarted((String)null);
    }

    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 

	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}
      
    }
    
    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(java.util.EventObject evt) {
	taskEnded("Status updated @ "+new java.util.Date().toString());
    }
  


    public void taskEnded(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);
	    else
		statusPanel.clear();
            
            synchronized (this) {
                    String dsp11 = dataServicesModel.getDC1Host();
                    String dsp12 = dataServicesModel.getDC1PHost();
                    String dsp21 = dataServicesModel.getDC2Host();
                    String dsp22 = dataServicesModel.getDC2PHost();
                    
                    if (dsp11 != null)
                            dspHostList1 = dsp11;
                    if (dsp12 != null)
                            dspPHostList1 = dsp12;
                    if (dsp21 != null)
                            dspHostList2 = dsp21;
                    if (dsp22 != null)
                            dspPHostList2 = dsp22;
            }
            
	    updateUIState(0);
	    //repaint();
	}

    }

 
   
    public void updateUIState(int flags) {

	int numRows = systemServicesTable.getRowCount();
	boolean enable = false;

	if (modeLabel1.getText().equals("ERROR")
	    ||modeLabel2.getText().equals("ERROR"))
	    modeButton3.setEnabled(false);
	else
	    modeButton3.setEnabled(true);
    
    
	for (int i = 0; i < numRows; i++) {
	    String p = (String)systemServicesTable.getValueAt(i,0);
	    /* If the adminserver is not running , disable start/stop buttons */
	    if (p.startsWith("Admin")) {
		String r1 = (String)systemServicesTable.getValueAt(i,1);
		String r2 = (String)systemServicesTable.getValueAt(i,2);
		if ((r1!=null) && r1.startsWith("Running")) {
		    enable = true;
		} else {
		    enable = false;
		}
		startButton11.setEnabled(enable);
		stopButton11.setEnabled(enable);
	    
		startButton12.setEnabled(enable);
		stopButton12.setEnabled(enable);
		modeButton12.setEnabled(enable);
	    
	    
	    
		java.awt.Component[] components	= optionPanel12.getComponents();
		for (int c = 0; c < components.length; c++)		
		    components[c].setEnabled(enable);
		
	    
		if ((r2!=null) && r2.startsWith("Running")) {                      
		    enable = true;
		} else { 
		    enable = false;
		}
	    
		startButton21.setEnabled(enable);
		stopButton21.setEnabled(enable);
	    
		startButton22.setEnabled(enable);
		stopButton22.setEnabled(enable);
		modeButton22.setEnabled(enable);
	    

		components  = optionPanel22.getComponents();
		for (int c = 0; c < components.length; c++)
		    components[c].setEnabled(enable);
	    }
	}
	int srows[] = dataServicesTable.getSelectedRows();
	statusButton11.setEnabled(false);  
	statusButton21.setEnabled(false);
  
	if (srows.length==1) {
	    String name = (String)dataServicesTable.getValueAt(srows[0],0);	
	    String v1 = (String)dataServicesTable.getValueAt(srows[0],1);
	    String v2 = (String)dataServicesTable.getValueAt(srows[0],2);
	    if (v1.equals(Constants.NOT_CONFIGURED)) {
		statusButton11.setEnabled(false);
		startButton11.setEnabled(false);
		stopButton11.setEnabled(false);
	    } else if (v1.equals("Running") ) {
		if (name.startsWith("Reader"))
		    statusButton11.setEnabled(true);
		startButton11.setEnabled(false);
		stopButton11.setEnabled(true);
	    } else {
		stopButton11.setEnabled(false);
	    }
	    if (v2.equals(Constants.NOT_CONFIGURED)) {
		statusButton21.setEnabled(false);
		startButton21.setEnabled(false);
		stopButton21.setEnabled(false);
	    } else if (v2.equals("Running")) {
		if (name.startsWith("Reader"))
		    statusButton21.setEnabled(true);
		startButton21.setEnabled(false);
		stopButton21.setEnabled(true);
	    } else {
		stopButton21.setEnabled(false);
	    }
	} else {
	    int on1=0,off1=0;
	    int on2=0,off2=0;
	    for (int r = 0; r < srows.length; r++) {
		String v1 = (String)dataServicesTable.getValueAt(srows[r],1);
		String v2 = (String)dataServicesTable.getValueAt(srows[r],2);
		if ((v1!=null) 
		    && (v1.startsWith(Constants.RUNNING)
			|| v1.startsWith(Constants.NOT_CONFIGURED))) 
		    on1++;
		else
		    off1++;
		if ((v2!=null) 
		    && (v2.startsWith(Constants.RUNNING)
			|| v2.startsWith(Constants.NOT_CONFIGURED))) 
		    on2++;
		else
		    off2++;
	    }
    
	    if (on1==srows.length)
		startButton11.setEnabled(false);
	    if (off1==srows.length)
		stopButton11.setEnabled(false);
	    if (on2==srows.length)
		startButton21.setEnabled(false);
	    if (off2==srows.length)
		stopButton21.setEnabled(false);
      
	}
  
  
	statusButton12.setEnabled(false);
	statusButton22.setEnabled(false);
	//	modeButton12.setEnabled(false);
	//modeButton22.setEnabled(false);
	srows = distrTable.getSelectedRows();

	if (srows.length==1) {
	    String v1 = (String)distrTable.getValueAt(srows[0],2);
	    String v2 = (String)distrTable.getValueAt(srows[0],3);
	    jButton5.setEnabled(true);
	    if ((v1!=null) && 
		(v1.startsWith("Running")
		 || v1.startsWith("ACTIVE")
		 || v1.startsWith("DORMANT"))) {
		statusButton12.setEnabled(true);
		modeButton12.setEnabled(true);
		stopButton12.setEnabled(true);
		startButton12.setEnabled(false);
	    } else {          
		stopButton12.setEnabled(false);          
	    }
	    if ((v2!=null) && 
                (v2.startsWith("Running")
		 || v2.startsWith("ACTIVE")
		 || v2.startsWith("DORMANT"))) {
		statusButton22.setEnabled(true);
		modeButton22.setEnabled(true);
		stopButton22.setEnabled(true);
		startButton22.setEnabled(false);          
	    } else {          
		stopButton22.setEnabled(false);          
	    }
	} else {
	    
	    jButton5.setEnabled(false);

	    int on1=0,off1=0;
	    int on2=0,off2=0;
	    for (int r = 0; r < srows.length; r++) {
		String v1 = (String)distrTable.getValueAt(srows[r],2);
		String v2 = (String)distrTable.getValueAt(srows[r],3);
		if ((v1!=null) && 
		    (v1.startsWith("Running")
		     || v1.startsWith("ACTIVE")
		     || v1.startsWith("DORMANT")))
		    on1++;
		else
		    off1++;
		if ((v2!=null) && 
		    (v2.startsWith("Running")
		     || v2.startsWith("ACTIVE")
		     || v2.startsWith("DORMANT")))
		    on2++;
		else
		    off2++;
	    }
    
	    if (on1==srows.length) {
		startButton12.setEnabled(false);
		modeButton12.setEnabled(true);
	    }
	    if (off1==srows.length) {
		stopButton12.setEnabled(false);
		modeButton12.setEnabled(false);
	    }
	    if (on2==srows.length) {
		startButton22.setEnabled(false);
		modeButton22.setEnabled(true);
	    }
	    if (off2==srows.length) {
		stopButton22.setEnabled(false);
		modeButton22.setEnabled(false);
	    }
  
	}


    }



        private void updateVRTSButtons(DefaultTableModel model,
                                       int selected_row,
                                       JButton startButton,
                                       JButton stopButton,
                                       JButton switchButton,
                                       JButton clearButton)
        {

                int numRows = model.getRowCount();
                boolean canStart = false;
                boolean canStop = false;
                boolean canSwitch = false;
                boolean canClear = false;

                int online_row = -1;
                int offline_count = 0;
                int transition_count = 0;
                

                for (int i = 0; i < numRows; i++) {
                        String s = (String)model.getValueAt(i, 2);
                        if (Constants.findPattern(s,"ONLINE")
                            || Constants.findPattern(s, "PARTIAL") )
                                online_row = i;
                        
                        if (s.equals("OFFLINE"))
                                offline_count++;
                        
                        if (Constants.findPattern(s,"STARTING")
                            || Constants.findPattern(s,"STOPPING") )
                                transition_count++;
                        
                }


                if (selected_row >= 0) {
                        
                        String s = (String)model.getValueAt(selected_row, 2);

                        if (transition_count <= 0){
                                if (selected_row == online_row) {
                                        canStop = true;
                                        if (Constants.findPattern(s, "PARTIAL"))
                                                canStart = true;
                                }
                                
                                if (Constants.findPattern(s, "OFFLINE")) {
                                        if (online_row == -1)
                                                canStart = true;
                                        else
                                                canSwitch = true;
                                }
                        }
                
                        if (Constants.findPattern(s, "FAULTED"))
                                canClear = true;
                }
                
                if (canStart)
                        startButton.setEnabled(true);
                else
                        startButton.setEnabled(false);
                
                if (canStop)
                        stopButton.setEnabled(true);
                else
                        stopButton.setEnabled(false);
                
                if (canSwitch)
                        switchButton.setEnabled(true);
                else
                        switchButton.setEnabled(false);

                if (canClear)
                        clearButton.setEnabled(true);
                else
                        clearButton.setEnabled(false);
                
                
        }



        private void updateVRTSModel(javax.swing.table.DefaultTableModel vrtsModel, HashMap map)
        {
                vrtsModel.setNumRows(0);
                 //vrtsModel.setRowCount(0);

                
                if (map==null) return;
                
                java.util.Iterator iter = map.keySet().iterator();
                int row = 0;
                while (iter.hasNext()) {
                        String r[] = new String[vrtsModel.getColumnCount()];
                        
                        r[0] = (String)iter.next();
                        Object o = map.get(r[0]);
			if (! (o instanceof String))
				continue;
                        String v = (String)map.get(r[0]);
                        int inx = v.indexOf(":");
                        
                        if (inx<0) continue;
                        
                        r[1] = v.substring(0,inx);
                        r[2] = v.substring(inx+1);
                        
                        vrtsModel.addRow(r);
                }
        }






        
  
    void myInitComponents() {

	/*
	** Create JTable for displaying data services and assiciate a model with the table
	*/
	dataServicesModel
	    = new DSPDataServicesStatusModel(Constants.DSPServicesTable,
					  Constants.GLB_TAG_DSP);

      
	dataServicesTable = new javax.swing.JTable(dataServicesModel) {
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row, int column) {

		if ((serviceCellRenderer!=null)
			&& ((column==1)||(column==2)))
		    return serviceCellRenderer;
		else
		    return super.getCellRenderer(row,column);
	    }
	};

	/* Create listerner to popup status when double clicked in the reader status cell */

	dataServicesTable.addMouseListener( new java.awt.event.MouseAdapter() {
	    public void mouseClicked(java.awt.event.MouseEvent evt) {

		if (evt.getClickCount() != 2) 
		    return;

		int row = dataServicesTable.getSelectedRow();
		int col = dataServicesTable.getSelectedColumn();
		if (col==0) return;

		String name = (String)dataServicesTable.getValueAt(row,0);
		if (!name.startsWith("Reader")) 
		    return;

		String value = (String)dataServicesTable.getValueAt(row,col);
		if ((value!=null) && value.equals(Constants.RUNNING)) {
		    int stype = Constants.DSP_READER;
		    value = (String)dataServicesTable.getValueAt(row,0);
		    int inx = value.indexOf(":");
		    String progname = value.substring(0,inx-1);
		    name     = value.substring(inx+1);
		    String serverList = null;
		    if (col==1) serverList = dataServicesModel.getDC1Host();
		    if (col==2) serverList = dataServicesModel.getDC2Host();
		    if (serverList == null) {
			Log.getInstance().log_error("Could not get hosts "
						    +"for DSP:", null);
			return;
		    }
		
		    StatusHandler statushandler = StatusHandler.getInstance();
		    try{
                            statushandler.displayStatus(myFrame,stype,col, serverList,
						Constants.GLB_TAG_DSP,
                                                        name);
                    }
                    catch(Exception e){
                    }
                    
		      
		} 
	    }
	});



	dataServicesTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200,85));


	javax.swing.JScrollPane jScrollPane1 = new javax.swing.JScrollPane(dataServicesTable);
      
	dataServicesTablePanel.add(jScrollPane1,java.awt.BorderLayout.CENTER);
      
      
	/* Create listener to sort when clicked on column header */
	javax.swing.table.JTableHeader header 
	    = dataServicesTable.getTableHeader();

	header.addMouseListener(
				dataServicesModel.new ColumnListener(dataServicesTable,rwLock));
      
      
      


	/*
	** End creation of data services table
	*/



	/* 
	** Create a JTable for displaying distributors configured on this DCM
	*/
    
    
	distrModel = new DSPDistributorStatusModel();
      
      
	distrTable = new javax.swing.JTable(distrModel) {
	    public javax.swing.table.TableCellRenderer 
		getCellRenderer(int row, int column) {

		if ((serviceCellRenderer!=null)
			&& ((column==2)||(column==3)))
		    return serviceCellRenderer;
		else
		    return super.getCellRenderer(row,column);
	    }
	};
	



	distrTable.addMouseListener( new java.awt.event.MouseAdapter() {

	    public void mouseClicked(java.awt.event.MouseEvent evt) {
		if (evt.getClickCount() != 2) 
		    return; 

		int row = distrTable.getSelectedRow();
		int col = distrTable.getSelectedColumn();
		if (col<=1) return;

		String value = (String)distrTable.getValueAt(row,col);

		if ((value==null) || value.equals(Constants.NOT_RUNNING)) 
		    return;
	
		String name = (String)distrTable.getValueAt(row,0);
		int stype = Constants.DSP_BROADCASTER;
		String serverList = null;
		if (col==2) serverList = dataServicesModel.getDC1Host();
		if (col==3) serverList = dataServicesModel.getDC2Host();
		if (serverList == null) {
		    Log.getInstance().log_error("Could not get hosts for DSP:"
						    , null);
		    return;
		}

		
		StatusHandler statushandler = StatusHandler.getInstance();
		try {
                        statushandler.displayStatus(myFrame,stype,col-1, serverList,
                                                    Constants.GLB_TAG_DSP,name);
                }
                catch (Exception e){
                }
                
	    }
	});





	distrTable.setPreferredScrollableViewportSize(new java.awt.Dimension(300,100));
	javax.swing.JScrollPane jScrollPane = new javax.swing.JScrollPane(distrTable);

	outputServicesTablePanel.add(jScrollPane,java.awt.BorderLayout.CENTER);


	/* Add listener to sort table */
	header = distrTable.getTableHeader();
	header.addMouseListener(
				distrModel.new ColumnListener(distrTable,rwLock));
      
    
	/*
	** End creation of Distributor table
	*/



    
	/*
	** Create a JTable for displaying system services
	*/
	
	systemServicesModel
	    = new SystemServicesStatusModel(Constants.DSPServicesTable3,
					    Constants.GLB_TAG_DSP);



	systemServicesTable = new javax.swing.JTable(systemServicesModel) {
	    public javax.swing.table.TableCellRenderer
		getCellRenderer(int row, int column) {

		if ((serviceCellRenderer!=null)
			&& ((column==1)||(column==2)))
		    return serviceCellRenderer;
		else
		    return super.getCellRenderer(row,column);
	    }
	};

	systemServicesTable.setPreferredScrollableViewportSize(new java.awt.Dimension(200,85));

	javax.swing.JScrollPane jScrollPane3 = new javax.swing.JScrollPane(systemServicesTable);   
	adminServicesTablePanel.add(jScrollPane3,java.awt.BorderLayout.CENTER);
      
        
	header = systemServicesTable.getTableHeader();
	header.addMouseListener(
				systemServicesModel.new ColumnListener(systemServicesTable,rwLock));
      

	/*
	** End creation of system services table
	*/



	/*
	** Create a model for updating  Config Server modes
	*/
	Utils.CSStatusModel csModel = new Utils.CSStatusModel(
						      new Utils.CSStatusListener() {
	    public void statusUpdated(final Utils.CSStatusEvent evt) {

		if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
		    Runnable callMe = new Runnable() {
			public void run() {
			    statusUpdated(evt);
			}
		    };	
		    javax.swing.SwingUtilities.invokeLater(callMe);

		} else {
		    int mode1 = evt.getDC1Mode();
		    int mode2 = evt.getDC2Mode();

		    updateModeLabel(modeLabel1,mode1);
		    updateModeLabel(modeLabel2,mode2);
		}
	    }

	});

        
        final javax.swing.JTable t1 = vrtsStatusTable1;
        final javax.swing.JTable t2 = vrtsStatusTable2;
        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(t1);        
        vrtsPanel1.add(scrollPane);
        scrollPane = new javax.swing.JScrollPane(t2);   
        vrtsPanel2.add(scrollPane);

        t1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        t2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        ListSelectionListener l = new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) 
                {
                        
                        if (e.getValueIsAdjusting()) return;

                        Object src = e.getSource();
                        ListSelectionModel m = null;
                        if (src instanceof ListSelectionModel)
                                m = (ListSelectionModel)src;


                        if (vrtsStatusTable1.getSelectionModel()==m)  {
				int srows[] = vrtsStatusTable1.getSelectedRows();
				int srow = -1;
				if (srows.length>0)
					srow = srows[0];
                                updateVRTSButtons(vrtsStatusModel1,
                                                  srow,
                                                  jButton6,jButton8,jButton9, jButton14);
			}
                        
                        

                        if (vrtsStatusTable2.getSelectionModel()==m) {
				int srows[] = vrtsStatusTable2.getSelectedRows();
				int srow = -1;
				if (srows.length>0)
					srow = srows[0];
                                updateVRTSButtons(vrtsStatusModel2,
                                                  srow,
                                                  jButton10,jButton11,jButton12, jButton17);
			}
                       
                        
                        
                        
                }
        };
        
        
        
        t1.getSelectionModel().addListSelectionListener( l );
        t2.getSelectionModel().addListSelectionListener( l );
        

        t1.addMouseListener( new java.awt.event.MouseAdapter() {
                public void mousePressed(MouseEvent e)
                {
                        handlePopup(e);
                }
                public void mouseReleased(MouseEvent e) 
                {
                        handlePopup(e);
                }
                private void handlePopup(MouseEvent e) 
                {
                        if (e.isPopupTrigger()) {
                                vrtsMenu(t1,1,e);
                        }
                }
                
	});
        t2.addMouseListener( new java.awt.event.MouseAdapter() {
                public void mousePressed(MouseEvent e)
                {
                        handlePopup(e);
                }
                public void mouseReleased(MouseEvent e) 
                {
                        handlePopup(e);
                }
                private void handlePopup(MouseEvent e) 
                {
                        if (e.isPopupTrigger()) {
                                vrtsMenu(t2,2,e);
                        }
                }
                
	});

         
        updateVRTSButtons(vrtsStatusModel1,
                          -1,
                          jButton6,jButton8,jButton9, jButton14);
                        
                        

        updateVRTSButtons(vrtsStatusModel2,
                          -1,
                          jButton10,jButton11,jButton12, jButton17);

        
	/*
	** Create a model for updating  Veritas status
	*/
	Utils.VRTSStatusModel vrtsModel = new Utils.VRTSStatusModel(
						      new Utils.VRTSStatusListener() {
	    public void statusUpdated(final Utils.VRTSStatusEvent evt) {

		if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
		    Runnable callMe = new Runnable() {
			public void run() {
			    statusUpdated(evt);
			}
		    };	
		    javax.swing.SwingUtilities.invokeLater(callMe);

		} else {

                        
		    HashMap stat1 = evt.getDC1VRTSStatus();
		    HashMap stat2 = evt.getDC2VRTSStatus();

                    updateVRTSModel(vrtsStatusModel1, stat1);

                    updateVRTSModel(vrtsStatusModel2, stat2);

		    
                    boolean b1 = ((Boolean)stat1.get("DSP_USE_VERITAS_COMMANDS")).booleanValue();
                    boolean b2 = ((Boolean)stat2.get("DSP_USE_VERITAS_COMMANDS")).booleanValue();

		    setVRTSGuiState(b1, b2);

                    location1TextField.setText(dataServicesModel.getDC1Location());
                    location2TextField.setText(dataServicesModel.getDC2Location());
                    host1TextField.setText(dataServicesModel.getDC1PHost());
                    host2TextField.setText(dataServicesModel.getDC2PHost());
                    
                    
		}
	    }

	});
	

	/*
	** Create a timer for updating models periodically
	*/
        
	Utils.UpdateModel m1[] = new Utils.UpdateModel[3];

	m1[0] = dataServicesModel;
	m1[1] = systemServicesModel;
	m1[2] = distrModel;
        
        Utils.UpdateModel m2[] = new Utils.UpdateModel[2];
	m2[0] = csModel;
	m2[1] = vrtsModel;

	Utils.UpdateListenerList2 updater = new Utils.UpdateListenerList2(rwLock, this, m1, m2);



        
	updateTimer = new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs,
					    updater);


        

	idTextF.getDocument().addDocumentListener( docListener );   
    	
    
    
	javax.swing.ButtonGroup group;

	noneRB12 = new javax.swing.JRadioButton();
	noneRB22 = new javax.swing.JRadioButton();
    
	group = new javax.swing.ButtonGroup();
	group.add(activeRB12);
	group.add(dormantRB12);
	group.add(noneRB12);
	group = new javax.swing.ButtonGroup();
	group.add(activeRB22);
	group.add(dormantRB22);
	group.add(noneRB22);
	noneRB12.setSelected(true);
	noneRB22.setSelected(true);
    
	dataServicesTable.setRowSelectionAllowed(true);
	dataServicesTable.setColumnSelectionAllowed(false);
	//statusButton11.setEnabled(false);
        //statusButton12.setEnabled(false);
	//statusButton21.setEnabled(false);
        //statusButton22.setEnabled(false);

	dataServicesTable.getSelectionModel().addListSelectionListener(this);
        distrTable.getSelectionModel().addListSelectionListener(this);
        systemServicesTable.getSelectionModel().addListSelectionListener(this);

	jPanel14.setBorder (new javax.swing.border.TitledBorder(Constants.DC1_CLUSTER_LABEL));
        jPanel20.setBorder (new javax.swing.border.TitledBorder(Constants.DC2_CLUSTER_LABEL));
        jPanel4.setBorder (new javax.swing.border.TitledBorder(Constants.DC1_CLUSTER_LABEL));
        jPanel9.setBorder (new javax.swing.border.TitledBorder(Constants.DC2_CLUSTER_LABEL));
    }


   javax.swing.event.DocumentListener docListener =  
        new javax.swing.event.DocumentListener() {
      
	    public void changedUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
	    public void insertUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
	    public void removeUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
      
	    private  void processEvent(){        
		String id1 = idTextF.getText();
		int l1 = id1.length();

		distrTable.getSelectionModel().removeListSelectionListener(myFrame);

		for (int i = 0; i < distrTable.getRowCount(); i++) {
		    String id2
			= distrTable.getValueAt(i,0).toString();
		    int l2 = id2.length();	  
		    if (l1<=l2 && l1>0  && (id2.substring(0,l1).equals(id1)))             
			distrTable.addRowSelectionInterval(i,i);
		    else
			distrTable.removeRowSelectionInterval(i,i);
		}
		if (!distrTable.getSelectionModel().isSelectionEmpty()) {
		    int row = distrTable.getSelectionModel().getMinSelectionIndex();
		    java.awt.Rectangle rowRect = distrTable.getCellRect(row, 0, true);
		    if (rowRect!=null) {
			rowRect.setSize( Integer.MAX_VALUE, (int)rowRect.getHeight());
			distrTable.scrollRectToVisible(rowRect);
		    }
		}

		distrTable.getSelectionModel().addListSelectionListener(myFrame);

	    }

    	};   



    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel2 = new javax.swing.JPanel ();
          jButton16 = new javax.swing.JButton ();
          jButton13 = new javax.swing.JButton ();
          jButton7 = new javax.swing.JButton ();
          statusPanel = new ids2ui.StatusPanel ();
          jTabbedPane1 = new javax.swing.JTabbedPane ();
          jPanel6 = new javax.swing.JPanel ();
          vrtsPanel2 = new javax.swing.JPanel ();
          vrtsPanel1 = new javax.swing.JPanel ();
          jPanel7 = new javax.swing.JPanel ();
          jPanel27 = new javax.swing.JPanel ();
          jButton10 = new javax.swing.JButton ();
          jButton11 = new javax.swing.JButton ();
          jButton12 = new javax.swing.JButton ();
          jPanel28 = new javax.swing.JPanel ();
          jButton17 = new javax.swing.JButton ();
          jButton18 = new javax.swing.JButton ();
          jPanel18 = new javax.swing.JPanel ();
          jPanel21 = new javax.swing.JPanel ();
          jButton6 = new javax.swing.JButton ();
          jButton8 = new javax.swing.JButton ();
          jButton9 = new javax.swing.JButton ();
          jPanel25 = new javax.swing.JPanel ();
          jButton14 = new javax.swing.JButton ();
          jButton15 = new javax.swing.JButton ();
          jPanel13 = new javax.swing.JPanel ();
          jPanel14 = new javax.swing.JPanel ();
          jPanel16 = new javax.swing.JPanel ();
          startButton11 = new javax.swing.JButton ();
          stopButton11 = new javax.swing.JButton ();
          statusButton11 = new javax.swing.JButton ();
          jPanel33 = new javax.swing.JPanel ();
          vrtsCheckBox11 = new javax.swing.JCheckBox ();
          dataServicesTablePanel = new javax.swing.JPanel ();
          jPanel1 = new javax.swing.JPanel ();
          jButton3 = new javax.swing.JButton ();
          jPanel20 = new javax.swing.JPanel ();
          jPanel23 = new javax.swing.JPanel ();
          startButton21 = new javax.swing.JButton ();
          stopButton21 = new javax.swing.JButton ();
          statusButton21 = new javax.swing.JButton ();
          jPanel34 = new javax.swing.JPanel ();
          vrtsCheckBox21 = new javax.swing.JCheckBox ();
          jPanel10 = new javax.swing.JPanel ();
          outputServicesTablePanel = new javax.swing.JPanel ();
          jPanel11 = new javax.swing.JPanel ();
          jPanel12 = new javax.swing.JPanel ();
          jLabel1 = new javax.swing.JLabel ();
          idTextF = new ids2ui.UCTextField ();
          jPanel8 = new javax.swing.JPanel ();
          jButton4 = new javax.swing.JButton ();
          jPanel4 = new javax.swing.JPanel ();
          optionPanel12 = new javax.swing.JPanel ();
          activeRB12 = new javax.swing.JRadioButton ();
          dormantRB12 = new javax.swing.JRadioButton ();
          jLabel3 = new javax.swing.JLabel ();
          jPanel15 = new javax.swing.JPanel ();
          startButton12 = new javax.swing.JButton ();
          stopButton12 = new javax.swing.JButton ();
          modeButton12 = new javax.swing.JButton ();
          statusButton12 = new javax.swing.JButton ();
          jPanel35 = new javax.swing.JPanel ();
          vrtsCheckBox12 = new javax.swing.JCheckBox ();
          jPanel9 = new javax.swing.JPanel ();
          optionPanel22 = new javax.swing.JPanel ();
          activeRB22 = new javax.swing.JRadioButton ();
          dormantRB22 = new javax.swing.JRadioButton ();
          jLabel5 = new javax.swing.JLabel ();
          jPanel19 = new javax.swing.JPanel ();
          startButton22 = new javax.swing.JButton ();
          stopButton22 = new javax.swing.JButton ();
          modeButton22 = new javax.swing.JButton ();
          statusButton22 = new javax.swing.JButton ();
          jPanel36 = new javax.swing.JPanel ();
          vrtsCheckBox22 = new javax.swing.JCheckBox ();
          jPanel5 = new javax.swing.JPanel ();
          jButton5 = new javax.swing.JButton ();
          jPanel3 = new javax.swing.JPanel ();
          jPanel22 = new javax.swing.JPanel ();
          jPanel24 = new javax.swing.JPanel ();
          jPanel17 = new javax.swing.JPanel ();
          jPanel26 = new javax.swing.JPanel ();
          jLabel2 = new javax.swing.JLabel ();
          modeLabel1 = new javax.swing.JLabel ();
          jLabel4 = new javax.swing.JLabel ();
          modeLabel2 = new javax.swing.JLabel ();
          jPanel30 = new javax.swing.JPanel ();
          modeButton3 = new javax.swing.JButton ();
          adminServicesTablePanel = new javax.swing.JPanel ();
          jPanel29 = new javax.swing.JPanel ();
          jPanel31 = new javax.swing.JPanel ();
          host1TextField = new javax.swing.JTextField ();
          location1TextField = new javax.swing.JTextField ();
          jPanel32 = new javax.swing.JPanel ();
          location2TextField = new javax.swing.JTextField ();
          host2TextField = new javax.swing.JTextField ();
          getContentPane ().setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;
          setTitle ("DSP Services Screen");
          addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
              exitForm (evt);
            }
          }
          );

          jPanel2.setLayout (new java.awt.FlowLayout (1, 25, 5));

            jButton16.setText ("DSP configuration");
            jButton16.setActionCommand (Constants.CONFIGURATION_DSP);
            jButton16.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                screenActionHandler (evt);
              }
            }
            );
  
            jPanel2.add (jButton16);
  
            jButton13.setText ("Output configuration menu");
            jButton13.setActionCommand (Constants.CONFIGURATION_DSP_DISTRIBUTORS);
            jButton13.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                screenActionHandler (evt);
              }
            }
            );
  
            jPanel2.add (jButton13);
  
            jButton7.setText ("Close");
            jButton7.addActionListener (new java.awt.event.ActionListener () {
              public void actionPerformed (java.awt.event.ActionEvent evt) {
                screenActionHandler (evt);
              }
            }
            );
  
            jPanel2.add (jButton7);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (jPanel2, gridBagConstraints1);

          statusPanel.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));


          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 3;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (statusPanel, gridBagConstraints1);

          jTabbedPane1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));

            jPanel6.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints2;
  
              vrtsPanel2.setLayout (new javax.swing.BoxLayout (vrtsPanel2, 0));
              vrtsPanel2.setBorder (new javax.swing.border.TitledBorder("Veritas Status"));
    
              gridBagConstraints2 = new java.awt.GridBagConstraints ();
              gridBagConstraints2.gridx = 1;
              gridBagConstraints2.gridy = 0;
              gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints2.weightx = 0.5;
              gridBagConstraints2.weighty = 0.6;
              jPanel6.add (vrtsPanel2, gridBagConstraints2);
    
              vrtsPanel1.setLayout (new javax.swing.BoxLayout (vrtsPanel1, 0));
              vrtsPanel1.setBorder (new javax.swing.border.TitledBorder("Veritas Status"));
    
              gridBagConstraints2 = new java.awt.GridBagConstraints ();
              gridBagConstraints2.gridx = 0;
              gridBagConstraints2.gridy = 0;
              gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints2.weightx = 0.5;
              gridBagConstraints2.weighty = 0.6;
              jPanel6.add (vrtsPanel1, gridBagConstraints2);
    
              jPanel7.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints3;
              jPanel7.setBorder (new javax.swing.border.TitledBorder(""));
    
      
                  jButton10.setText ("START");
                  jButton10.setForeground (new java.awt.Color (0, 153, 51));
                  jButton10.setActionCommand ("START 2");
                  jButton10.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel27.add (jButton10);
        
                  jButton11.setText ("STOP");
                  jButton11.setForeground (java.awt.Color.red);
                  jButton11.setActionCommand ("STOP 2");
                  jButton11.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel27.add (jButton11);
        
                  jButton12.setText ("SWITCH");
                  jButton12.setForeground (java.awt.Color.red);
                  jButton12.setActionCommand ("SWITCH 2");
                  jButton12.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel27.add (jButton12);
        
                gridBagConstraints3 = new java.awt.GridBagConstraints ();
                gridBagConstraints3.insets = new java.awt.Insets (2, 2, 5, 5);
                jPanel7.add (jPanel27, gridBagConstraints3);
      
      
                  jButton17.setText ("CLEAR FAULT");
                  jButton17.setForeground (java.awt.Color.blue);
                  jButton17.setActionCommand ("CLEAR_FAULT 2");
                  jButton17.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel28.add (jButton17);
        
                  jButton18.setText ("STATUS");
                  jButton18.setForeground (java.awt.Color.blue);
                  jButton18.setActionCommand ("STATUS 2");
                  jButton18.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel28.add (jButton18);
        
                gridBagConstraints3 = new java.awt.GridBagConstraints ();
                gridBagConstraints3.gridx = 0;
                gridBagConstraints3.gridy = 1;
                gridBagConstraints3.insets = new java.awt.Insets (0, 2, 2, 2);
                jPanel7.add (jPanel28, gridBagConstraints3);
      
              gridBagConstraints2 = new java.awt.GridBagConstraints ();
              gridBagConstraints2.gridx = 1;
              gridBagConstraints2.gridy = 1;
              gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints2.insets = new java.awt.Insets (0, 5, 5, 5);
              gridBagConstraints2.weightx = 0.5;
              gridBagConstraints2.weighty = 0.4;
              jPanel6.add (jPanel7, gridBagConstraints2);
    
              jPanel18.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints4;
              jPanel18.setBorder (new javax.swing.border.TitledBorder(""));
              jPanel18.setForeground (java.awt.Color.red);
    
                jPanel21.setLayout (new java.awt.FlowLayout (1, 10, 5));
      
                  jButton6.setText ("START");
                  jButton6.setForeground (new java.awt.Color (0, 153, 51));
                  jButton6.setActionCommand ("START 1");
                  jButton6.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel21.add (jButton6);
        
                  jButton8.setText ("STOP");
                  jButton8.setForeground (java.awt.Color.red);
                  jButton8.setActionCommand ("STOP 1");
                  jButton8.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel21.add (jButton8);
        
                  jButton9.setText ("SWITCH");
                  jButton9.setForeground (java.awt.Color.red);
                  jButton9.setActionCommand ("SWITCH 1");
                  jButton9.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel21.add (jButton9);
        
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.insets = new java.awt.Insets (2, 2, 5, 2);
                jPanel18.add (jPanel21, gridBagConstraints4);
      
                jPanel25.setLayout (new java.awt.FlowLayout (1, 10, 5));
      
                  jButton14.setText ("CLEAR FAULT");
                  jButton14.setForeground (java.awt.Color.blue);
                  jButton14.setActionCommand ("CLEAR_FAULT 1");
                  jButton14.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel25.add (jButton14);
        
                  jButton15.setText ("STATUS");
                  jButton15.setForeground (java.awt.Color.blue);
                  jButton15.setActionCommand ("STATUS 1");
                  jButton15.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      vrtsHandler (evt);
                    }
                  }
                  );
        
                  jPanel25.add (jButton15);
        
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 0;
                gridBagConstraints4.gridy = 1;
                gridBagConstraints4.insets = new java.awt.Insets (0, 2, 2, 2);
                jPanel18.add (jPanel25, gridBagConstraints4);
      
              gridBagConstraints2 = new java.awt.GridBagConstraints ();
              gridBagConstraints2.gridx = 0;
              gridBagConstraints2.gridy = 1;
              gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints2.insets = new java.awt.Insets (0, 5, 5, 5);
              gridBagConstraints2.weightx = 0.5;
              gridBagConstraints2.weighty = 0.4;
              jPanel6.add (jPanel18, gridBagConstraints2);
    
            jTabbedPane1.addTab ("Veritas services", jPanel6);
  
            jPanel13.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints5;
  
              jPanel14.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints6;
              jPanel14.setBorder (new javax.swing.border.TitledBorder("Data center - I"));
    
                jPanel16.setLayout (new java.awt.FlowLayout (1, 15, 5));
      
                  startButton11.setText ("Start");
                  startButton11.setActionCommand ("Start 11");
                  startButton11.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  jPanel16.add (startButton11);
        
                  stopButton11.setText ("Stop");
                  stopButton11.setActionCommand ("Stop 11");
                  stopButton11.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  jPanel16.add (stopButton11);
        
                  statusButton11.setText ("Status");
                  statusButton11.setActionCommand ("Status 11");
                  statusButton11.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspStatusHandler (evt);
                    }
                  }
                  );
        
                  jPanel16.add (statusButton11);
        
                gridBagConstraints6 = new java.awt.GridBagConstraints ();
                gridBagConstraints6.gridx = 0;
                gridBagConstraints6.gridy = 1;
                gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints6.weightx = 1.0;
                jPanel14.add (jPanel16, gridBagConstraints6);
      
      
                  vrtsCheckBox11.setSelected (true);
                  vrtsCheckBox11.setText ("Use Veritas Commands");
        
                  jPanel33.add (vrtsCheckBox11);
        
                gridBagConstraints6 = new java.awt.GridBagConstraints ();
                gridBagConstraints6.insets = new java.awt.Insets (0, 0, 5, 0);
                jPanel14.add (jPanel33, gridBagConstraints6);
      
              gridBagConstraints5 = new java.awt.GridBagConstraints ();
              gridBagConstraints5.gridx = 0;
              gridBagConstraints5.gridy = 1;
              gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints5.weightx = 0.5;
              jPanel13.add (jPanel14, gridBagConstraints5);
    
              dataServicesTablePanel.setLayout (new java.awt.BorderLayout ());
              dataServicesTablePanel.setBorder (new javax.swing.border.TitledBorder(""));
    
                jPanel1.setLayout (new java.awt.FlowLayout (1, 25, 5));
      
                  jButton3.setText ("Select all");
                  jButton3.setActionCommand ("All Services");
                  jButton3.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      selectServicesHandler (evt);
                    }
                  }
                  );
        
                  jPanel1.add (jButton3);
        
                dataServicesTablePanel.add (jPanel1, java.awt.BorderLayout.SOUTH);
      
              gridBagConstraints5 = new java.awt.GridBagConstraints ();
              gridBagConstraints5.gridwidth = 2;
              gridBagConstraints5.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints5.weightx = 1.0;
              gridBagConstraints5.weighty = 1.0;
              jPanel13.add (dataServicesTablePanel, gridBagConstraints5);
    
              jPanel20.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints7;
              jPanel20.setBorder (new javax.swing.border.TitledBorder(
              new javax.swing.border.EtchedBorder(), "Data center - II"));
    
                jPanel23.setLayout (new java.awt.FlowLayout (1, 15, 5));
      
                  startButton21.setText ("Start");
                  startButton21.setActionCommand ("Start 21");
                  startButton21.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  jPanel23.add (startButton21);
        
                  stopButton21.setText ("Stop");
                  stopButton21.setActionCommand ("Stop 21");
                  stopButton21.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  jPanel23.add (stopButton21);
        
                  statusButton21.setText ("Status");
                  statusButton21.setActionCommand ("Status 21");
                  statusButton21.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspStatusHandler (evt);
                    }
                  }
                  );
        
                  jPanel23.add (statusButton21);
        
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.gridx = 0;
                gridBagConstraints7.gridy = 1;
                gridBagConstraints7.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints7.weightx = 1.0;
                jPanel20.add (jPanel23, gridBagConstraints7);
      
      
                  vrtsCheckBox21.setSelected (true);
                  vrtsCheckBox21.setText ("Use Veritas Commands");
        
                  jPanel34.add (vrtsCheckBox21);
        
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.insets = new java.awt.Insets (0, 0, 5, 0);
                jPanel20.add (jPanel34, gridBagConstraints7);
      
              gridBagConstraints5 = new java.awt.GridBagConstraints ();
              gridBagConstraints5.gridx = 1;
              gridBagConstraints5.gridy = 1;
              gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints5.weightx = 0.5;
              jPanel13.add (jPanel20, gridBagConstraints5);
    
            jTabbedPane1.addTab ("Data services", jPanel13);
  
            jPanel10.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints8;
  
              outputServicesTablePanel.setLayout (new java.awt.BorderLayout ());
              outputServicesTablePanel.setBorder (new javax.swing.border.TitledBorder(""));
    
                jPanel11.setLayout (new java.awt.BorderLayout ());
      
        
                    jLabel1.setText ("ID");
          
                    jPanel12.add (jLabel1);
          
                    idTextF.setColumns (5);
          
                    jPanel12.add (idTextF);
          
                  jPanel11.add (jPanel12, java.awt.BorderLayout.WEST);
        
        
                    jButton4.setMargin (new java.awt.Insets(1, 4, 1, 4));
                    jButton4.setText ("Select all");
                    jButton4.setActionCommand ("DISTRIBUTORS");
                    jButton4.addActionListener (new java.awt.event.ActionListener () {
                      public void actionPerformed (java.awt.event.ActionEvent evt) {
                        selectAll (evt);
                      }
                    }
                    );
          
                    jPanel8.add (jButton4);
          
                  jPanel11.add (jPanel8, java.awt.BorderLayout.EAST);
        
                outputServicesTablePanel.add (jPanel11, java.awt.BorderLayout.SOUTH);
      
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.gridwidth = 2;
              gridBagConstraints8.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints8.weightx = 1.0;
              gridBagConstraints8.weighty = 1.0;
              jPanel10.add (outputServicesTablePanel, gridBagConstraints8);
    
              jPanel4.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints9;
              jPanel4.setBorder (new javax.swing.border.TitledBorder("Data center - I"));
    
                optionPanel12.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints10;
      
                  activeRB12.setText ("Active");
        
                  gridBagConstraints10 = new java.awt.GridBagConstraints ();
                  gridBagConstraints10.gridx = 1;
                  gridBagConstraints10.gridy = 0;
                  gridBagConstraints10.insets = new java.awt.Insets (0, 0, 0, 5);
                  optionPanel12.add (activeRB12, gridBagConstraints10);
        
                  dormantRB12.setText ("Dormant");
        
                  gridBagConstraints10 = new java.awt.GridBagConstraints ();
                  gridBagConstraints10.gridx = 2;
                  gridBagConstraints10.gridy = 0;
                  gridBagConstraints10.insets = new java.awt.Insets (0, 5, 0, 0);
                  optionPanel12.add (dormantRB12, gridBagConstraints10);
        
                  jLabel3.setText ("Mode");
        
                  gridBagConstraints10 = new java.awt.GridBagConstraints ();
                  gridBagConstraints10.gridx = 0;
                  gridBagConstraints10.gridy = 0;
                  gridBagConstraints10.insets = new java.awt.Insets (0, 0, 0, 10);
                  optionPanel12.add (jLabel3, gridBagConstraints10);
        
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 0;
                gridBagConstraints9.gridy = 0;
                gridBagConstraints9.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints9.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints9.weightx = 0.6;
                jPanel4.add (optionPanel12, gridBagConstraints9);
      
                jPanel15.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints11;
      
                  startButton12.setText ("Start");
                  startButton12.setActionCommand ("Start 12");
                  startButton12.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints11 = new java.awt.GridBagConstraints ();
                  gridBagConstraints11.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel15.add (startButton12, gridBagConstraints11);
        
                  stopButton12.setText ("Stop");
                  stopButton12.setActionCommand ("Stop 12");
                  stopButton12.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints11 = new java.awt.GridBagConstraints ();
                  gridBagConstraints11.gridx = 1;
                  gridBagConstraints11.gridy = 0;
                  gridBagConstraints11.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel15.add (stopButton12, gridBagConstraints11);
        
                  modeButton12.setText ("Set Mode");
                  modeButton12.setActionCommand ("Mode 12");
                  modeButton12.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspModeHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints11 = new java.awt.GridBagConstraints ();
                  gridBagConstraints11.gridx = 2;
                  gridBagConstraints11.gridy = 0;
                  gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel15.add (modeButton12, gridBagConstraints11);
        
                  statusButton12.setText ("Status");
                  statusButton12.setActionCommand ("Status 12");
                  statusButton12.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspStatusHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints11 = new java.awt.GridBagConstraints ();
                  gridBagConstraints11.gridx = 3;
                  gridBagConstraints11.gridy = 0;
                  gridBagConstraints11.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel15.add (statusButton12, gridBagConstraints11);
        
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.gridx = 0;
                gridBagConstraints9.gridy = 1;
                gridBagConstraints9.gridwidth = 2;
                gridBagConstraints9.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints9.weightx = 1.0;
                gridBagConstraints9.weighty = 0.5;
                jPanel4.add (jPanel15, gridBagConstraints9);
      
      
                  vrtsCheckBox12.setSelected (true);
                  vrtsCheckBox12.setText ("Use Veritas Commands");
        
                  jPanel35.add (vrtsCheckBox12);
        
                gridBagConstraints9 = new java.awt.GridBagConstraints ();
                gridBagConstraints9.insets = new java.awt.Insets (0, 5, 5, 0);
                jPanel4.add (jPanel35, gridBagConstraints9);
      
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.gridx = 0;
              gridBagConstraints8.gridy = 2;
              gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints8.weightx = 0.5;
              jPanel10.add (jPanel4, gridBagConstraints8);
    
              jPanel9.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints12;
              jPanel9.setBorder (new javax.swing.border.TitledBorder("Data center - II"));
    
                optionPanel22.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints13;
      
                  activeRB22.setText ("Active");
        
                  gridBagConstraints13 = new java.awt.GridBagConstraints ();
                  gridBagConstraints13.gridx = 1;
                  gridBagConstraints13.gridy = 0;
                  gridBagConstraints13.insets = new java.awt.Insets (0, 0, 0, 5);
                  optionPanel22.add (activeRB22, gridBagConstraints13);
        
                  dormantRB22.setText ("Dormant");
        
                  gridBagConstraints13 = new java.awt.GridBagConstraints ();
                  gridBagConstraints13.gridx = 2;
                  gridBagConstraints13.gridy = 0;
                  gridBagConstraints13.insets = new java.awt.Insets (0, 5, 0, 0);
                  optionPanel22.add (dormantRB22, gridBagConstraints13);
        
                  jLabel5.setText ("Mode");
        
                  gridBagConstraints13 = new java.awt.GridBagConstraints ();
                  gridBagConstraints13.gridx = 0;
                  gridBagConstraints13.gridy = 0;
                  gridBagConstraints13.insets = new java.awt.Insets (0, 0, 0, 10);
                  optionPanel22.add (jLabel5, gridBagConstraints13);
        
                gridBagConstraints12 = new java.awt.GridBagConstraints ();
                gridBagConstraints12.gridx = 0;
                gridBagConstraints12.gridy = 0;
                gridBagConstraints12.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints12.anchor = java.awt.GridBagConstraints.WEST;
                gridBagConstraints12.weightx = 0.6;
                jPanel9.add (optionPanel22, gridBagConstraints12);
      
                jPanel19.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints14;
      
                  startButton22.setText ("Start");
                  startButton22.setActionCommand ("Start 22");
                  startButton22.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints14 = new java.awt.GridBagConstraints ();
                  gridBagConstraints14.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints14.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel19.add (startButton22, gridBagConstraints14);
        
                  stopButton22.setText ("Stop");
                  stopButton22.setActionCommand ("Stop 22");
                  stopButton22.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspServicesHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints14 = new java.awt.GridBagConstraints ();
                  gridBagConstraints14.gridx = 1;
                  gridBagConstraints14.gridy = 0;
                  gridBagConstraints14.fill = java.awt.GridBagConstraints.HORIZONTAL;
                  gridBagConstraints14.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel19.add (stopButton22, gridBagConstraints14);
        
                  modeButton22.setText ("Set Mode");
                  modeButton22.setActionCommand ("Mode 22");
                  modeButton22.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspModeHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints14 = new java.awt.GridBagConstraints ();
                  gridBagConstraints14.gridx = 2;
                  gridBagConstraints14.gridy = 0;
                  gridBagConstraints14.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel19.add (modeButton22, gridBagConstraints14);
        
                  statusButton22.setText ("Status");
                  statusButton22.setActionCommand ("Status 22");
                  statusButton22.addActionListener (new java.awt.event.ActionListener () {
                    public void actionPerformed (java.awt.event.ActionEvent evt) {
                      dspStatusHandler (evt);
                    }
                  }
                  );
        
                  gridBagConstraints14 = new java.awt.GridBagConstraints ();
                  gridBagConstraints14.gridx = 3;
                  gridBagConstraints14.gridy = 0;
                  gridBagConstraints14.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel19.add (statusButton22, gridBagConstraints14);
        
                gridBagConstraints12 = new java.awt.GridBagConstraints ();
                gridBagConstraints12.gridx = 0;
                gridBagConstraints12.gridy = 1;
                gridBagConstraints12.gridwidth = 2;
                gridBagConstraints12.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints12.weightx = 1.0;
                gridBagConstraints12.weighty = 0.5;
                jPanel9.add (jPanel19, gridBagConstraints12);
      
      
                  vrtsCheckBox22.setSelected (true);
                  vrtsCheckBox22.setText ("Use Veritas Commands");
        
                  jPanel36.add (vrtsCheckBox22);
        
                gridBagConstraints12 = new java.awt.GridBagConstraints ();
                gridBagConstraints12.insets = new java.awt.Insets (0, 5, 5, 0);
                jPanel9.add (jPanel36, gridBagConstraints12);
      
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.gridx = 1;
              gridBagConstraints8.gridy = 2;
              gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
              gridBagConstraints8.weightx = 0.5;
              jPanel10.add (jPanel9, gridBagConstraints8);
    
              jPanel5.setBorder (new javax.swing.border.TitledBorder(""));
    
                jButton5.setText ("Configuration");
                jButton5.setActionCommand (Constants.CONFIGURATION_DISTRIBUTOR_PREFIX);
                jButton5.addActionListener (new java.awt.event.ActionListener () {
                  public void actionPerformed (java.awt.event.ActionEvent evt) {
                    screenActionHandler (evt);
                  }
                }
                );
      
                jPanel5.add (jButton5);
      
              gridBagConstraints8 = new java.awt.GridBagConstraints ();
              gridBagConstraints8.gridx = 0;
              gridBagConstraints8.gridy = 1;
              gridBagConstraints8.gridwidth = 2;
              gridBagConstraints8.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints8.insets = new java.awt.Insets (2, 0, 0, 0);
              jPanel10.add (jPanel5, gridBagConstraints8);
    
            jTabbedPane1.addTab ("Output services", jPanel10);
  
            jPanel3.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints15;
  
              jPanel22.setLayout (new java.awt.BorderLayout ());
              jPanel22.setBorder (new javax.swing.border.TitledBorder(
              new javax.swing.border.EtchedBorder(), ""));
    
                jPanel24.setLayout (new java.awt.FlowLayout (1, 25, 5));
      
                  jPanel17.setLayout (new java.awt.GridBagLayout ());
                  java.awt.GridBagConstraints gridBagConstraints16;
                  jPanel17.setBorder (new javax.swing.border.CompoundBorder(
                  new javax.swing.border.TitledBorder("Configuration server mode"),
                  new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
        
                    jPanel26.setLayout (new java.awt.GridBagLayout ());
                    java.awt.GridBagConstraints gridBagConstraints17;
          
                      jLabel2.setText ("DC - I:");
            
                      gridBagConstraints17 = new java.awt.GridBagConstraints ();
                      gridBagConstraints17.gridx = 0;
                      gridBagConstraints17.gridy = 0;
                      gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
                      jPanel26.add (jLabel2, gridBagConstraints17);
            
                      modeLabel1.setText ("------");
            
                      gridBagConstraints17 = new java.awt.GridBagConstraints ();
                      gridBagConstraints17.gridx = 1;
                      gridBagConstraints17.gridy = 0;
                      gridBagConstraints17.insets = new java.awt.Insets (0, 5, 0, 15);
                      gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
                      jPanel26.add (modeLabel1, gridBagConstraints17);
            
                      jLabel4.setText ("DC - II:");
            
                      gridBagConstraints17 = new java.awt.GridBagConstraints ();
                      gridBagConstraints17.gridx = 2;
                      gridBagConstraints17.gridy = 0;
                      gridBagConstraints17.insets = new java.awt.Insets (0, 15, 0, 0);
                      gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
                      jPanel26.add (jLabel4, gridBagConstraints17);
            
                      modeLabel2.setText ("------");
            
                      gridBagConstraints17 = new java.awt.GridBagConstraints ();
                      gridBagConstraints17.gridx = 3;
                      gridBagConstraints17.gridy = 0;
                      gridBagConstraints17.insets = new java.awt.Insets (0, 5, 0, 0);
                      gridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
                      jPanel26.add (modeLabel2, gridBagConstraints17);
            
                    gridBagConstraints16 = new java.awt.GridBagConstraints ();
                    gridBagConstraints16.fill = java.awt.GridBagConstraints.HORIZONTAL;
                    jPanel17.add (jPanel26, gridBagConstraints16);
          
          
                      modeButton3.setText ("Switch modes");
                      modeButton3.setActionCommand ("Mode 0");
                      modeButton3.setEnabled (false);
                      modeButton3.addActionListener (new java.awt.event.ActionListener () {
                        public void actionPerformed (java.awt.event.ActionEvent evt) {
                          dspModeHandler (evt);
                        }
                      }
                      );
            
                      jPanel30.add (modeButton3);
            
                    gridBagConstraints16 = new java.awt.GridBagConstraints ();
                    gridBagConstraints16.gridx = 0;
                    gridBagConstraints16.gridy = 1;
                    gridBagConstraints16.fill = java.awt.GridBagConstraints.HORIZONTAL;
                    jPanel17.add (jPanel30, gridBagConstraints16);
          
                  jPanel24.add (jPanel17);
        
                jPanel22.add (jPanel24, java.awt.BorderLayout.SOUTH);
      
                adminServicesTablePanel.setLayout (new java.awt.BorderLayout ());
                adminServicesTablePanel.setBorder (new javax.swing.border.TitledBorder(""));
      
                jPanel22.add (adminServicesTablePanel, java.awt.BorderLayout.CENTER);
      
              gridBagConstraints15 = new java.awt.GridBagConstraints ();
              gridBagConstraints15.gridwidth = 2;
              gridBagConstraints15.fill = java.awt.GridBagConstraints.BOTH;
              gridBagConstraints15.weightx = 1.0;
              gridBagConstraints15.weighty = 1.0;
              jPanel3.add (jPanel22, gridBagConstraints15);
    
            jTabbedPane1.addTab ("System services", jPanel3);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 1.0;
          gridBagConstraints1.weighty = 1.0;
          getContentPane ().add (jTabbedPane1, gridBagConstraints1);

          jPanel29.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints18;

            jPanel31.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints19;
  
              host1TextField.setEditable (false);
    
              gridBagConstraints19 = new java.awt.GridBagConstraints ();
              gridBagConstraints19.gridx = 1;
              gridBagConstraints19.gridy = 0;
              gridBagConstraints19.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints19.anchor = java.awt.GridBagConstraints.WEST;
              gridBagConstraints19.weightx = 0.5;
              jPanel31.add (host1TextField, gridBagConstraints19);
    
              location1TextField.setEditable (false);
    
              gridBagConstraints19 = new java.awt.GridBagConstraints ();
              gridBagConstraints19.gridx = 0;
              gridBagConstraints19.gridy = 0;
              gridBagConstraints19.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints19.anchor = java.awt.GridBagConstraints.EAST;
              gridBagConstraints19.weightx = 0.5;
              jPanel31.add (location1TextField, gridBagConstraints19);
    
            gridBagConstraints18 = new java.awt.GridBagConstraints ();
            gridBagConstraints18.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints18.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints18.weightx = 0.5;
            jPanel29.add (jPanel31, gridBagConstraints18);
  
            jPanel32.setLayout (new java.awt.GridBagLayout ());
            java.awt.GridBagConstraints gridBagConstraints20;
  
              location2TextField.setEditable (false);
    
              gridBagConstraints20 = new java.awt.GridBagConstraints ();
              gridBagConstraints20.gridx = 0;
              gridBagConstraints20.gridy = 0;
              gridBagConstraints20.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints20.anchor = java.awt.GridBagConstraints.EAST;
              gridBagConstraints20.weightx = 0.5;
              jPanel32.add (location2TextField, gridBagConstraints20);
    
              host2TextField.setEditable (false);
    
              gridBagConstraints20 = new java.awt.GridBagConstraints ();
              gridBagConstraints20.fill = java.awt.GridBagConstraints.HORIZONTAL;
              gridBagConstraints20.anchor = java.awt.GridBagConstraints.WEST;
              gridBagConstraints20.weightx = 0.5;
              jPanel32.add (host2TextField, gridBagConstraints20);
    
            gridBagConstraints18 = new java.awt.GridBagConstraints ();
            gridBagConstraints18.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints18.insets = new java.awt.Insets (5, 5, 5, 5);
            gridBagConstraints18.weightx = 0.5;
            jPanel29.add (jPanel32, gridBagConstraints18);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          getContentPane ().add (jPanel29, gridBagConstraints1);

        }//GEN-END:initComponents

private void vrtsHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vrtsHandler
// Add your handling code here:

        String command = evt.getActionCommand();

	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_vrtsHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();
        
  }//GEN-LAST:event_vrtsHandler

        
        private void veritasHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_veritasHandler
// Add your handling code here:

	

  }//GEN-LAST:event_veritasHandler

        private void _vrtsHandler(javax.swing.JButton cmdButton,
                                  String command) 
    {
            
            DefaultTableModel model = null;
            javax.swing.JTable table = null;
            
            String dspHostList = null,dspPHostList = null;

            synchronized (this) {
                    if (command.endsWith("1")) {
                            model = vrtsStatusModel1;
                            dspHostList = dspHostList1;
                            dspPHostList = dspPHostList1;
                            table = vrtsStatusTable1;
                    } else if (command.endsWith("2")) {
                            model = vrtsStatusModel2;
                            dspHostList = dspHostList2;
                            dspPHostList = dspPHostList2;
                            table = vrtsStatusTable2;
                    }
            }
            if ( (dspHostList==null)
                 ||(dspPHostList==null)) {
                    Log.getInstance().show_error(this,"Error",
					 "Can't get DSP host configuration. Please retry later.",
					 null); 
                    if (cmdButton!=null) cmdButton.setEnabled(true);
                    return;
            }
            
            int selected_row = table.getSelectedRow();
            if (selected_row == -1) {
                    Log.getInstance().show_error(this,"Error",
					 "Please select a row.",
					 null); 
                    if (cmdButton!=null) cmdButton.setEnabled(true);
                    return;
                    
            }
            String host = (String)model.getValueAt(selected_row, 0);
            String state = (String)model.getValueAt(selected_row, 2);

            final String r[] = new String[1];
            r[0] = dataServicesModel.getVRTSGroup();

            StringBuffer prompt = new StringBuffer("Are you sure you want to ");
            int l = prompt.length();
            
            if (command.startsWith("START")) {
                    if (Constants.findPattern(state, "PARTIAL"))
                            prompt.append(" fully start up all services on ")
                                    .append(host)
                                    .append("?");
                    else
                            prompt.append(" start services on ")
                                    .append(host)
                                    .append("?");
            }
            else if  (command.startsWith("STOP"))
                    prompt.append(" stop all services on ")
                            .append(host)
                            .append("?");
            else if (command.startsWith("CLEAR"))
                    prompt.append(" clear the fault on ")
                            .append(host)
                            .append("?"); 
            else if (command.startsWith("SWITCH")) 
                    prompt.append(" switch all services to ")
                            .append(host)
                            .append("?");
            else if (!command.startsWith("STATUS")) {
                    Log.getInstance().show_error(this,"Error",
					 "Unsupported command: "+command,
					 null); 
                    if (cmdButton!=null) cmdButton.setEnabled(true);
                    return;
                    
            }
            
                    
                    
            if (prompt.length() > l) {
                    if (javax.swing.JOptionPane.YES_OPTION
                        != Log.getInstance().show_confirm(this,
                                                      "Confirmation dialog",
                                                       prompt.toString())) {
                            if (cmdButton != null ) 
                                    cmdButton.setEnabled(true);
                            return;
                    }
            }
            




            
            String status = null;
            try {
                    
                    if (command.startsWith("START")) 
                            status = VRTSCommands.ha_online_group(dspPHostList, r, host);
                    
                    if (command.startsWith("STOP"))
                            status = VRTSCommands.ha_offline_group(dspPHostList, r, host);
                    
                    
                    if (command.startsWith("CLEAR")) 
                            status = VRTSCommands.ha_clear_group(dspPHostList, r[0], host);
                    
                    if (command.startsWith("SWITCH")) 
                            status = VRTSCommands.ha_switch(dspPHostList, host, r[0]);
                    
                    if (command.startsWith("STATUS")) 
                            status = VRTSCommands.getGroupStatus(dspPHostList,
                                                                 r[0], host);
            } catch (Exception e) {
                    status = e.getMessage();
                    Log.getInstance().log_error("Veritas command failed.", e);
            }
            
            
                    
                    
            if ( (status!=null)
                 && (status.trim().length()>0) )
                    Log.getInstance().show_error(myFrame,
                                                 "Veritas command status",
                                                 status,
                                                 null);
            
            if (cmdButton!=null) cmdButton.setEnabled(true);

    }
        

    private void selectAll (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectAll
	// Add your handling code here:
	String command = evt.getActionCommand();
	if (command.startsWith("DISTR"))
	    distrTable.selectAll();    
	if (command.startsWith("CONFIG"))
	    systemServicesTable.selectAll();
    }//GEN-LAST:event_selectAll


    private void selectServicesHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectServicesHandler
	// Add your handling code here:

	String command = evt.getActionCommand();

       if (command.startsWith("All")){
	    dataServicesTable.selectAll();
	}

    }//GEN-LAST:event_selectServicesHandler





    private void dspModeHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dspModeHandler
	// Add your handling code here:
	final String command= evt.getActionCommand();

	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_dspModeHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();
    

    } //GEN-LAST:event_dspModeHandler





    private void _dspModeHandler(javax.swing.JButton cmdButton, String command) 
    {


	
	if (command.equals("Mode 0")) { // Config Server mode
	    taskStarted("Changing CS modes..");
	    csModeHandler();
	} /* Mode 0 : Config server mode */




	if (command.endsWith("12")||command.endsWith("22")) { // Line handler mode
	    taskStarted("Setting mode ..");
	    lhModeHandler(command);
	} // Line handler mode


	taskEnded();
	if (cmdButton!=null) cmdButton.setEnabled(true);


  
    }  /* End of _dspModeHandler */



    private void lhModeHandler(String command) 
    {
	javax.swing.JRadioButton dormantRB=dormantRB12;
	javax.swing.JRadioButton activeRB=activeRB12;
	javax.swing.JRadioButton noneRB = noneRB12;



	String serverList1 = dataServicesModel.getDC1Host();
	String serverList2 = dataServicesModel.getDC2Host();

	if ((serverList1==null) || (serverList2==null)) {
	    Log.getInstance().show_error(this,"Error",
					 "Could not retrieve DSP host configuration",
					 null); 
	    return;
	}

	String server = serverList1;
	if (command.endsWith("22")) {
	    dormantRB=dormantRB22;
	    activeRB=activeRB22;
	    noneRB = noneRB22;
	    server = serverList2;            
	}

	if (noneRB.isSelected()) {
	    Log.getInstance().show_error(this,"Error",
					 "Please specify mode.",
					 null); 
	    return;
	}
    
    
	int srows[] = distrTable.getSelectedRows();
	if (srows.length <= 0) {
	    Log.getInstance().show_error(this,"Error",
					 "Please select line handlers.",
					 null); 
	    return;
	}
    



	    
	    /* Create commands for adminserver */
	StringBuffer reqbuf = new StringBuffer();
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String id = (String)distrTable.getValueAt(row,0);

	    reqbuf.append(id+";"+AdminComm.CHANGE_MODE+" ");


	    if (activeRB.isSelected())
		reqbuf.append(" 1 ")
		    .append(Constants.DSP_DEFAULT_LINEHANDLER_MODE).append(";");
	    else
		reqbuf.append(" 0;");

	    reqbuf.append(ConfigComm.CONF_GS);

	} /* for srows.length */

	Utils.AdminWorker worker =
	    new Utils.AdminWorker(AdminComm.CHANGE_MODE, server, reqbuf.toString());

	    
	worker.start();

	Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
	if (status.status != 0) {
	    Log.getInstance().show_error(this,"Error",status.response.toString(),
					 null);
	}

	   
	noneRB.setSelected(true);
  
    }



    private void csModeHandler()
    {
	int r1 = -1;
	int r2 = -1;
	    
	    

	String serverList1 = dataServicesModel.getDC1Host();
	String serverList2 = dataServicesModel.getDC2Host();

	if ((serverList1==null) || (serverList2==null)) {
	    Log.getInstance().show_error(this,"Error",
					 "Could not retrieve DSP host configuration",
					 null); 
	    return;
	}

	    

	/* Retrieve modes from configservers in both data centers */
	try {
	    r1 = ConfigComm.modeRequest(serverList1,ConfigComm.GET_MODE,-1);
	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Server: "+serverList1+" Mode: "+r1);
	} catch (Exception e) {
	    Log.getInstance().log_error("Error in retrieving CS mode from "
					+serverList1, e);
	}
	    
	try {
	    r2 = ConfigComm.modeRequest(serverList2,ConfigComm.GET_MODE,-1);
	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Server: "+serverList2+" Mode: "+r2);
	} catch (Exception e) {
	    Log.getInstance().log_error("Error in retrieving CS mode from "
					+serverList2, e);
	}



	if ((r1==-1)&&(r2==-1)){
	    Log.getInstance().show_error(this,"Error",
					 "Could not determine config server modes"
					 +r1+" "+r2, null); 
	    return;
	}


	String primaryHostList = null;
	String secondaryHostList = null;
	if ((r2==-1) || (r1==ConfigComm.CONFIG_SLAVE_MODE)) {
	    primaryHostList=serverList1;
	    secondaryHostList=serverList2;      
	} else  {
	    primaryHostList = serverList2;
	    secondaryHostList = serverList1;       
	}

	     

	Utils.CSModeWorker work1 
	    = new Utils.CSModeWorker(secondaryHostList,ConfigComm.CONFIG_SLAVE_MODE);

	Utils.CSModeWorker work2 
	    = new Utils.CSModeWorker(primaryHostList,ConfigComm.CONFIG_MASTER_MODE);

	work1.start();
	work2.start();
    
	    // Wait for threads to complete
	Integer v1 = (Integer)work1.get();
	Integer v2 = (Integer)work2.get();

	if ((v1.intValue()==-1) || (v2.intValue()==-1)) {
	    Log.getInstance().show_error(this, "Error",
					 "Please check log for "
					 +"error messages",null);
	}

    }





    private void dspStatusHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dspStatusHandler
	// Add your handling code here:

	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_dspStatusHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();
   

    }//GEN-LAST:event_dspStatusHandler

  
    private void _dspStatusHandler(javax.swing.JButton cmdButton, String command)
    {
	int which=0,type=-1;
	String serverList=null;
	String progname = null;
	String name = null;

	String serverList1 = dataServicesModel.getDC1Host();
	String serverList2 = dataServicesModel.getDC2Host();

	if ((serverList1==null) || (serverList2==null)) {
	    Log.getInstance().show_error(this,"Error",
					 "Could not retrieve DSP host configuration",
					 null); 
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;
	}



	if (command.endsWith("11")||command.endsWith("12")) {
	    which = 1;
	    serverList = serverList1;
	}

	if (command.endsWith("21")||command.endsWith("22")) {
	    which = 2;
	    serverList = serverList2;
	}


    endofblock:
	if (command.endsWith("11")|| command.endsWith("21")) {    

	    int srows[] = dataServicesTable.getSelectedRows();
	    if (srows.length == 0) 
		break endofblock;

	    int srow = srows[0];

	    String value = (String)dataServicesTable.getValueAt(srow,0);

	    if (value.startsWith("Reader")) {
		type = Constants.DSP_READER;
		int inx = value.indexOf(":");
		progname = value.substring(0,inx-1);
		name     = value.substring(inx+1);
	    } 

	} else if (command.endsWith("12")||command.endsWith("22")) {

	    int srows[] = distrTable.getSelectedRows();
	    if (srows.length == 0)
		break endofblock;
            
	    int srow = srows[0];
	    type = Constants.DSP_BROADCASTER;
	    name = (String) distrTable.getValueAt(srow,0);

	}


	if (type != -1) {
	    taskStarted("Displaying status window ..");
            try {
                    
                    StatusHandler.getInstance().displayStatus(myFrame,type,which,serverList,
                                                              Constants.GLB_TAG_DSP,name);
            }
            catch (Exception e){
            }
            
	    taskEnded();
	}

	if (cmdButton!=null) cmdButton.setEnabled(true);
	

    }

  
  
    private void dspServicesHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dspServicesHandler
	// Add your handling code here:
	String command = evt.getActionCommand();

	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_dspServicesHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();


    }//GEN-LAST:event_dspServicesHandler


        private void _dspServicesHandler(javax.swing.JButton cmdButton, String command) 
        {
  
                String idsdir = Constants.idsdir;
                int option = -1;
                String server = null;
                java.util.Vector ifVector=null;
                
                javax.swing.JRadioButton activeRB=activeRB12;
                javax.swing.JRadioButton noneRB = noneRB12;
                
                javax.swing.JCheckBox vrtsCheckBox=null;
                
                
                boolean error = false;
                
                
                String m=null;
                if (command.startsWith("Start"))
                        m = "Starting selected services..";
                else if (command.startsWith("Stop"))
                        m = "Stopping selected services..";
                
                taskStarted(m);
                
                
                boolean xxxxSelected = false;
                boolean USE_VERITAS_COMMANDS = true;
                
                
          uicheckblock:  {
                        if (command.endsWith("1")) {
                                int srow = dataServicesTable.getSelectedRowCount();
                                if (srow <=0) {
                                        Log.getInstance().show_error(this,"Error",
                                                                     "Please select services.",
                                                                     null); 
                                        error = true;
                                        break uicheckblock;
                                }
                                int srows[] = distrTable.getSelectedRows(); 
                                for (int i = 0; i < srows.length; i++) 
                                        if (((String)distrTable.getValueAt(srows[i],0)).equals("XXXX"))
                                                xxxxSelected = true;
                

                    
	    
                        } else if (command.endsWith("2")) {
                                int srow = distrTable.getSelectedRowCount();
                                if (srow <=0) {
                                        Log.getInstance().show_error(this,"Error",
                                                                     "Please select line handlers.",
                                                                     null); 
                                        error = true;
                                        break uicheckblock;
                                }
                        } else {
                                Log.getInstance().log_error("Unsupported action: "+command,null);
                                error = true;
                                break uicheckblock;
                        }

                        if (command.startsWith("Start"))
                                option = AdminComm.START_IDS2_PROC;
                        else if (command.startsWith("Stop"))
                                option = AdminComm.STOP_IDS2_PROC;
                        else {
                                Log.getInstance().log_error("Unsupported action: "
                                                            +command,null);
                                error = true;
                                break uicheckblock;
                        }


                        if (command.endsWith("11"))
                                vrtsCheckBox = vrtsCheckBox11;
                        else if (command.endsWith("12"))
                                vrtsCheckBox = vrtsCheckBox12;
                        else if (command.endsWith("21"))
                                vrtsCheckBox = vrtsCheckBox21;
                        else if (command.endsWith("22"))
                                vrtsCheckBox = vrtsCheckBox22;

                        if (vrtsCheckBox != null)
                                USE_VERITAS_COMMANDS = vrtsCheckBox.isSelected();
            
                     
                        if (command.endsWith("22")) {
                                activeRB=activeRB22;
                                noneRB = noneRB22;
                        }

                        if (command.startsWith("Start") 
                            && (command.endsWith("2") && noneRB.isSelected())
                            && xxxxSelected ) {
                                Log.getInstance().show_error(this,"Error",
                                                             "Please specify mode.",null);
                                error = true;
                                break uicheckblock;
                        }
            
                }

                if (error) {
                        if (cmdButton != null ) cmdButton.setEnabled(true);
                        taskEnded();
                        return;
                }

                StringBuffer prompt = new StringBuffer();
        

        

                updateTimer.stop();
                try {
                        rwLock.readLock().acquire();
                } catch (InterruptedException ie ) {
                        Log.getInstance().show_error(this,"Error",
                                                     "Service handler interrupted",ie);
                        if (cmdButton != null ) cmdButton.setEnabled(true);
                        taskEnded();
                        updateTimer.start();
                        return;
                }

                String serverList1 = null;
                String serverList2 = null;
                String version = null;
                java.util.Vector ifVector1 = null;
                java.util.Vector ifVector2 = null;

          configblock:
                {
                        serverList1 = dataServicesModel.getDC1PHost();
                        serverList2 = dataServicesModel.getDC2PHost();
                        if ((serverList1==null) || (serverList2==null)) {
                                Log.getInstance().show_error(this,"Error",
                                                             "Could not retrieve DSP host configuration",
                                                             null); 
                                error = true;
                                break configblock;
                        }


                        version = dataServicesModel.getSWVersion();
                        if (version==null) {
                                Log.getInstance().show_error(this,"Error",
                                                             "Error in retrieving DSP software version ",
                                                             null);
                                error = true;
                                break configblock;
                        }

                        if (version.equals(Constants.DEFAULT_SW_VERSION))
                                version = Constants.DEFAULT_SW_VERSION_DIR;

                        ifVector1 = dataServicesModel.getDC1InputFeed();
                        ifVector2 = dataServicesModel.getDC2InputFeed();
                        if ((ifVector1==null)||(ifVector2==null)) {
                                Log.getInstance().show_error(this,"Error",
                                                             "Error in retrieving DSP input "
                                                             +"configuration:",
                                                             null);
                                error = true;
                                break configblock;
                        }

                }  // End of config block



                if (error) {
                        if (cmdButton != null ) cmdButton.setEnabled(true);
                        taskEnded();
                        rwLock.readLock().release();
                        updateTimer.start();
                        return;
                }


                if (idsdir==null) idsdir = "/ids2";
                idsdir.trim();
                idsdir = idsdir+"/dsp/"+version;


                server = serverList1;
                ifVector = ifVector1;
                if (command.endsWith("21") || command.endsWith("22")) {
                        server = serverList2;
                        ifVector = ifVector2;
                }
                String vrts_tree = "\nError in getting dependencies.\n";
                try {
                        vrts_tree = VRTSCommands.ha_res_depend(server,null);
                } catch (Exception e){
                        Log.getInstance().log_error("Error in retrieving dependency"
                                                    +"tree. ",
                                                    e);
                }
        
        
	
                    // Create commands for adminserver depending of the type of service
                StringBuffer reqbuf = new StringBuffer();
                String response = null;

                if (USE_VERITAS_COMMANDS)
                {
                
                        String [] resources = null;

        
        
                        if (command.endsWith("1")) {   // Data Services Table
                                resources = createDataServicesRequest();
                        }
	    
                        if (command.endsWith("2")) { // Output services (dsp_linehandler) 
                                resources = createDistrServicesRequest(idsdir,
                                                                       activeRB.isSelected(),
                                                                       reqbuf);
                        }  // *Output services table




        
        
        

                        if (  (resources != null)
                              && ( resources.length > 0) )
                        {
                                String s = " ";
                                String s2 = " ";
                
                
                                if (command.startsWith("Start")) {
                                        s = "online";
                                        s2 = "Please note that the dependent resources will also be brought online as per the following dependencies:\n";
                                }        
                                else if (command.startsWith("Stop")) {
                                        s = "offline";
                                        s2 = "Please note that the dependent resources will have to be brought offline first as per the following dependencies:\n";
                                }
                
                
                                prompt.append("Are you sure you want to ")
                                        .append(s)
                                        .append(" the following : \n");
                                for (int r = 0; r < resources.length; r++)
                                        prompt.append(resources[r]).append(" ");
                                prompt.append("\n\n")
                                        .append(s2)
                                        .append(vrts_tree);

                                String btns[] = { "Yes", "No"  };
                
                
                                MessageDialog md = new MessageDialog(this, true,"Please confirm",
                                                                     prompt.toString(),
                                                                     btns);
                                md.show();
                
                                if (!md.getAction().equals(btns[0])) {
                                        if (cmdButton != null ) cmdButton.setEnabled(true);
                                        taskEnded();
                                        rwLock.readLock().release();
                                        updateTimer.start();
                                        return;  
                                }
                

                        
                
                
                                try {
                        
                                        if (command.startsWith("Start"))
                                                response = VRTSCommands.ha_online_resource(server, resources);
                                        else if (command.startsWith("Stop"))
                                                response = VRTSCommands.ha_offline_resource(server, resources);
                                } catch (Exception e){
                                        response = e.getMessage();
                                        Log.getInstance().log_error("Error :"
                                                                    +e.getMessage(),
                                                                    e);
                                }
                        }
        
                } // USE_VERITAS_COMMANDS
                else
                {
                        if (command.endsWith("1")) {   // Data Services Table
                                createDataServicesRequest(option, ifVector, idsdir, reqbuf);
                        }
                
                        if (command.endsWith("2")) { // Output services (dsp_linehandler) services
                                createDistrServicesRequest(activeRB.isSelected(), idsdir, reqbuf);
                        }  // *Output services table
	
                
                }
        
        
                if ( reqbuf.length() > 0) {
                        Utils.AdminWorker worker =
                                new Utils.AdminWorker(option, server,
                                                      reqbuf.toString());

                            // Start the worker thread
                        worker.start();
                

                            // Wait for the thread to finish
                        Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                        if (status.status != 0) {
                                if (status.response.length()>0)
                                        Log.getInstance().log_error("Error :"
                                                                    +status.response.toString(),
                                                                    null);

                                String s = "Error in starting XXXX";
                                if (response == null)
                                        response = s;
                                else
                                        response += s;
                        
                        }
                }

                if ((response != null) && (response.trim().length()>0))
                        Log.getInstance().show_error(this, "Command status",
                                                     "Request status: \n "
                                                     +response,null);


	
                taskEnded();
                rwLock.readLock().release();

                if (cmdButton != null ) cmdButton.setEnabled(true);
                updateTimer.start();



        } /* End of _dspServicesHandler */


        private String[]
    createDataServicesRequest()
    {


	String reader = Constants.DSPServicesTable[0][1];
	String msgmgr = Constants.DSPServicesTable[1][1];

	
	int srows[] = dataServicesTable.getSelectedRows();

        ArrayList resources = new ArrayList(10);


        
	/* Start any readers first */
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String prg = (String)dataServicesTable.getValueAt(row,0);

            
            
	    if (prg.startsWith("Reader")) {
		int inx = prg.indexOf(":")+1;
                if (inx < 0) continue;
                
		StringBuffer resource_name = new StringBuffer(prg.substring(inx));
                resource_name.insert(0,"reader_");
                resources.add(resource_name.toString().toLowerCase());
	    } /* Reader */
	} /* for srows = 0 */




        
	/*
	** Start any remaining data services after reader(s) 
	** are started
	*/
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String prg = (String)dataServicesTable.getValueAt(row,0);


	    if (prg.startsWith("Synch")) {
                    resources.add("syncserver");
	    } else if (prg.startsWith("Message")) {
		int inx = prg.indexOf(":")+1;
                if (inx<0) continue;
                
		StringBuffer resource_name = new StringBuffer(prg.substring(inx));
                resource_name.insert(0,"msgmgr_");
                
                resources.add(resource_name.toString().toLowerCase());

	    } /* Message */

	} /* for srows = 0 */


        return (String[])resources.toArray(new String[1]);
        

    } // End of createDataServicesRequest() 


    private String[]
    createDistrServicesRequest(String idsdir, boolean isActive,
                               StringBuffer reqbuf)
    {

	int srows[] = distrTable.getSelectedRows();

        if (srows.length == 0) return new String[0];
        
        ArrayList resources = null;
        
	for (int i = 0; i < srows.length; i++) {
                String id = (String)distrTable.getValueAt(srows[i],0);
                
                if (id.equals("XXXX")) {
                        reqbuf.append(ConfigComm.CONF_GS)
                                .append(idsdir+"/bin/dsp_linehand")
                                .append(";-d;-d ")
                                .append(id);

                        if (isActive)
                                reqbuf.append(" -A -s")
                                        .append(Constants.DSP_DEFAULT_LINEHANDLER_MODE)
                                        .append(";");
                        else
                                reqbuf.append(" -D;");
                }
                else {
                        if (resources == null)
                                resources = new ArrayList(srows.length);
                        resources.add("linehand_"+id);
                }
                
        }
        
        if (resources == null) return null;

        return (String[])resources.toArray(new String[1]);
	
    }

            /*
****************************************
*/


    private void createDataServicesRequest(int option, java.util.Vector ifVector,
					   String idsdir, StringBuffer reqbuf)
    {


	String reader = Constants.DSPServicesTable[0][1];
	String msgmgr = Constants.DSPServicesTable[1][1];

	
	String DSP_MESSAGE_MANAGER_ARGS = " -o "
	    +Constants.GLB_IDS_FORMAT
	    +" ";

	String DSP_SYNC_SERVER_ARGS = " -f "
	    +Constants.GLB_IDS_FORMAT
	    +" -t "
	    +Constants.GLB_IDS_TRANSPORT    +" ";


	int srows[] = dataServicesTable.getSelectedRows();

	/* Start any readers first */
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String prg = (String)dataServicesTable.getValueAt(row,0);

	    if (prg.startsWith("Reader")) {
		int inx = prg.indexOf(":")+1;
		String reader_name = prg.substring(inx);

		for (int r = 0; r < ifVector.size() ; r++) {
		    Object [] rowData = (Object[]) ifVector.get(r);
		    if (reader_name.equals((String)rowData[0])) {

			StringBuffer cmdline = new StringBuffer();
			String fmt = (String)rowData[1];
			String protocol = (String) rowData[2];

			cmdline.append(" -n ").append(reader_name)
			    .append(" -f ")
			    .append(fmt.substring(0,Constants.MSGFMTSZ))
			    .append(" -p ")
			    .append(protocol);
			if (fmt.substring(0,Constants.MSGFMTSZ)
			    .equals(Constants.DSP_DEFAULT_KEEPALIVE_FORMAT)) {
			    cmdline.append(" -k ")
				.append(Constants.DSP_DEFAULT_KEEPALIVE);
			}

			String transport = (String) rowData[3];

			int index = transport.indexOf(" ");

			if (index != -1) {
			    cmdline.append(" -t ").append(transport.substring(0,index));
			    cmdline.append(" -a ").append(transport.substring(index+1));
			} else {
			    cmdline.append(" -t ").append(transport);
			    cmdline.append(" -a ").append(" 0 ");
			}
			String products = (String) rowData[4];
			if (products != null)  {
			    cmdline.append(" ").append(products);
			}

			reqbuf.append(ConfigComm.CONF_GS)
			    .append(idsdir+"/bin/"+reader)
			    .append(";-n;"+cmdline);

			if (option == AdminComm.START_IDS2_PROC)
			    reqbuf.append(ConfigComm.CONF_GS)
				.append("DELAY;")
				.append(Integer.toString(Constants.DSP_READER_MSGMGR_DELAY))
				.append(";;");
			
			break;
		    } /* reader_name.equals */
		} /* for r = 0 */

		continue;
	    } /* Reader */
	} /* for srows = 0 */

	/*
	** Start any remaining data services after reader(s) 
	** are started
	*/
	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    String prg = (String)dataServicesTable.getValueAt(row,0);


	    if (prg.startsWith("Message")) {
		int inx = prg.indexOf(":")+1;
		String reader_name = prg.substring(inx);


		for (int r = 0; r < ifVector.size() ; r++) {
		    Object [] rowData = (Object[]) ifVector.get(r);
		    if (reader_name.equals((String)rowData[0])) {

			StringBuffer msgmgr_cl = new StringBuffer();

			msgmgr_cl.append(" -n ").append(reader_name)
			    .append(" -i ");
			String fmt = (String)rowData[1];
			msgmgr_cl.append(fmt.substring(0,Constants.MSGFMTSZ));

			if (!fmt.substring(0,Constants.MSGFMTSZ).equals(Constants.GLB_IDS_FORMAT))
			    msgmgr_cl.append(DSP_MESSAGE_MANAGER_ARGS);

			String products = (String) rowData[4];
			if (products != null)  {
			    msgmgr_cl.append(" ").append(products);
			}

			reqbuf.append(ConfigComm.CONF_GS)
			    .append(idsdir+"/bin/"+msgmgr)
			    .append(";-n;"+msgmgr_cl.toString());
			break;
		    } /* reader_name.equals */
		} /* r = 0 */
		continue;
	    } /* Message */

	} /* for srows = 0 */

    } // End of createDataServicesRequest() 


    private void createDistrServicesRequest(boolean isActive,String idsdir, 
					    StringBuffer reqbuf)
    {
	int srows[] = distrTable.getSelectedRows();

	for (int i = 0; i < srows.length; i++) {
	    int row = srows[i];
	    reqbuf.append(ConfigComm.CONF_GS)
		.append(idsdir+"/bin/dsp_linehand")
		.append(";-d;-d ")
		.append((String)distrTable.getValueAt(row,0));

	    if (isActive)
		reqbuf.append(" -A -s")
			.append(Constants.DSP_DEFAULT_LINEHANDLER_MODE).append(";");
	    else
		reqbuf.append(" -D;");
	    
	}
	
    }





        

            /*
****************************************
*/

    private void screenActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_screenActionHandler
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;

	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		_screenActionHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();
    }//GEN-LAST:event_screenActionHandler


    private void _screenActionHandler(javax.swing.JButton cmdButton, String command)
    {

	if (command.equals("Close")) {
	    exitForm(null);
	    return;
	}  
  

	taskStarted("Displaying window ..");
	javax.swing.JFrame f = null;
	
	if (command.equals(Constants.CONFIGURATION_DISTRIBUTOR_PREFIX)) {
	    int srows[] = distrTable.getSelectedRows();

	    if (srows.length == 1) {
		int row = srows[0];
		String distr = (String)distrTable.getValueAt(row,0);
		f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
		.findWindow(Constants.CONFIGURATION_DISTRIBUTOR_PREFIX+distr);

		if (f == null) {
		    try {
			f = new DistributorConfigurationForm(distr, null,
							 false);
		    } catch (Exception e) {
			Log.getInstance().log_error("Error in displaying"
						    +" DSP LH configuration:"
						    +distr,e);
		    }
		}
	    } else {
		Log.getInstance().show_error(this,"Message",
					     "Please select one line handler from list",
					     null);
	    }

	} else {

	    f = (javax.swing.JFrame)WindowEventAdapter
		.getInstance().findWindow(command);

	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Action "+command);
  
	    if (f == null) {    
		try {
		    Class c = Constants.getActionClass(command);
		    if (c != null) 
			f = (javax.swing.JFrame) c.newInstance();
		} catch (Exception e) {
		    Log.getInstance().log_error("Error in displaying"
						+" window: "+command,e);
		}
	    }
	}
  
	if (f != null) f.show();
  
	taskEnded();
	if (cmdButton!=null) cmdButton.setEnabled(true);


    }




    /** Exit the Application */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm

	if (isExiting)
	    return;

	isExiting = true;

	if (updateTimer!=null)
	    updateTimer.stop();

	
	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	//gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);




	final DSPServicesForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();
		    //model.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();
	
    }//GEN-LAST:event_exitForm




  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton7;
    private ids2ui.StatusPanel statusPanel;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel vrtsPanel2;
    private javax.swing.JPanel vrtsPanel1;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JButton startButton11;
    private javax.swing.JButton stopButton11;
    private javax.swing.JButton statusButton11;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JCheckBox vrtsCheckBox11;
    private javax.swing.JPanel dataServicesTablePanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JButton startButton21;
    private javax.swing.JButton stopButton21;
    private javax.swing.JButton statusButton21;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JCheckBox vrtsCheckBox21;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel outputServicesTablePanel;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JLabel jLabel1;
    private ids2ui.UCTextField idTextF;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel optionPanel12;
    private javax.swing.JRadioButton activeRB12;
    private javax.swing.JRadioButton dormantRB12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JButton startButton12;
    private javax.swing.JButton stopButton12;
    private javax.swing.JButton modeButton12;
    private javax.swing.JButton statusButton12;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JCheckBox vrtsCheckBox12;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel optionPanel22;
    private javax.swing.JRadioButton activeRB22;
    private javax.swing.JRadioButton dormantRB22;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JButton startButton22;
    private javax.swing.JButton stopButton22;
    private javax.swing.JButton modeButton22;
    private javax.swing.JButton statusButton22;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JCheckBox vrtsCheckBox22;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel modeLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel modeLabel2;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JButton modeButton3;
    private javax.swing.JPanel adminServicesTablePanel;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JTextField host1TextField;
    private javax.swing.JTextField location1TextField;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JTextField location2TextField;
    private javax.swing.JTextField host2TextField;
    // End of variables declaration//GEN-END:variables




    private void updateModeLabel(javax.swing.JLabel modeLabel, int mode) {
	switch (mode) {
	case ConfigComm.CONFIG_MASTER_MODE:
	    modeLabel.setText("PRIMARY");
	    break;
	case ConfigComm.CONFIG_SLAVE_MODE:
	    modeLabel.setText("SECONDARY");
	    break;
	case ConfigComm.CONFIG_SYNC_MODE:
	    modeLabel.setText("SYNC");
	    break;
	case ConfigComm.CONFIG_IDLE_MODE:
	    modeLabel.setText("IDLE");
	    break;
	default:
	    modeLabel.setText("ERROR");
	}

    }

        
        


        


        ActionListener vrtsListener = new ActionListener() 
        {
                public void actionPerformed(ActionEvent ae) 
                {

                        StringTokenizer  st = new StringTokenizer(ae.getActionCommand(),
                                                                  ":");

                        if (st.countTokens() < 5) return;
                        
                        final String serverList = st.nextToken();
                        final String host1 = st.nextToken();
                        final String host = st.nextToken();
                        final String idsgroup = st.nextToken();
                        final String command = st.nextToken();

                        

                        final String r[] = new String[1];

                        r[0] = idsgroup;

                        

                        SwingWorker worker = new SwingWorker() 
                        {

                                String status = null;
                                
                                public Object construct() 
                                {
                                        
                                        try {


                                                if (command.equals("ONLINE")) 
                                                        status = VRTSCommands.ha_online_group(serverList, r, host);

                                                
                                                if (command.equals("OFFLINE"))
                                                         status = VRTSCommands.ha_offline_group(serverList, r, host);

                                                
                                                if (command.equals("CLEAR")) 
                                                         status = VRTSCommands.ha_clear_group(serverList, idsgroup, host);

                                                
                                                if (command.equals("START")) 
                                                         status = VRTSCommands.ha_start(host);

                                                
                                                if (command.equals("STOP")) 
                                                         status = VRTSCommands.ha_stop(host);

                                                
                                                if (command.equals("SWITCH")) 
                                                         status = VRTSCommands.ha_switch(serverList, host, idsgroup);

                                        }
                                        catch (Exception e) {
                                                status = e.getMessage();
                                                Log.getInstance().log_error("Veritas command failed.",
                                                                            e);
                                        }
                                        return status;
                                        
                                }

                                public void finished() 
                                {
                                        if ( (status!=null)
                                             && (status.trim().length()>0) )
                                                Log.getInstance().show_error(myFrame,
                                                                             "Veritas command status",
                                                                             status,
                                                                             null);
                                        
                                }
                        };
                        

                        worker.start();
                        
                }
        };


        private void createItem(JPopupMenu vrtsMenu, String title,
                                StringBuffer command, String action) 
        {
             JMenuItem  item = new JMenuItem(title);
                        
             command.append(action);
             item.setActionCommand(command.toString());

             item.addActionListener(vrtsListener);
             vrtsMenu.add(item);
             
        }
        

        private void
        vrtsMenu(JTable table, int dc, MouseEvent e) 
        {

                String location = "";
                String dspHostList = null,dspPHostList = null;
                
                if (dc==1) {
                        location  = dataServicesModel.getDC1Location();
                        dspHostList = dataServicesModel.getDC1Host();
                        dspPHostList = dataServicesModel.getDC1PHost();
                }
                else if (dc==2) {
                        location  = dataServicesModel.getDC2Location();
                        dspHostList = dataServicesModel.getDC2Host();
                        dspPHostList = dataServicesModel.getDC2PHost();
                }
                JPopupMenu vrtsMenu = new JPopupMenu("Veritas menu ("+location+")");
                
                DefaultTableModel model = (DefaultTableModel)table.getModel();
                
                int selected_row = table.getSelectedRow();
                if (selected_row == -1) return;

                        
                
                String vs = (String)model.getValueAt(selected_row,1);
                String is = (String)model.getValueAt(selected_row, 2);
                String selected_host = (String)model.getValueAt(selected_row, 0);
                int num_rows = model.getRowCount();
                int online_row = -1;
                String other_hosts[] = new String[num_rows-1];

                int k = 0;



                
                
                for (int i = 0; i < num_rows; i++) {
                        String s1 = (String)model.getValueAt(i, 2);
                                                
                        if (Constants.findPattern(s1,"STARTING")
                            || Constants.findPattern(s1,"STOPPING") ) {
                                javax.swing.JOptionPane.showMessageDialog(myFrame,
                                            "Veritas is in transition. Please try again.");
                                return;
                                
                        }
                        
                                
                        
                        if (s1.equals("ONLINE")
                            || s1.equals("PARTIAL") )
                                online_row = i;
                        
                        if (i != selected_row) 
                                other_hosts[k++] = (String)model.getValueAt(i, 0);
                }
                


                String ids2group = dataServicesModel.getVRTSGroup();
                StringBuffer command = new StringBuffer();
                command.append(dspHostList).append(":")
                .append(dspPHostList).append(":")
                .append(selected_host).append(":")
                .append(ids2group).append(":");
                int len = command.length();
                

                
                if (!vs.equals("RUNNING")) {
                        command.setLength(len);
                        createItem(vrtsMenu, "Start Veritas on "+selected_host,
                                   command, "START");
                } else {
                        
                        boolean faulted = Constants.findPattern(is, "FAULTED");

                        if (faulted) {
                                command.setLength(len);
                                createItem(vrtsMenu,"Clear fault on "+selected_host,
                                           command,"CLEAR");
                                
                        }
                        else {

                                if (Constants.findPattern(is,"ONLINE")
                                    || Constants.findPattern(is, "PARTIAL") ) {
                                        command.setLength(len);
                                        createItem(vrtsMenu,"Offline Apps on "
                                                   +selected_host,
                                                   command,
                                                   "OFFLINE");
                                        
                                        if (Constants.findPattern(is, "PARTIAL") ) {
                                                command.setLength(len);
                                                createItem(vrtsMenu,"Online Apps on "
                                                           +selected_host,
                                                           command,"ONLINE");
                                        }
                                }

                                if ((online_row!=-1)
                                    && (online_row != selected_row) ) {
                                        command.setLength(len);
                                        createItem(vrtsMenu,"Switch to "
                                                   +selected_host,
                                                   command,"SWITCH");
                                }

                        }
                        
                }

                vrtsMenu.show(e.getComponent(), e.getX(), e.getY());
                
                
        }

  
  


 
}

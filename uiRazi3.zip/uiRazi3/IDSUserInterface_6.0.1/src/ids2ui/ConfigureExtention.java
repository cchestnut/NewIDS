
/*
**  SCCS Info :  "@(#)ConfigureExtention.java	1.2    03/04/04"
*/


package ids2ui;
import java.io.*;
import java.util.*;


public class ConfigureExtention {

    public ConfigureExtention(){}
	
    static public void saveFTPDistr(String ID, HashMap map) 
    throws Exception
    {
	    String hostTag = (String)map.get("TAG");
	    String desc = (String)map.get("DESCRIPTION");
	    String ckptPort = (String)map.get("CHECKPOINT");
	    String ctype = (String)map.get("CONFIGURATION_TYPE");
	    String transport  = (String)map.get("TRANSPORT");
	    String ka1  = (String)map.get("KEEPALIVE_1");
	    String ka2  = (String)map.get("KEEPALIVE_2");
	    String stats1  = (String)map.get("STATISTICS_1");
	    String stats2  = (String)map.get("STATISTICS_2");

	    String products1  = (String)map.get("PRODUCTS_1");
	    String products2  = (String)map.get("PRODUCTS_2");

	    


	    StringBuffer savebuf = new StringBuffer();

	    savebuf.append(ConfigComm.CONF_RS)
		.append("TAG").append(ConfigComm.CONF_RS)
		.append(hostTag).append(ConfigComm.CONF_RS)
		.append("TRANSPORT").append(ConfigComm.CONF_RS)
		.append(transport).append(ConfigComm.CONF_RS)
		.append("KEEPALIVE_1").append(ConfigComm.CONF_RS)
		.append(ka1).append(ConfigComm.CONF_RS)
		.append("STATISTICS_1").append(ConfigComm.CONF_RS)
		.append(stats1).append(ConfigComm.CONF_RS)
		.append("KEEPALIVE_2").append(ConfigComm.CONF_RS)
		.append(ka2).append(ConfigComm.CONF_RS)
		.append("STATISTICS_2").append(ConfigComm.CONF_RS)
		.append(stats2).append(ConfigComm.CONF_RS)
		.append("DESCRIPTION").append(ConfigComm.CONF_RS)
		.append(desc).append(ConfigComm.CONF_RS)
		.append("CHECKPOINT").append(ConfigComm.CONF_RS)
		.append(ckptPort).append(ConfigComm.CONF_RS)
		.append("CONFIGURATION_TYPE").append(ConfigComm.CONF_RS)
		.append(ctype).append(ConfigComm.CONF_RS)
		.append("PRODUCTS_1").append(ConfigComm.CONF_RS)
		.append(products1).append(ConfigComm.CONF_RS)
		.append("PRODUCTS_2").append(ConfigComm.CONF_RS)
		.append(products2).append(ConfigComm.CONF_RS);


	    String sendChanges = (String)map.get("DJNEWS_SEND_CHANGES");
	    String contentType = (String)map.get("DJNEWS_CONTENT_TYPE");
	    String ftpDelay = (String)map.get("DJNEWS_TIMER");
	    String ftpDeliveryType = (String)map.get("DJNEWS_DELIVERY_TYPE");
	    String ftpFormatType = (String)map.get("DJNEWS_FORMAT_TYPE");
	    String formatEncoding =(String)map.get("DJNEWS_FORMAT_ENCODING");
	    String ftpDeliveryMethod = (String)map.get("DJNEWS_DELIVERY_METHOD");
	    String ftpFileGenType = (String)map.get("DJNEWS_FILE_GENERATION_TYPE");
	    String ftpTakeType = (String)map.get("DJNEWS_TAKE_TYPE");

	    
	    savebuf.append("DJNEWS_SEND_CHANGES").append(ConfigComm.CONF_RS)
		.append(sendChanges).append(ConfigComm.CONF_RS)
		.append("DJNEWS_CONTENT_TYPE").append(ConfigComm.CONF_RS)
		.append(contentType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_TIMER").append(ConfigComm.CONF_RS)
		.append(ftpDelay).append(ConfigComm.CONF_RS)
		.append("DJNEWS_DELIVERY_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpDeliveryType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_FORMAT_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpFormatType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_DELIVERY_METHOD").append(ConfigComm.CONF_RS)
		.append(ftpDeliveryMethod).append(ConfigComm.CONF_RS)
		.append("DJNEWS_TAKE_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpTakeType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_FILE_GENERATION_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpFileGenType).append(ConfigComm.CONF_RS);


	    String ftpFileExtention = (String) map.get("DJNEWS_FILE_EXTENTION");
	    if ( ftpFileExtention != null)
		savebuf.append("DJNEWS_FILE_EXTENTION")
		    .append(ConfigComm.CONF_RS)
		    .append(ftpFileExtention).append(ConfigComm.CONF_RS);

	    if (ftpFormatType.startsWith("XML")) {
		savebuf.append("DJNEWS_FORMAT_ENCODING")
		    .append(ConfigComm.CONF_RS)
		    .append(formatEncoding)
		    .append(ConfigComm.CONF_RS);
	    }


	    int numParams = -1;
	    String numPars =(String)map.get(Constants.FTP_NUM_ENTRIES);

	    try {
		numParams = Integer.parseInt(numPars);
	    } catch (Exception e){}
	    for (int np = 0; np < numParams; np++) {
		String ftpServer = (String)map.get(Constants.FTP_SERVER_PREFIX+np);
		String ftpPort = (String)map.get(Constants.FTP_PORT_PREFIX+np);
		String ftpUser = (String)map.get(Constants.FTP_USERNAME_PREFIX+np);
		String ftpPassword = (String)map.get(Constants.FTP_PASSWORD_PREFIX+np);
		
		String ftpPassiveMode = (String)map.get(Constants.FTP_PASSIVE_MODE_PREFIX+np);
		String ftpTransferMode = (String)map.get(Constants.FTP_TRANSFER_MODE_PREFIX+np);
		String ftpStatistics = (String)map.get(Constants.FTP_STATISTICS_FILE_PREFIX+np);
		
		
		String ftpRemoteDir = (String)map.get(Constants.FTP_REMOTE_DIR_PREFIX+np);
		String ftpRenameFile = (String)map.get(Constants.FTP_RENAME_FILE_PREFIX+np);
		
		
		
		savebuf.append(Constants.FTP_SERVER_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpServer)
		    .append(ConfigComm.CONF_RS)
		    .append(Constants.FTP_PORT_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpPort)
		    .append(ConfigComm.CONF_RS)
		    .append(Constants.FTP_USERNAME_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpUser).append(ConfigComm.CONF_RS);
		
		if ((ftpPassword!=null) && (ftpPassword.length()>0))
		    savebuf.append(Constants.FTP_PASSWORD_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpPassword)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpPassiveMode!=null) && (ftpPassiveMode.length()>0))
		    savebuf.append(Constants.FTP_PASSIVE_MODE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpPassiveMode)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpTransferMode!=null) && (ftpTransferMode.length()>0))
		    savebuf.append(Constants.FTP_TRANSFER_MODE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpTransferMode)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpStatistics!=null) && (ftpStatistics.length()>0))
		    savebuf.append(Constants.FTP_STATISTICS_FILE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpStatistics)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpRemoteDir!=null) && (ftpRemoteDir.length()>0))
		    savebuf.append(Constants.FTP_REMOTE_DIR_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpRemoteDir)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpRenameFile!=null) && (ftpRenameFile.length()>0))
		    savebuf.append(Constants.FTP_RENAME_FILE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpRenameFile)
			.append(ConfigComm.CONF_RS);
		
	    } // for np = 

	    savebuf.append(Constants.FTP_NUM_ENTRIES)
		.append(ConfigComm.CONF_RS)
		.append(numPars)
		.append(ConfigComm.CONF_RS);
	    

	    StringBuffer reqbuf = new StringBuffer();

      
	    ConfigComm.saveDistrTag(reqbuf,ID,savebuf.toString(),
				    false);


	    byte [] b = ConfigComm.configRequest(reqbuf);

	}






    
    public static void addExtentions(String dcmlist) {

	DCMDistributorStatusModel model = new DCMDistributorStatusModel(dcmlist);
	model.Refresh();

	int numlh = model.getRowCount();


	for (int lh = 0; lh < numlh; lh++) {

	    String did = (String)model.getValueAt(lh,0);

	    java.util.HashMap map = null;
	    
	    try {
		map =  
		    ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);

		String extn = (String)map.get("DJNEWS_FILE_EXTENTION");
		if (extn == null) {

		    String format = (String)map.get("DJNEWS_FORMAT_TYPE");

		    if (format.startsWith("XML"))
			map.put("DJNEWS_FILE_EXTENTION", ".xml");
		    else
			map.put("DJNEWS_FILE_EXTENTION", ".txt");

		    String dt = (String)map.get("DJNEWS_DELIVERY_TYPE");

		    if (dt.startsWith("contentdelay"))
			map.put("DJNEWS_TIMER","3600");

		    if (dt.startsWith("webservices"))
			map.put("DJNEWS_TIMER","10800");


		    saveFTPDistr(did,map);
		    
		} else {

		    System.out.println("Distributor "+did+" already has "
				       +extn+" extention. Skipping.");
		}

	    } catch (Exception e) {
		System.out.println("Error in retrieving distributor: "
				   +did+" configuration"
				   +e.toString());
		
	    }

	    map = null;
	}

    }



	

	public static void main(String[] args)
	{

		try {
		    StringBuffer userName = new StringBuffer();
		    StringBuffer hostList = new StringBuffer();
		    StringBuffer idsDir   = new StringBuffer();

		    String dcmlist = "DCMN11,DCMN12,DCMN13";

		    String platform = null;
		    if (args.length <= 0) {
			System.out.println("Usage: java -jar ConfigureExtention.java.jar platform [ dsp_host_list ]");
			System.exit(1);
		    }
		    else {
			if ( !args[0].equals("production")
				&& !args[0].equals("development") ) {
				System.out.println("Usage: java -jar ConfigureExtention.java.jar platform [ dsp_host_list ] [dcmid_list");
				System.out.println("platform is either production or development");
				System.exit(1);

			}
		    }

		    
		    if (args.length > 1) {
			userName.append("ids2adm");
			idsDir.append("/ids2");
			hostList.append(args[1]);
			if (args.length>2)
			    dcmlist = args[2];
		    } 
		    else {
			UILoginDialog dlg = new UILoginDialog(new javax.swing.JFrame(),true);
			dlg.show();
			if (!dlg.getLoginParams(userName,hostList,idsDir)) 
					System.exit(1);
		    }

		    platform = args[0];
		    System.out.println("Platform : "+platform);
		    System.out.println("Configuration host list: "
						+hostList.toString());
		    System.out.println("DCM List : "+dcmlist);

		    ConfigComm.initLoginLite(userName.toString(),
						 hostList.toString(),
						 idsDir.toString());

		    
		    addExtentions(dcmlist);

		}
		catch (Exception e) {
		    e.printStackTrace();
		}
		
		System.exit(0);


	}


}



/*
**  SCCS Info :  "@(#)DBRetryException.java	1.1    00/11/16"
*/
/*
 * DBRetryException.java
 *
 * Created on May 10, 2000, 4:57 PM
 */

package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DBRetryException extends RuntimeException {

  /**
   * Creates new <code>DBRetryException</code> without detail message.
   */
  public DBRetryException() {
  }
  

  /**
   * Constructs an <code>DBRetryException</code> with the specified detail message.
   * @param msg the detail message.
   */
  public DBRetryException(String msg) {
    super(msg);
  }
}


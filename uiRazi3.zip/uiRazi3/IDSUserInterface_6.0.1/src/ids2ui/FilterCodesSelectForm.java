/*
**  SCCS Info :  "@(#)FilterCodesSelectForm.java	1.10    04/04/01"
*/
/*
 * FilterCodesSelectForm.java
 *
 * Created on July 6, 2000, 11:45 AM
 */
 
package ids2ui;

import java.awt.Dialog;

/** 
 *
 * @author  srz
 * @version 
 */
public class FilterCodesSelectForm 
extends javax.swing.JFrame 
implements TaskListener, javax.swing.event.ListSelectionListener
{

    private FilterCodesSelectForm myFrame = null;

    private javax.swing.JTable codeTable=null;
    private FilterCodesDataModel codeModel=null;

    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();

    private volatile boolean isExiting = false;

  
  
    /** Creates new form FilterCodesSelectScreen */
    public FilterCodesSelectForm() {

	myFrame = this;



	setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	this.setModalExclusionType(Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
	initComponents ();
	myInitComponents();
        if ( AccessLevel.MENU_ACCESS_LEVEL != 0 ) {
                String action = jButton3.getActionCommand();
                jButton3.setText ("View");
                jButton3.setActionCommand(action);
                
                jButton2.setEnabled(false); //"Add"
                jButton5.setEnabled(false); //"Copy"
                jButton4.setEnabled(false); //"Delete"
        }
        
	pack ();
        
	WindowEventAdapter.getInstance()
	    .registerWindow(Constants.CONFIGURATION_FILTERCODES,this);
	updateTimer.start();

    }



    public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
	if (evt.getValueIsAdjusting()) return;

	int srows[] = codeTable.getSelectedRows();

	idTextF.getDocument().removeDocumentListener( docListener);

	if (srows.length!=1)
		idTextF.setText("");
	else
		idTextF.setText((String)codeTable.getValueAt(srows[0],0));

	idTextF.getDocument().addDocumentListener( docListener);
		

    }


    public void Refresh() {
        try {
	    if (codeModel!=null)
		codeModel.Update();
	} catch (Exception e){
	    Log.getInstance().log_error("FilterCodesSelectForm: Status update failed:",
					e);
	}
        
    }    
    

    
    /** Called when a task is scheduled to start. */
    public void taskStarted(java.util.EventObject event) {
	taskStarted("Updating filter list...");
    }


    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 

	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}
    }



    /** Called when a task ends. */
    public void taskEnded(java.util.EventObject event) {
	taskEnded((String)null);
    }

    public void taskEnded(final String s) {
	
	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);
	    else
		statusPanel.clear();

	    repaint();
	}

    }

    
    
    
    
    
    
    private void myInitComponents() 
    {

    codeModel = new FilterCodesDataModel();
    codeTable = new javax.swing.JTable(codeModel);
    
    codeTable.setPreferredScrollableViewportSize(new java.awt.Dimension(325,350));
  
    javax.swing.JScrollPane jScrollPane1 
      = new javax.swing.JScrollPane(codeTable);

    java.awt.GridBagConstraints gridBagConstraints1 
      = new java.awt.GridBagConstraints ();
    gridBagConstraints1.gridx = 0;
    gridBagConstraints1.gridy = 0;
    gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
    gridBagConstraints1.weightx = 1.0;
    gridBagConstraints1.weighty = 1.0;
    jPanel4.add (jScrollPane1, gridBagConstraints1);


    javax.swing.table.JTableHeader header = codeTable.getTableHeader();
    header.addMouseListener(((FilterCodesDataModel)codeTable.getModel()) .new ColumnListener(codeTable, rwLock));
    
	idTextF.getDocument().addDocumentListener( docListener );   
       
    	
	
	Utils.UpdateListener updater = new Utils.UpdateListener(rwLock,
									this,
									codeModel);

	
	updateTimer = new Utils.UpdateTimer(2*Constants.ServiceStatusUpdateMilliSecs,
					    updater);
	
	

	codeTable.getSelectionModel().addListSelectionListener(myFrame);
    

    }


    javax.swing.event.DocumentListener docListener = 
	 new javax.swing.event.DocumentListener() {
      
	    public void changedUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
	    public void insertUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
	    public void removeUpdate(javax.swing.event.DocumentEvent evt) {
		processEvent();
	    }
      
	    private  void processEvent(){        
		String id1 = idTextF.getText();
		int l1 = id1.length();

		codeTable.getSelectionModel().removeListSelectionListener(myFrame);


		for (int i = 0; i < codeTable.getRowCount(); i++) {
		    String id2
			= (String)((FilterCodesDataModel)codeTable.getModel()).getValueAt(i,0);
		    int l2 = id2.length();	  
		    if (l1<=l2 && l1>0  && (id2.substring(0,l1).equals(id1)))             
			codeTable.addRowSelectionInterval(i,i);
		    else
			codeTable.removeRowSelectionInterval(i,i);
		}
		if (!codeTable.getSelectionModel().isSelectionEmpty()) {
		    int row = codeTable.getSelectionModel().getMinSelectionIndex();
		    java.awt.Rectangle rowRect = codeTable.getCellRect(row, 0, true);
		    if (rowRect!=null) {
			rowRect.setSize( Integer.MAX_VALUE, (int)rowRect.getHeight());
			codeTable.scrollRectToVisible(rowRect);
		    }
		}

		codeTable.getSelectionModel().addListSelectionListener(myFrame);

	    }

	};   



    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel4 = new javax.swing.JPanel ();
          jPanel5 = new javax.swing.JPanel ();
          jLabel1 = new javax.swing.JLabel ();
          idTextF = new ids2ui.UCTextField ();
          jPanel1 = new javax.swing.JPanel ();
          jPanel2 = new javax.swing.JPanel ();
          jButton2 = new javax.swing.JButton ();
          jButton5 = new javax.swing.JButton ();
          jButton3 = new javax.swing.JButton ();
          jButton4 = new javax.swing.JButton ();
          jPanel3 = new javax.swing.JPanel ();
          jButton1 = new javax.swing.JButton ();
          statusPanel = new ids2ui.StatusPanel ();
          getContentPane ().setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;
          setTitle ("Filter Codes Main Screen");
          addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
              exitForm (evt);
            }
          }
          );

          jPanel4.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
          jPanel4.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
          new javax.swing.border.EtchedBorder()));
          jPanel4.setMinimumSize (new java.awt.Dimension(306, 350));

            jPanel5.setLayout (new java.awt.FlowLayout (0, 5, 5));
  
              jLabel1.setText ("ID");
    
              jPanel5.add (jLabel1);
    
              idTextF.setColumns (16);
    
              jPanel5.add (idTextF);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 1;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
            gridBagConstraints2.weightx = 1.0;
            jPanel4.add (jPanel5, gridBagConstraints2);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 0;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 1.0;
          gridBagConstraints1.weighty = 1.0;
          getContentPane ().add (jPanel4, gridBagConstraints1);

          jPanel1.setLayout (new javax.swing.BoxLayout (jPanel1, 1));
          jPanel1.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
          new javax.swing.border.EtchedBorder()));

            jPanel2.setLayout (new java.awt.FlowLayout (1, 25, 5));
            jPanel2.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
  
              jButton2.setText ("Add");
              jButton2.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tableActionHandler (evt);
                }
              }
              );
    
              jPanel2.add (jButton2);
    
              jButton5.setText ("Copy");
              jButton5.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tableActionHandler (evt);
                }
              }
              );
    
              jPanel2.add (jButton5);
    
              jButton3.setText ("Modify");
              jButton3.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tableActionHandler (evt);
                }
              }
              );
    
              jPanel2.add (jButton3);
    
              jButton4.setText ("Delete");
              jButton4.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tableActionHandler (evt);
                }
              }
              );
    
              jPanel2.add (jButton4);
    
            jPanel1.add (jPanel2);
  
  
              jButton1.setText ("Close");
              jButton1.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  closeForm (evt);
                }
              }
              );
    
              jPanel3.add (jButton1);
    
            jPanel1.add (jPanel3);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (jPanel1, gridBagConstraints1);



          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (statusPanel, gridBagConstraints1);

        }//GEN-END:initComponents

    private void closeForm (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeForm
	// Add your handling code here:
	exitForm(null);
    }//GEN-LAST:event_closeForm

    private void tableActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tableActionHandler
	// Add your handling code here:
	String command = evt.getActionCommand();

	Object src = evt.getSource();
        javax.swing.JButton source = null;

	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, 
                command) {
	    public Object construct() {
		_tableActionHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();

    }//GEN-LAST:event_tableActionHandler


    private void _tableActionHandler(javax.swing.JButton cmdButton, 
				     String command)
    {

	if (command.equals("Add")) {
	    new FilterCodesConfigForm(this,null,true).show();
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;
	}

	int srows[] = codeTable.getSelectedRows();
	if (srows.length == 0 ) {
	    Log.getInstance().show_warning(this,"Error",
				"Please select a filter code from the list",
					   null);
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;

	} else if (srows.length>1) {
	    Log.getInstance().show_warning(this,"Error",
				"Please select only one filter code.",
					   null);
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;

	}

	String tag = (String)codeTable.getValueAt(srows[0],0);

	if (command.equals("Modify")) {
	    javax.swing.JDialog f =
		(javax.swing.JDialog)WindowEventAdapter.getInstance()
		.findWindow(Constants.CONFIGURATION_FILTERCODE_PREFIX+tag);
	    if (f == null)
		f = new FilterCodesConfigForm(this,tag,false);

	    f.show();
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;
	}

	if (command.equals("Copy")) {
	    javax.swing.JDialog f =
		  new FilterCodesConfigForm(this,tag,true);

	    f.show();
	    if (cmdButton!=null) cmdButton.setEnabled(true);
	    return;
	}


	try {
	    rwLock.readLock().acquire();
	} catch (InterruptedException ie ) {
	    Log.getInstance().log_error("Service handler interrupted",ie);
	    if (cmdButton != null ) 
		cmdButton.setEnabled(true);
	    return;
	}

	


    deleteblock:
	if (command.equals("Delete")) {

	    if (javax.swing.JOptionPane.YES_OPTION !=
      		Log.getInstance().show_confirm(this,"Confirm delete",
					       "Are you sure you want to "
					   +"delete filter configuration ?."))
		break deleteblock;

	    StringBuffer reqbuf = new StringBuffer();
		
	    ConfigComm.getServKey(reqbuf,
				  ConfigComm.GET_DISTRIBUTORS_USING_FILTER,
				  tag);

	    try { 
		byte[] b = ConfigComm.configRequest(reqbuf);
	    } catch (Exception e ) {
		if (e instanceof DBException) {
		    if (((DBException)e).getErrorNo() == Constants.KEY_IN_USE){
			Log.getInstance().show_error(this,"Error",
						     "Cannot delete "+tag
						     +".\nIt is in use by "
						     +"distributors.",
						     e);
			break deleteblock;
		    }
		}
		Log.getInstance().show_error(this,"Error",
					     "Cannot delete "+tag
					     +".\nError in checking if filter "
					     +"is in use.",
					     e);
		break deleteblock;

	    }


	    reqbuf = new StringBuffer();
	    ConfigComm.deleteKeyValue(reqbuf,
				      Constants.GLB_TAG_FILTERCODE_PREFIX+tag);

	    FilterCodesConfigForm f = 
		(FilterCodesConfigForm)WindowEventAdapter.getInstance()
		.findWindow(Constants.CONFIGURATION_FILTERCODE_PREFIX+tag);

	    if (f != null) {
		f.exitForm(null);
	    }


	    try {
		byte[] b;
		ConfigComm.configRequest(reqbuf);
		FilterCodesDataModel model = 
		    (FilterCodesDataModel) codeTable.getModel();
		model.deleteRow(tag);
	    } catch (Exception e) {
      		Log.getInstance().show_error(this,
					     "Error",
					     "Error in deleting filter code"
					     +" "+tag,e);
		break deleteblock;
		
	    }

	} // Delete


	rwLock.readLock().release();
	if (cmdButton!=null) cmdButton.setEnabled(true);

    }

    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
	
	if (isExiting) return;

	isExiting = true;

	if (updateTimer!=null)
	    updateTimer.stop();

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final FilterCodesSelectForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();
		    codeModel.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();

	




    }//GEN-LAST:event_exitForm

    /**
     * @param args the command line arguments
     */
    public static void main (String args[]) {
	new FilterCodesSelectForm ().show ();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel jLabel1;
    private ids2ui.UCTextField idTextF;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton jButton1;
    private ids2ui.StatusPanel statusPanel;
    // End of variables declaration//GEN-END:variables

    
}

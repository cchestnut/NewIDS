
/*
**  SCCS Info :  "@(#)IOUtil.java	1.1    03/09/16"
*/
  package ids2ui;
  import java.io.IOException;
  import java.io.InputStream;
  import java.io.OutputStream;
  
  /****
   ***/
  
  public final class IOUtil
  {
  
      public static final void readWrite(final InputStream remoteInput,
                                         final OutputStream remoteOutput,
                                         final InputStream localInput,
                                         final OutputStream localOutput)
      {
          Thread reader, writer;
  
          reader = new Thread()
                   {
                       public void run()
                       {
                           int ch;
  
                           try
                           {
                               while (!interrupted() && (ch = localInput.read()) != -1)
                               {
                                   remoteOutput.write(ch);
                                   remoteOutput.flush();
                               }
                           }
                           catch (IOException e)
                           {
                              //e.printStackTrace();
                          }
                      }
                  }
                  ;
 
 
         writer = new Thread()
                  {
                      public void run()
                      {
			  
                          try
                          {
                              Util.copyStream(remoteInput, localOutput);
                          }
                          catch (IOException e)
                          {
                              e.printStackTrace();
                              System.exit(1);
                          }
                      }
                  };
 
 
         writer.setPriority(Thread.currentThread().getPriority() + 1);
 
         writer.start();
         if (localInput!=null) {
                 reader.setDaemon(true);
                 reader.start();
         }
         
 
         try
         {
             writer.join();
             if (localInput!=null)
                     reader.interrupt();
         }
         catch (InterruptedException e)
         {
         }
     }
 
 }
 





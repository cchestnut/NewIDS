/*
**  SCCS Info :  "@(#)ConfigureFTP.java	1.1    03/03/07"
*/


package ids2ui;
import java.io.*;
import java.util.*;


public class ConfigureFTP {

	public ConfigureFTP(){}


    static String FTPProds[] = { "DN", "LL", "SN" };
    static HashMap  productCodes = null;

    static void addTokens(HashMap map, String[] tokens, int nt) 
    throws Exception
    {

	int type,index;
	int FTP_PULL = 1;
	int HTTP_PULL = 2;
	int FTP_PUSH = 3;


	if (!tokens[1].equals("-")) {
	    map.put("ID",tokens[1]);
	    map.put("TAG","GLB_TAG_DCM_"+tokens[3]);
	}



	String desc = (String)map.get("DESCRIPTION");

	if (desc == null)
	    desc = tokens[0]+":"+tokens[2];
	else
	    desc += (" "+tokens[0]+":"+tokens[2]);
	
	map.put("DESCRIPTION",desc);


	if (tokens[4].equals("FTP Push")) {
	    map.put("DJNEWS_DELIVERY_METHOD", "DJNEWS_PUSH");
	    type = FTP_PUSH;
	} else if (tokens[4].equals("HTTP")) {
	    map.put("DJNEWS_DELIVERY_METHOD", "DJNEWS_HTTP");
	    type = HTTP_PULL;
	} else if (tokens[4].equals("FTP Pull")) {
	    map.put("DJNEWS_DELIVERY_METHOD", "DJNEWS_PULL");
	    type = FTP_PULL;
	} else
	    throw new Exception("Unknown DJNEWS_DELIVERY_METHOD token: "+tokens[4]);
	if (  (type == FTP_PULL) 
	      || (type == HTTP_PULL) )
	    index = 7;
	else
	    index = 6;

	if (tokens[index].equals("Story Only"))
	    map.put("DJNEWS_CONTENT_TYPE", "STORY_ONLY");
	else if (tokens[index].equals("Headline Only"))
	    map.put("DJNEWS_CONTENT_TYPE", "HEADLINE_ONLY");
	else if (tokens[index].equals("Both"))
	    map.put("DJNEWS_CONTENT_TYPE", "STORY_AND_HEADLINE");
	else
	    throw new Exception("Unknown DJNEWS_CONTENT_TYPE token: '"
				+tokens[index]+"'");


	if (  (type == FTP_PULL) 
	      || (type == HTTP_PULL) )
	    index = 9;
	else
	    index = 8;



	if (tokens[index].equals("1")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "compressed");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_PRECHAINED");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_FIRST_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.FALSE.toString());
	} else if (tokens[index].equals("2")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "compressed");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_PRECHAINED");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.TRUE.toString());
	} else if (tokens[index].equals("3")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "compressed");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_PRECHAINED");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.FALSE.toString());
	} else if (tokens[index].equals("4")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "compressed");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_SINGLE_TAKE");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.TRUE.toString());
	} else if (tokens[index].equals("5")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "compressed");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_SINGLE_TAKE");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.FALSE.toString());
	} else if (tokens[index].equals("6")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "webservices");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_PRECHAINED");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.TRUE.toString());
	} else if (tokens[index].equals("7")) {
	    map.put("DJNEWS_DELIVERY_TYPE", "webservices");
	    map.put("DJNEWS_TAKE_TYPE", "DJNEWS_PRECHAINED");
	    map.put("DJNEWS_FILE_GENERATION_TYPE", 
		    "DJNEWS_FILENAME_CURRENT_TAKE");
	    map.put("DJNEWS_SEND_CHANGES", Boolean.FALSE.toString());
	} else 
	    throw new Exception("Unknown Type token: "+tokens[index]);


	if (  (type == FTP_PULL) 
	      || (type == HTTP_PULL) )
	    index = 10;
	else
	    index = 9;

	String timer = Integer.toString(Integer.parseInt(tokens[index])*60);
	map.put("DJNEWS_TIMER", timer);


	if (  (type == FTP_PULL) 
	      || (type == HTTP_PULL) )
	    index = 11;
	else
	    index = 10;
	
	if (tokens[index].equals("Plain With <P>"))
	    map.put("DJNEWS_FORMAT_TYPE", "PLAINWITHP");
	else if (tokens[index].equals("Plain"))
	    map.put("DJNEWS_FORMAT_TYPE", "PLAIN");
	else if (tokens[index].equals("XMLTag")
		 || tokens[index].equals("XML") )
	    map.put("DJNEWS_FORMAT_TYPE", "XMLTAG");
	else
	    throw new Exception("Unknown DJNEWS_FORMAT_TYPE token: "+tokens[index]);

	index++;

	map.put("DJNEWS_FORMAT_ENCODING", tokens[index]);



	

	String nps = (String)map.get(Constants.FTP_NUM_ENTRIES);
	
	int np = 0;
	if (nps == null)
	    np = 0;
	else
	    np = Integer.parseInt(nps);
	
	if (type == FTP_PULL) {
	    

	    index = 15;

	    for (int ns = 1; ns <=2 ; ns++) {
		map.put(Constants.FTP_SERVER_PREFIX+np,
			"proxy.mcn.dowjones.com");
		map.put(Constants.FTP_PORT_PREFIX+np,"21");
		if (ns==1)
		    map.put(Constants.FTP_USERNAME_PREFIX+np,
			    tokens[index]+"@ftp.dowjones.com");
		else
		    map.put(Constants.FTP_USERNAME_PREFIX+np,
			    tokens[index]+"@ftp2.dowjones.com");
		
		map.put(Constants.FTP_PASSWORD_PREFIX+np,tokens[index+1]);

		//map.put(Constants.FTP_PASSIVE_MODE_PREFIX+np,);
		//map.put(Constants.FTP_TRANSFER_MODE_PREFIX+np,);
		//map.put(Constants.FTP_STATISTICS_FILE_PREFIX+np,);

		if (!tokens[index+2].equals("-"))
		    map.put(Constants.FTP_REMOTE_DIR_PREFIX+np,tokens[index+2]);
		np++;
	
		//map.put(Constants.FTP_RENAME_FILE_PREFIX+np,);
	    }

	} else if (type == HTTP_PULL) {

	    index = 13;


	    for (int ns = 1; ns <=2 ; ns++) {

		map.put(Constants.FTP_SERVER_PREFIX+np,
			"proxy.mcn.dowjones.com");
		map.put(Constants.FTP_PORT_PREFIX+np,"21");
		if (ns==1)
		    map.put(Constants.FTP_USERNAME_PREFIX+np,
			    tokens[index]+"@ftp.dowjones.com");
		else
		    map.put(Constants.FTP_USERNAME_PREFIX+np,
			    tokens[index]+"@ftp2.dowjones.com");
		
		map.put(Constants.FTP_PASSWORD_PREFIX+np,tokens[index+1]);

		//map.put(Constants.FTP_PASSIVE_MODE_PREFIX+np,);
		//map.put(Constants.FTP_TRANSFER_MODE_PREFIX+np,);
		//map.put(Constants.FTP_STATISTICS_FILE_PREFIX+np,);
		//map.put(Constants.FTP_REMOTE_DIR_PREFIX+np,tokens[11]);
		//map.put(Constants.FTP_RENAME_FILE_PREFIX+np,);

		np++;
	    }

	} else if (type == FTP_PUSH ) {

	    index = 12;

	    map.put(Constants.FTP_SERVER_PREFIX+np,tokens[index]);
	    map.put(Constants.FTP_PORT_PREFIX+np,tokens[index+1]);
	    map.put(Constants.FTP_USERNAME_PREFIX+np,tokens[index+2]);
	    map.put(Constants.FTP_PASSWORD_PREFIX+np,tokens[index+3]);


	    String dir = tokens[index+4];
	    if (!dir.equals("-"))
		map.put(Constants.FTP_REMOTE_DIR_PREFIX+np,dir);

	    int pm = Integer.parseInt(tokens[index+5]);
	    String passive = (pm==1)
		?(Boolean.TRUE.toString()):(Boolean.FALSE.toString());
		
	    map.put(Constants.FTP_PASSIVE_MODE_PREFIX+np,passive);

	    //map.put(Constants.FTP_TRANSFER_MODE_PREFIX+np,);
	    //map.put(Constants.FTP_STATISTICS_FILE_PREFIX+np,);
	    //map.put(Constants.FTP_RENAME_FILE_PREFIX+np,);
	    np++;
	    
	}

	map.put(Constants.FTP_NUM_ENTRIES,Integer.toString(np));

	if (type == FTP_PULL) 
	    index = 19;
	else if (type == HTTP_PULL)
	    index = 15;
	else
	    index = 18;
	
	String  filter = (String)map.get("FILTER_CODES");
	if (filter == null)
	    filter = tokens[index];
	else
	    filter = "("+filter+") | ("+tokens[index]+")";

	map.put("FILTER_CODES",filter);

	


    }





    public static HashMap loadProductCodes(String file) 
    throws Exception {

	
	java.io.LineNumberReader fileReader
	    = new java.io.LineNumberReader(
			new java.io.InputStreamReader(
			ConfigureFTP.class.getResourceAsStream(file)));

	
	//java.io.LineNumberReader fileReader = new java.io.LineNumberReader(new FileReader(file));
		
	char	COMMENT = '#';
	String line = null;
	StringBuffer reqbuf = new StringBuffer();
	byte [] b;

	HashMap map = new HashMap(50);
	
	while ( (line = fileReader.readLine()) != null) {
	    
	    if ( (line.trim().length()==0)
		 || (line.charAt(0)==COMMENT) )
		continue;
	    
	    int index = line.indexOf("\t");
	    
	    if (index > 0) {
		
		String key = line.substring(0,index).trim();
		String value = line.substring(index+1);
		
		map.put(key,value);
		
	    }
	}

	return map;
    }
    
    



    public static void replace(StringBuffer sb, String srcpat, String destpat) {
	int inx = sb.toString().indexOf(srcpat);
	while (inx >= 0) {
	    sb.replace(inx,inx+srcpat.length(), destpat);
	    inx = sb.toString().indexOf(srcpat);
	}

    }

    public static int replaceCodes(HashMap productCodes, StringBuffer sb) {


	Iterator iter = productCodes.keySet().iterator();

	while (iter.hasNext()) {
	    String key = (String)iter.next();
	    String srcpat = "/~"+key;
	    String destpat = (String)productCodes.get(key);
	    int inx = sb.toString().indexOf(srcpat);
	    while (inx >= 0) {
		sb.replace(inx,inx+srcpat.length(), destpat);
		inx = sb.toString().indexOf(srcpat);
	    }
	}


	if (sb.toString().indexOf("/~") > 0)
	     return 1;


	 return 0;
    }

    public static void processFilterCodes(String ID, String codes, StringBuffer codebuf) 
    throws Exception {

	codebuf.append(codes);

	replace(codebuf," AND "," & ");
	replace(codebuf," OR "," | ");
	replace(codebuf," NOT "," ! ");

	if (productCodes == null)
	    productCodes = loadProductCodes("config/ProductCodes.txt");

	
	if (replaceCodes(productCodes,codebuf)!= 0)
	    System.out.println("Filter:"+ID+" All product codes NOT replaced");

	codebuf.insert(0,"( ");
	codebuf.append(" ) & ( !")
		.append((String)productCodes.get("FF"))
		.append(" )");
    }



    static HashMap dcmPorts = new HashMap(3);
    static int BasePort = 35000;
	
	static public void saveFTPDistr(HashMap map) 
    throws Exception
    {

	    String ID = (String)map.get("ID");
	    StringBuffer savebuf = new StringBuffer();

	    String hostTag = (String)map.get("TAG");
	    String desc = (String)map.get("DESCRIPTION");
	    String ckptPort = Constants.DEFAULT_DISTR_CHECKPOINT_STRING;
	    String ctype = Constants.DJNEWS_CONFIGURATION;

	    String port = (String)dcmPorts.get("PORTS");
	    int p = BasePort;
	    if (port != null){
		p = Integer.parseInt(port);
		p++;
	    }
	    port = Integer.toString(p);

	    dcmPorts.put("PORTS",port);

	    StringBuffer transport  = new StringBuffer("TRANSPORT");
	    transport.append(ConfigComm.CONF_RS)
		.append("TCPSA localhost:")
		.append(port)
		.append(ConfigComm.CONF_RS);

	    savebuf.append(ConfigComm.CONF_RS)
		.append("TAG").append(ConfigComm.CONF_RS)
		.append(hostTag).append(ConfigComm.CONF_RS)
		.append(transport.toString()).append(ConfigComm.CONF_RS)
		.append("KEEPALIVE_1").append(ConfigComm.CONF_RS)
		.append("-").append(ConfigComm.CONF_RS)
		.append("STATISTICS_1").append(ConfigComm.CONF_RS)
		.append("NONE").append(ConfigComm.CONF_RS)
		.append("KEEPALIVE_2").append(ConfigComm.CONF_RS)
		.append("-").append(ConfigComm.CONF_RS)
		.append("STATISTICS_2").append(ConfigComm.CONF_RS)
		.append("NONE").append(ConfigComm.CONF_RS)
		.append("DESCRIPTION").append(ConfigComm.CONF_RS)
		.append(desc).append(ConfigComm.CONF_RS)
		.append("CHECKPOINT").append(ConfigComm.CONF_RS)
		.append(ckptPort).append(ConfigComm.CONF_RS)
		.append("CONFIGURATION_TYPE").append(ConfigComm.CONF_RS)
		.append(ctype).append(ConfigComm.CONF_RS);


	    StringBuffer prods = new StringBuffer();
	    String Format = "DJI";
	    String ProdDelay = "0";
	    String FreeWheel = Boolean.FALSE.toString();
	    String Codes = ID;

	    for (int np = 0; np < FTPProds.length; np++) {
		prods.append(ConfigComm.CONF_US).append(FTPProds[np])
		    .append(ConfigComm.CONF_US).append(Format)
		    .append(ConfigComm.CONF_US).append(ProdDelay)
		    .append(ConfigComm.CONF_US).append(FreeWheel)
		    .append(ConfigComm.CONF_US).append(Codes)
		    .append(ConfigComm.CONF_US);
	    }

	    savebuf.append("PRODUCTS_1")
		.append(ConfigComm.CONF_RS)
		.append(prods)
		.append(ConfigComm.CONF_RS);


	    savebuf.append("PRODUCTS_2")
		.append(ConfigComm.CONF_RS)
		.append(prods)
		.append(ConfigComm.CONF_RS);

	    String sendChanges = (String)map.get("DJNEWS_SEND_CHANGES");
	    String contentType = (String)map.get("DJNEWS_CONTENT_TYPE");
	    String ftpDelay = (String)map.get("DJNEWS_TIMER");
	    String ftpDeliveryType = (String)map.get("DJNEWS_DELIVERY_TYPE");
	    String ftpFormatType = (String)map.get("DJNEWS_FORMAT_TYPE");
	    String formatEncoding =(String)map.get("DJNEWS_FORMAT_ENCODING");
	    String ftpDeliveryMethod = (String)map.get("DJNEWS_DELIVERY_METHOD");
	    String ftpFileGenType = (String)map.get("DJNEWS_FILE_GENERATION_TYPE");
	    String ftpTakeType = (String)map.get("DJNEWS_TAKE_TYPE");
	    
	    savebuf.append("DJNEWS_SEND_CHANGES").append(ConfigComm.CONF_RS)
		.append(sendChanges).append(ConfigComm.CONF_RS)
		.append("DJNEWS_CONTENT_TYPE").append(ConfigComm.CONF_RS)
		.append(contentType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_TIMER").append(ConfigComm.CONF_RS)
		.append(ftpDelay).append(ConfigComm.CONF_RS)
		.append("DJNEWS_DELIVERY_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpDeliveryType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_FORMAT_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpFormatType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_DELIVERY_METHOD").append(ConfigComm.CONF_RS)
		.append(ftpDeliveryMethod).append(ConfigComm.CONF_RS)
		.append("DJNEWS_TAKE_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpTakeType).append(ConfigComm.CONF_RS)
		.append("DJNEWS_FILE_GENERATION_TYPE").append(ConfigComm.CONF_RS)
		.append(ftpFileGenType).append(ConfigComm.CONF_RS);


	    if (ftpFormatType.startsWith("XML"))
		savebuf.append("DJNEWS_FORMAT_ENCODING")
		    .append(ConfigComm.CONF_RS)
		    .append(formatEncoding)
		    .append(ConfigComm.CONF_RS);




	    int numParams = -1;
	    String numPars =(String)map.get(Constants.FTP_NUM_ENTRIES);

	    try {
		numParams = Integer.parseInt(numPars);
	    } catch (Exception e){}
	    for (int np = 0; np < numParams; np++) {
		String ftpServer = (String)map.get(Constants.FTP_SERVER_PREFIX+np);
		String ftpPort = (String)map.get(Constants.FTP_PORT_PREFIX+np);
		String ftpUser = (String)map.get(Constants.FTP_USERNAME_PREFIX+np);
		String ftpPassword = (String)map.get(Constants.FTP_PASSWORD_PREFIX+np);
		
		String ftpPassiveMode = (String)map.get(Constants.FTP_PASSIVE_MODE_PREFIX+np);
		String ftpTransferMode = (String)map.get(Constants.FTP_TRANSFER_MODE_PREFIX+np);
		String ftpStatistics = (String)map.get(Constants.FTP_STATISTICS_FILE_PREFIX+np);
		
		
		String ftpRemoteDir = (String)map.get(Constants.FTP_REMOTE_DIR_PREFIX+np);
		String ftpRenameFile = (String)map.get(Constants.FTP_RENAME_FILE_PREFIX+np);
		
		
		
		savebuf.append(Constants.FTP_SERVER_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpServer)
		    .append(ConfigComm.CONF_RS)
		    .append(Constants.FTP_PORT_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpPort)
		    .append(ConfigComm.CONF_RS)
		    .append(Constants.FTP_USERNAME_PREFIX+np)
		    .append(ConfigComm.CONF_RS)
		    .append(ftpUser).append(ConfigComm.CONF_RS);
		
		if ((ftpPassword!=null) && (ftpPassword.length()>0))
		    savebuf.append(Constants.FTP_PASSWORD_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpPassword)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpPassiveMode!=null) && (ftpPassiveMode.length()>0))
		    savebuf.append(Constants.FTP_PASSIVE_MODE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpPassiveMode)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpTransferMode!=null) && (ftpTransferMode.length()>0))
		    savebuf.append(Constants.FTP_TRANSFER_MODE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpTransferMode)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpStatistics!=null) && (ftpStatistics.length()>0))
		    savebuf.append(Constants.FTP_STATISTICS_FILE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpStatistics)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpRemoteDir!=null) && (ftpRemoteDir.length()>0))
		    savebuf.append(Constants.FTP_REMOTE_DIR_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpRemoteDir)
			.append(ConfigComm.CONF_RS);
		
		if ((ftpRenameFile!=null) && (ftpRenameFile.length()>0))
		    savebuf.append(Constants.FTP_RENAME_FILE_PREFIX+np)
			.append(ConfigComm.CONF_RS)
			.append(ftpRenameFile)
			.append(ConfigComm.CONF_RS);
		
	    } // for np = 

	    savebuf.append(Constants.FTP_NUM_ENTRIES)
		.append(ConfigComm.CONF_RS)
		.append(numPars)
		.append(ConfigComm.CONF_RS);
	    

	    StringBuffer reqbuf = new StringBuffer();

      
	    ConfigComm.saveDistrTag(reqbuf,ID,savebuf.toString(),
				    true);


	    //System.out.println("Saving : "+ID);

	    //System.out.println("Save Buffer: "+reqbuf.toString());
	    byte [] b ;
	    b = ConfigComm.configRequest(reqbuf);


	    
	    String codes = (String)map.get("FILTER_CODES");
	    

	    FileWriter fw = new FileWriter(ID+"_before.codes");
	    fw.write(codes);
	    fw.close();


	    StringBuffer codebuf = new StringBuffer();
	    processFilterCodes(ID,codes, codebuf);

	    

	    fw = new FileWriter(ID+"_after.codes");
	    fw.write(codebuf.toString());
	    fw.close();


	    reqbuf.setLength(0);
	    ConfigComm.getServKey(reqbuf,
				  ConfigComm.VALIDATE_FILTER_STRING,
				  codebuf.toString());

	    b = ConfigComm.configRequest(reqbuf);
	    
	    String rbuf = new String(b);
	    int index = rbuf.indexOf(ConfigComm.CONF_STX) +1;
	    StringBuffer separator = new StringBuffer();
	    
	    String databuf = rbuf.substring(index);
	    separator.append(ConfigComm.CONF_ETX)
		.append(ConfigComm.CONF_US)
		.append(ConfigComm.CONF_FS);
	    
	    java.util.StringTokenizer st =
		new java.util.StringTokenizer(databuf,
					      separator.toString());
	    int ret = -1;
	    if (st.hasMoreTokens()) {
		String s = st.nextToken();
		try {
		    ret = Integer.parseInt(s);
		} catch (Exception e){ e.printStackTrace();}
	    }
	    if (ret != 0) {
		String errStr = null;
		if (st.hasMoreTokens()) 
		    errStr =  st.nextToken();
		System.out.println("Filter:"+ID+" Syntax error: \n"+errStr);
	    }
	    


	    reqbuf.setLength(0);
	    ConfigComm.addFilterCode(reqbuf,ID,"Filter for "+ID,
				     codebuf.toString(),true);
	    b = ConfigComm.configRequest(reqbuf);


	}


    static public void loadFTP_CSV(String file)
		throws Exception
	{

	    
	    String tokens[] = new String[25];


	   
	    java.io.LineNumberReader fileReader
		= new java.io.LineNumberReader(
				new java.io.InputStreamReader(
				ConfigureFTP.class.getResourceAsStream(file)));

	    


	    //System.out.println("Opening file : "+file);
	    //java.io.LineNumberReader fileReader
	//	= new java.io.LineNumberReader(new FileReader(file));


		
		char	COMMENT = '#';
		String line = null;
		StringBuffer reqbuf = new StringBuffer();
		byte [] b;

		java.util.HashMap map = new java.util.HashMap(50);

		while ( (line = fileReader.readLine()) != null) {
			
			if ( (line.trim().length()==0)
				|| (line.charAt(0)==COMMENT) )
				continue;

		

			
			String value = line;
			


			StringTokenizer st = new StringTokenizer(value,",");
			
			int nt = st.countTokens();
			if (nt > tokens.length) {
			    throw new IndexOutOfBoundsException("Too many tokens: "+nt);
			}
			
			for (int i = 0; i < nt; i++)
			    tokens[i] = st.nextToken();
			
			
			
			if (!tokens[1].equals("-")
			    && (map.size()>0) ) {
			    saveFTPDistr(map);
			    map.clear();
			}
			try {
			    addTokens(map,tokens,nt);
			} catch (Exception e) {
			    e.printStackTrace();
			    map.clear();
			}
			
		}


		if (!tokens[1].equals("-")
		    && (map.size()>0) ) {
		    saveFTPDistr(map);
		    map.clear();
		}
	}







	

	public static void main(String[] args)
	{

		try {
		    StringBuffer userName = new StringBuffer();
		    StringBuffer hostList = new StringBuffer();
		    StringBuffer idsDir   = new StringBuffer();
		    
		    String platform = null;
		    if (args.length <= 0) {
			System.out.println("Usage: java -jar ConfigureFTP.jar platform [ dsp_host_list ]");
			System.exit(1);
		    }
		    else {
			if ( !args[0].equals("production")
				&& !args[0].equals("development") ) {
				System.out.println("Usage: java -jar ConfigureFTP.jar platform [ dsp_host_list ]");
				System.out.println("platform is either production or development");
				System.exit(1);

			}
		    }

		    
		    if (args.length > 1) {
			userName.append("ids2adm");
			idsDir.append("/ids2");
			hostList.append(args[1]);
		    } 
		    else {
			UILoginDialog dlg = new UILoginDialog(new javax.swing.JFrame(),true);
			dlg.show();
			if (!dlg.getLoginParams(userName,hostList,idsDir)) 
					System.exit(1);
		    }

		    platform = args[0];
		    System.out.println("Platform : "+platform);
		    System.out.println("Configuration host list: "
						+hostList.toString());

		    ConfigComm.initLoginLite(userName.toString(),
						 hostList.toString(),
						 idsDir.toString());

		    
		    loadFTP_CSV("config/FTPData.csv");

		}
		catch (Exception e) {
		    e.printStackTrace();
		}
		
		System.exit(0);


	}


}



/*
**  SCCS Info :  "@(#)DCMDistributorConfigCache.java	1.3    04/05/10"
*/
/*
 * DCMDistributorConfig.java
 *
 * Created on Apr 07, 2007, 5:08 PM
 */
 
package ids2ui;
import java.util.*;



/** 
 *
 * @author  srz
 * @version 
 */
public class DCMDistributorConfigCache
{
        
        private static java.util.TreeMap       t_dcmList = new java.util.TreeMap();
        private static java.util.HashMap       t_hostmap = new java.util.HashMap(20);
	private static java.util.Vector        t_vector = new java.util.Vector(500);
	private static java.util.HashMap       t_distrData = new java.util.HashMap(500);

        private static java.util.HashMap       t_hostmap_buf = new java.util.HashMap(20);
	private static java.util.Vector        t_vector_buf = new java.util.Vector(500);
	private static java.util.HashMap       t_distrData_buf = new java.util.HashMap(500);

        
        static boolean              done = false;

        static final String     ALL_DCMS = "__ALL__";
        
        static Exception               configException = null;

        static ConfigLoader            loaderThread = null;
        static protected int 		m_columnsCount = 
                                	Constants.DistributorStatusTableColumnNames.length;


        static java.util.HashMap       listeners = new java.util.HashMap();
        static String                  last_update_dcmlist = "";
        


                
        public static void
        subscribe(Object o, String dlist) 
        {
                synchronized (t_dcmList) {
                        Object[] a = new Object[2];
                        a[0] = dlist;
                        a[1] = new Long(System.currentTimeMillis());
                        listeners.put(o, a);
                
                        updateDCMList_nolock(true);
                }
        }
        
                  
        public static void
        unsubscribe(Object o) 
        {
                synchronized (t_dcmList) {
                        listeners.remove(o);
                }
                updateDCMList(false);
        }



        public static void
        force_update()
        {

                if (Constants.DEBUG && (Constants.Verbose > 1))
                        System.out.println("Forcing update..");
                
                synchronized (t_dcmList) {
                        t_dcmList.notifyAll();
                }
        }
        







        private static void copyData(String dlist,
                                       java.util.Vector  src_vector,
                                       java.util.HashMap src_distrData,
                                       java.util.HashMap src_hostmap,
                                       java.util.Vector  dst_vector,
                                       java.util.HashMap dst_distrData,
                                       java.util.HashMap dst_hostmap
                                     )
        {
                        
                    /*
                    ** Copy ONLY the required entries based on dlist
                    */
                if (dlist == null) {
                        dst_vector.addAll(src_vector);
                        dst_distrData.putAll(src_distrData);
                        dst_hostmap.putAll(src_hostmap);
                }
                else {
                        int size = src_vector.size();
                        
                        for (int i = 0; i < size; i++) {
                                String[] row = (String[]) src_vector.get(i);
                                String did = row[0];
                                String dcm = row[1];
                                
                                if (Constants.matchPattern(dlist,
                                                           ",", dcm)) {
                                        
                                        dst_vector.add(row);
                                        
                                        String []host_data
                                                = (String [])src_distrData.get(did);
                                        dst_distrData.put(did, host_data);
                                        
                                        
                                        DistrHostData distrHostData
                                                = (DistrHostData)src_hostmap.get(dcm);
                                        dst_hostmap.put(dcm, distrHostData);
                                        
                                }
                        }
                }
                
        }









        
        
        public static boolean  getData(Object listener, boolean blockWhileLoading,
                                       java.util.Vector u_vector,
                                       java.util.HashMap u_distrData,
                                       java.util.HashMap u_hostmap)
        {

                boolean entry_found = true;
                String dlist = "";
                
                synchronized (t_dcmList) {
                        Object[] a = (Object[]) listeners.get(listener);
                        if (a != null) {
                                String s = (String)a[0];
                                if (s!=null)
                                        dlist = new String(s);
                                else
                                        dlist = null;
                                
                                a[1] = new Long(System.currentTimeMillis());
                                listeners.put(listener, a);
                        } else
                                entry_found = false;
                        
                }


                
                if (  (!entry_found)
                        || ( (dlist!=null)  && (dlist.length()==0)) )
                        return false;


                

                if (blockWhileLoading) {
                            //System.out.println("*** Blocked get Data ***");
                        
                        boolean update;
                        
                        synchronized(t_vector) {
                                update = updateDCMList(true);
                        }
                        if (update)
                                Thread.yield();
                        
                        synchronized(t_vector) {
                                copyData(dlist, t_vector, t_distrData, t_hostmap,
                                         u_vector, u_distrData, u_hostmap);
                        }
                }
                else {
                            //System.out.println("*** Async get Data ***");
                        
                        synchronized(t_vector_buf) {
                                copyData(dlist, t_vector_buf, t_distrData_buf, t_hostmap_buf,
                                         u_vector, u_distrData, u_hostmap);
                        }
                }
                
                return entry_found;
        }




        
        private static void addDCM(String dcm) 
        {
                int knt = 0;

                Integer count = (Integer)t_dcmList.get(dcm);
                if (count != null) 
                        knt = count.intValue();
                
                knt ++;
                t_dcmList.put(dcm, new Integer(knt));

        }





        
        private static boolean
        updateDCMList(boolean notify) 
        {
                boolean b;
                
                synchronized (t_dcmList) {
                        b = updateDCMList_nolock(notify);
                }

                return b;
        }
        
        


        private static boolean
        updateDCMList_nolock(boolean notify) 
        {
                boolean needs_update = true;
                
                
                String orig_dcmList = last_update_dcmlist;
                t_dcmList.clear();
                
                java.util.Iterator iter = listeners.keySet().iterator();
                while (iter.hasNext()) {
                        
                        Object o = iter.next();
                        Object[] a = (Object[])listeners.get(o);
                        
                        if (a != null) {
                                
                                String dlist = (String)a[0];
                                
                                if (dlist == null)
                                        addDCM(ALL_DCMS);
                                else {
                                        StringTokenizer st = new StringTokenizer(dlist,",");
                                        while (st.hasMoreTokens())
                                                addDCM(st.nextToken());
                                }
                                
                        }
                        else
                                listeners.remove(o);
                }
                
                
                
                String new_dcmList = keysToString(t_dcmList, ",");

                    //System.out.println("ORIG LIST: "+orig_dcmList+" NEW LIST: "+new_dcmList);

                
                
                    
                
                if (  ( (orig_dcmList == null) && (new_dcmList == null) )
                      ||  ( (orig_dcmList!=null) && (new_dcmList!=null)
                            && orig_dcmList.equals(new_dcmList))  )
                        needs_update = false;

                
                if ( (t_dcmList.size()>0) && (loaderThread==null) ){
                        loaderThread = new ConfigLoader();
                        loaderThread.start();
                        System.out.println("ConfigLoader thread started.");
                }


                
                if (notify && needs_update)
                        t_dcmList.notifyAll();



                
                return (notify && needs_update);
                
        }

        




        
        
        public static void stop() 
        {


                synchronized (t_dcmList) {
                        
                        t_dcmList.clear();
                        if (loaderThread!=null)
                                loaderThread.done = true;
                        t_dcmList.notifyAll();
                        loaderThread = null;
                        listeners.clear();
                }

                
                synchronized (t_vector) {
                        
                        t_hostmap.clear();
                        t_vector.clear();
                        t_distrData.clear();
                        configException = null;
                        last_update_dcmlist = "";
                }
                
        
                System.out.println("DCMDistributorConfig stopped.");
                
        }

        
        static StringBuffer rowSeparator = new StringBuffer();
        static StringBuffer colSeparator = new StringBuffer();
        

        static 
                {
                        
                        rowSeparator.append(ConfigComm.CONF_STX).
                                append(ConfigComm.CONF_ETX).
                                append(ConfigComm.CONF_FS);
                        
                        colSeparator.append(ConfigComm.CONF_ETX).
                                append(ConfigComm.CONF_RS);
                }

        
        
        private static class ConfigLoader
                extends Thread 
        {
                protected boolean done = false;
                int milliSecondSleepTime = Constants.ConfigUpdateMilliSecs;
                long cacheLoadTimeStamp = -1;
                
                
                public void run() 
                {

                        while (true) {

                                if (done)
                                        break;

                                if (Constants.Verbose > 1) 
                                        System.out.println("------------Loading Configuration... "
                                                   +new java.util.Date());


                                
                                synchronized (t_vector) {
                                        
                                        loadConfig();

                                        synchronized(t_vector_buf) {
                                                
                                                t_vector_buf.clear();
                                                t_distrData_buf.clear();
                                                t_hostmap_buf.clear();
                                                
                                                t_vector_buf.addAll(t_vector);
                                                t_distrData_buf.putAll(t_distrData);
                                                t_hostmap_buf.putAll(t_hostmap);
                                        }
                                }


                                if (Constants.Verbose > 1) 
                                        System.out.println("------------Loaded Configuration... "
                                                   +new java.util.Date());


                                
                                synchronized (t_dcmList) {
                                        
                                        try {
                                                t_dcmList.wait(milliSecondSleepTime);
                                        }
                                        catch (InterruptedException ie){
                                        }
                                }
                                
                                
                        }
                        
                        System.out.println("Exiting background ConfigLoader thread.");
                        
                }




                
                 
                        
                private void 
                loadConfig()
                {
                        
                        
                        int numRows = 0;
                        int sColumn = 2;
                        
                        if (Constants.DEBUG && Constants.Verbose>2)
                                System.out.println("DCMDistributorConfig: Updating..");
                        

                        configException = null;
                        
                        
                        
                        String       respbuf = null, databuf;
                        
                        
                        java.util.StringTokenizer rowTokenizer, colTokenizer;

                        String update_dcmlist = "";


                        
                        synchronized (t_dcmList) {
                                update_dcmlist = keysToString(t_dcmList, ",");
                        }
                        

                        

                        if ( (update_dcmlist != null)
                             && update_dcmlist.length()==0) {
                                
                                last_update_dcmlist = update_dcmlist;
                                
                                t_hostmap.clear();
                                t_vector.clear();
                                t_distrData.clear();
                                
                                return;
                        }



                        

                        long config_update_time = CacheManager.getConfigTimeStamp();



                        if (Constants.Verbose>1) {
                                System.out.println("config_update_time = "+config_update_time);
                                System.out.println("cacheLoadTimeStamp = "+cacheLoadTimeStamp);
                                System.out.println("last_update_dcmlist = "+last_update_dcmlist);
                                System.out.println("update_dcmlist = "+update_dcmlist);
                        }
                        

                        if ( ( (config_update_time != 0)
                               && (cacheLoadTimeStamp >= config_update_time ) )
                             && (  ( (last_update_dcmlist == null) && (update_dcmlist == null) )
                                      ||  ( (last_update_dcmlist !=null) && (update_dcmlist!=null)
                                            && last_update_dcmlist.equals(update_dcmlist))  ) )
                        {

                                if (Constants.Verbose>1)
                                        System.out.println("Config did not change. Skip loading.");
                                
                                return;
                        }
                        
                        
                        t_hostmap.clear();
                        t_vector.clear();
                        t_distrData.clear();
                        


                        
                            /*
                            **	Get List of distributor IDs from configserver
                            */
                        StringBuffer reqbuf = new StringBuffer();
                        try {
                         
                                ConfigComm.getServKey(reqbuf,ConfigComm.GET_DCM_DIST_ALL_INFO,
                                                      update_dcmlist);
                                byte         [] b = ConfigComm.configRequest(reqbuf);
                                respbuf = new String(b);
                                
                        } catch (Exception e) {
                                configException = e;
                        }

                        

                        if (respbuf == null )
                                return;
                        
                        
                        
                        int index = respbuf.indexOf(ConfigComm.CONF_STX) + 1;
                        
                        databuf = respbuf.substring(index);
                        
                               
                        
                        rowTokenizer = new
                                java.util.StringTokenizer(databuf,rowSeparator.toString());
                        
                        
                        
                            /*
                            ** Format of response of  GET_DCM_DIST_ALL_INFO query
                            ** ID<RS>TAG<RS>DESC<RS>HOST1<RS>HOST2<RS>
                            **       PHOST1<RS>PHOST2<RS>
                            **       LOCATION1<RS><LOCATION2<RS>
                            **       HOME_LOCATION<RS>
                            */
                        
                        
                        
                            //System.out.println("+++++++ Start loading config ++: "+new Date());
                        
                        
                        while (rowTokenizer.hasMoreTokens()) {
                                
                                String [] rowData = new String [m_columnsCount];
                                
                                
                                rowTokenizer.nextToken(); // Skip "key"
                                String fstr = rowTokenizer.nextToken();
                                
                                colTokenizer = new
                                        java.util.StringTokenizer(fstr, colSeparator.toString());
                                
                                rowData[0] = colTokenizer.nextToken();
                                
                                String dcmtag = (String) colTokenizer.nextToken();
                                rowData[1] = dcmtag.substring(Constants.GLB_TAG_DCM_PREFIX.length()); 
                                
                                
                                
                                if (colTokenizer.hasMoreTokens())
                                        rowData[sColumn] = colTokenizer.nextToken();
                                else
                                        rowData[sColumn] = null;

                                
                                rowData[sColumn+1] = Constants.ERROR_STATUS;
                                rowData[sColumn+2] = Constants.ERROR_STATUS;
                                
                                String host1 = colTokenizer.nextToken();
                                String host2 = colTokenizer.nextToken();
                                
                                String phost1 = colTokenizer.nextToken();
                                String phost2 = colTokenizer.nextToken();
                                
                                String location1 = null, location2 = null;

                                if (colTokenizer.hasMoreTokens())
                                        location1 = colTokenizer.nextToken();
                                
                                if (colTokenizer.hasMoreTokens())
                                        location2 = colTokenizer.nextToken();
                                
                                String primary_location = null;

                                if (colTokenizer.hasMoreTokens())
                                        primary_location = colTokenizer.nextToken();

                                
                                
                                String dcm = (String)rowData[1];
                                String did = (String)rowData[0];


                                
                                if (!t_hostmap.containsKey(dcm)) {
                                        
                                        DistrHostData distrHostData = new DistrHostData(phost1,
                                                                                        phost2,did);
                                        t_hostmap.put(dcm,distrHostData);
                                        
                                } else {
                                        
                                        DistrHostData distrHostData = 
                                                (DistrHostData) t_hostmap.get(dcm);
                                        distrHostData.distrList.append(did).append(" ");
                                }

                                
                                
                                    /* Associate the host names with distributor ID for easy look up */

                                
                                String []host_data = new String[6];
                                
                                host_data[0] = new String(host1);
                                host_data[1] = new String(host2);
                                
                                host_data[2] = new String(phost1);
                                host_data[3] = new String(phost2);
                                
                                host_data[4] = null;
                                host_data[5] = null;
                                
                                try {

                                            
                                            if ( (location1==null) || (location2==null) ) {
                                                    java.util.HashMap dcmconfig
                                                            = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                                                    location1 = (String)dcmconfig.get("LOCATION1");
                                                    location2 = (String)dcmconfig.get("LOCATION2");
                                            }
                                            
                                            if (primary_location == null) {
                                                    java.util.HashMap m
                                                            = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);  
                                                    primary_location = (String)m.get("HOME_LOCATION");
                                            }


                                            
                                        if (primary_location != null
                                            && !primary_location.equals("1")) {
                                                
                                                host_data[2] = new String(phost2);
                                                host_data[3] = new String(phost1);
                                                String l1 = location1;
                                                
                                                location1 = location2;
                                                location2 = l1;
                                                
                                        }

                                        
                                        host_data[4] = location1;
                                        host_data[5] = location2;  
                                                
                                } catch (Exception de){
                                        de.printStackTrace();
                                }


                                
                                t_distrData.put(did , host_data);
                                
                                        
                                t_vector.add(rowData);
                                        
                                        
                                numRows++;
                                        
                                host1 = null;
                                host2 = null;
                                dcmtag = null;
                                fstr = null;
                                        
                        } /* while rowTokenizer() */

                        
                        
                            //System.out.println("+++++++ End loading config ++: "+new Date());       
                                
                        if (Constants.DEBUG && Constants.Verbose>2)
                                System.out.println("DCMDistributorConfig: Num rows: "+numRows);

                        
                                
                        respbuf = null;
                        reqbuf = null;
                        databuf = null;
                                
                        last_update_dcmlist = update_dcmlist;

                        cacheLoadTimeStamp = CacheManager.getConfigTimeStamp();
                        
                        	
                        
                } //loadConfig


                    /***********************/


                 
                
                                         
                
        }  // Class ConfigLoader




        

        static private String
        keysToString(java.util.TreeMap map, String separator) 
        {
                if ((map==null) || (map.size()==0))
                        return "";

                if (map.get(ALL_DCMS) != null)
                        return null;
                
                StringBuffer sb = new StringBuffer();
                java.util.Iterator iter
                        = map.keySet().iterator();

                
                while (iter.hasNext())
                        sb.append((String)iter.next())
                                .append(separator);

                

                return sb.toString();
        }

        static int milliSecondSleepTime = 60*1000;
        static int MAX_INACTIVE_TIME    = 10 * milliSecondSleepTime;
        private static Thread clearInactiveListenersThread = new Thread(
                new Runnable() 
                {
                        public void run() 
                                {
                                        
                                        while (true) {
                                                
                                                try {
                                                        synchronized (t_dcmList) {
                                                                
                                                                long now = System.currentTimeMillis();
                                                                java.util.Iterator iter = listeners.keySet().iterator();
                                                                while (iter.hasNext()) {
                                                                        
                                                                        Object o = iter.next();
                                                                        Object[] a = (Object[])listeners.get(o);
                                                                        if (a != null) {
                                                                                
                                                                                long inactive_time
                                                                                        = now - ((Long)a[1]).longValue();
                                                                                
                                                                                
                                                                                
                                                                                if (inactive_time >= MAX_INACTIVE_TIME){
                                                                                        listeners.remove(o);
                                                                                        System.out.println("Removing inactive listener "
                                                                                                           +o
                                                                                                           +"\n\tLast update: "
                                                                                                           +((Long)a[1]).longValue()
                                                                                                           +" Diff: "+inactive_time
                                                                                                           +" Max : "+MAX_INACTIVE_TIME);
                                                                                
                                                                                }
                                                                        }
                                                                }

                                                        }

                                                        
                                                } catch (java.util.ConcurrentModificationException cme)
                                                { //Ignore
                                                }

                                                updateDCMList(false);
                                                
                                                try {
                                                        Thread.sleep(milliSecondSleepTime);
                                                }
                                                catch (InterruptedException ie)
                                                { //Ignore
                                                }
                                        }
                                        
                                }
                }
                );




        
        
        static
        {
                try
                {
                        clearInactiveListenersThread.setPriority(Thread.MIN_PRIORITY);
                        clearInactiveListenersThread.start();
                }
                catch(Exception e)
                {
                            //Ignore but log
                        Log.getInstance().log_error("DCMDistributorConfig:Static Block failed",e);
                }
        }

        
}

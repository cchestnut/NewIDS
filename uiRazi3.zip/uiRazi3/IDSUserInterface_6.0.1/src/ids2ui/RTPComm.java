/*
**  SCCS Info :  "@(#)RTPComm.java	1.6    02/10/14"
*/
/*
 * RTPComm.java
 *
 * Created on May 15, 2000, 2:51 PM
 */
 
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;


/** 
 *
 * @author  srz
 * @version 
 */
public class RTPComm extends Object {

 
	/* rtp request types */
    static final int            IPM_MSG  =   1;      /* message packet */
    static final int            IPM_STS  =   2;      /* status packet  */
    static final int            IPM_DEL  =   3;     /* delete packet  */
    static final int            IPM_CHK  =   4;      /* check packet  */



  static private String   userName="USER-NAME";
  static private String           testServer = "dist-c1d2";

  
  /** Creates new RTPComm */
  public RTPComm() {
  }
  
 
  
  private static int getResponse(Socket server) 
      throws IOException, DBException, DBModeException
  {

      InputStream din = server.getInputStream();
      
      byte[] hdrb = new byte[8];
      
      din.read(hdrb,0,8);
      String hdr = new String(hdrb);
      
      int len=0, status = -1;
      
      
      try {
	  len = Integer.parseInt(hdr);
      } catch (Exception e) {
	  Log.getInstance().log_error("RTPComm:Error in parsing length of response",e);
	  
	  throw new IOException("Error in parsing length of response");
      }
      
      int rlen = len - 8;
      
      if (rlen <= 0) throw new IOException("Error in reading server response");   

      byte[] b = new byte[rlen];
      int nleft=rlen,nread=0,offset=0;
      while (nleft > 0) {
	  nread = din.read(b,offset,nleft);
	  if (nread <= 0) break;
	  nleft -= nread;
	  offset += nread;
      }
      
      if (offset != rlen) 
	  throw new IOException("Error in reading server response");   
      
      String resp = new String(b);


      java.util.StringTokenizer tokenizer
	  = new java.util.StringTokenizer(resp,",");
      String s = null;
      if (tokenizer.hasMoreTokens())
	  s = tokenizer.nextToken();
      else
	  throw new IOException("Error in parsing status");

      try {
	  int l = s.length();


	  String zerostr = new String("00000000000000000000000000000000");
	  if (s.regionMatches(0,zerostr,0,l)) 
	      status = 0;
	  else 
	      status = Integer.parseInt(s);
      } catch (Exception e) {
	  Log.getInstance().log_error("RTPComm:Error in parsing status",e);
	  
	  throw new IOException("Error in parsing status");
      }

      server.close();
      
     
      return status;
  }

   

  private static Socket connectToRTPServer(String serverName) throws IOException
  {
      //Socket sock =  new Socket(serverName, Constants.RTP_SERVER_PORT);
      Socket sock = TimeoutSocket.Connect(serverName, 
					  Constants.RTP_SERVER_PORT,
					  Constants.ConnectTimeout);


 	/* Set timeout */
      sock.setSoTimeout(Constants.NetworkTimeout);
	  sock.setTcpNoDelay(true);

      return sock;
  }

  private static void sendRequest(Socket server,StringBuffer buf) 
      throws IOException
  {
    BufferedOutputStream dout;
    StringBuffer b = new StringBuffer();
    
    dout = new BufferedOutputStream( server.getOutputStream() );

    if (Constants.DEBUG && Constants.Verbose>1)
      System.out.println("Buffer " + buf.toString() );

    dout.write(buf.toString().getBytes(),0,buf.length()); 
    dout.flush();

  }


  
  
  public static int
      rtpRequest(String SL, StringBuffer buf) 
      throws Exception
  {
    int b=-1;
    boolean done=false;
    int ntries =Constants.NUM_CONNECTION_TRIES;
      
     String serverList = SL;


    java.util.StringTokenizer tok = new java.util.StringTokenizer(serverList,",");

    String serverName;

	if (tok.hasMoreTokens())
		serverName = tok.nextToken();
	else
		throw new DBException("Could not get RTP server list");

    Socket server=null;
    char[] str = {'0','0','0','0','0','0','0','0','0'};
    int l = buf.length();
    buf.insert(0,l);
    int l1 = buf.length();
    int i = (l+8)-l1;
    
    buf.insert(0,str,0,i);
    buf.append('\0'); // NULL terminate
    
	StringBuffer rbuf = new StringBuffer();

	rbuf.append(serverList)
		.append(ConfigComm.CONF_GS)
			.append(buf);

	byte[] byt = AdminComm.serviceRequest(ConfigComm.getServerList(),
					      AdminComm.PROXY_MESSAGE,
					      AdminComm.RETRANSMISSION, 
					      rbuf.toString());

	String s = new String(byt);

	Utils.RequestHeader hdr = new Utils.RequestHeader(s);


	return hdr.error_number;


    
  }


  

  
  
}

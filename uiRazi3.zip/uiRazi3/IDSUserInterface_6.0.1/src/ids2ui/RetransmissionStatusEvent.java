/*
**  SCCS Info :  "@(#)RetransmissionStatusEvent.java	1.3    01/03/26"
*/
/*
 * RetransmissionStatusEvent.java
 *
 * Created on October 18, 2000, 12:41 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class RetransmissionStatusEvent extends java.util.EventObject {
  private String name=null;
  private String timeStamp=null;
  private int   status;
  private String   error_string;
  
  /** Creates new RetransmissionStatusEvent */
  public RetransmissionStatusEvent(Object source) {
    super(source);
  }
  
  public RetransmissionStatusEvent(Object source, String n,String t) {
    super(source);
    name = new String (n);
    timeStamp = new String (t);
    status = 0;
  }
  
  public RetransmissionStatusEvent(Object source, int s, String e) {
    super(source);
    status = s;
    error_string = new String (e);
  }
  
  public int getStatus() { return status; }  
  
  public String getError() { return error_string; }
  
  public String getName() { return name; }
  public String getTimeStamp() { return timeStamp; }
  
}

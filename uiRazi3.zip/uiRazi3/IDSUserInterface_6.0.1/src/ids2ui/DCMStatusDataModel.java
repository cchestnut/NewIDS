/*
**  SCCS Info :  "@(#)DCMStatusDataModel.java	1.7    04/05/10"
*/
/*
 * DCMSelectDataModel.java
 *
 * Created on May 24, 2000, 4:58 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

  
public class DCMStatusDataModel 
    extends javax.swing.table.AbstractTableModel 
    implements Utils.UpdateModel 
{

    java.util.HashMap m_dcmData = null;



    protected int     m_sortCol = 0;
    protected boolean m_sortAsc = true;
    protected java.util.Vector m_vector = null;

    protected int m_columnsCount = 
	Constants.DCMServicesTableColumnNamesBrief.length;



    /** Creates new DCMSelectDataModel */
    public DCMStatusDataModel()  {
	m_vector = new java.util.Vector(50);
	m_dcmData = new java.util.HashMap(50);
    }


    


    public String getHost1(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_dcmData!=null)) {
	    String data[] = (String[])m_dcmData.get(id);
	    return data[0];
	}
	return null;
    }

    public String getHost2(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_dcmData!=null)) {
	    String data[] = (String[])m_dcmData.get(id);
	    return data[1];
	}
	return null;
    }

    public String getVersion(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_dcmData!=null)) {
	    String data[] = (String[])m_dcmData.get(id);
	    return data[2];
	}
	return null;
    }

    public String getPHost1(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_dcmData!=null)) {
	    String data[] = (String[])m_dcmData.get(id);
	    return data[3];
	}
	return null;
    }

    public String getPHost2(int r) {
	String id = (String)getValueAt(r,0);
	if ((id!=null)&&(m_dcmData!=null)) {
	    String data[] = (String[])m_dcmData.get(id);
	    return data[4];
	}
	return null;
    }

    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }

    public boolean isCellEditable(int nRow, int nCol) {
	return false;
    }

    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int column) {
      	String str = Constants.DCMServicesTableColumnNamesBrief[column];
	if (column==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 
    
    synchronized public Object getValueAt(int nRow, int nCol) {

	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((Object[])m_vector.get(nRow))[nCol];
    }


    synchronized public java.util.Vector getDataVector(){
	return m_vector;
    }


    synchronized public void addRow(Object[] o) {

	m_vector.add(o);
	java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));

	fireTableDataChanged();

    }

    synchronized public void removeRow(int r) {

	m_vector.remove(r);

	fireTableDataChanged();

    }




    public void Update() 
    throws Exception
    {

	int numRows = 0;
	int oldRows = m_vector.size();

	java.util.Vector u_vector = new java.util.Vector(oldRows);
	java.util.HashMap u_dcmData = new java.util.HashMap(oldRows);


	try {

	    StringBuffer reqbuf = new StringBuffer();
	    String       respbuf,databuf;
	    byte[] b;

		

	    ConfigComm.getTagKey(reqbuf,ConfigComm.GET_DCM_ALL_INFO);
	    b = ConfigComm.configRequest(reqbuf);

	    respbuf = new String(b);
	    b = null;

	    int index = respbuf.indexOf(ConfigComm.CONF_STX)+1;

	    databuf = respbuf.substring(index);


	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Response: "+databuf);


	    java.util.StringTokenizer rowTokenizer, colTokenizer;

	    StringBuffer rowSeparator = new StringBuffer();
	    StringBuffer colSeparator = new StringBuffer();

	    rowSeparator.append(ConfigComm.CONF_STX).
		append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_FS);

	    colSeparator.append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_RS);

	    rowTokenizer = new
		java.util.StringTokenizer(databuf,rowSeparator.toString());

	    


	    while (rowTokenizer.hasMoreTokens()) {

		rowTokenizer.nextToken(); // Skip "key"
		String fstr = rowTokenizer.nextToken();
		colTokenizer =
		    new java.util.StringTokenizer(fstr,
						  colSeparator.toString());

		//Parse DCM configuration & store in  hash table
		java.util.HashMap map = new java.util.HashMap(5);

		while (colTokenizer.hasMoreTokens()) {
		    String key=null,value=null;
		    key = colTokenizer.nextToken();
		    if (colTokenizer.hasMoreTokens()) {
			value = colTokenizer.nextToken();
		    } else {
			continue;
		    }
		    if ((key!=null) && (key.length()>0))
			map.put(key,value);
		}


		

		String id	 = (String)map.get("ID");
		String desc  = (String)map.get("DESCRIPTION");
		String host1 = (String)map.get("HOST1");
		String phost1 = (String)map.get("PHOST1");
		String host2 = (String)map.get("HOST2");
		String phost2 = (String)map.get("PHOST2");
		String ver = (String)map.get("SOFTWARE_VERSION");

		if ( (id==null) || (host1==null) || (host2==null)
			|| (phost1==null) || (phost2==null)
		     || (ver==null)) {
		    Log.getInstance().log_error("Invalid DCM configuration: "
						+"ID:"+id
						+"DESC:"+desc
						+"HOST1:"+host1
						+"HOST2:"+host2
						+"PHOST1:"+phost1
						+"PHOST2:"+phost2
						+"SOFTWARE_VERSION:"+ver, null);
		    continue;
		}


		String [] data = new String[5];

		data[0] = host1;
		data[1] = host2;
		data[2] = ver;
		data[3] = phost1;
		data[4] = phost2;
		u_dcmData.put(id, data);


		String [] rowData = 
		    new String[Constants.DCMServicesTableColumnNamesBrief.length];

		rowData[0]  = id;
		rowData[1]  = desc;

		u_vector.add(rowData);

		numRows++;

		map.clear();
		map = null;
		
	    } // while rowTokenizer() 

	} catch (Exception e) {
	    synchronized(this) {
		m_vector.removeAllElements();
		m_dcmData.clear();
	    }
	    u_vector = null;
	    u_dcmData = null;
	    fireTableDataChanged();
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND)
		    return;
	    }

	    //Log.getInstance().log_error("Error in retrieving DCM list",e);
	    throw (e);
	}

	java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));
        int newRows = 0;
        
	synchronized (this ) {
	    m_vector = null;
	    m_vector = u_vector;
	    m_dcmData = null;
	    m_dcmData = u_dcmData;
            newRows = m_vector.size();
            
	}
	
	IDS_SwingUtils.fireTableChanged(this, oldRows, newRows);

    } // Update()

   
    



    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	 rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;


	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }


	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;



	    for (int i=0; i < m_columnsCount ; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }

	    m_table.getTableHeader().repaint();  

	    synchronized (DCMStatusDataModel.this ) {
		java.util.Collections.sort(m_vector, new 
				       StatusComparator(modelIndex, m_sortAsc));
	    }

	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DCMStatusDataModel.this)); 
	    m_table.repaint();

	    rwLock.writeLock().release();
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;
	    switch (m_sortCol) {
	    case 0:    // id
	    case 1:    // desc
		if (s1!=null && s2!=null)
		    result = s1.compareTo(s2);
		else if (s1==null)
		    result = -1000;
		else if (s2==null)
		    result = 1000;
		break;
	    }

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

	public boolean equals(Object obj) {
	    return false;
	}
    }


}

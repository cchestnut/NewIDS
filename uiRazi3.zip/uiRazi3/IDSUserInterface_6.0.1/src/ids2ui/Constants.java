/*
**  SCCS Info :  "%W%    %E%"
*/
/*
 * Constants.java
 *
 * Created on April 18, 2000, 1:19 PM
 */
 
package ids2ui;
import java.net.*;
import java.io.*;
import java.util.*;




/** 
 *
 * @author  srz
 * @version 
 */
public class Constants  {

	public static String VERSION_STRING = " v1.4   [Build: %I% %D%:%T%]";

	public static String FIDS_PLATFORM_STRING = "FIDS2";
	public static String IDS_PLATFORM_STRING = "IDS2";



	public static boolean isExiting = false;
	public static ThreadGroup uiThreads = null;

        public static boolean DEBUG  = false;
        public static int Verbose = 0;

        public static java.awt.event.MouseMotionAdapter MOUSE_MOTION_ADAPTER
		= new java.awt.event.MouseMotionAdapter(){};

	public static java.awt.event.MouseAdapter MOUSE_ADAPTER 
		= new java.awt.event.MouseAdapter(){};



	public static boolean SHOW_PORTS_BUTTON = true;

	public static boolean isDistrDCMEditable = false;

        public static boolean checkpointStatusFromDSP = true;


	public static int		DefaultServiceStatusUpdateMilliSecs = 30000;       // 15 secs
        public static int		DefaultCacheTTLSecs                 = 24*60*60;    // 1 day
        public static int		DefaultConfigUpdateMilliSecs        = 30000;       // 15 secs

        public static int		DefaultConfigCheckMilliSecs         = 10000;       // 10 secs


        public static int		DefaultNetworkTimeout   = 90000; // 90 Secs
        public static int       DefaultConnectTimeout   = 5000; // 5 seconds

        public static int		ServiceStatusUpdateMilliSecs 
                                          = DefaultServiceStatusUpdateMilliSecs;
        public static int		NetworkTimeout
        = DefaultNetworkTimeout;
        public static int       ConnectTimeout
        =DefaultConnectTimeout;
        public static int	RtpDistrStatusUpdateInterval	= 1*60*1000;

        
        public static int		CacheTTLSecs 
                                          = DefaultCacheTTLSecs;

        public static int		ConfigUpdateMilliSecs 
                                          = DefaultConfigUpdateMilliSecs;

        public static int		ConfigCheckMilliSecs 
                                          = DefaultConfigCheckMilliSecs;

        

        public static int    DEFAULT_CONFIG_SERVER_PORT = 15015;
        public static int    DEFAULT_ADMIN_SERVER_PORT = 15012;
        public static int    DEFAULT_STATUS_SERVER_PORT = 12759;
        public static int    DEFAULT_RTP_SERVER_PORT = 12760;
        public static int    MIN_PORT_NUM = 0;
        public static int    MAX_PORT_NUM = 65535;
        public static int    CONFIG_SERVER_PORT = DEFAULT_CONFIG_SERVER_PORT;
        public static int    ADMIN_SERVER_PORT = DEFAULT_ADMIN_SERVER_PORT;
        public static int    STATUS_SERVER_PORT = DEFAULT_STATUS_SERVER_PORT;
        public static int    RTP_SERVER_PORT = DEFAULT_RTP_SERVER_PORT;


        final public static int ACCESS_LEVEL_ADMIN=0;
        final public static int ACCESS_LEVEL_RESTRICTED=2;        
        final public static int ACCESS_LEVEL_OPERATOR=1;

        public static String DEFAULT_IDSDIR = "/ids2";
        public static String idsdir = DEFAULT_IDSDIR;

        public static String DEFAULT_SW_VERSION_LABEL = "Release";
        public static String DEFAULT_SW_VERSION_DIR = "rel";
        public static String DEFAULT_SW_VERSION = "DEFAULT_SW_VERSION";
        public static char SVC_SEPARATOR = '.';

        public static String DEFAULT_DISTR_CHECKPOINT_STRING = "IDS2_CKPTXXX";
        public static String GLB_DSP_DISTR_CHECKPOINT_STRING = null;
        public static String GLB_DCM_DISTR_CHECKPOINT_STRING = null;




        public static String DESCRIPTION_LABEL = "Description";
        public static String CONFIGURATION_DSP = "CONFIGURATION_DSP";
        public static String CONFIGURATION_IAB = "CONFIGURATION_IAB";
        public static String CONFIGURATION_DCM = "CONFIGURATION_DCM";
        public static String CONFIGURATION_DCM_PREFIX   = "CONFIGURATION_DCM_";
        public static String CONFIGURATION_DSP_DISTRIBUTORS = "CONFIGURATION_DSP_DISTRIBUTORS";
        public static String CONFIGURATION_DCM_DISTRIBUTORS = "CONFIGURATION_DCM_DISTRIBUTORS";
        public static String CONFIGURATION_DISTRIBUTOR_PREFIX = "CONFIGURATION_DISTRIBUTOR_";
        public static String PRODUCT_MODIFIER_PREFIX = "PRODUCT_MODIFIER_DIALOG_";
        public static String CONFIGURATION_PRODUCTS = "CONFIGURATION_PRODUCTS";
        public static String CONFIGURATION_PRODUCT_CACHE ="CONFIGURATION_PRODUCT_CACHE";
        public static String CONFIGURATION_FILTERCODES = "CONFIGURATION_FILTERCODES";
        public static String CONFIGURATION_PREMIUMCODES = "CONFIGURATION_PREMIUMCODES";
        public static String CONFIGURATION_FILTERCODE_PREFIX = "CONFIGURATION_FILTERCODE_";
        public static String CONFIGURATION_SYSINFO = "CONFIGURATION_SYSINFO";
        public static String CONFIGURATION_OPTIONS = "CONFIGURATION_OPTIONS";
  
  
        public static String SERVICES_DSP = "SERVICES_DSP";
        public static String SERVICES_IAB = "SERVICES_IAB";
        public static String SERVICES_DCM = "SERVICES_DCM";
        public static String SERVICES_DCM_PREFIX = "SERVICES_DCM_";
        public static String SERVICES_DISTRIBUTORS_DETAILED = "SERVICES_DISTRIBUTORS_DETAILED";
        public static String SERVICES_DISTRIBUTORS_SUMMARY = "SERVICES_DISTRIBUTORS_SUMMARY";
  
        public static String RETRANSMISSION_REQUEST_PREFIX   = "RETRANSMISSION_REQUEST_";

        public static String X25_LINK_DIALOG_PREFIX   = "X25_LINK_DIALOG_";

	public static String STATUS_RETRANSMISSION_PREFIX 	= "STATUS_RTP_";
	public static String STATUS_DISTR_RETRANSMISSION_PREFIX 	= "STATUS_RTP_DISTR_";
	public static String STATUS_DISTRIBUTOR_PREFIX 	= "STATUS_DISTR_";
	public static String STATUS_READER_PREFIX 	= "STATUS_READER_";


	public static String MAIN_DISTRIBUTOR_SUMMARY_MENU = SERVICES_DISTRIBUTORS_SUMMARY;
	public static String MAIN_DISTRIBUTOR_MENU =SERVICES_DISTRIBUTORS_DETAILED;
	public static String MAIN_DISTRIBUTOR_CONFIGURATION = "MAIN_DISTRIBUTOR_CONFIGURATION";
	public static String MAIN_DISTRIBUTOR_STATUS = "MAIN_DISTRIBUTOR_STATUS";

	public static String MAIN_DCM_SERVICES_MENU = "MAIN_DCM_SERVICES_MENU";
	public static String MAIN_DCM_CONFIGURATION = "MAIN_DCM_CONFIGURATION";
	public static String MAIN_DCM_MENU = SERVICES_DCM;
	public static String MAIN_DCM_STATUS = "MAIN_DCM_STATUS";
	public static String MAIN_DSP_STATUS = "MAIN_DSP_STATUS";
        public static String MAIN_DCM_MESSAGE_FORMATS = "MAIN_DCM_MESSAGE_FORMATS";
        public static String MAIN_ALL_DCM_STATUS = "MAIN_ALL_DCM_STATUS";
        public static String DCM_DISTRIBUTOR_SAVE_STATE = "DCM_DISTRIBUTOR_SAVE_STATE";
          
  
        public static String GLB_TAG_DSP 			= "GLB_TAG_DSP";
        public static String GLB_TAG_DCM_PREFIX 	= "GLB_TAG_DCM_";
        public static String GLB_TAG_DISTR_PREFIX = "GLB_TAG_DISTR_";
        public static String GLB_TAG_FILTERCODE_PREFIX = "GLB_TAG_FILTERCODE_";
        public static String GLB_PRODUCT_LIST 	= "GLB_PRODUCT_LIST";
        public static String GLB_PRODUCT_CACHE 	= "GLB_PRODUCT_CACHE";

        public static String GLB_TRANSPORT_LIST 	= "GLB_TRANSPORT_LIST";
        public static String GLB_STATISTICS_LIST 	= "GLB_STATISTICS_LIST";
        public static String GLB_SYSFILE_LIST 	= "GLB_SYSFILE_LIST";
        public static String GLB_DCM_TYPES_LIST       = "GLB_DCM_TYPES_LIST";
        public static String GLB_RETRANS_FORMAT_LIST       = "CF5";
        public static String GLB_DISTR_FAVORITES_LIST  = "GLB_DISTR_FAVORITES_LIST";
        public static String GLB_IDS_TRANSPORT_LIST 	= "GLB_IDS_TRANSPORT_LIST";
        public static String GLB_DJNEWS_DCM_TRANSPORT_LIST 	= "GLB_DJNEWS_DCM_TRANSPORT_LIST";
        public static String GLB_IDS_PRODUCT_FORMATS 	= "GLB_IDS_PRODUCT_FORMATS";

        public static String GLB_DCM_PRODUCT_CONVERSION_TABLE 	= "GLB_DCM_PRODUCT_CONVERSION_TABLE";
        public static String GLB_LOCATION_LIST 	= "GLB_LOCATION_LIST";

        public static String GLB_DERIVED_DATA_DICTIONARIES_LIST 	= "GLB_DERIVED_DATA_DICTIONARIES_LIST";
        public static String GLB_OUTPUT_ENCODING_LIST 	= "GLB_OUTPUT_ENCODING_LIST";

        public static String GLB_DSP_SW_VERSION_LIST 	= "1.0";
        public static String GLB_DCM_SW_VERSION_LIST 	= "1.0";

        public static String   GLB_PRODUCT_TYPES_LIST  = "GLB_PRODUCT_TYPES_LIST";

        public  static final String PICK_LOCATION = "Select a location";
        public static  final String HOME_LOCATION = "HOME";
        public  static final String AWAY_LOCATION = "AWAY";
        private static final String SHOW_RUNNING_ONLY = "Show running only";
        public static  final String DC1_LOCATION = "Location-I";
        public  static final String DC2_LOCATION = "Location-II";
        public static  final String DC1_LOCATION_LABEL = "Location-I";
        public  static final String DC2_LOCATION_LABEL = "Location-II";
        public static  final String DC1_CLUSTER_LABEL = "Cluster/Location-I";
        public  static final String DC2_CLUSTER_LABEL = "Cluster/Location-II";
        public static final String LOCATION1 = "LOCATION1";
        public static final String LOCATION2 = "LOCATION2";

        public static final String ADMINSERVER = "adminserver";
        

        public static final String RTP_SERVER_NAME = "rtp";
        public static final String Running		 = "Running";
        public static final String NotRunning		 = "Not Running";
        public static final String NotConfigured	 = "Not Configured";

        public static final String RUNNING		 = "Running";
        public static final String NOT_RUNNING	 = "Not Running";
        public static final String NOT_CONFIGURED	 = "Not Configured";

        public static final String DUPLICATE_WINDOW	 = "Duplicate Window";
    
        public static final String NO_STATUS		="Not Running";
        public static final String ERROR_STATUS	="Not running";


        public static final int   DSP_READER        = 1;
        public static final int   DSP_BROADCASTER   = 2;
        public static final int   DSP_SYNCSERVER    = 3;
        public static final int   DSP_CONFSERVER    = 4;
        public static final int   DCM_READER        = 5;
        public static final int   DCM_LINEHANDLER   = 6;
        public static final int   DCM_DATA_SERVICES = 7;
        public static final int   DCM_RTP           = 8;
        public static final int   DSP_LINEHANDLER   = 9;
        public static final int   DJNEWS_LINEHANDLER   = 10;
        public static final int   MSGMGR   		= 11;


        public static final String BROADCASTER_TEMPLATE = "BROADCASTER_TEMPLATE";
        public static final String FULL_CONFIGURATION = "FULL_CONFIGURATION";
        public static final String DJNEWS_CONFIGURATION = "DJNEWS_CONFIGURATION";



	public static String FILTER_CODES_NONE		="NONE";
	public static int    DISTRIBUTOR_ID_SIZE = 4;
	public static int    PRODUCT_ID_SIZE = 2;
        public static String DEFAULT_KEEPALIVE	= null;
        public static String DSP_DEFAULT_KEEPALIVE_FORMAT = null;
        public static String DSP_DEFAULT_KEEPALIVE = null;
        public static String DSP_DEFAULT_INPUT_TRANSPORT = null;
        public static String DSP_DEFAULT_INPUT_FORMAT = null;
        public static String DSP_DEFAULT_INPUT_PROTOCOL = null;

        public static int DEFAULT_DSP_READER_MSGMGR_DELAY = 5;
        public static int DEFAULT_DCM_READER_MSGMGR_DELAY = 60;
        public static int DEFAULT_DCM_MSGMGR_MULTI2UNI_DELAY = 60;


        public static int DSP_READER_MSGMGR_DELAY = DEFAULT_DSP_READER_MSGMGR_DELAY;
        public static int DCM_READER_MSGMGR_DELAY = DEFAULT_DCM_READER_MSGMGR_DELAY;
        public static int DCM_MSGMGR_MULTI2UNI_DELAY = DEFAULT_DCM_MSGMGR_MULTI2UNI_DELAY;


        

            /*
            ** Seconds to wait to restart the linehandlers
            ** in DORMANT mode after sending the stop signal
            ** to the previously ACTIVE linehandler on this dcm.
            ** This allows time for the line handler to stop.
            */
        public static int DCM_DISTRIBUTOR_DORMANT_START_DELAY = 180;


        
            /*
            ** Seconds to wait to send the ACTIVE mode command
            ** after sending the stop signal to the previously
            ** ACTIVE linehandler on the other dcm. This allows 
            ** time for the ACTIVE LH to flush checkpoints.
            */
        public static int DCM_DISTRIBUTOR_SWITCH_MODE_DELAY = 2;




        
        public static java.util.Vector DCM_VECTOR = null;



        public static int MAX_TCP_ADDRESS = 5;
        public static int MIN_X25_LINKID = 0;
        public static int MAX_X25_LINKID = 255;
    

        public static String[] defaultProductTypes = {"1","2","3","4"};
        public static String[] defaultRTP_Keys = {"GLB_RTP_SERVERS","GLB_RTP_SERVERS2"};
    
   

	public static String ADMIN_PRODUCT_ID	= "AD";
	public static String ROOT_PRODUCT_ID	= "Products";
	public static String ADMIN_DEFAULT_FORMAT_LIST	= "CF5";
	public static String GLB_CONTAINER_CONVERSION_FORMAT	= "DJU";
	public static String GLB_ADMIN_FORMAT_LIST = ADMIN_DEFAULT_FORMAT_LIST;
        public static int    DEFAULT_IDS_READER_TCP_PORT = 8469;

        public static String GLB_IDS_PROTOCOL = null;
        public static String GLB_IDS_FORMAT = null;
	public static String GLB_IDS_TRANSPORT = null;
	public static String GLB_IDS_TRANSPORT_ADDRESS = null;

	public static String GLB_DCM_INPUT_NAME = null;

	public static String GLB_DJNEWS_DCM_MSGMGR_NAME = "MSGINDEX";

        public static String RBP_INTERFACE_LIST = null;

	public static int DSP_DEFAULT_DELAY = 0;
	public static boolean DSP_DEFAULT_FREEWHEEL = false;
	public static boolean DSP_DEFAULT_NEWSPLUSOFF = false;
	public static String DSP_DEFAULT_FILTER_CODES = FILTER_CODES_NONE;
	public static String  DSP_DEFAULT_LINEHANDLER_MODE = "HOT";
	public static int     DSP_DEFAULT_DERIVED_DATA_FLAG = 0;

        public static boolean DSP_USE_VERITAS_COMMANDS = true;
        
	
	public static String OutputLanguageOptions[]
        = {"Default","Auto"};
	public static String OutputEncodingOptions[]
        = {"Default", "Auto", "UTF-8" };
        
    
    
        //public static String DEFAULT_PREMIUM_CODES_LIST = "<P/PRT ,Premium RT><P/PRD ,Premium Delayed>";

        public static String DEFAULT_PREMIUM_CODES_LIST = "<P/PRE ,Premium RT><P/STD ,Premium Delayed>";
        public static String GLB_TAG_PREMIUM_FILTER_CODES = "GLB_TAG_PREMIUM_FILTER_CODES";

        public static String DSPServicesTableColumnNames[]
        = {"Server","DC-I Status","DC-II Status"};
        

        public static String SystemServicesTableColumnNames[]
        = {"Server","DC-I Status","DC-II Status"};

        
        public static String ReaderStatusTableColumnNames[] =
        {"Product","Format","Sequence #"};

        
        public static String RetransmissionStatusTableColumnNames[] =
        { "Host","Distributor","Product","Date", "Queued","Start","End"};

        
        public static String DistrRetransStatusTableColumnNames[] =
        { "Host","Product","Date", "Queued","Start","End"};


        public static String DistributorStatusColumnNames[] =
        {  "Product","Format","LCN", "Last sent","State",
           "Display time", "Free Wheel",
           "Block WSJ Links", "Derived data", "Filter codes", 
		   "Encoding","Premium codes", "Sig/About"
        };


        
        public static String DistrProductColumnNames[] =
        {  "Product","Format","Delay", "FreeWheel","WSJ Links Off", 
            "Derived data", "Filter Codes", "Language", 
            "Encoding", "Premium codes", "Sig/About"
        };


        
        final public static String[] DistributorStatusTableColumnNames = {
                "ID",   "DCM", 
                "Description", "Home Status",  "Away Status", "Active Location" 
        };

        final public static String[] DSPDistributorStatusTableColumnNames = {
                "ID",   
                "Description", "DC-I Status",  "DC-II Status" 
        };
    
        final public static String[] DistributorSummaryStatusTableColumnNames = {
                "ID", "Description", "Home Status",  "Away Status" 
        };
    
        public static String DSPBroadcasterID = "BDCR";

        public static String DSPServicesTable[][] = {
                { "Reader", 			"dsp_reader"},
                { "Message Manager", 		"msgmgr"}
        };


        public static int DSP_READER_INDEX = 0;
        public static int DSP_MESSAGE_MANAGER_INDEX = 1;
        public static int DSP_SYNC_SERVER_INDEX = 2;
        public static int DSP_SENDER_INDEX = 3;



        public static String DSPServicesTable3[][] = {
                { "Admin Server",       "adminserver" },
                { "Configuration Server", "configserver" },
                { "Status Server", "status_server"},
                { "Watchdog Server", "watchdog"},
                { "Status Multiplexer", 	"status_mux" },
                { "Message Filter",             "msgfilter"  }
                
        };

  
        public static String DCMServicesTable3[][] = {
                { "Admin Server",       	"adminserver" },	
                { "Watchdog Server", 		"watchdog" },
                { "Retransmission Server", 	RTP_SERVER_NAME },
                { "Status Multiplexer", 	"status_mux" }
        };

        public static String TCPColumnNames[] = {
                "Host address",
                "Service/Port"
        };

 
        public static String DCMServicesTableColumnNamesBrief[]= {
                "ID",
                "Description"
        };

        public static String DCMServicesTableColumnNames[]= {
                "ID",
                "Description",
                "DC-I Status",
                "DC-II Status"
        };

        public static String DCMServicesTable[][] = {
                { "Reader", 		"dcm_reader"},
                    //{ "Message Manager", 	"msgmgr"},
                    //{ "Retransmission Server", 	RTP_SERVER_NAME},
                    //{ "RBP Receiver", 	"receiver"},
                    //{ "Watchdog",           "watchdog"},
                    //{ "Admin Server",       "adminserver"}
        };
        
        public static String IABServicesTable[][] = {
                { "Reader", 		"dsp_reader"},
                    //{ "Message Manager", 	"msgmgr"},
                    //{ "Retransmission Server", 	RTP_SERVER_NAME},
                    //{ "RBP Receiver", 	"receiver"},
                    //{ "Watchdog",           "watchdog"},
                    //{ "Admin Server",       "adminserver"}
        };

        public static String ReaderStatusColumnTitles[] = {
                "Product ID",
                "Sequence Number"
        };


        public static String labelToKey[][] = {
                {"Story only","STORY_ONLY" },
                {"Headline only","HEADLINE_ONLY" },
                {"Both (Story+Headline)","STORY_AND_HEADLINE" },
                {"dowjonesnews.com (Real time news)","compressed" },
                {"Content based delay (Newspaper)","contentdelay" },
                {"Content based delay (Web services)","webservices" },
                {"XML TAG","XMLTAG" },
                {"XML TAG FIRST PARAGRAPH","XMLTAGFIRSTPG" },
            {"DISTDOC", "DISTDOC"},
                {"PLAIN TEXT","PLAIN" },
                {"PLAIN TEXT WITH <P>","PLAINWITHP" },
                {"NewsML/NITF","NEWSML_NITF" },
                {"NewsML/XHTML","NEWSML_XHTML" },
                {"HTTP","DJNEWS_HTTP" },
                {"FTP PUSH","DJNEWS_PUSH" },
                {"FTP PULL","DJNEWS_PULL" },
                {"Light Weight Client","DJNEWS_LWC" },
                {"First take","DJNEWS_FILENAME_FIRST_TAKE" },
                {"Current take","DJNEWS_FILENAME_CURRENT_TAKE" },
                {"Pre-chained","DJNEWS_PRECHAINED" },
                {"Single take","DJNEWS_SINGLE_TAKE" }
        };



        public static String default_contentTypes[] = {
                "Story only",
                "Headline only",
                "Both (Story+Headline)"
        };
  
        public static String default_deliveryTypes[] = {
                "dowjonesnews.com (Real time news)",
                "Content based delay (Web services)" ,
                "Content based delay (Newspaper)"
        };
      
        public static String default_conversionTypes[] = {
                "XML TAG",
                "XML TAG FIRST PARAGRAPH",
                "DISTDOC",
                "PLAIN TEXT",
                "PLAIN TEXT WITH <P>"
        };
    
        public static String default_deliveryMethods[] = {
                "FTP PUSH",
                "FTP PULL",
                "HTTP",
                "Light Weight Client"
        };
      
        public static String default_encodingList[] = {
                "UTF-8",
                "UTF-7",
                "ISO-8859-1"
        };

        public static String default_fileGenList[] = {
                "Current take",
                "First take"
        };

        public static String default_takeTypeList[] = {
                "Pre-chained",
                "Single take"
        };
     
     
        public static final String DJNEWS_CONTENT_TYPES = "DJNEWS_CONTENT_TYPES";
        public static final String DJNEWS_DELIVERY_TYPES = "DJNEWS_DELIVERY_TYPES";
        public static final String DJNEWS_CONVERSION_TYPES = "DJNEWS_CONVERSION_TYPES";
        public static final String DJNEWS_DELIVERY_METHODS = "DJNEWS_DELIVERY_METHODS";
        public static final String DJNEWS_ENCODING_LIST = "DJNEWS_ENCODING_LIST";
        public static final String DJNEWS_FILE_GENERATION_TYPES = "DJNEWS_FILE_GENERATION_TYPES";
        public static final String DJNEWS_TAKE_TYPES = "DJNEWS_TAKE_TYPES";

        public static java.util.HashMap label2KeyMap = new java.util.HashMap(100);

        static {
                for (int i = 0; i < labelToKey.length; i++){
                        label2KeyMap.put(labelToKey[i][0],labelToKey[i][1]);
                        label2KeyMap.put(labelToKey[i][1],labelToKey[i][0]);
                }
        }

        public static final String FTP_NUM_ENTRIES = "FTP_NUM_ENTRIES";
        public static final String FTP_SERVER_PREFIX = "FTP_SERVER_";
        public static final String FTP_PORT_PREFIX = "FTP_PORT_";
        public static final String FTP_USERNAME_PREFIX = "FTP_USERNAME_";
        public static final String FTP_PASSWORD_PREFIX = "FTP_PASSWORD_";
        public static final String FTP_PASSIVE_MODE_PREFIX = "FTP_PASSIVE_MODE_";
        public static final String FTP_REMOTE_DIR_PREFIX = "FTP_REMOTE_DIR_";
        public static final String FTP_RENAME_FILE_PREFIX = "FTP_RENAME_FILE_";
        public static final String FTP_STATISTICS_FILE_PREFIX = "FTP_STATISTICS_FILE_";
        public static final String FTP_TRANSFER_MODE_PREFIX = "FTP_TRANSFER_MODE_";

        public static final String TAB_SEPARATOR = "--";
                
        public static String FilterCodesTableColumnNames[]= {"ID","Description"};

        public static String PremiumCodesTableColumnNames[]
                = {"Content", "Token/Code", "Enabled" };
        
        public static int	  MINKEEPALIVE=0;
        public static int   MAXKEEPALIVE=65536;
        public static int   NUM_HEADER_FIELDS=8;
        public static int   MIN_HEADER_BYTES=18;
        public static int   NUM_CONNECTION_TRIES=1;

        public static int	  MSGFMTSZ=3;



        public static final int  MODE_ERR            = -10000;      /* Server not in master mode */
        public static final int  SYNC_ERR            = -10001;      /* Server is currently sync'ing */
        public static final int  COMM_ERR            = -10002;      /* Communication error          */
        public static final int  QUEUE_ERR           = -10003;


        public static final int  SERVER_ERROR        = -11000;
        public static final int  KEY_NOT_FOUND       = -11001;
        public static final int  DB_PRESENT_ERR      = -11002;
        public static final int  DB_STORE_ERR        = -11003;
        public static final int  HOSTIN_USE_ERR      = -11004;
        public static final int  DSP_UNDEFINED       = -11005;
        public static final int  DCM_UNDEFINED       = -11006;
        public static final int  DISTR_UNDEFINED     = -11007;
        public static final int  PROD_UNDEFINED      = -11008;
        public static final int  HOST_NOT_IN_DB      = -11009;
        public static final int  KEY_IN_USE          = -11010;
        public static final int  MAX_DISTR_ERR       = -11011;
        public static final int  PROD_CACHE_ERR      = -11012;

        public static final int  PROGRAM_NOT_RUNNING =   -12001;
        public static final int  PROGRAM_RUNNING     =   -12002;
        public static final int  PROGRAM_ERROR       =   -12003;
        public static final int  PROGRAM_NORESPONSE  =   -12004;
        public static final int  SEND_MESSAGE_ERROR  =   -12005;
        public static final int  FILE_NOT_FOUND      =   -12006;
        public static final int  DISTRCACHE_ERR      =   -12007;

  
        public static Class
        getActionClass(String action)
        {
                try {
                        String name = " ";
      
                        if (action.equals(CONFIGURATION_DSP))
                                name = "ids2ui.DSPConfigForm";      

                        if (action.equals(CONFIGURATION_IAB))
                                name = "ids2ui.IABConfigForm";      
                        if (action.equals(CONFIGURATION_DSP_DISTRIBUTORS))
                                name = "ids2ui.DSPDistrConfigSelectForm";      

                        if (action.equals(CONFIGURATION_PRODUCTS))
                                name = "ids2ui.ProductConfigurationDialog";      
                        if (action.equals(CONFIGURATION_FILTERCODES))
                                name = "ids2ui.FilterCodesSelectForm";  
                        if (action.equals(CONFIGURATION_PREMIUMCODES))
                                name = "refactor.ui.forms.PremiumCodesForm";
                        if (action.equals(CONFIGURATION_SYSINFO))
                                name = "ids2ui.SysInfoMainScreen";
                        if (action.equals(CONFIGURATION_OPTIONS))
                                name = "ids2ui.UIOptionsDialog";
      
                        if (action.equals(SERVICES_DSP))
                                name = "ids2ui.DSPServicesForm";      
                        if (action.equals(SERVICES_IAB))
                                name = "ids2ui.IABServicesForm";      
                        if (action.equals(SERVICES_DCM))
                                name = "ids2ui.DCMServicesSelectForm";      
                        if (action.equals(SERVICES_DISTRIBUTORS_DETAILED))
                                name = "ids2ui.DistrServicesForm";
                        if (action.equals(SERVICES_DISTRIBUTORS_SUMMARY))
                                name = "ids2ui.DistrSummaryForm";
      
                        if (action.equals(DCM_DISTRIBUTOR_SAVE_STATE))
                                name = "ids2ui.DCMDistributorSaveState";
                        if (action.startsWith(CONFIGURATION_DCM_PREFIX))
                                name = "ids2ui.DCMConfigForm";
            
      
                        return Class.forName(name);
                } catch (Exception e) {
                        Log.getInstance().log_error("Class not found: "+action,null);
                        return null;
                }

    
        }
  

        public static boolean
        findPattern(String bigString, String s1) 
        {

                if ((bigString == null)
                    || (bigString.length()==0) )
                        return false;

                int i;
                for (i = 0; i < bigString.length(); i++)
                        if (bigString.regionMatches(i,s1,0,s1.length()))
                                return true;

                return false;
        }

        public static boolean
        matchPattern(String bigString, String separator, String s1) 
        {

                if ((bigString == null)
                    || (bigString.length()==0) )
                        return false;

                if ((separator == null)
                    || (separator.length()==0) )
                        return false;

                if ((s1 == null)
                    || (s1.length()==0) )
                        return false;
	

                java.util.StringTokenizer st = 
                        new java.util.StringTokenizer(bigString,separator);

                int numTokens = st.countTokens();
                for (int i = 0; i < numTokens ; i++) {
                        String s = st.nextToken();
                        if (s.equals(s1)) return true;
                }

                return false;
        }

    static String getDefaultPremiumEntitlement(String item) {
        return parser.DistributorProductConfiguration.getDefaultPremiumCode(item);        
    }

        private Constants()
        {
        }
  

} /* End of Class */

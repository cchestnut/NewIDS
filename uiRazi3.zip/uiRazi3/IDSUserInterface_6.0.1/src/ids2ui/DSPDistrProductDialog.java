/*
**  SCCS Info :  "%W%    %E%"
*/
/*
 * DSPDistrProductDialog.java
 *
 * Created on March 22, 2000, 2:04 PM
 */
 
package ids2ui;

import model.DistributorProductFlagOptions;

/** 
 *
 * @author  srz
 * @version 
 */
public class DSPDistrProductDialog 
    extends javax.swing.JDialog 
{


  private javax.swing.DefaultComboBoxModel productComboModel;
  private javax.swing.DefaultComboBoxModel formatComboModel = new javax.swing.DefaultComboBoxModel() ;  
  private javax.swing.DefaultComboBoxModel derivedDataComboModel = new javax.swing.DefaultComboBoxModel(DistributorProductFlagOptions.DerivedDataOptions) ;  
  private javax.swing.DefaultComboBoxModel languageComboModel = new javax.swing.DefaultComboBoxModel(Constants.OutputLanguageOptions);  
  private javax.swing.DefaultComboBoxModel encodingComboModel = new javax.swing.DefaultComboBoxModel(Constants.OutputEncodingOptions) ;  
  private DistrProductStructure[]     distrProductStruct1 = null;
  
  private String SELECT_STRING = "Select";
  
  private DistrProductTableModel tableModel1;
  private DistrProductTableModel tableModel2;
  
  private javax.swing.DefaultComboBoxModel  productModel;
  
  private int actionType;
  

    java.util.HashSet newSet1 = new java.util.HashSet();
    java.util.HashSet newSet2 = new java.util.HashSet();
    java.util.HashSet commonSet = new java.util.HashSet();


  
    /** Creates new form DSPDistrProductDialog */
    public DSPDistrProductDialog(java.awt.Frame parent,
                              boolean modal, 
			      DistrProductTableModel tabModel1,
			      DistrProductTableModel tabModel2,
			      javax.swing.DefaultComboBoxModel pModel, 
			      int defaultScope) 
    {    
        
	super (parent, modal);

	if (parent != null)
	    setLocationRelativeTo(parent);
           
        //this.setAlwaysOnTop(false);
        
	tableModel1        = tabModel1;
	tableModel2        = tabModel2;
	productModel       = pModel;
	
        
	int nrows1 = tableModel1.getRowCount();
	int nrows2 = tableModel2.getRowCount();
        
        java.util.HashSet currSet1 = new java.util.HashSet();
	java.util.HashSet currSet2 = new java.util.HashSet();
	java.util.HashSet prodSet = new java.util.HashSet();

	
	for (int i = 0; i < nrows1 ; i++)
	    currSet1.add((String)tableModel1.getValueAt(i,0));

	for (int i = 0; i < nrows2; i++)
	    currSet2.add((String)tableModel2.getValueAt(i,0));

	int nsize = pModel.getSize();
	for (int i = 0; i < nsize; i++)
	    prodSet.add((String)pModel.getElementAt(i));

	newSet1.addAll(prodSet);
	newSet2.addAll(prodSet);

	newSet1.removeAll(currSet1);
	newSet2.removeAll(currSet2);

	commonSet.addAll(newSet1);
	commonSet.retainAll(newSet2);

	
	if (commonSet.isEmpty()
	    && newSet1.isEmpty()
	    && newSet2.isEmpty()) {
	    //All products added
	    Log.getInstance().show_error(this,"Error",
					 "All products are already added",null);
	    okButton.setEnabled(false);
	}
	

        
    
	initComponents ();

    
	actionType=0;
        
       

        formatCombo.addItem(Constants.GLB_IDS_FORMAT);
        formatCombo.setSelectedItem(Constants.GLB_IDS_FORMAT);
        delayTextF.setText(Integer.toString(Constants.DSP_DEFAULT_DELAY));
        freewheelCB.setSelected(Constants.DSP_DEFAULT_FREEWHEEL);
        newsplusOffCB.setSelected(Constants.DSP_DEFAULT_NEWSPLUSOFF);
		derivedDataCombo.setSelectedItem(DistributorProductFlagOptions.getDerivedDataOptionString(Constants.DSP_DEFAULT_DERIVED_DATA_FLAG));
		languageCombo.setSelectedItem(Constants.OutputLanguageOptions[0]);
		encodingCombo.setSelectedItem(Constants.OutputEncodingOptions[0]);
        formatCombo.setEnabled(false);
        delayTextF.setEnabled(false);
        freewheelCB.setEnabled(false);
        newsplusOffCB.setEnabled(false);
        derivedDataCombo.setEnabled(false);
        languageCombo.setEnabled(false);
        encodingCombo.setEnabled(false);

       


      
        
        

	java.util.HashSet set  = null;
	java.awt.event.ActionEvent evt = null;

	if (!commonSet.isEmpty()) {
	    set = commonSet;
	    bothRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "Both");
	    
	} else if (!newSet1.isEmpty()) {
	    set = newSet1;
	    oneRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "One");
	    
	} else if (!newSet2.isEmpty()) {
	    set = newSet2;
	    twoRB.setSelected(true);
	    evt = new java.awt.event.ActionEvent(this,
			    java.awt.event.ActionEvent.ACTION_PERFORMED,
						 "Two");
	    
	}

	String prods[] = (String[])set.toArray(new String[1]);
	java.util.Arrays.sort(prods);
	productComboModel = new javax.swing.DefaultComboBoxModel(prods);
	

	productCombo.setModel(productComboModel);

	javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();

	if (commonSet.isEmpty()) {
	    bothRB.setEnabled(false);
	}
	if (newSet1.isEmpty()) {
	    oneRB.setEnabled(false);
	    group.add(twoRB);
	}
	if (newSet2.isEmpty()) {
	    twoRB.setEnabled(false);
	    group.add(oneRB);
	}


	scopeRBHandler(evt);
	    
	  



	String fmt = (String)formatCombo.getSelectedItem();
	allProductsCB.setText("Add all "+fmt+" products");
       

	validate();
	pack ();

      }

      /** This method is called from within the constructor to
       * initialize the form.
       * WARNING: Do NOT modify this code. The content of this method is
       * always regenerated by the FormEditor.
       */
      private void initComponents () {//GEN-BEGIN:initComponents
        jPanel1 = new javax.swing.JPanel ();
        jLabel1 = new javax.swing.JLabel ();
        productCombo = new javax.swing.JComboBox ();
        jLabel2 = new javax.swing.JLabel ();
        formatCombo = new javax.swing.JComboBox ();
        jLabel3 = new javax.swing.JLabel ();
        delayTextF = new ids2ui.IntTextField ();
        jLabel4 = new javax.swing.JLabel ();
        jLabel41 = new javax.swing.JLabel ();
        freewheelCB = new javax.swing.JCheckBox ();
        newsplusOffCB = new javax.swing.JCheckBox ();
        allProductsCB = new javax.swing.JCheckBox ();
        jPanel2 = new javax.swing.JPanel ();
        okButton = new javax.swing.JButton ();
        jButton3 = new javax.swing.JButton ();
        javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();
        derivedDataCombo = new javax.swing.JComboBox ();
        languageCombo = new javax.swing.JComboBox ();
        encodingCombo = new javax.swing.JComboBox ();

        jPanel3 = new javax.swing.JPanel ();
        bothRB = new javax.swing.JRadioButton ();
        group.add(bothRB);
        bothRB.setSelected(true);
        oneRB = new javax.swing.JRadioButton ();
        group.add(oneRB);
        twoRB = new javax.swing.JRadioButton ();
        group.add(twoRB);
        setTitle ("Distributor product configuration");
        addWindowListener (new java.awt.event.WindowAdapter () {
          public void windowClosing (java.awt.event.WindowEvent evt) {
            closeDialog (evt);
          }
        }
        );

        jPanel1.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints1;
        jPanel1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 10, 10, 10)));

          jLabel1.setText ("Product");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel1, gridBagConstraints1);
  
          productCombo.setActionCommand ("Product");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (productCombo, gridBagConstraints1);
  
          jLabel2.setText ("Format");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel2, gridBagConstraints1);
  
          formatCombo.setActionCommand ("Format");
          formatCombo.setEnabled (false);
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (formatCombo, gridBagConstraints1);
  
          jLabel3.setText ("Delay (mins.)");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel3, gridBagConstraints1);
  
          delayTextF.setColumns (10);
          delayTextF.setText ("0");
          delayTextF.setEnabled (false);
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (delayTextF, gridBagConstraints1);
  
          jLabel4.setText ("Free Wheel");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 3;
          gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel4, gridBagConstraints1);
  
          freewheelCB.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
          freewheelCB.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
          freewheelCB.setEnabled (false);
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 3;
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (freewheelCB, gridBagConstraints1);
  
          jLabel41.setText ("Block WSJ Link");
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 4;
          gridBagConstraints1.insets = new java.awt.Insets (0, 0, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel41, gridBagConstraints1);
  
          newsplusOffCB.setHorizontalTextPosition (javax.swing.SwingConstants.CENTER);
          newsplusOffCB.setHorizontalAlignment (javax.swing.SwingConstants.CENTER);
          newsplusOffCB.setEnabled (false);
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 1;
          gridBagConstraints1.gridy = 4;
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (newsplusOffCB, gridBagConstraints1);


          allProductsCB.setText ("Add all products");
          allProductsCB.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              allProductsSelected (evt);
            }
          }
          );
  
          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 2;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.insets = new java.awt.Insets (0, 5, 10, 0);
          jPanel1.add (allProductsCB, gridBagConstraints1);
  

        getContentPane ().add (jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout (new java.awt.FlowLayout (1, 15, 5));

          okButton.setText ("OK");
          okButton.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              dialogAction (evt);
            }
          }
          );
  
          jPanel2.add (okButton);
  
          jButton3.setText ("Cancel");
          jButton3.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              dialogAction (evt);
            }
          }
          );
  
          jPanel2.add (jButton3);
  

        getContentPane ().add (jPanel2, java.awt.BorderLayout.SOUTH);

        jPanel3.setLayout (new javax.swing.BoxLayout (jPanel3, 0));
        jPanel3.setBorder (new javax.swing.border.CompoundBorder(
        new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
        new javax.swing.border.LineBorder(java.awt.Color.black)));

          bothRB.setText ("Both");
          bothRB.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              scopeRBHandler (evt);
            }
          }
          );
  
          jPanel3.add (bothRB);
  
          oneRB.setText ("Data center - I only");
          oneRB.setActionCommand ("One");
          oneRB.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              scopeRBHandler (evt);
            }
          }
          );
  
          jPanel3.add (oneRB);
  
          twoRB.setText ("Data center - II only");
          twoRB.setActionCommand ("Two");
          twoRB.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              scopeRBHandler (evt);
            }
          }
          );
  
          jPanel3.add (twoRB);
  

        getContentPane ().add (jPanel3, java.awt.BorderLayout.NORTH);

      }//GEN-END:initComponents

private void allProductsSelected (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allProductsSelected
// Add your handling code here:
  
    if (allProductsCB.isSelected())
      productCombo.setEnabled(false);
    else
      productCombo.setEnabled(true);
  
  }//GEN-LAST:event_allProductsSelected

private void scopeRBHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scopeRBHandler
  // Add your handling code here:


    if (evt == null) return;
    
    String action = evt.getActionCommand();
    //System.out.println("Radio Button action :"+action);
    
    if (actionType==1) return;
    
    /* setup products  */
    
    String selectedItem = (String)productCombo.getSelectedItem();
    
    java.util.HashSet set  = null;
    if (action.equals("Both")){
	set = commonSet;
    } else if (action.equals("One")) {
	set = newSet1;
    } else if (action.equals("Two")) {
	set = newSet2;
    }
    
    String prods[] = (String[])set.toArray(new String[1]);
    java.util.Arrays.sort(prods);
    productComboModel = new javax.swing.DefaultComboBoxModel(prods);
    
    productCombo.setModel(productComboModel);
    
    if (selectedItem != null) productCombo.setSelectedItem(selectedItem);
    
  }//GEN-LAST:event_scopeRBHandler


private void dialogAction (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dialogAction
// Add your handling code here:
    String action = evt.getActionCommand();
    
    distrProductStruct1 = null;
    
    if (action.equals("OK")) {
      try {
        int delay = Integer.parseInt(delayTextF.getText());
        String dd = (String)derivedDataCombo.getSelectedItem();
		int ddf = DistributorProductFlagOptions.getDerivedDataOptionFlag(dd);
      
        if (allProductsCB.isSelected()) {
          String format = (String) formatCombo.getSelectedItem();
          java.util.Vector v = ConfigComm.getCSCSparseMatrixModel().getFormatProducts(format);
          
          int numprods = v.size();
        


          distrProductStruct1 = new DistrProductStructure[numprods];
          for (int i = 0; i < numprods; i++) {
            distrProductStruct1[i] = new DistrProductStructure(
                        (String) v.get(i),
                        format,
                        delay, freewheelCB.isSelected(),
                        newsplusOffCB.isSelected(), ddf, "NONE",
                        Constants.DSP_DEFAULT_FILTER_CODES,
                        Constants.OutputLanguageOptions[0],
                        Constants.OutputEncodingOptions[0],"NONE", false);
            }
        } else {
          distrProductStruct1 = new DistrProductStructure[1];
              distrProductStruct1[0] = new DistrProductStructure(
                      (String) productCombo.getSelectedItem(),
                      (String) formatCombo.getSelectedItem(),
                      delay, freewheelCB.isSelected(),
                      newsplusOffCB.isSelected(), ddf, "NONE",
                      Constants.DSP_DEFAULT_FILTER_CODES,
                      Constants.OutputLanguageOptions[0],
                      Constants.OutputEncodingOptions[0],"NONE", false);
          }
        
        
      } catch (NumberFormatException e) {
          distrProductStruct1= null;
          javax.swing.JOptionPane.showMessageDialog(this,"Error in parsing delay ","Error",javax.swing.JOptionPane.ERROR_MESSAGE);
          return;
      }
      
    }
  
    closeDialog(null);
  }//GEN-LAST:event_dialogAction

  public DistrProductStructure[] getDistrProduct1() {
    return distrProductStruct1;
  }

 
  
  public int getScope() {
    if (bothRB.isSelected()) return 0;
    if (oneRB.isSelected()) return 1;
    if (twoRB.isSelected()) return 2;
    return 0;
  }
  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
    setVisible (false);
    dispose ();
  }//GEN-LAST:event_closeDialog

  /**
  * @param args the command line arguments
  */
  public static void main (String args[]) {
    //new DSPDistrProductDialog (new javax.swing.JFrame (), true).show ();
  }


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel1;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JComboBox productCombo;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JComboBox formatCombo;
  private javax.swing.JLabel jLabel3;
  private ids2ui.IntTextField delayTextF;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JLabel jLabel41;
  private javax.swing.JCheckBox freewheelCB;
  private javax.swing.JCheckBox newsplusOffCB;
  private javax.swing.JCheckBox allProductsCB;
  private javax.swing.JComboBox derivedDataCombo;
  private javax.swing.JComboBox languageCombo;
  private javax.swing.JComboBox encodingCombo;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JButton okButton;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JRadioButton bothRB;
  private javax.swing.JRadioButton oneRB;
  private javax.swing.JRadioButton twoRB;
  // End of variables declaration//GEN-END:variables

}

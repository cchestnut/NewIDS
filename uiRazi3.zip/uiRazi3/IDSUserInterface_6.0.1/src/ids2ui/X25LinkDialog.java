/*
**  SCCS Info :  "@(#)X25LinkDialog.java	1.1    01/11/09"
*/

/*
 * X25LinkDialog.java
 *
 * Created on October 15, 2001, 3:10 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class X25LinkDialog extends javax.swing.JDialog {


    String distrTag = null;
    String dcmTag = null;
    String hostList1 = null;
    String hostList2 = null;
    String x25Link1 = null;
    String x25Link2 = null;
    String x25Type = null;
    
    String linkConfig1 = null;
    String linkConfig2 = null;


    final int NEW_LINK = 1;
    final int EXISTING_LINK = 2;
    final int IGNORE_LINK = 3;
    final int LOAD_ERROR = 4;

    int dc1LinkStatus = LOAD_ERROR;
    int dc2LinkStatus = LOAD_ERROR;

        
    private MutexLock   mLock = new MutexLock();
    private volatile boolean isExiting = false;
    
    javax.swing.ButtonGroup btnGroup = null;

    javax.swing.JDialog myFrame = null;


    String packetSizes = "128 256 512 1024 2048 4096";

    String X25LINK_FILENAME_PREFIX = "/etc/opt/SUNWconn/x25/config/link_config_";
    String X25LINK_FILENAME_SUFFIX = ".cfg";

    
    String X25LINK_COMMAND_PREFIX = "(export X25CONFIGDIR=/etc/SUNWconn/x25;export MYX25LINK=";

    String X25LINK_START_COMMAND = "; op linkstate -e $MYX25LINK >/dev/null 2>&1; case $? in 0|1) (mode=`op linkstate -e $MYX25LINK | awk '{printf $12}'`; if [ X${mode} = \"XOFF\" -o X${mode} = \"XD_CONN\" ]; then (op linkstart $MYX25LINK; echo \"Link started.\n`op linkstate -e $MYX25LINK`\"); else echo \"Link $MYX25LINK is already in running state.\n`op linkstate -e $MYX25LINK\"; fi);; 255) (op linkadd $MYX25LINK $X25CONFIGDIR);; 254) echo \"Can't start link.\nX.25 software is not running on host.\";; esac) ";

    String X25LINK_STOP_COMMAND = ";op linkstate -e $MYX25LINK >/dev/null 2>&1; case $? in 0|1) (mode=`op linkstate -e $MYX25LINK | awk '{printf $12}'`; if [ X${mode} = \"XOFF\" ]; then echo \"Link $MYX25LINK is already in stopped mode.\n`op linkstate -e $MYX25LINK`\"; else (op linkstop $MYX25LINK;echo \"Link stopped.\n`op linkstate -e $MYX25LINK`\"); fi);; 255) echo \"Can't stop link.\nLink $MYX25LINK does not exist.\";; 254) echo \"Can't stop link.\nX.25 software is not running on host.\";; esac) ";

    String X25LINK_STATUS_COMMAND =";op linkstate -e $MYX25LINK >/dev/null 2>&1; case $? in 0|1) op linkstate -e $MYX25LINK;; 255) echo \"Can't status link.\nLink $MYX25LINK does not exist.\";; 254) echo \"Can't status link.\nX.25 software is not running on host.\";; esac) ";



  

 /** Creates new form X25LinkDialog */
  public X25LinkDialog(java.awt.Frame parent,boolean modal,
		       String distr, String dcm, String hl1, String hl2 ) 
      throws Exception
  {
    super (parent, modal);

    java.util.HashMap distrConfig 
	= ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+distr);

    String transportString = (String)distrConfig.get("TRANSPORT_1");
    String transportString2 = (String)distrConfig.get("TRANSPORT_2");

    if (transportString==null) {
	transportString = (String)distrConfig.get("TRANSPORT");
	transportString2 = new String(transportString);
    }

    if (!Utils.isX25TransportType(transportString))
	throw new Exception("Distributor "+distr+" does not use X.25 protocol");

    Utils.X25AddrInfo addr1 = Utils.parseX25Field(transportString);
    Utils.X25AddrInfo addr2 = Utils.parseX25Field(transportString2);

    if ( (addr1==null) || (addr2==null) )
	throw new Exception("Error in parsing X.25 address for distributor: "
			+distr);
			

    if ( (hl1==null) || (hl2==null) ) {
	java.util.HashMap dcmConfig 
	    = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);

	hl1 = (String)dcmConfig.get("HOST1");
	hl2 = (String)dcmConfig.get("HOST2");
    }


    String link1, link2;

    
    if (addr1.type.startsWith("PVC")) {
	link1 = addr1.link;
	link2 = addr2.link;
    } else {
	link1 = addr1.link+Constants.SVC_SEPARATOR+addr1.dte;
	link2 = addr2.link+Constants.SVC_SEPARATOR+addr2.dte;
	
    }

    init(distr,dcm,hl1,hl2,link1, link2, addr1.type);
  }


  /** Creates new form X25LinkDialog */
  public X25LinkDialog(java.awt.Frame parent,boolean modal, 
	String distr,String dcm, String hl1, String hl2,
	String link1, String link2, String type ) 
  {
    super (parent, modal);
    init(distr,dcm,hl1,hl2,link1, link2, type);
  }


  /** Creates new form X25LinkDialog */
  public X25LinkDialog(java.awt.Frame parent,boolean modal, 
	String distr,String dcm, String link1, String link2, String type ) 
  throws Exception
  {
    super (parent, modal);
    
    java.util.HashMap dcmConfig 
		= ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);

    init(distr,dcm, (String)dcmConfig.get("HOST1"),
		(String)dcmConfig.get("HOST2"),link1, link2, type);
  }




    private String linkUISetup(String type, String link, 
			     javax.swing.JTextField linkField,
			     javax.swing.JTextField dteField)
    {
	String x25Link = null;
        if (type.startsWith("SVC")) {
	    int inx = link.indexOf('.');
	    if (inx<0) inx = link.indexOf(':');
	    x25Link = new String(link.substring(0,inx));
	    dteField.setText(link.substring(inx+1)); 
        } else {
	    x25Link = new String(link);
        }
	linkField.setText(x25Link);	
	return x25Link;
    }

    private void panelsetEnabled(javax.swing.JPanel panel, boolean mode) 
    {
	java.awt.Component [] c = panel.getComponents();

	for (int i = 0; i < c.length; i++) {
	    if (c[i] instanceof javax.swing.JPanel)
		panelsetEnabled((javax.swing.JPanel)c[i], mode);
	    else
		c[i].setEnabled(mode);
	}
    }




  private void init(String distr, String dcm, String hl1, String hl2,
		    String link1,String link2, String type )
  {

	/* Register window */
      myFrame = this;

      


    initComponents ();

    descTextField1.setDocument(new IDS_SwingUtils.LimitCharsDocument(128));
    descTextField2.setDocument(new IDS_SwingUtils.LimitCharsDocument(128));

	/* Disable buttons while loading */
    jButton5.setEnabled(false); // "Save configuration"
    jButton6.setEnabled(false); // "Start Link"
    jButton7.setEnabled(false); //"Stop Link"
    jButton8.setEnabled(false); // "Status Link"

    linkTextField1.setEditable(false);    
    linkTextField2.setEditable(false);
	

    javax.swing.ButtonGroup 
	group = new javax.swing.ButtonGroup();
    group.add(dceRadioButton1);
    group.add(dteRadioButton1);

    group = new javax.swing.ButtonGroup();
    group.add(dceRadioButton2);
    group.add(dteRadioButton2);

    btnGroup = new javax.swing.ButtonGroup();
    btnGroup.add(bothDCRadioButton);
    btnGroup.add(dc1RadioButton);
    btnGroup.add(dc2RadioButton);


    java.util.StringTokenizer tok = new java.util.StringTokenizer(packetSizes,
								  " \t");
    while (tok.hasMoreTokens()) {
	String item = tok.nextToken();
	packetSizeComboBox1.addItem(item);
	packetSizeComboBox2.addItem(item);
    }

    hostList1 = new String(hl1);
    hostList2 = new String(hl2);
    hostTextField1.setText(Utils.getShortNameFromHostList(hostList1));
    hostTextField2.setText(Utils.getShortNameFromHostList(hostList2));

    x25Type = new String(type);


    if (distr!=null)
	distrTag = new String(distr);

    dcmTag = new String(dcm);

    if (distrTag!=null) distrTextField.setText(distrTag);
    dcmTextField.setText(dcmTag);

    if (x25Type.startsWith("PVC")) {

	jPanel1.remove(jLabel24);
	jPanel1.remove(dteTextField1);

	jPanel11.remove(jLabel35);
	jPanel11.remove(dteTextField2);

    } else {
    	dteTextField1.setEditable(false);    
    	dteTextField2.setEditable(false);

	jPanel1.remove(jPanel5);
	jPanel1.remove(jLabel3);

	jPanel11.remove(jPanel14);
	jPanel11.remove(jLabel27);
    }

    //Disable UI while loading configuration
    panelsetEnabled(jPanel1, false);
    panelsetEnabled(jPanel11, false);
    dc1RadioButton.setEnabled(false);
    dc2RadioButton.setEnabled(false);
    bothDCRadioButton.setEnabled(false);
    jButton3.setEnabled(false);
    jButton4.setEnabled(false);

    if ((link1!=null)&&(link1.length()>0)) {
	x25Link1 = linkUISetup(x25Type,link1, linkTextField1,dteTextField1);
    } else {
	dc1LinkStatus = IGNORE_LINK;
    }
    
    if ((link2!=null)&&(link2.length()>0)) {
	x25Link2 = linkUISetup(x25Type,link2, linkTextField2,dteTextField2);
    }else {
	dc2LinkStatus = IGNORE_LINK;
    }
 
    pack ();

    /* Create and start loader threads */
    /* Enable buttons after loading is completed*/
    WindowEventAdapter.getInstance().registerWindow(
				Constants.X25_LINK_DIALOG_PREFIX+distr,
				this);
    statusPanel.start("Loading configuration. Please wait..");
    LoadLinkConfig loader = new LoadLinkConfig();
    loader.start();

  

  }
  
  
  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
  private void initComponents () {//GEN-BEGIN:initComponents
    jPanel2 = new javax.swing.JPanel ();
    jPanel3 = new javax.swing.JPanel ();
    jButton2 = new javax.swing.JButton ();
    statusPanel = new ids2ui.StatusPanel ();
    jPanel4 = new javax.swing.JPanel ();
    jLabel23 = new javax.swing.JLabel ();
    distrTextField = new javax.swing.JTextField ();
    dcmTextField = new javax.swing.JTextField ();
    jLabel8 = new javax.swing.JLabel ();
    jPanel8 = new javax.swing.JPanel ();
    jPanel9 = new javax.swing.JPanel ();
    jPanel1 = new javax.swing.JPanel ();
    jLabel1 = new javax.swing.JLabel ();
    dceRadioButton1 = new javax.swing.JRadioButton ();
    dteRadioButton1 = new javax.swing.JRadioButton ();
    jLabel2 = new javax.swing.JLabel ();
    descTextField1 = new javax.swing.JTextField ();
    jLabel3 = new javax.swing.JLabel ();
    jLabel4 = new javax.swing.JLabel ();
    jLabel5 = new javax.swing.JLabel ();
    linkTextField1 = new ids2ui.IntTextField ();
    packetSizeComboBox1 = new javax.swing.JComboBox ();
    jLabel6 = new javax.swing.JLabel ();
    jLabel7 = new javax.swing.JLabel ();
    windowSizeTextField1 = new ids2ui.IntTextField ();
    nsduLengthTextField1 = new ids2ui.IntTextField ();
    jPanel5 = new javax.swing.JPanel ();
    pvcMinTextField1 = new ids2ui.IntTextField ();
    jLabel12 = new javax.swing.JLabel ();
    pvcMaxTextField1 = new ids2ui.IntTextField ();
    jLabel19 = new javax.swing.JLabel ();
    jLabel24 = new javax.swing.JLabel ();
    dteTextField1 = new ids2ui.IntTextField ();
    hostTextField1 = new javax.swing.JTextField ();
    jPanel12 = new javax.swing.JPanel ();
    jButton3 = new javax.swing.JButton ();
    jPanel13 = new javax.swing.JPanel ();
    jButton4 = new javax.swing.JButton ();
    jPanel11 = new javax.swing.JPanel ();
    jLabel25 = new javax.swing.JLabel ();
    dceRadioButton2 = new javax.swing.JRadioButton ();
    dteRadioButton2 = new javax.swing.JRadioButton ();
    jLabel26 = new javax.swing.JLabel ();
    descTextField2 = new javax.swing.JTextField ();
    jLabel27 = new javax.swing.JLabel ();
    jLabel28 = new javax.swing.JLabel ();
    jLabel29 = new javax.swing.JLabel ();
    linkTextField2 = new ids2ui.IntTextField ();
    packetSizeComboBox2 = new javax.swing.JComboBox ();
    jLabel30 = new javax.swing.JLabel ();
    jLabel31 = new javax.swing.JLabel ();
    windowSizeTextField2 = new ids2ui.IntTextField ();
    nsduLengthTextField2 = new ids2ui.IntTextField ();
    jPanel14 = new javax.swing.JPanel ();
    pvcMinTextField2 = new ids2ui.IntTextField ();
    jLabel32 = new javax.swing.JLabel ();
    pvcMaxTextField2 = new ids2ui.IntTextField ();
    jLabel33 = new javax.swing.JLabel ();
    jLabel35 = new javax.swing.JLabel ();
    dteTextField2 = new ids2ui.IntTextField ();
    hostTextField2 = new javax.swing.JTextField ();
    jPanel10 = new javax.swing.JPanel ();
    jPanel15 = new javax.swing.JPanel ();
    bothDCRadioButton = new javax.swing.JRadioButton ();
    dc1RadioButton = new javax.swing.JRadioButton ();
    dc2RadioButton = new javax.swing.JRadioButton ();
    jPanel16 = new javax.swing.JPanel ();
    jButton5 = new javax.swing.JButton ();
    jButton6 = new javax.swing.JButton ();
    jButton7 = new javax.swing.JButton ();
    jButton8 = new javax.swing.JButton ();
    setTitle ("X.25 Link Configuration");
    addWindowListener (new java.awt.event.WindowAdapter () {
      public void windowClosing (java.awt.event.WindowEvent evt) {
        closeDialog (evt);
      }
    }
    );

    jPanel2.setLayout (new javax.swing.BoxLayout (jPanel2, 1));

      jPanel3.setLayout (new java.awt.FlowLayout (1, 20, 5));
  
        jButton2.setText ("Close");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
          public void actionPerformed (java.awt.event.ActionEvent evt) {
            exitForm (evt);
          }
        }
        );
    
        jPanel3.add (jButton2);
    
      jPanel2.add (jPanel3);
  
  
      jPanel2.add (statusPanel);
  

    getContentPane ().add (jPanel2, java.awt.BorderLayout.SOUTH);

    jPanel4.setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints1;
    jPanel4.setBorder (new javax.swing.border.CompoundBorder(
    new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
    new javax.swing.border.CompoundBorder(
    new javax.swing.border.TitledBorder(""),
    new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)))));

      jLabel23.setText ("Distributor");
  
      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 0;
      gridBagConstraints1.gridy = 0;
      gridBagConstraints1.insets = new java.awt.Insets (5, 0, 5, 0);
      jPanel4.add (jLabel23, gridBagConstraints1);
  
      distrTextField.setColumns (8);
      distrTextField.setEditable (false);
  
      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 1;
      gridBagConstraints1.gridy = 0;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.insets = new java.awt.Insets (5, 5, 5, 10);
      jPanel4.add (distrTextField, gridBagConstraints1);
  
      dcmTextField.setColumns (8);
      dcmTextField.setEditable (false);
  
      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 3;
      gridBagConstraints1.gridy = 0;
      gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
      gridBagConstraints1.insets = new java.awt.Insets (5, 5, 5, 0);
      jPanel4.add (dcmTextField, gridBagConstraints1);
  
      jLabel8.setText ("DCM");
  
      gridBagConstraints1 = new java.awt.GridBagConstraints ();
      gridBagConstraints1.gridx = 2;
      gridBagConstraints1.gridy = 0;
      gridBagConstraints1.insets = new java.awt.Insets (5, 0, 5, 0);
      jPanel4.add (jLabel8, gridBagConstraints1);
  

    getContentPane ().add (jPanel4, java.awt.BorderLayout.NORTH);

    jPanel8.setLayout (new java.awt.GridBagLayout ());
    java.awt.GridBagConstraints gridBagConstraints2;

      jPanel9.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints3;
  
        jPanel1.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints4;
        jPanel1.setBorder (new javax.swing.border.CompoundBorder(
        new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
        new javax.swing.border.CompoundBorder(
        new javax.swing.border.TitledBorder("Data Center - I"),
        new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)))));
    
          jLabel1.setText ("Interface");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 4;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel1, gridBagConstraints4);
      
          dceRadioButton1.setText ("DCE");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 4;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (dceRadioButton1, gridBagConstraints4);
      
          dteRadioButton1.setText ("DTE");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 2;
          gridBagConstraints4.gridy = 4;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (dteRadioButton1, gridBagConstraints4);
      
          jLabel2.setText ("Description");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 3;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel2, gridBagConstraints4);
      
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 3;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          gridBagConstraints4.weightx = 1.0;
          jPanel1.add (descTextField1, gridBagConstraints4);
      
          jLabel3.setText ("PVC Range");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 5;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel3, gridBagConstraints4);
      
          jLabel4.setText ("Packet Size");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 6;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel4, gridBagConstraints4);
      
          jLabel5.setText ("Link Number");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 1;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel5, gridBagConstraints4);
      
          linkTextField1.setColumns (5);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 1;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (linkTextField1, gridBagConstraints4);
      
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 6;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (packetSizeComboBox1, gridBagConstraints4);
      
          jLabel6.setText ("Window Size");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 7;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel6, gridBagConstraints4);
      
          jLabel7.setText ("NSDU Length");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 8;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel7, gridBagConstraints4);
      
          windowSizeTextField1.setColumns (5);
          windowSizeTextField1.setText ("7");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 7;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (windowSizeTextField1, gridBagConstraints4);
      
          nsduLengthTextField1.setColumns (5);
          nsduLengthTextField1.setText ("2048");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 8;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (nsduLengthTextField1, gridBagConstraints4);
      
          jPanel5.setLayout (new java.awt.FlowLayout (0, 5, 5));
      
            pvcMinTextField1.setColumns (5);
            pvcMinTextField1.setText ("1");
        
            jPanel5.add (pvcMinTextField1);
        
            jLabel12.setText ("-");
        
            jPanel5.add (jLabel12);
        
            pvcMaxTextField1.setColumns (5);
            pvcMaxTextField1.setText ("50");
        
            jPanel5.add (pvcMaxTextField1);
        
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 5;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jPanel5, gridBagConstraints4);
      
          jLabel19.setText ("Host");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel19, gridBagConstraints4);
      
          jLabel24.setText ("DTE Address");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 0;
          gridBagConstraints4.gridy = 2;
          gridBagConstraints4.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (jLabel24, gridBagConstraints4);
      
          dteTextField1.setColumns (15);
          dteTextField1.setText ("39990000000100");
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridx = 1;
          gridBagConstraints4.gridy = 2;
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (dteTextField1, gridBagConstraints4);
      
          hostTextField1.setColumns (16);
          hostTextField1.setEditable (false);
      
          gridBagConstraints4 = new java.awt.GridBagConstraints ();
          gridBagConstraints4.gridwidth = 2;
          gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints4.insets = new java.awt.Insets (1, 10, 5, 0);
          gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
          jPanel1.add (hostTextField1, gridBagConstraints4);
      
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 0;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.gridheight = 2;
        gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints3.weightx = 0.5;
        gridBagConstraints3.weighty = 1.0;
        jPanel9.add (jPanel1, gridBagConstraints3);
    
    
          jButton3.setMargin (new java.awt.Insets(2, 5, 2, 5));
          jButton3.setText (">>");
          jButton3.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              copyConfig (evt);
            }
          }
          );
      
          jPanel12.add (jButton3);
      
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.SOUTH;
        gridBagConstraints3.weighty = 0.5;
        jPanel9.add (jPanel12, gridBagConstraints3);
    
    
          jButton4.setMargin (new java.awt.Insets(2, 5, 2, 5));
          jButton4.setText ("<<");
          jButton4.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              copyConfig (evt);
            }
          }
          );
      
          jPanel13.add (jButton4);
      
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 1;
        gridBagConstraints3.gridy = 1;
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints3.weighty = 0.5;
        jPanel9.add (jPanel13, gridBagConstraints3);
    
        jPanel11.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints5;
        jPanel11.setBorder (new javax.swing.border.CompoundBorder(
        new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
        new javax.swing.border.CompoundBorder(
        new javax.swing.border.TitledBorder(
        new javax.swing.border.EtchedBorder(), "Data Center - II"),
        new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)))));
    
          jLabel25.setText ("Interface");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 4;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel25, gridBagConstraints5);
      
          dceRadioButton2.setText ("DCE");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 4;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (dceRadioButton2, gridBagConstraints5);
      
          dteRadioButton2.setText ("DTE");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 2;
          gridBagConstraints5.gridy = 4;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (dteRadioButton2, gridBagConstraints5);
      
          jLabel26.setText ("Description");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 3;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel26, gridBagConstraints5);
      
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 3;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          gridBagConstraints5.weightx = 1.0;
          jPanel11.add (descTextField2, gridBagConstraints5);
      
          jLabel27.setText ("PVC Range");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 5;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel27, gridBagConstraints5);
      
          jLabel28.setText ("Packet Size");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 6;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel28, gridBagConstraints5);
      
          jLabel29.setText ("Link Number");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 1;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel29, gridBagConstraints5);
      
          linkTextField2.setColumns (5);
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 1;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (linkTextField2, gridBagConstraints5);
      
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 6;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (packetSizeComboBox2, gridBagConstraints5);
      
          jLabel30.setText ("Window Size");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 7;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel30, gridBagConstraints5);
      
          jLabel31.setText ("NSDU Length");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 8;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel31, gridBagConstraints5);
      
          windowSizeTextField2.setColumns (5);
          windowSizeTextField2.setText ("7");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 7;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (windowSizeTextField2, gridBagConstraints5);
      
          nsduLengthTextField2.setColumns (5);
          nsduLengthTextField2.setText ("2048");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 8;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (nsduLengthTextField2, gridBagConstraints5);
      
          jPanel14.setLayout (new java.awt.FlowLayout (0, 5, 5));
      
            pvcMinTextField2.setColumns (5);
            pvcMinTextField2.setText ("1");
        
            jPanel14.add (pvcMinTextField2);
        
            jLabel32.setText ("-");
        
            jPanel14.add (jLabel32);
        
            pvcMaxTextField2.setColumns (5);
            pvcMaxTextField2.setText ("50");
        
            jPanel14.add (pvcMaxTextField2);
        
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 5;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jPanel14, gridBagConstraints5);
      
          jLabel33.setText ("Host");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel33, gridBagConstraints5);
      
          jLabel35.setText ("DTE Address");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 0;
          gridBagConstraints5.gridy = 2;
          gridBagConstraints5.insets = new java.awt.Insets (5, 0, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (jLabel35, gridBagConstraints5);
      
          dteTextField2.setColumns (15);
          dteTextField2.setText ("39990000000100");
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridx = 1;
          gridBagConstraints5.gridy = 2;
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (dteTextField2, gridBagConstraints5);
      
          hostTextField2.setEditable (false);
      
          gridBagConstraints5 = new java.awt.GridBagConstraints ();
          gridBagConstraints5.gridwidth = 2;
          gridBagConstraints5.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints5.insets = new java.awt.Insets (5, 10, 5, 0);
          gridBagConstraints5.anchor = java.awt.GridBagConstraints.WEST;
          jPanel11.add (hostTextField2, gridBagConstraints5);
      
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.gridx = 2;
        gridBagConstraints3.gridy = 0;
        gridBagConstraints3.gridheight = 2;
        gridBagConstraints3.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints3.weightx = 0.5;
        gridBagConstraints3.weighty = 1.0;
        jPanel9.add (jPanel11, gridBagConstraints3);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 1.0;
      gridBagConstraints2.weighty = 0.8;
      jPanel8.add (jPanel9, gridBagConstraints2);
  
      jPanel10.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints6;
      jPanel10.setBorder (new javax.swing.border.CompoundBorder(
      new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
      new javax.swing.border.TitledBorder("")));
  
        jPanel15.setLayout (new java.awt.FlowLayout (1, 20, 5));
    
          bothDCRadioButton.setText ("Both");
      
          jPanel15.add (bothDCRadioButton);
      
          dc1RadioButton.setText ("Data Center - I");
      
          jPanel15.add (dc1RadioButton);
      
          dc2RadioButton.setText ("Data Center - II");
      
          jPanel15.add (dc2RadioButton);
      
        gridBagConstraints6 = new java.awt.GridBagConstraints ();
        gridBagConstraints6.gridx = 0;
        gridBagConstraints6.gridy = 0;
        gridBagConstraints6.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints6.weightx = 1.0;
        jPanel10.add (jPanel15, gridBagConstraints6);
    
        jPanel16.setLayout (new java.awt.FlowLayout (1, 10, 5));
    
          jButton5.setText ("Save configuration");
          jButton5.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              linkActionHandler (evt);
            }
          }
          );
      
          jPanel16.add (jButton5);
      
          jButton6.setText ("Start Link");
          jButton6.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              linkActionHandler (evt);
            }
          }
          );
      
          jPanel16.add (jButton6);
      
          jButton7.setText ("Stop Link");
          jButton7.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              linkActionHandler (evt);
            }
          }
          );
      
          jPanel16.add (jButton7);
      
          jButton8.setText ("Status Link");
          jButton8.addActionListener (new java.awt.event.ActionListener () {
            public void actionPerformed (java.awt.event.ActionEvent evt) {
              linkActionHandler (evt);
            }
          }
          );
      
          jPanel16.add (jButton8);
      
        gridBagConstraints6 = new java.awt.GridBagConstraints ();
        gridBagConstraints6.gridx = 0;
        gridBagConstraints6.gridy = 1;
        jPanel10.add (jPanel16, gridBagConstraints6);
    
      gridBagConstraints2 = new java.awt.GridBagConstraints ();
      gridBagConstraints2.gridx = 0;
      gridBagConstraints2.gridy = 1;
      gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
      gridBagConstraints2.weightx = 1.0;
      gridBagConstraints2.weighty = 0.2;
      jPanel8.add (jPanel10, gridBagConstraints2);
  

    getContentPane ().add (jPanel8, java.awt.BorderLayout.CENTER);

  }//GEN-END:initComponents

private void linkActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkActionHandler
// Add your handling code here:
    Object src = evt.getSource();
    javax.swing.JButton source = null;
    String cmd = evt.getActionCommand();
    int scope = -1;

    if (bothDCRadioButton.isSelected()) 
	scope = 0;
    else if (dc1RadioButton.isSelected())
	scope = 1;
    else if (dc2RadioButton.isSelected())
	scope = 2;

    if (scope == -1) {
	Utils.showDialog(this,"Please select the host for command");
	return;
    }

    if (src instanceof javax.swing.JButton ) {
	source = (javax.swing.JButton)src;
	source.setEnabled(false);
    }
    
    final Utils.ActionWorker sw = new Utils.ActionWorker(source,
							 (String)cmd) {
	public Object construct() {
	    _linkActionHandler(cmdButton, action);
	    return null;
	}
    };
    
    sw.start();
    

  }//GEN-LAST:event_linkActionHandler


    private Utils.SaveX25ConfigFile createSaveThread(String orig_config,
					     Utils.x25ConfigParams params,
					     String hosts, 
					     String saveFilename)
	throws Exception
    {
	
	String saveConfig = Utils.applyX25Configuration(orig_config,
							params );

	Utils.SaveX25ConfigFile  saveThread 
	    = new Utils.SaveX25ConfigFile(hosts, saveFilename, 
					  saveConfig, null);
	
		
	return saveThread;

    }




    private void _linkActionHandler(javax.swing.JButton cmdButton, 
				    String action) 
    {


	try {
	    mLock.acquire();
	} catch (InterruptedException ie) {
	    Log.getInstance().log_error("Service handler interrupted",ie);
	    if (cmdButton != null ) 
		cmdButton.setEnabled(true);
	    return;
	}

	int scope = -1;

	if (bothDCRadioButton.isSelected()) 
	    scope = 0;
	else if (dc1RadioButton.isSelected())
	    scope = 1;
	else if (dc2RadioButton.isSelected())
	    scope = 2;
	
	String link1 = linkTextField1.getText();
	String link2 = linkTextField2.getText();
	String statusStr1=null, statusStr2=null;

	statusPanel.start("Please wait ...");

    ACTIONBLOCK:
	if (action.startsWith("Save")) {
	    statusPanel.showStatus("Saving configuration. Please wait ...");

	    Utils.SaveX25ConfigFile saveThread1 = null,
		saveThread2=null;

	    String user = ConfigComm.getUserName();


	    if (scope == 1 || scope == 0) {

		StringBuffer buf = new StringBuffer();
		StringBuffer sfx = new StringBuffer(x25Link1);
		for (int i = 4; i > x25Link1.length(); i--)
		    sfx.insert(0,'0');
		
		
		
		String device = "/dev/hihp"+x25Link1;
		String pvcrange = pvcMinTextField1.getText()
		    +"-"+pvcMaxTextField1.getText();
		String desc = descTextField1.getText();
		String iface = dceRadioButton1.isSelected()?"DCE":"DTE";
		String ps = (String)packetSizeComboBox1.getSelectedItem();
		String ws = windowSizeTextField1.getText();
		String nsl = nsduLengthTextField1.getText();
		
		
		Utils.x25ConfigParams params =
		    new Utils.x25ConfigParams(user, device, 
					      pvcrange,desc,
					      iface, ps,ws,nsl);
		try {
		    saveThread1 = createSaveThread(linkConfig1, params,
						   hostList1, "link_config_"
						   +sfx.toString()+".cfg");
		    
		    saveThread1.start();
		} catch (Exception e) {
		    statusStr1 = "Data center - I:\n"
			+"Error in creating configuration buffer "
			+"for link: "+x25Link1
			+"\n\t\t"+e.getMessage()+"\n";
		    Log.getInstance().log_error("Error in creating "
						+"configuration buffer for DC-I:link: "
						+x25Link1, e);
		}

	    } // (scope == 1 || scope == 0)




	    if (scope == 2 || scope == 0) {

		StringBuffer buf = new StringBuffer();
		StringBuffer sfx = new StringBuffer(x25Link2);
		for (int i = 4; i > x25Link2.length(); i--)
		    sfx.insert(0,'0');
		
		
		
		String device = "/dev/hihp"+x25Link2;
		String pvcrange = pvcMinTextField2.getText()
		    +"-"+pvcMaxTextField2.getText();
		String desc = descTextField2.getText();
		String iface = dceRadioButton2.isSelected()?"DCE":"DTE";
		String ps = (String)packetSizeComboBox2.getSelectedItem();
		String ws = windowSizeTextField2.getText();
		String nsl = nsduLengthTextField2.getText();
	

		Utils.x25ConfigParams params = 
		    new Utils.x25ConfigParams(user, device, 
			  pvcrange,desc,
			  iface, ps,ws,nsl);


		try {
		    saveThread2 = createSaveThread(linkConfig2, params,
						   hostList2, "link_config_"
						   +sfx.toString()+".cfg");
		    saveThread2.start();

		} catch  (Exception e) {
		    statusStr1 = "Data center - II:\n"
			+"Error in creating configuration buffer "
			+"for link: "+x25Link2
			+"\n\t\t"+e.getMessage()+"\n";
		    Log.getInstance().log_error("Error in creating "
						+"configuration buffer for DC-II:link: "
						+x25Link2, e);
		}
	    } // (scope == 2 || scope == 0) 
	    

	    if (saveThread1!=null) {
		Exception e = (Exception)saveThread1.get();
		if (e!=null)
		    statusStr1 = "Data center - I:\n"
			+"Error in saving configuration: \n\t\t"
			+e.getMessage()+"\n";
	    }
	    if (saveThread2!=null) {
		Exception e = (Exception)saveThread2.get();
		if (e!=null)
		    statusStr2 = "Data center - II:\n"
			+"Error in saving configuration: \n\t\t"
			+e.getMessage()+"\n";
	    }

	    

	} else {   	

	    String command1 = null;
	    String command2 = null;

	    if (action.startsWith("Start")) {

		if (scope==1||scope==0)
		    command1 = X25LINK_COMMAND_PREFIX+link1
			+X25LINK_START_COMMAND;

		if (scope==2||scope==0)
		    command2 = X25LINK_COMMAND_PREFIX+link2
			+X25LINK_START_COMMAND;

	    } else if (action.startsWith("Stop")) {

		if (scope==1||scope==0)
		    command1 = X25LINK_COMMAND_PREFIX+link1
			+X25LINK_STOP_COMMAND;

		if (scope==2||scope==0)
		    command2 = X25LINK_COMMAND_PREFIX+link2
			+X25LINK_STOP_COMMAND;

	    } else if (action.startsWith("Status")) {

		if (scope==1||scope==0)
		    command1 = X25LINK_COMMAND_PREFIX+link1
			+X25LINK_STATUS_COMMAND;

		if (scope==2||scope==0)
		    command2 = X25LINK_COMMAND_PREFIX+link2
			+X25LINK_STATUS_COMMAND;
		    
	    } else {
		Log.getInstance().log_error("Command cannot be handled: "+action,null);
		    break ACTIONBLOCK;
	    }



	    
	    if (command1 != null) {
		try {

		    byte b[] = AdminComm.serviceRequest(hostList1,
						    AdminComm.EXEC_COMMAND,
						    AdminComm.RUN_COMMAND,
						    command1);
		
		    String resp = new String(b);
		    int inx = resp.indexOf(ConfigComm.CONF_STX)+1;
		    
		    if (inx > 0) {
			statusStr1 = "Data Center - I :\n"
			    +resp.substring(inx).trim()+"\n";
		    } else {
			statusStr1 = "Data Center - I :\n"
			    +"Error while handling request.\n";
		    }

		} catch (Exception e) {
		    Log.getInstance().log_error("Error in sending request to "+hostList1+" ("+command1+")",e);
		    statusStr1 = "Data Center - I :\n"
			+e.getMessage()+".\n";
		}
	    } // command1 != null
	    
	    
	    if (command2 != null) {

		try {

		    byte b[] = AdminComm.serviceRequest(hostList2,
						    AdminComm.EXEC_COMMAND,
						    AdminComm.RUN_COMMAND,
						    command2);
		
		    String resp = new String(b);
		    int inx = resp.indexOf(ConfigComm.CONF_STX)+1;
		    
		    if (inx > 0) {
			statusStr2 = "Data Center - II :\n"
			    +resp.substring(inx).trim()+"\n";
		    } else {
			statusStr2 = "Data Center - II :\n"
			    +"Error while handling request.\n";
			
		    }
		} catch (Exception e) {
		    Log.getInstance().log_error("Error in sending request to "+hostList2+" ("+command2+")",e);
		    statusStr2 = "Data Center - II :\n"
			+e.getMessage()+".\n";
		}
		    
	    } // command2!= null

	   
	    
	    
	}

	String statusStr = null;
	if (statusStr1 != null && statusStr2!=null)
	    statusStr = statusStr1+"\n\n"+statusStr2;
	else if (statusStr1!=null) 
	    statusStr = statusStr1;
	else if (statusStr2!=null)
	    statusStr = statusStr2;
	
	if ( (statusStr != null) && (statusStr.length() > 0) )
	    Utils.showDialog(this,statusStr);
	
	
	statusPanel.stop();
	statusPanel.clear();
	mLock.release();
	if (cmdButton != null ) cmdButton.setEnabled(true);
	
	return;
	
    }
    





private void copyConfig (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyConfig
// Add your handling code here:

	String action = evt.getActionCommand();

	javax.swing.JTextField 	src_linkTextField = null,
				src_dteTextField = null,
				src_pvcMinTextField = null,
				src_pvcMaxTextField = null,
				src_windowSizeTextField = null,
				src_nsduLengthTextField= null;
	javax.swing.JComboBox   src_packetSizeComboBox = null;
	javax.swing.JRadioButton   src_dceRadioButton = null;
	javax.swing.JRadioButton   src_dteRadioButton = null;

	javax.swing.JTextField dst_linkTextField = null,
				dst_dteTextField = null,
				dst_pvcMinTextField = null,
				dst_pvcMaxTextField = null,
				dst_windowSizeTextField = null,
				dst_nsduLengthTextField= null;
	javax.swing.JComboBox   dst_packetSizeComboBox = null;
	javax.swing.JRadioButton   dst_dceRadioButton = null;
	javax.swing.JRadioButton   dst_dteRadioButton = null;

	if (action.equals(">>")) {
		src_linkTextField = linkTextField1;
		src_dteTextField = dteTextField1;
		src_pvcMinTextField = pvcMinTextField1;
		src_pvcMaxTextField = pvcMaxTextField1;
		src_windowSizeTextField = windowSizeTextField1;
		src_nsduLengthTextField = nsduLengthTextField1;
		src_packetSizeComboBox = packetSizeComboBox1;
		src_dceRadioButton = dceRadioButton1;
		src_dteRadioButton = dteRadioButton1;

		dst_linkTextField = linkTextField2;
		dst_dteTextField = dteTextField2;
		dst_pvcMinTextField = pvcMinTextField2;
		dst_pvcMaxTextField = pvcMaxTextField2;
		dst_windowSizeTextField = windowSizeTextField2;
		dst_nsduLengthTextField = nsduLengthTextField2;
		dst_packetSizeComboBox = packetSizeComboBox2;
		dst_dceRadioButton = dceRadioButton2;
		dst_dteRadioButton = dteRadioButton2;
	} else {
		src_linkTextField = linkTextField2;
		src_dteTextField = dteTextField2;
		src_pvcMinTextField = pvcMinTextField2;
		src_pvcMaxTextField = pvcMaxTextField2;
		src_windowSizeTextField = windowSizeTextField2;
		src_nsduLengthTextField = nsduLengthTextField2;
		src_packetSizeComboBox = packetSizeComboBox2;
		src_dceRadioButton = dceRadioButton2;
		src_dteRadioButton = dteRadioButton2;

		dst_linkTextField = linkTextField1;
		dst_dteTextField = dteTextField1;
		dst_pvcMinTextField = pvcMinTextField1;
		dst_pvcMaxTextField = pvcMaxTextField1;
		dst_windowSizeTextField = windowSizeTextField1;
		dst_nsduLengthTextField = nsduLengthTextField1;
		dst_packetSizeComboBox = packetSizeComboBox1;
		dst_dceRadioButton = dceRadioButton1;
		dst_dteRadioButton = dteRadioButton1;
	}

	//dst_linkTextField.setText(src_linkTextField.getText());
	//dst_dteTextField.setText(src_dteTextField.getText());
	dst_pvcMinTextField.setText(src_pvcMinTextField.getText());
	dst_pvcMaxTextField.setText(src_pvcMaxTextField.getText());
	dst_windowSizeTextField.setText(src_windowSizeTextField.getText());
	dst_nsduLengthTextField.setText(src_nsduLengthTextField.getText());
	dst_packetSizeComboBox.setSelectedItem(src_packetSizeComboBox.getSelectedItem());
	dst_dceRadioButton.setSelected(src_dceRadioButton.isSelected());
	dst_dteRadioButton.setSelected(src_dteRadioButton.isSelected());


  }//GEN-LAST:event_copyConfig

private void exitForm (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitForm
// Add your handling code here:

    if (isExiting) return;

    isExiting = true;

    final javax.swing.JPanel gpanel = 
	(javax.swing.JPanel) getGlassPane();

    gpanel.setLayout(new java.awt.GridBagLayout());

	
    final StatusPanel sp = new StatusPanel();
    sp.setBackground(java.awt.Color.yellow);
    sp.start("Closing window.\nPlease wait..");
	
    gpanel.add(sp);
    gpanel.validate();
    gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
    gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
    gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
    gpanel.setVisible(true);
    
    
    final X25LinkDialog This = this;
    
    final SwingWorker exitThread = new SwingWorker() {
	public Object construct() {
	    try {
		mLock.acquire();
	    } catch (InterruptedException ie ) {}
	    return null;
	}
	
	public void finished() {
	    This.setVisible(false);
	    sp.stop();
	    gpanel.removeAll();
	    gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	    gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
	    This.dispose();
	    WindowEventAdapter.getInstance().unregisterWindow(This);
	}
	
    };
    
    exitThread.start();
    

  }//GEN-LAST:event_exitForm

  /** Closes the dialog */
  private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
      exitForm(null);
  }//GEN-LAST:event_closeDialog

  /**
  * @param args the command line arguments
  */
  public static void main (String args[]) {
    
    try {
      ConfigComm.initLogin("test","dist-c1q1,dist-c1q2","/ids2"); 
    new X25LinkDialog (new javax.swing.JFrame (), true, 
		       "X25T","DCMQ3","dcm-c1q3","dcm-c1q4","15","10",
                        "PVCIN").show ();
  } catch (Exception e) {e.printStackTrace();}
  }


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel2;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JButton jButton2;
  private ids2ui.StatusPanel statusPanel;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JLabel jLabel23;
  private javax.swing.JTextField distrTextField;
  private javax.swing.JTextField dcmTextField;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JPanel jPanel8;
  private javax.swing.JPanel jPanel9;
  private javax.swing.JPanel jPanel1;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JRadioButton dceRadioButton1;
  private javax.swing.JRadioButton dteRadioButton1;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JTextField descTextField1;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JLabel jLabel5;
  private ids2ui.IntTextField linkTextField1;
  private javax.swing.JComboBox packetSizeComboBox1;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JLabel jLabel7;
  private ids2ui.IntTextField windowSizeTextField1;
  private ids2ui.IntTextField nsduLengthTextField1;
  private javax.swing.JPanel jPanel5;
  private ids2ui.IntTextField pvcMinTextField1;
  private javax.swing.JLabel jLabel12;
  private ids2ui.IntTextField pvcMaxTextField1;
  private javax.swing.JLabel jLabel19;
  private javax.swing.JLabel jLabel24;
  private ids2ui.IntTextField dteTextField1;
  private javax.swing.JTextField hostTextField1;
  private javax.swing.JPanel jPanel12;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel13;
  private javax.swing.JButton jButton4;
  private javax.swing.JPanel jPanel11;
  private javax.swing.JLabel jLabel25;
  private javax.swing.JRadioButton dceRadioButton2;
  private javax.swing.JRadioButton dteRadioButton2;
  private javax.swing.JLabel jLabel26;
  private javax.swing.JTextField descTextField2;
  private javax.swing.JLabel jLabel27;
  private javax.swing.JLabel jLabel28;
  private javax.swing.JLabel jLabel29;
  private ids2ui.IntTextField linkTextField2;
  private javax.swing.JComboBox packetSizeComboBox2;
  private javax.swing.JLabel jLabel30;
  private javax.swing.JLabel jLabel31;
  private ids2ui.IntTextField windowSizeTextField2;
  private ids2ui.IntTextField nsduLengthTextField2;
  private javax.swing.JPanel jPanel14;
  private ids2ui.IntTextField pvcMinTextField2;
  private javax.swing.JLabel jLabel32;
  private ids2ui.IntTextField pvcMaxTextField2;
  private javax.swing.JLabel jLabel33;
  private javax.swing.JLabel jLabel35;
  private ids2ui.IntTextField dteTextField2;
  private javax.swing.JTextField hostTextField2;
  private javax.swing.JPanel jPanel10;
  private javax.swing.JPanel jPanel15;
  private javax.swing.JRadioButton bothDCRadioButton;
  private javax.swing.JRadioButton dc1RadioButton;
  private javax.swing.JRadioButton dc2RadioButton;
  private javax.swing.JPanel jPanel16;
  private javax.swing.JButton jButton5;
  private javax.swing.JButton jButton6;
  private javax.swing.JButton jButton7;
  private javax.swing.JButton jButton8;
  // End of variables declaration//GEN-END:variables





    private class LoadLinkConfig 
    extends SwingWorker 
    {
	Utils.LoadX25ConfigFile loadThread1 = null;
	Utils.LoadX25ConfigFile loadThread2 = null;
	Utils.LoadX25ConfigFile loadThread0 = null;

	Exception exc1 = null, exc2 = null;
	Exception exc0 = null;

	String defaultLinkConfig = null;

	Utils.x25ConfigParams linkDefaultParams = null;


	public Object construct()
	{

	    try {
		mLock.acquire();
	    } catch (InterruptedException ie) {
		Log.getInstance().log_error("LoadLinkConfig:Service handler interrupted",ie);
		return null;
	    }

	    loadThread0
		= new Utils.LoadX25ConfigFile(hostList1,null);
	    loadThread0.start();

	    if (dc1LinkStatus != IGNORE_LINK) {
		StringBuffer lb = new StringBuffer(x25Link1);
		for (int i = 4; i > x25Link1.length(); i--)
		    lb.insert(0,'0');
	
		loadThread1 = 
		    new Utils.LoadX25ConfigFile(hostList1,
						X25LINK_FILENAME_PREFIX
						+lb.toString()
						+X25LINK_FILENAME_SUFFIX);
		loadThread1.start();

	    }

	    if (dc2LinkStatus != IGNORE_LINK) {
		StringBuffer lb = new StringBuffer(x25Link2);
		for (int i = 4; i > x25Link2.length(); i--)
		    lb.insert(0,'0');
	
		loadThread2 = 
		    new Utils.LoadX25ConfigFile(hostList2,
						X25LINK_FILENAME_PREFIX
						+lb.toString()
						+X25LINK_FILENAME_SUFFIX);
		loadThread2.start();


	    }


	    if (dc1LinkStatus != IGNORE_LINK) {
		linkConfig1 = (String)loadThread1.get();
		exc1 = loadThread1.getException();
	    }

	    if (dc2LinkStatus != IGNORE_LINK) {
		linkConfig2 = (String)loadThread2.get();
		exc2 = loadThread2.getException();
	    }

	    defaultLinkConfig = (String)loadThread0.get();
	    exc0 = loadThread0.getException();
	    if ( (defaultLinkConfig==null) 
		 || defaultLinkConfig.equals("Error")) {
		loadThread0
		    = new Utils.LoadX25ConfigFile(hostList2,null);
		loadThread0.start();
		defaultLinkConfig = (String)loadThread0.get();
		exc0 = loadThread0.getException();
	    } 

	    mLock.release();

	    return null;

	} // End of construct()



			    
	public void finished()
	{
	    StringBuffer errstr = new StringBuffer();

	    boolean defaultConfigError = true;

	    if ( (defaultLinkConfig!=null) 
		 && (!defaultLinkConfig.equals("Error"))  ) {

		try {
		    linkDefaultParams = Utils.parseX25Configuration(defaultLinkConfig);
		    defaultConfigError = false;
		} catch (Exception e) {
		    Log.getInstance().log_error("Error in parsing default link configuration file.",
						e);
		}

	    }

	    
	    if (dc1LinkStatus != IGNORE_LINK) {
		
		if ((linkConfig1 == null) && (linkDefaultParams!=null)) {

		    dc1LinkStatus = NEW_LINK;
		    linkConfig1 = new String(defaultLinkConfig);
		    initUI(linkDefaultParams, descTextField1,dceRadioButton1,
			       dteRadioButton1, packetSizeComboBox1,
			       windowSizeTextField1,nsduLengthTextField1,
			       pvcMinTextField1, pvcMaxTextField1);

		} else if ( (linkConfig1 != null)
		     && (!linkConfig1.equals("Error"))) {

		    try {
			Utils.x25ConfigParams p = Utils.parseX25Configuration(linkConfig1);
			initUI(p,descTextField1,dceRadioButton1,
			       dteRadioButton1, packetSizeComboBox1,
			       windowSizeTextField1,nsduLengthTextField1,
			       pvcMinTextField1, pvcMaxTextField1);

			dc1LinkStatus = EXISTING_LINK;
			
		    } catch (Exception e) {
			dc1LinkStatus = LOAD_ERROR;
			Log.getInstance().log_error("Error in parsing configuration file for link "
						    +x25Link1+" on "+hostList1, e);
			errstr.append("Error in parsing configuration file"
				      +"for link "+x25Link1+" on "+hostList1+"\n");
		    }

		} else {
		    dc1LinkStatus = LOAD_ERROR;
		    errstr.append("Error in loading link configuration: "
				  + x25Link1+" from "+hostList1+"\n");
		    if (exc1!=null) errstr.append("\t"+exc1.getMessage()+"\n");
		}

	    }




	    if (dc2LinkStatus != IGNORE_LINK) {

		if ((linkConfig2 == null) && (linkDefaultParams!=null)) {

		    dc2LinkStatus = NEW_LINK;
		    linkConfig2 = new String(defaultLinkConfig);
		    initUI(linkDefaultParams, descTextField2,dceRadioButton2,
			       dteRadioButton2, packetSizeComboBox2,
			       windowSizeTextField2,nsduLengthTextField2,
			       pvcMinTextField2, pvcMaxTextField2);

		} else if ( (linkConfig2 != null) 
			    && (!linkConfig2.equals("Error")) ) {


		    try {
			Utils.x25ConfigParams p = Utils.parseX25Configuration(linkConfig2);
			initUI(p,descTextField2,dceRadioButton2,
			       dteRadioButton2, packetSizeComboBox2,
			       windowSizeTextField2,nsduLengthTextField2,
			       pvcMinTextField2, pvcMaxTextField2);
			
			dc2LinkStatus = EXISTING_LINK;
			panelsetEnabled(jPanel11, true);
		    } catch (Exception e){
			dc2LinkStatus = LOAD_ERROR;
			Log.getInstance().log_error("Error in parsing configuration file for link "
						    +x25Link2+" from "+hostList2, e);
			errstr.append("Error in parsing configuration file"
				      +"for link "+x25Link2+" from "+hostList2+"\n");
		    
		    }


		} else {
		    dc2LinkStatus = LOAD_ERROR;
		    errstr.append("Error in loading link configuration: "
				  + x25Link2+" from "+hostList2+"\n");
		    if (exc2!=null) errstr.append("\t"+exc2.getMessage()+"\n");
		}
	    }



	    if (  (defaultConfigError) 
		  && ( (dc1LinkStatus == NEW_LINK) 
		       || (dc2LinkStatus == NEW_LINK) ) ) {
		errstr.append("Error in loading default link configuration"
			      +" file.\n Please check log for details.\n");
		Log.getInstance().log_error("Error in loading default "
					    +"link configuration file.",
					    exc0);
		dc1LinkStatus = LOAD_ERROR;
		dc2LinkStatus = LOAD_ERROR;
	    }

	    

	    if ( (dc1LinkStatus == NEW_LINK) 
		 || (dc1LinkStatus == EXISTING_LINK) ) {
		panelsetEnabled(jPanel1, true);
		dc1RadioButton.setEnabled(true);
	    }

	    if ( (dc2LinkStatus == NEW_LINK) 
		 || (dc2LinkStatus == EXISTING_LINK) ) {
		panelsetEnabled(jPanel11, true);
		dc2RadioButton.setEnabled(true);
	    }
		 
	    if (dc1RadioButton.isEnabled()
		&& dc2RadioButton.isEnabled()) {
		bothDCRadioButton.setEnabled(true);
		bothDCRadioButton.setSelected(true);
		jButton3.setEnabled(true); // ">>"
		jButton4.setEnabled(true); // "<<"
	    } else {
		if (dc1RadioButton.isEnabled()) dc1RadioButton.setSelected(true);
		if (dc2RadioButton.isEnabled()) dc2RadioButton.setSelected(true);
	    }


	    if (dc1LinkStatus == LOAD_ERROR
		|| dc2LinkStatus == LOAD_ERROR) {
		Utils.showDialog(myFrame, errstr.toString());
	    }


	    if (dc1RadioButton.isEnabled()
		|| dc2RadioButton.isEnabled()) {
		jButton5.setEnabled(true); // "Save configuration"
		jButton6.setEnabled(true); // "Start Link"
		jButton7.setEnabled(true); //"Stop Link"
		jButton8.setEnabled(true); // "Status Link"
		
	    }

	    myFrame.invalidate();
            myFrame.validate();
	    defaultLinkConfig = null;
	    statusPanel.stop();
	    statusPanel.clear();
	    if (defaultConfigError) 
		statusPanel.showStatus("Could not load configuration.");

	} // End of finished()
	
	private void initUI(Utils.x25ConfigParams p,
			    javax.swing.JTextField descTextField,
			    javax.swing.JRadioButton dceRadioButton,
			    javax.swing.JRadioButton dteRadioButton,
			    javax.swing.JComboBox  packetSizeComboBox,
			    javax.swing.JTextField windowSizeTextField,
			    javax.swing.JTextField nsduLengthTextField,
			    javax.swing.JTextField pvcMinTextField,
			    javax.swing.JTextField pvcMaxTextField)
	{
	    descTextField.setText(p.description);
	    if (p.iface.equals("DCE"))
		dceRadioButton.setSelected(true);
	    else
		dteRadioButton.setSelected(true);
	    packetSizeComboBox.setSelectedItem(p.packetSize);
	    windowSizeTextField.setText(p.windowSize);
	    nsduLengthTextField.setText(p.nsduLength);
	    if (x25Type.startsWith("PVC")) {
		int index = p.pvcRange.indexOf("-");
		pvcMinTextField.setText(p.pvcRange.substring(0,index));
		pvcMaxTextField.setText(p.pvcRange.substring(index+1));
	    }
	}


    } // End of class LoadLinkConfig
}

/*
**  SCCS Info :  "@(#)DSPDataServicesStatusModel.java	1.8    05/05/05"
*/
/*
 * DSPDataServicesStatusModel.java
 *
 * Created on June 29, 2000, 9:43 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class DSPDataServicesStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements	Utils.UpdateModel
{
  
    private String 		   	m_hostTag = null;
    private String		   	m_progList = null;


    protected int     		m_sortCol = 0;
    protected boolean 		m_sortAsc = true;
    protected java.util.Vector 	m_vector = null;
    protected java.util.Vector	m_dc1InputFeed = null;
    protected java.util.Vector	m_dc2InputFeed = null;
    protected String			m_dc1Host = null;
    protected String			m_dc2Host = null;
        protected String			m_dc1PHost = null;
    protected String			m_dc2PHost = null;

    protected String			m_swVersion = null;

        protected String m_vrtsGroup = null;
        protected String m_vrtsSSResource = null;
        protected String m_dc1Location = null;
        protected String m_dc2Location = null;
        

    protected int 			m_columnsCount = 
	Constants.SystemServicesTableColumnNames.length;

    protected int 			m_rowsCount = 0;

    private String[][]		m_serverDesc = null;


    public DSPDataServicesStatusModel(String[][] tableDesc, String hTag)
    {

	m_serverDesc = tableDesc;

	int nservers  = m_serverDesc.length;

	m_vector = new java.util.Vector(nservers*2);
	m_hostTag = hTag;

	StringBuffer progList = new StringBuffer();
	for ( int i = 0; i < nservers; i++)  {
	    progList.append(m_serverDesc[i][1]);
	    if (i < (nservers-1))
		progList.append(",");
	}
	    
	m_progList = progList.toString();
        try {
                java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
                m_dc1Location = (String)map.get("LOCATION1");
                m_dc2Location = (String)map.get("LOCATION2");
        }
        catch (Exception e)
        {
        }
        
    }




    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }


    synchronized public java.util.Vector getDC1InputFeed() {
	return m_dc1InputFeed;
    }

    synchronized public java.util.Vector getDC2InputFeed() {
	return m_dc2InputFeed;
    }

    synchronized public String getDC1Host() {
	return m_dc1Host;
    }

    synchronized public String getDC2Host() {
	return m_dc2Host;
    }

    synchronized public String getDC1PHost() {
	return m_dc1PHost;
    }

    synchronized public String getDC2PHost() {
	return m_dc2PHost;
    }

    synchronized public String getSWVersion() {
	return m_swVersion;
    }

        synchronized public String getVRTSGroup() {
                return m_vrtsGroup;
        }
        
        synchronized public String getVRTSSyncServerResource() {
                return m_vrtsSSResource;
        }

        synchronized public String getDC1Location() {
                return m_dc1Location;
        }
        
        synchronized public String getDC2Location() {
                return m_dc2Location;
        }

        
    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    synchronized public int getRowCount() {
	return m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int col) {
	int column = col;
      	String str = Constants.SystemServicesTableColumnNames[column];
       
        if (column == 1 && m_dc1Location != null)  str = m_dc1Location;
        if (column == 2 && m_dc2Location != null)  str = m_dc2Location;
 
	if (col==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 

    synchronized public Object getValueAt(int nRow, int nCol) {
	
	if (nRow < 0 || nRow>=m_rowsCount)
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }

    synchronized public java.util.Vector getDataVector(){
	return m_vector;
    }

    synchronized public void stop() {
	//threadPool.waitForAll(true);
	m_vector.clear();
	m_vector = null;

    }
   
    public void Update() 
	throws Exception 
    {


	/* Retrieve DCM configuration ;
	   fill all fields and select current items in lists */
	try {

	    java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
		
	    String serverList1 = new String((String)map.get("HOST1"));
	    String serverList2 = new String((String)map.get("HOST2"));
            
            String pserver1 = new String((String)map.get("PHOST1"));
	    String pserver2 = new String((String)map.get("PHOST2"));
			
	    String ver = (String) map.get("SOFTWARE_VERSION");

	    /* Retrieve the list of running system programs from server and update status fields */
	  
	    
            String statusBuf1 = null;
            String statusBuf2 = null;
            boolean exc1=false, exc2=false;
            try
            {
                    statusBuf1 =
                            Utils.getProgramStatus(pserver1,
                                                   Constants.ADMINSERVER,
                                                   Constants.ADMINSERVER);
                    
            }
            catch (Exception ignore)
            {
                    exc1= true;
                    ignore.printStackTrace();
            }

  
            try
            {
                    statusBuf2
                            = Utils.getProgramStatus(pserver2,
                                                     Constants.ADMINSERVER,
                                                     Constants.ADMINSERVER);
            }
            catch (Exception ignore)
            {
                    exc2 = true;
                    ignore.printStackTrace();
            }



	    java.util.Vector ifVector1 = new java.util.Vector(5);
	    java.util.Vector ifVector2 = new java.util.Vector(5);


	    boolean prod_err1= false, prod_err2 = false;

	    String ifstr = (String)map.get("INPUT_FEED1");
	    parseInputFeed(ifVector1, ifstr);
	    ifstr = (String)map.get("INPUT_FEED2");
	    parseInputFeed(ifVector2, ifstr);




	    java.util.Vector u_vector = new java.util.Vector(m_vector.size());

	    boolean found;

	    /* Update the Data services table with all possible reader and message mgr entries */
	    for ( int i = 0; i < m_serverDesc.length; i++) {
		
		

		if ((!prod_err1 && !prod_err2) 
		    && (m_serverDesc[i][0].equals("Reader")
			|| m_serverDesc[i][0].equals("Message Manager")) ) {
			
		    for (int r = 0; r < ifVector1.size() ; r++) {
			String [] rowData = new String[m_columnsCount];

			rowData[1] = Constants.NO_STATUS;
			rowData[2] = Constants.NO_STATUS;


          		String [] row = (String[]) ifVector1.get(r);
          		String name = row[0];
			String id = m_serverDesc[i][0]+":"+name;
			found = false;
			
			for (int r2 = 0; r2 < ifVector2.size() ; r2++) {
			    String [] row2 = (String[]) ifVector2.get(r2);
			    String name2 = row2[0];
			    if (name.equals(name2)) {
				found = true;
				break;
			    }
			}
			if (!found) 
			    rowData[2] = Constants.NOT_CONFIGURED;
			//else
			//  rowData[2] = null;
					
			
			rowData[0] = id;

			u_vector.add(rowData);
		    }
		    
		    for (int r2 = 0; r2 < ifVector2.size() ; r2++) {
          		String [] row2 = (String[]) ifVector2.get(r2);
          		String name2 = row2[0];
			found = false;			
			for (int r = 0; r < ifVector1.size() ; r++) {
			    String [] row1 = (String[]) ifVector1.get(r);
			    String name1 = row1[0];
			    if (name1.equals(name2)) {
				found = true;
				break;
			    }
			}
			if (!found) {
			    String [] rowData = new String[m_columnsCount];

			    rowData[1] = Constants.NO_STATUS;
			    rowData[2] = Constants.NO_STATUS;


			    String id = m_serverDesc[i][0]+":"
				+name2;
			    rowData[0] = id;
			    rowData[1] = Constants.NOT_CONFIGURED;
			    
			    u_vector.add(rowData);
			}
		    }
		} else {
		    String [] rowData = new String[m_columnsCount];
		    rowData[0] = m_serverDesc[i][0];
		    rowData[1] = Constants.NO_STATUS;
		    rowData[2] = Constants.NO_STATUS;
		    u_vector.add(rowData);
		}

	    }

	    
	    if (exc1) {
		for (int r = 0; r < m_rowsCount; r++) 
		    setValueAt(u_vector,Constants.NO_STATUS,r,1);
	    } else {
		updateStatus(u_vector,statusBuf1, 1);
	    }
	    if (exc2) {
		for (int r = 0; r < m_rowsCount; r++) 
		    setValueAt(u_vector,Constants.NO_STATUS,r,2);
	    } else {
		updateStatus(u_vector,statusBuf2, 2);
	    }
	    

	    java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));	    
            int oldRows = 0, newRows = 0;
            
	    synchronized (this) {
		if (m_vector!=null) {
                        oldRows = m_vector.size();
                        m_vector.clear();
                }
                
		m_vector = null;
		m_vector = u_vector;
		m_rowsCount = m_vector.size();

		if (m_dc1InputFeed!=null) m_dc1InputFeed.clear();
		if (m_dc2InputFeed!=null) m_dc2InputFeed.clear();
		m_dc1InputFeed=null;
		m_dc2InputFeed=null;
		m_dc1InputFeed = ifVector1;
		m_dc2InputFeed = ifVector2;
		m_dc1Host      = serverList1;
		m_dc2Host      = serverList2;
                
		m_dc1PHost      = pserver1;
		m_dc2PHost      = pserver2;

		m_swVersion    = ver;

                m_vrtsGroup    =  (String)map.get("VERITAS_GROUP");
                m_vrtsSSResource =  (String)map.get("VERITAS_SYNCSERVER_RESOURCE");
                m_dc1Location    =  (String)map.get("LOCATION1");
                m_dc2Location    =  (String)map.get("LOCATION2");

                newRows = m_vector.size();
	    }

	    IDS_SwingUtils.fireTableChanged(this, oldRows, newRows);

	} catch (Exception e) {

	    synchronized (this) {
		for (int r = 0; r < m_rowsCount; r++) {
		    setValueAt(Constants.NO_STATUS,r,1);
		    setValueAt(Constants.NO_STATUS,r,2);
		}
		/*
		**    Reuse old config ??
		if (m_dc1InputFeed!=null) m_dc1InputFeed.clear();
		if (m_dc2InputFeed!=null) m_dc2InputFeed.clear();
		m_dc1InputFeed=null;
		m_dc2InputFeed=null;
		m_dc1Host=null;
		m_dc2Host=null;
		m_swVersion    = null;
		**
		*/
		java.util.Collections.sort(m_vector, new
					   StatusComparator(m_sortCol, m_sortAsc));	
	    }
	    fireTableDataChanged();
	    
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND) {
		    Log.getInstance().log_error(
				  "DSPDataServicesStatusModel:Configuration does not exist."
				  +m_hostTag,e);          
		    
		    return;
		}
	    }
	    Log.getInstance().log_error("Error in retrieving configuration"
					+m_hostTag,e);
	    throw (e);
	}




    }



    private void setValueAt(java.util.Vector v, String s, int row, int col) 
    {
	String[] rowData = (String[])v.get(row);
	rowData[col] = s;
	v.set(row,rowData);
    }
   
   
    private void updateStatus(java.util.Vector v, String datastr, int column)
    {
	
	for (int r = 0; r < v.size(); r++) {
	    String rdata[] = (String[])v.get(r);
	    if (rdata.length > column ) {
		String vc = rdata[column];
		if (vc.equals(Constants.NOT_CONFIGURED))
		    continue;
	    }
	    setValueAt(v,Constants.NOT_RUNNING, r, column);
	}
	

	if ((datastr==null) || datastr.trim().length()==0) 
	    return;



	java.util.StringTokenizer st
	    = new java.util.StringTokenizer(datastr.trim(),
					    "\n");
        boolean first_record = true;
        
	while (st.hasMoreTokens()){
	    int kindex=-1;

            String s = st.nextToken();
            if (first_record)
            {
                    String separator = new String(",\0\n");
                    java.util.StringTokenizer tokenizer 
                            = new java.util.StringTokenizer(s,separator);
                    
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    
                    if (tokenizer.hasMoreTokens())
                            s = tokenizer.nextToken();

                    first_record = false;
            }
            

	    String sep1 = new String(" \t");
	    java.util.StringTokenizer st1 = 
		new java.util.StringTokenizer(s.trim(),sep1);
	    String progname = null;
	    if (st1.hasMoreTokens())
		progname = st1.nextToken();	
	    else
		continue;

	    for ( int k = 0; k < m_serverDesc.length; k++) {
		if (m_serverDesc[k][1].equals(progname)){
		    kindex = k;
		    break;
		}
	    }

	    if (kindex <0) 
		continue;

	    String pattern = m_serverDesc[kindex][0];
	    if (kindex < 2 ) {
		int inx = s.indexOf("-n");
		String ss = s.substring(inx+2);
		java.util.StringTokenizer st2 = 
		    new java.util.StringTokenizer(ss,sep1);
		String n1 = (String)st2.nextToken();
		pattern=pattern+":"+n1;
	    }

	    int numRows = v.size();
	    for ( int i = 0; i < numRows; i++) {
		String[] data = (String[])v.get(i);

		if (pattern.equals(data[0])) {
		    String o1 = data[column];
		    if ((o1!=null) && o1.equals(Constants.NOT_CONFIGURED))
			setValueAt(v,Constants.NOT_CONFIGURED+" (?Running?)",
				   i,column);
		    else
			setValueAt(v,"Running",i,column);
		}
	    }

	} /* st.hasMoreTokens() */
	
    }



    private void parseInputFeed(java.util.Vector ifVector, String ifstr) 
    {

	StringBuffer separator=new StringBuffer();
	separator.append(ConfigComm.CONF_GS).append(ConfigComm.CONF_ETX);

	java.util.StringTokenizer st 
	    = new java.util.StringTokenizer(ifstr,separator.toString());
	
	
	while (st.hasMoreTokens()) {

	    String s = st.nextToken();

	    java.util.StringTokenizer fst
		= new java.util.StringTokenizer(s,",");


	    String name,format,transport,products,protocol;

	    name = format = transport = products = protocol = null;
            
            

	    name = fst.nextToken();
	    if (fst.hasMoreTokens())
		format = fst.nextToken();

	    if (fst.hasMoreTokens())
		protocol = fst.nextToken();

	    if (fst.hasMoreTokens())
		transport = fst.nextToken();
            
 
	    if (fst.hasMoreTokens())
		products = fst.nextToken();

	    String [] rowData1 = new String[5];
	    rowData1[0]=name;
	    rowData1[1]=format;
	    rowData1[2]=protocol;
	    rowData1[3]=transport;
	    rowData1[4]=products;
	    

	    ifVector.add(rowData1);

	}


    }






    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;
	
	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock lk) {
	    m_table = table;
	    rwLock = lk;
	}	
	
	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel 
		= m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }

	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;


		
	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }

	    m_table.getTableHeader().repaint();  

	    synchronized (DSPDataServicesStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, m_sortAsc));
	    }

	  
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DSPDataServicesStatusModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release();
	    
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;

	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }



    private class ProductWorker extends SwingWorker {

	ProductWorker(String dcm, String s) {
	    dcmName = dcm;
	    dc = s;
	    data[0] = data[1] = null;
	}

	Object data[] = new Object[2];
	String dc = null;
	String dcmName = null;
	public Object construct() {
	    try {
		data[0]=Utils.getDCMProducts(dcmName,dc);
	    } catch (DBException dbe) {
		data[1] = dbe;
		if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND) {
		    data[0]=null;
		    data[1]=null;
		}	
			
	    } catch (Exception e) {
		Log.getInstance().log_error("Error in retrieving product list for DCM:"
					    +dcmName+" "+dc,e);
		data[1] = e;
	    }
			
	    return data;
	}

    }
	    




}  // End of class DSPDataServicesStatusModel

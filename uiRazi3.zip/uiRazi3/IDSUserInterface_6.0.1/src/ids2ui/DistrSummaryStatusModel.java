/*
**  SCCS Info :  "@(#)DistrSummaryStatusModel.java	1.7    04/04/01"
*/
/*
 * DistrSummaryStatusModel.java
 *
 * Created on May 24, 2000, 5:08 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

public class DistrSummaryStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements Utils.UpdateModel 
{
  

    private String 			m_dcmList = null;

    private java.util.HashMap 	m_hostVectorDC1=null;
    private java.util.HashMap 	m_hostVectorDC2=null;
    private java.util.HashMap 	m_lhtypeVector=null;
    private String 			m_favoritesList = null;

    protected int     m_sortCol = 0;
    protected boolean m_sortAsc = true;
    protected java.util.Vector m_vector = null;

    protected int m_columnsCount 
	= Constants.DistributorSummaryStatusTableColumnNames.length;


    private ThreadPool threadPool = new ThreadPool(10);


    public DistrSummaryStatusModel()
    {
	this((String)null);
    }

    public DistrSummaryStatusModel(String dlist)
    {
	m_dcmList = dlist;
	m_hostVectorDC1 =  new java.util.HashMap(25);
	m_hostVectorDC2 =  new java.util.HashMap(25);
	m_lhtypeVector =  new java.util.HashMap(25);
	m_vector = new java.util.Vector(25);
    }


    public void loadConfig(String dlist) {
	m_dcmList = dlist;
	Refresh();

	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("Load Config called");
    }



    synchronized public String getHost1(int r) {
	String row[] = (String[])m_vector.get(r);
	return (String)m_hostVectorDC1.get(row[0]);
    }

    synchronized public String getHost2(int r) {
	String row[] = (String[])m_vector.get(r);
	return (String)m_hostVectorDC2.get(row[0]);
    }

    synchronized public String getType(int r) {
	String row[] = (String[])m_vector.get(r);
	return (String)m_lhtypeVector.get(row[0]);
    }


    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }

    synchronized public void stop() 
    {
	try {
	    threadPool.waitForAll(true);
	} catch (InterruptedException ie){}

	if (m_vector!=null) m_vector.clear();
	if (m_hostVectorDC1!=null)m_hostVectorDC1.clear();
	if (m_hostVectorDC2!=null)m_hostVectorDC2.clear();
	if (m_lhtypeVector!=null)m_lhtypeVector.clear();

	m_vector 	= null;
	m_hostVectorDC1 = null;
	m_hostVectorDC2 = null;
	m_lhtypeVector  = null;
    }

    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int column) {
      	String str = Constants.DistributorSummaryStatusTableColumnNames[column];
	if (column==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 

    synchronized public Object getValueAt(int nRow, int nCol) {
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }



    public void Update() 
    throws Exception
    {

	int oldRows = m_vector.size();
	int numRows = 0;
	java.util.Vector 	u_vector = new java.util.Vector(oldRows);
	java.util.HashMap 	u_hostVectorDC1 =  new java.util.HashMap(oldRows);
	java.util.HashMap 	u_hostVectorDC2 =  new java.util.HashMap(oldRows);
	java.util.HashMap 	u_lhtypeVector =  new java.util.HashMap(oldRows);

	/*
	** Retrieve favorites list
	*/
	try {
	    StringBuffer reqbuf = new StringBuffer();
    
	    ConfigComm.getKey(reqbuf,ConfigComm.getLocalDir());    
	    byte[] b = ConfigComm.configRequest(reqbuf);
	    String tmp = new String(b);
	    int index = tmp.indexOf(ConfigComm.CONF_STX)+1;
            
	    synchronized (this) {
		m_favoritesList = tmp.substring(index).trim();
	    }
    
	} catch (Exception e) {
	    synchronized (this) {
		m_vector.removeAllElements();
		m_hostVectorDC1.clear();
		m_hostVectorDC2.clear();
		m_lhtypeVector.clear();
		m_favoritesList = null;

	    }
	    fireTableDataChanged();
	    
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND) {
		    return;
		}
	    }

	    Log.getInstance().log_error("Error in retrieving favorites list",e);
	  
	    throw(e);
	}


	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DistrSelectDataModel: Updating..");


	java.util.HashMap hostmap = new java.util.HashMap(20);


	/*
	** Retrieve configuration 
	*/
	try {
	  
	    StringBuffer reqbuf = new StringBuffer();
	    String          respbuf, databuf;
	    byte[] b;
	    java.util.StringTokenizer rowTokenizer, colTokenizer;


	    ConfigComm.getServKey(reqbuf,ConfigComm.GET_DIST_ALL_INFO,null);
	    b = ConfigComm.configRequest(reqbuf);
	    respbuf = new String(b);
	    int index = respbuf.indexOf(ConfigComm.CONF_STX) + 1;
      

	    databuf = respbuf.substring(index);

	    StringBuffer rowSeparator, colSeparator;
	    rowSeparator = new StringBuffer();
	    colSeparator = new StringBuffer();

	    rowSeparator.append(ConfigComm.CONF_STX).
		append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_FS);

	    colSeparator.append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_RS);

	    rowTokenizer = new
		java.util.StringTokenizer(databuf,rowSeparator.toString());

	  
	    while (rowTokenizer.hasMoreTokens()) {

		String [] hostData = new String[2];
		rowTokenizer.nextToken(); // Skip "key"
		String fstr = rowTokenizer.nextToken();
		colTokenizer = new
		    java.util.StringTokenizer(fstr, colSeparator.toString());

		String distr = colTokenizer.nextToken();

		if (!Constants.matchPattern(m_favoritesList,",",distr))
		    continue;


		String [] rowData = new String [m_columnsCount];

		rowData[0] = distr;
		String tag = (String) colTokenizer.nextToken();

		u_lhtypeVector.put(distr, tag);
	      

		if (colTokenizer.hasMoreTokens()) // Description
		    rowData[1] = colTokenizer.nextToken();
		else
		    rowData[1] = null;

		String host1 = (String)colTokenizer.nextToken();
		String host2 = (String)colTokenizer.nextToken();

                
 
	      
		hostData[0] = host1;
		hostData[1] = host2;

		if (!hostmap.containsKey(tag))
		    hostmap.put(tag,hostData);

		u_hostVectorDC1.put(distr,host1);
		u_hostVectorDC2.put(distr,host2);

	      
		u_vector.add(numRows,rowData);

		numRows++;
	    } // while rowTokenizer()

	} catch (Exception e) {
	    
	    synchronized (this) {
		m_vector.removeAllElements();
		m_hostVectorDC1.clear();
		m_hostVectorDC2.clear();
		m_lhtypeVector.clear();
		m_favoritesList = null;
	    }

	    fireTableDataChanged();
	  
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND) {
		    return;
		}
	    }
	    Log.getInstance().log_error("Error in retrieving distributors list",e);

	    throw (e);

	}
      
	java.util.Iterator iter = hostmap.keySet().iterator();

	String distList1 = null, distList2 = null;

	    
	  
	  
	java.util.Vector workers1 = new java.util.Vector(numRows);
	java.util.Vector workers2 = new java.util.Vector(numRows);

	for (int r = 0; r < numRows; r++) {

	    String[] data = (String[])u_vector.get(r);
	    String distr = data[0];

	    String dcm = (String)u_lhtypeVector.get(distr);

	    String [] hostData = (String[]) hostmap.get(dcm);

	    int lhtype = Constants.DCM_LINEHANDLER;
	      
	    if (dcm.startsWith(Constants.GLB_TAG_DSP)) {
		lhtype = Constants.DSP_BROADCASTER;
	    } 
	      
	    DistributorStatusEvent evt1= new DistributorStatusEvent(this);
            DistributorStatusEvent evt2= new DistributorStatusEvent(this);

	    StatusThread t1 = new StatusThread(lhtype,1,distr, evt1);
	    StatusThread t2 = new StatusThread(lhtype,2,distr, evt2);
	    threadPool.addRequest(t1);
	    threadPool.addRequest(t2);

	    workers1.add(t1);
	    workers2.add(t2);
	}
		    
	threadPool.waitForAll();

	for (int r = 0; r < numRows; r++) {
	    String[] data = (String[])u_vector.get(r);
	    StatusThread t1 =  (StatusThread)workers1.get(r);
	    StatusThread t2 =  (StatusThread)workers2.get(r);
	    DistributorStatusEvent evt1,evt2;
	    DistributorStatusModel model1, model2;


            model1 = t1.getModel();
	    evt1   = t1.getEvent();
            model2 = t2.getModel();
	    evt2   = t2.getEvent();

            
            try {
                    String distr=data[0];
                    
                    java.util.HashMap m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+distr);
                        
                    
                    String primary_location = (String)m.get("HOME_LOCATION");
                    if (primary_location != null
                        && !primary_location.equals("1")) {
                            model1 = t2.getModel();
                            evt1   = t2.getEvent();
                            model2 = t1.getModel();
                            evt2   = t1.getEvent();
                    }
            } catch (Exception de){
            }
            
	   		  
	    if (evt1.getStatus()==0) {
		String mode = evt1.getMode();
		if (mode.startsWith("DORMANT"))
		    data[2] = "DORMANT";

		if (mode.startsWith("ACTIVE")) {
		    data[2] = "UP";

		    int num_rows = model1.getRowCount();
		    for (int i = 0; i < num_rows; i++) {
			String state = (String)model1.getValueAt(i,4);
			if (!state.equals("UP")) {
			    data[2] = "DOWN";
			    break;
			}
		    }
		}
	    } else {
		data[2] = Constants.NO_STATUS;
	    }
			  
	    		  	   
			  
	    if (evt2.getStatus()==0) {
		String mode = evt2.getMode();
		if (mode.startsWith("DORMANT"))
		    data[3] = "DORMANT";
		
		if (mode.startsWith("ACTIVE")) {
		    data[3] = "UP";
		    
		    int num_rows = model2.getRowCount();
		    for (int i = 0; i < num_rows; i++) {
			String state = (String)model2.getValueAt(i,4);
			if (!state.equals("UP")) {
			    data[3] = "DOWN";
			    break;
			}
		    }
		}
	    } else {
		data[3] = Constants.NO_STATUS;
	    }
	    
	    
	    u_vector.setElementAt(data,r);
	}

	workers1.clear();
	workers2.clear();
	workers1=null;
	workers2=null;
	
	java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	synchronized (this) {
	    m_vector.clear();
	    m_vector = u_vector;
	    m_hostVectorDC1.clear();
	    m_hostVectorDC1 = null;
	    m_hostVectorDC1 = u_hostVectorDC1;
	    m_hostVectorDC2.clear();
	    m_hostVectorDC2 = null;
	    m_hostVectorDC2 = u_hostVectorDC2;
	    m_lhtypeVector.clear();
	    m_lhtypeVector = null;
	    m_lhtypeVector = u_lhtypeVector;
	}


	fireTableDataChanged();
      
      
	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DistrSelectDataModel: Num rows: "+numRows);
      
      
      
	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("DistrSelectDataModel: Update done.");
    }



    class StatusThread implements Runnable {
	int lhType;
	int dataCenter;
	String distrID;
	DistributorStatusEvent event;
	DistributorStatusModel model = null;

	public StatusThread(int ltype,
			    int dc, String distrId, DistributorStatusEvent evtIn)
	{
	    lhType 	= ltype;
	    dataCenter 	= dc;
	    distrID    	= distrId;
	    event 	= evtIn;
	}


	public void run() 
	{
	    try {
	    	model = new DistributorStatusModel(lhType,dataCenter,
					       distrID, event);
	    } catch (Exception e) {
		model = null;
		Log.getInstance().log_error("Error in retrieving status: "
			+lhType+" "+dataCenter+" "+distrID, e);
	    }
	}

	public DistributorStatusModel getModel() {
	    return model;
	}

	public DistributorStatusEvent getEvent() {
	    return event;
	}
    }



    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	 rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }


	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;



	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }
	    m_table.getTableHeader().repaint();

	    synchronized (DistrSummaryStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
				       StatusComparator(modelIndex, m_sortAsc));
	    }
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DistrSummaryStatusModel.this)); 
	    m_table.repaint();

	    rwLock.writeLock().release();  
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	   
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;
	    
	    if ( (s1!=null) && (s2!=null))
		result = s1.compareTo(s2);
	

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }

}


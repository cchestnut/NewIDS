/*
**  SCCS Info :  "@(#)StatusRequest.java	1.7    05/08/25"
*/
/*
 * StatusRequest.java
 *
 * Created on October 16, 2000, 4:47 PM
 */
 
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;


/** 
 *
 * @author  srz
 * @version 
 */
public class StatusRequest extends Object {

    static private boolean _init = false;
    static private String dspList=null;
    static private String lastServer=null;
  
    private java.net.Socket server = null;

    static private  StatusRequest _instance = null;
    

    
    public static StatusRequest getInstance()
        throws IOException
        {
                /*if (_instance == null) {
                synchronized (StatusRequest.class) {
                    if (_instance == null)
                        _instance = new StatusRequest();
                }
            }


            return _instance;*/
            return new StatusRequest();
            
        }
    

    
        /** Creates new StatusRequest */
    private StatusRequest()  throws IOException{
        if (!_init) throw new IOException("StatusRequest: Not initialized");
        server = null;
    }


    private static String StatusServers[];
    private static java.util.Random rand = new java.util.Random();
        
        
    static public void init(String dList)
        {
           
            resetLogin();
            dspList = new String(dList);	
            Log.getInstance().log_warning("StatusRequest:Using server list: "
                                          +dspList,null);

            java.util.StringTokenizer tok
                = new java.util.StringTokenizer(dspList,", ");
            int n = tok.countTokens();
            if (n == 0)
                StatusServers = null;
            else
                StatusServers = new String[n];
            for (int i = 0; i < n; i++)
                StatusServers[i] = tok.nextToken();
            _init = true;
    
        }
  
    static public void resetLogin()
        {
                /*if (server != null)
            {
                try {
                    server.close();
                }
                catch (IOException ioe){
                }
                
            }
            server = null;*/
            _init = false;    
            lastServer = null;
            dspList = null;
            StatusServers = null;
        }



    private static Socket connectToStatusServer(String serverName) 
        throws IOException
        {
            Socket sock = TimeoutSocket.Connect(serverName, 
                                                Constants.STATUS_SERVER_PORT,
                                                Constants.ConnectTimeout);

                /* Set timeout */
            sock.setSoTimeout(4*Constants.NetworkTimeout);
            sock.setTcpNoDelay(true);
            sock.setReceiveBufferSize(64*1024);
            sock.setSendBufferSize(64*1024);
            

            return sock;
        }


    private static String getNextHost()
        throws IOException
        {
                
                
            if ( (StatusServers == null)
                 || (StatusServers.length == 0) )
                throw new IOException("Could not get status server list");
                
                
            String s =  StatusServers[rand.nextInt(StatusServers.length)];

            if (lastServer != null  && s.equals(lastServer))
                s = StatusServers[rand.nextInt(StatusServers.length)];
            lastServer= null;
            
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("Directing status request to "+s
                                   +" "+new Date());

            return s;
                
             
        }


    private void closeStatusConnection(java.net.Socket server)
        {
            try {
                
                if (server != null) server.close();
            }
            catch (IOException ioe){
            }
            
            server = null;
        }
    

    private Socket getStatusConnection()
        throws IOException {

            /*
        if ( (server != null)
             && server.isConnected() )
            return server;
            
            */
        java.net.Socket server = null;
        
        String serverName = getNextHost() ;
        int ntries = Constants.NUM_CONNECTION_TRIES;
        boolean done=false;
        
        java.util.StringTokenizer tok = new java.util.StringTokenizer(dspList,", ");    
        
        while ( !done ) {
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("StatusRequest:Connecting to host: "+serverName);
            
            try {
                    
                if (Constants.DEBUG && Constants.Verbose>2)
                    System.out.println("Connecting to : "+serverName+" for status");
                
                server = connectToStatusServer(serverName);
                
                lastServer=new String(serverName);
                    if (Constants.DEBUG && Constants.Verbose>2)
                    System.out.println("Connected to : "+serverName+" for status");

                    done = true;
                
            } catch (Exception ioEx) {
                closeStatusConnection(server);
                ntries--;
                
                if (Constants.DEBUG && Constants.Verbose>2) {
                    System.out.println("Error in connect: "+ioEx.getMessage());
                    System.out.println("Could not connect to status server on: "+serverName);
                }
                    
                    
                    
                if (ntries>0) {
                    Log.getInstance().log_warning("StatusRequest:Communication error: Retrying .. "
                                                  +serverName+".",ioEx);
                    continue;
                } else {
                    ntries=Constants.NUM_CONNECTION_TRIES;
                    if (tok.hasMoreTokens()) {
                        serverName = tok.nextToken();
                        Log.getInstance().log_warning(
                            "Could not connect. Trying "+serverName,
                            ioEx);
                        continue;
                    } else         
                        throw new DBException("Error in retrieving status from DSP "
                                              +serverName);
                }        
            }
        }
        
            
            
        return server;
    }


            
    private byte [] statusRequest(String query)
        throws IOException
        {
        byte[] b=null;
        Socket statusSocket = null;
        
        
        
        
        try {
            long t1 = System.currentTimeMillis();
            statusSocket = getStatusConnection();

                //System.out.println("Running query '"+query+"' on "+statusSocket.toString());
            
            long t2 = System.currentTimeMillis();

            java.io.OutputStream dout = statusSocket.getOutputStream();
            dout.write(query.getBytes(),0,query.length());
            dout.flush();

            long t3 = System.currentTimeMillis();
            
            java.io.InputStream din = statusSocket.getInputStream();
            byte[] lbytes = new byte[8];
            int nr = din.read(lbytes,0,8);

            
            if (nr != lbytes.length) {
                IOException ex =  new IOException("Error in reading status server response: "
                                                  +statusSocket.toString());
                closeStatusConnection(statusSocket);
                throw ex;
            }
            
            String s = new String(lbytes);
            int len = Integer.parseInt(s);
            b = new byte[len];
            
            int nleft=len,nread=0,offset=0;

            while (nleft > 0) {
                nread = din.read(b,offset,nleft);
                

                if (nread <= 0) break;
                nleft -= nread;
                offset += nread;

            }

            if (offset != len) {
                IOException ex =  new IOException("Error in reading status server response: "
                                                  +statusSocket.toString());
                closeStatusConnection(statusSocket);
                throw ex;
            }
            
             long t4 = System.currentTimeMillis();
            
            if (Constants.DEBUG && Constants.Verbose>2)
            {
                System.out.println("Status ..."+len+" bytes."+"( "+s+")"); 
                
                System.out.println("T1="+t1+" T2="+t2+" T3="+t3+" T4="+t4);
                System.out.println("T2-T1="+(t2-t1)+" T3-T2="+(t3-t2)+" T4-T3="+(t4-t3));
            }
            
            closeStatusConnection(statusSocket);
            
        } catch (java.io.IOException ioEx) {
            IOException ioex =  new IOException("Error in reading status from server "
                                  +statusSocket.toString());
            closeStatusConnection(statusSocket);
            throw ioex;
        }

        return b;
        
    }
    


    public String statusQuery(String query) 
        throws IOException {
    
    
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("statusRequest:Query: "+query);

            long t1 = System.currentTimeMillis();

            byte b[] = statusRequest(query);

            long t2 = System.currentTimeMillis();

            String resp =  new String(b);
            
            long t3 = System.currentTimeMillis();
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("Response time: "+(t2-t1)+" String time: "+(t3-t2));
            
                //if (Constants.DEBUG && Constants.Verbose>2)
                //System.out.println("statusRequest:"+(t2-t1)+" ms. Status response:\n"+resp+"\n");

            
            return resp;
    }
  

    public String statusQuery(String hostName, String programName, String programID)
        throws IOException
        {
            StringBuffer req = new StringBuffer();
            req.append(hostName).append(",")
                .append(programName).append(",")
                .append(programID)
                .append('\0'); // NULL terminate
            
            return statusQuery(req.toString());
        }
    
}

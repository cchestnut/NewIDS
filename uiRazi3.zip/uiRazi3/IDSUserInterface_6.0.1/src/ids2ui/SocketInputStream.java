
/*
**  SCCS Info :  "@(#)SocketInputStream.java	1.1    03/09/16"
*/
  package ids2ui;
  import java.io.*;
  import java.net.*;

  public class SocketInputStream extends FilterInputStream
  {
      private Socket __socket;
  
      /****
       * Creates a SocketInputStream instance wrapping an input stream and
       * storing a reference to a socket that should be closed on closing
       * the stream.
       * <p>
       * @param socket  The socket to close on closing the stream.
       * @param stream  The input stream to wrap.
       ***/
      public SocketInputStream(Socket socket, InputStream stream)
      {
          super(stream);
          __socket = socket;
      }
  
      /****
       * Closes the stream and immediately afterward closes the referenced
       * socket.
       * <p>
       * @exception IOException  If there is an error in closing the stream
       *                         or socket.
       ***/
     public void close() throws IOException
     {
         super.close();
         __socket.close();
     }
 }





/*
**  SCCS Info :  "@(#)Cacheable.java	1.2    04/05/10"
*/
package ids2ui;

public interface Cacheable
{
        public boolean isExpired();
        public Object  getIdentifier();
        public long    getConfigTimeStamp();
        public long    getAccessTime();
        public long    getAccessCount();
        public void    updateAccess();
        
}

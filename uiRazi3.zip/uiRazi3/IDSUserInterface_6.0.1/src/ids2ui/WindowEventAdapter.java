/*
**  SCCS Info :  "@(#)WindowEventAdapter.java	1.6    04/04/01"
*/
/*
 * WindowManager.java
 *
 * Created on April 10, 2000, 5:06 PM
 */
 
package ids2ui;

import javax.swing.JOptionPane;

/** 
 *
 * @author  srz
 * @version 
 */
public class WindowEventAdapter extends java.awt.event.WindowAdapter {
  
        static private java.util.Hashtable winTable;
        static private WindowEventAdapter _instance = null;
        static private java.awt.Point lastLocation = null;
        static private int maxX = 500;
        static private int maxY = 500;

            /** Creates new WindowManager */
  
        private WindowEventAdapter() {
        }
  
        public static WindowEventAdapter getInstance() {
                if (_instance == null ) {
                        synchronized(WindowEventAdapter.class){
                                if (_instance == null) {
                                        _instance = new WindowEventAdapter();
                                        winTable = new java.util.Hashtable(20);
                                        java.awt.Dimension screenSize 
						= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
                                        maxX = screenSize.width;// - screenSize.width/5; 
                                        maxY = screenSize.height;// - screenSize.width/5;
                                }
                        }
                }
                return _instance;
    
        }
  
        public void registerWindow(String id,Object win) {
                ((java.awt.Window)win).addWindowListener(this);
                winTable.put(win,id);
                    
                if (win instanceof javax.swing.JFrame) {
                        javax.swing.JFrame frame = (javax.swing.JFrame)win;
                        if (lastLocation != null) {
                                    //Move the window over and down 40 pixels.
                                lastLocation.translate(40, 40);
                                if (((lastLocation.x + frame.getWidth()) > maxX) 
                                        || ((lastLocation.y + frame.getHeight()) > maxY)) {
                                        lastLocation.setLocation(0, 0);
                                }
                                frame.setLocation(lastLocation);
                        } else {
                                lastLocation = frame.getLocation();
                        }
                }
                    

                if (Constants.DEBUG && Constants.Verbose >2)
                        System.out.println("Window added "+id);
        }
   
        public void unregisterWindow(Object win) {
                java.util.Enumeration e = winTable.keys();
                java.awt.Window f;

                while (e.hasMoreElements()) {
                        f = (java.awt.Window)e.nextElement();
                        if (f == win) {
                                String id = (String)winTable.get(f);
                                winTable.remove(f);
                                if (Constants.DEBUG && Constants.Verbose >2)
                                        System.out.println("Window deleted "+id);
                        }
                }
        }
  
        public void windowClosing(java.awt.event.WindowEvent evt) {
                java.awt.Window win = evt.getWindow();
                java.util.Enumeration e = winTable.keys();
                java.awt.Window f;


                if (Constants.DEBUG && Constants.Verbose >2)
                        System.out.println("windowClosed "+evt.paramString()+ " "+win.toString());


                while (e.hasMoreElements()) {
                        f = (java.awt.Window)e.nextElement();
                        if (f == win) {
                                String id = (String)winTable.get(f);
                                winTable.remove(f);

                        }
                }
        }
  
        public Object findWindow(String id) {
                java.util.Enumeration e = winTable.keys();
                while (e.hasMoreElements()) {
                        Object o = e.nextElement();
                        String id1 = (String)winTable.get(o);
                        if (id.equals(id1)) {
                                return o;
                        }
                }
                return null;
        }
  
        public java.util.Vector findWindows(String pattern) {

                if (winTable.size()==0) return null;
                java.util.Enumeration e = winTable.keys();
                java.util.Vector v = new java.util.Vector(winTable.size());
                while (e.hasMoreElements()) {
                        Object o = e.nextElement();
                        String id = (String)winTable.get(o);
                        if (pattern.equals("*") || id.startsWith(pattern)) {
                                v.add(o);
                        }
                }
                return v;
        }


        synchronized public void closeAll() {
                java.util.Enumeration e = winTable.keys();
                while (e.hasMoreElements()) {
                        Object win = e.nextElement();
      
                        if (win instanceof javax.swing.JFrame) {
                                javax.swing.JFrame frame = (javax.swing.JFrame)win;
                                frame.setVisible(false);
                                frame.dispose();
                        }
                        if (win instanceof javax.swing.JDialog) {
                                javax.swing.JDialog dlg = (javax.swing.JDialog)win;
                                dlg.setVisible(false);
                                dlg.dispose();
                        }
                }
    
    
        }
  
  
        synchronized public void applyUI() {
                java.util.Enumeration e = winTable.keys();
                while (e.hasMoreElements()) {
                        java.awt.Component win = (java.awt.Component)e.nextElement();
                        javax.swing.SwingUtilities.updateComponentTreeUI(win);
                }
    
    
        }



}


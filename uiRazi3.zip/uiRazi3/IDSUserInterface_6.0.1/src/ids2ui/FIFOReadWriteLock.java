/*
**  SCCS Info :  "@(#)FIFOReadWriteLock.java	1.2    01/07/10"
*/
/*
  File: FIFOReadWriteLock.java
*/

package ids2ui;


public class FIFOReadWriteLock implements ReadWriteLock {

  /** 
    * FIFO queue of threads waiting for access 
    * Also serves as the Writer lock
   **/
  protected final FIFOSemaphore active_ = new FIFOSemaphore(1);
  public Sync writeLock() { return active_; }

  /**
   * Control reader access to active semaphore
  **/
  protected final Sync readerSync_ = new ReaderSync();
  public Sync readLock() { return readerSync_; }

  class ReaderSync implements Sync {

    protected int readers_ = 0;

    protected Mutex oneWaiter_ = new Mutex();

    protected synchronized void incReaders() throws InterruptedException { 
      // if first reader, wait for access, otherwise just proceed
      if (readers_ == 0) active_.acquire();
      ++readers_;
    }

    protected synchronized boolean tryRead(long msecs) throws InterruptedException {
      boolean pass = (readers_ > 0 || active_.attempt(msecs));
      if (pass) ++readers_;
      return pass;
    }

    public void acquire() throws InterruptedException {
      oneWaiter_.acquire();  // block if another is waiting for access
      try     { incReaders(); }
      finally { oneWaiter_.release();  }
    }

    public synchronized  void release()  { 
      if (--readers_ == 0) active_.release();
    }

    public boolean attempt(long msecs) throws InterruptedException {
      long startTime = (msecs <= 0)? 0 : System.currentTimeMillis();
      if (!oneWaiter_.attempt(msecs)) return false;

      long timeLeft = (msecs <= 0)? 0 :
        msecs - (System.currentTimeMillis() - startTime);

      try { return tryRead(timeLeft); }
      finally { oneWaiter_.release(); }
    }

  }

}


/*
**  SCCS Info :  "@(#)ConfigConnection.java	1.1    05/03/29"
*/
package ids2ui;

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;


 

public class ConfigConnection {

    private static int ConnectionLimit = 5;
    private static int ConnectionCount = 0;
    
    private static ConfigConnection[]
    ConnectionPool = new ConfigConnection[ConnectionLimit];
    
    Socket server     = null;
    String serverList = null;
    
    public static synchronized ConfigConnection 
    getConnection()
    {
        ConfigConnection c = null;
        
        if (ConnectionCount == 0)
        {
            c = new ConfigConnection();
            //System.out.println("Creating new connection "+c.toString());
        }
        else
        {
            c = ConnectionPool[--ConnectionCount];
            ConnectionPool[ConnectionCount] = null;            
            //System.out.println("Reusing connection "+ConnectionCount
            //                        +" "+c.toString());
        }
        
        return c;
    }
    
    
    public static synchronized void 
    freeConnection(ConfigConnection c)
    {         
        if (c == null) return;
        
        if (ConnectionCount < ConnectionLimit)        
        {
            ConnectionPool[ConnectionCount++] = c;                        
            //System.out.println("Caching connection "+ConnectionCount
            //                        +" "+c.toString());
        }
        else
        {
            c.closeSocket();
                                    
            //System.out.println("Closing connection "+c.toString());
        }
        
        return;
    }
    
    public static synchronized void
    closeConnectionPool() {         
        
        if (ConnectionCount == 0) return;
        //System.out.println("Connection count "+ConnectionCount);
        for (; ConnectionCount > 0; ) {
            ConfigConnection c = ConnectionPool[--ConnectionCount];
            ConnectionPool[ConnectionCount] = null;
            if (c != null) 
            {
                c.closeSocket();
                //System.out.println("Closing connection "+c.toString());
            }
        }
        
        //System.out.println("Connection count "+ConnectionCount);
        
        return;
    }
    
    
    public byte[]
    configRequest(StringBuffer buf)
    throws IOException, DBException {
        
        
        
        byte[] b=null;
        int ntries = Constants.NUM_CONNECTION_TRIES;
        boolean done=false;
        boolean insertHeader = true;
        Exception excep = null;
        
        if (serverList == null) {
            serverList = ConfigComm.getServerList();
            if (serverList == null) {
                throw new DBException("Server list is null");
            }
        }
        
        java.util.StringTokenizer tok
        = new java.util.StringTokenizer(serverList,", \t");
        
        String serverName = ConfigComm.getLastServer();
        if (serverName == null) {
            if (tok.hasMoreTokens())
                serverName = tok.nextToken();
            else
                throw new DBException("Could not get configuration server list");
        }
        
        //Socket server=null;
        
        while ( !done ) {
            
            if (Constants.DEBUG && Constants.Verbose>2)
                System.out.println("Connecting to host: "+serverName);
            
            try {
                
                if (server == null)
                    server = ConfigComm.connectToConfigServer(serverName);
                ConfigComm.sendRequest(server,buf,insertHeader);
                insertHeader = false;
                
            } catch (UnknownHostException uhe) {
                closeSocket();
                Log.getInstance().log_warning("ConfigComm:Unknown host: "
                +serverName+".",uhe);
                
                
                ntries=Constants.NUM_CONNECTION_TRIES;
                
                if (tok.hasMoreTokens()) {
                    
                    String previousHost = serverName;
                    serverName = tok.nextToken();
                    
                    Log.getInstance().log_warning(
                    "Could not connect to configuration server"
                    +" on "+previousHost+". Trying "
                    +serverName,
                    uhe);
                    continue;
                    
                } else
                    throw
                    new DBException("Could not establish communications"
                    +" with configuration server.",
                    Constants.COMM_ERR);
                
            } catch (Exception ioEx) {
                closeSocket();
                ntries--;
                
                if (ntries>0) {
                    Log.getInstance().log_warning(
                    "Communication error: Retrying .. "
                    +serverName+".",ioEx);
                    continue;
                    
                } else {
                    
                    ntries=Constants.NUM_CONNECTION_TRIES;
                    
                    if (tok.hasMoreTokens()) {
                        
                        String previousHost = serverName;
                        serverName = tok.nextToken();
                        
                        Log.getInstance().log_warning(
                        "Could not connect to configuration server"
                        +" on "+previousHost+". Trying "
                        +serverName,
                        ioEx);
                        
                        
                        continue;
                        
                    } else
                        throw
                        new DBException("Could not establish communications"
                        +" with configuration server.",
                        Constants.COMM_ERR);
                } /* else ntries */
                
            } /* try - catch */
            
            
            
            insertHeader=false;
            
            
            
            try {
                
                
                b = ConfigComm.getResponse(server);
                done=true;
                ConfigComm.setLastServer(serverName);
                
            } catch (DBModeException modeEx) {
                
                closeSocket();
                if (tok.hasMoreTokens()) {
                    
                    ntries=Constants.NUM_CONNECTION_TRIES;
                    
                    String previousHost = serverName;
                    serverName = tok.nextToken();
                    Log.getInstance().log_warning(
                    "Server not in master mode on "
                    +previousHost+". Trying "+serverName,
                    modeEx);
                    
                } else {
                    
                    Log.getInstance().log_error(
                    "Communication Error:Could not establish "
                    +"communications with configuration server. "
                    +serverList,
                    modeEx);
                    
                    throw new
                    DBException("Could not connect to any master server. "
                    +serverList,
                    Constants.MODE_ERR);
                }
                
                
                
            } catch (DBRetryException retryEx) {
                closeSocket();
                ntries--;
                
                if (ntries>0) {
                    Log.getInstance().log_warning("Configuration server in "
                    +"sync. mode on "
                    +serverName+" .Retrying",
                    null);
                    continue;
                } else
                    throw new DBException("Configuration server still in "
                    +"sync. mode. "+serverList,
                    Constants.SYNC_ERR);
                
                
                
                
            } catch (IOException ioEx) {
                closeSocket();
                ntries--;
                if (ntries>0) {
                    Log.getInstance().log_warning("Communication error: "
                    +serverName+" .Retrying ",
                    null);
                    continue;
                } else
                    throw new DBException("Error in retrieving configuration "
                    +"from configuration server. "
                    +serverName,Constants.COMM_ERR);
            }
            
            
            
        } /* While ! done */
        
        return b;
        
    }
    
    
    
    private void closeSocket() {
        
        try {
            if (server!=null) {
                server.close();
                server = null;
            }
        }
        catch (Exception e){}
        
    }
    
 
}

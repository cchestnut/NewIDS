/*
**  SCCS Info :  "@(#)TaskListener.java	1.2    01/07/10"
*/
/*
 * TaskListener.java
 * This may be used for any purposes whatsoever without acknowledgment.
 */

package ids2ui;

import java.util.EventListener;

/**
 * TaskListeners are notified when tasks begin and end. 
 *
 * @author  srz
 * @version 
 */
public interface TaskListener extends EventListener {
    /** Called when a task is scheduled to start. */
    void taskStarted(java.util.EventObject  event);
    void taskStarted(String s);
    /** Called when a task ends. */
    void taskEnded(java.util.EventObject  event);
    void taskEnded(String s);
}

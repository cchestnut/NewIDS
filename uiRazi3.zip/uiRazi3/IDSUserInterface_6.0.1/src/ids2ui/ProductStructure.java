/*
**  SCCS Info :  "@(#)ProductStructure.java	1.1    00/11/16"
*/
package ids2ui;



public class ProductStructure {
    public ProductStructure(String id, int t, int l, boolean h)
    {
        ID=id;
        type = t;
        lcn = l;
        history = h;
      }
      
    public String ID;
    public int   type;
    public int   lcn;
    public boolean history;
    
    public ProductStructure() {
    }
  }

/*
**  SCCS Info :  "@(#)FilterCodesDataModel.java	1.6    04/05/10"
*/

/*
 * FilterCodesSelectDataModel.java
 *
 * Created on May 24, 2000, 4:58 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

  
public class FilterCodesDataModel 
    extends javax.swing.table.AbstractTableModel  
    implements	Utils.UpdateModel
{



    protected int     m_sortCol = 0;
    protected boolean m_sortAsc = true;
    protected java.util.Vector m_vector = null;
    protected int m_columnsCount = Constants.FilterCodesTableColumnNames.length;



    /** Creates new FilterCodesSelectDataModel */
    public  FilterCodesDataModel()
    {
	m_vector = new java.util.Vector(25);	
    }

  


    synchronized public void addRow(String id, String desc) {
	boolean new_entry = true;
	int nrows = m_vector.size();
	for (int i = 0; i < nrows; i++) {
	    String t[] = (String[])m_vector.get(i);
	    if (id.equals(t[0])) {
		t[1] = desc;
		new_entry = false;
		break;
	    }
	}
	if (new_entry) {
	    String [] rowData = new String[m_columnsCount];
	    rowData[0] = id;
	    rowData[1] = desc;
	    m_vector.add(rowData);
	}

	java.util.Collections.sort(m_vector, new
				   RowComparator(m_sortCol, m_sortAsc));
	fireTableDataChanged();
    }

    synchronized public void deleteRow(String id) {

	int nrows = getRowCount();
	for (int i = 0; i < nrows; i++) {
	    String t[] = (String[])m_vector.get(i);
	    if (id.equals(t[0])) {
		m_vector.removeElementAt(i);
		fireTableRowsDeleted(i,i);
		return;
	    }
	}
    }


    synchronized public void addRow(Object[] r ) {

	m_vector.add(r);
	java.util.Collections.sort(m_vector, new
				   RowComparator(m_sortCol, m_sortAsc));
	fireTableDataChanged();
    }

    synchronized public void removeRow(int i ) {

	m_vector.removeElementAt(i);
	fireTableRowsDeleted(i,i);
	return;
    }

    synchronized public void stop() {
	//threadPool.waitForAll(true);
	m_vector.clear();
	m_vector = null;

    }
  

    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int column) {
      	String str = Constants.FilterCodesTableColumnNames[column];
	if (column==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 
    public boolean isCellEditable(int nRow, int nCol) {
	return false;
    }

    synchronized public Object getValueAt(int nRow, int nCol) {
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((Object[])m_vector.get(nRow))[nCol];
    }








    public void Update() 
    {
	int oldRows = m_vector.size();
	java.util.Vector u_vector = new java.util.Vector(oldRows);


        try { 
	    StringBuffer reqbuf = new StringBuffer();
	    String       respbuf,databuf;
	    byte[] b;
          
          
	    ConfigComm.getTagKey(reqbuf,ConfigComm.GET_ALL_FILTERCODES_INFO);
	    b = ConfigComm.configRequest(reqbuf);
	    respbuf = new String(b);
	    int index = respbuf.indexOf(ConfigComm.CONF_STX)+1;
	    databuf = respbuf.substring(index);
          

	    if (Constants.DEBUG && Constants.Verbose>2)
		System.out.println("Response: "+databuf);


	    java.util.StringTokenizer rowTokenizer, colTokenizer;
          
	    StringBuffer rowSeparator, colSeparator;
	    rowSeparator = new StringBuffer();
	    colSeparator = new StringBuffer();
          
	    rowSeparator.append(ConfigComm.CONF_STX).
		append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_FS);
          
	    colSeparator.append(ConfigComm.CONF_ETX).
		append(ConfigComm.CONF_RS);
          
	    rowTokenizer = new 
                java.util.StringTokenizer(databuf,rowSeparator.toString());

	    
	    String key=null,value=null;

	    java.util.HashMap map = null;
	    while (rowTokenizer.hasMoreTokens()) {
          	String [] rowData = new String[m_columnsCount];
		rowTokenizer.nextToken(); // Skip "key"
		String fstr = rowTokenizer.nextToken();
		colTokenizer = 
		    new java.util.StringTokenizer(fstr,
						  colSeparator.toString());

		map = new java.util.HashMap(4);
		while (colTokenizer.hasMoreTokens()) {
		    key = colTokenizer.nextToken();
		    if (colTokenizer.hasMoreTokens()) {
			value = colTokenizer.nextToken();
		    } else {
			continue;
		    }
		    if (key.length()>0)
			map.put(key,value);
		}

		rowData[0]  = (String)map.get("ID");
		rowData[1]  = (String)map.get("DESCRIPTION");


		u_vector.add(rowData);
              
            }

	    java.util.Collections.sort(u_vector, new
				       RowComparator(m_sortCol, m_sortAsc));

            int  newRows = 0;
            
	    synchronized (this) {
		if (m_vector!=null) {
                        oldRows = m_vector.size();
                        m_vector.clear();
                }
                
		m_vector=null;
		m_vector = u_vector;
                newRows = m_vector.size();
	    }
	    IDS_SwingUtils.fireTableChanged(this, oldRows, newRows);

        
        } catch (Exception e) {
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();

	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == -11001)
		    return; 
	    }
	    Log.getInstance().log_error(
					"Error in retrieving Filter codes list",e);
                      
        }
    }

    
  



    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }

	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }
	    m_table.getTableHeader().repaint();  

	    synchronized (FilterCodesDataModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   RowComparator(modelIndex, m_sortAsc));
	    }
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(FilterCodesDataModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release(); 
	}
    }


    class RowComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public RowComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;


	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;

	    return result;
	}
    }


}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ids2ui;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.*;
/**
 *
 * @author ChestnutC
 */
public class StatusTabHandler extends JFrame{
    JTabbedPane statusTabs;
    JFrame statusFrame;
    String title;
    public StatusTabHandler(){
        
    }
    
    public StatusTabHandler(String title, Component parent, int type, int which,
            String id, String tag){
        init(title, parent, type, which, id, tag);       
    }
    public StatusTabHandler(String title, Component parent, int type, int which,
            String id){
        init(title, parent, type, which, id, null);
        
    }
    
    private void init(String title, Component parent, int type, int which,
            String id, String tag){
        this.title = title;
        this.setTitle(title);
        statusFrame = this;
        statusTabs = new JTabbedPane();
        this.add(statusTabs);
        this.addWindowListener(new WindowListener(){
            public void windowClosing(WindowEvent e){
                                       
                for(int x =statusTabs.getTabCount()-1; x>=0;x--){
                    Component selected = 
                        statusTabs.getTabComponentAt(x);
                                                    
                    JPanel master2 = (JPanel)selected;
                    for(int y=0;y<master2.getComponentCount();y++)
                        if(master2.getComponent(y) instanceof JButton
                        && ((JButton)master2.getComponent(y)).getText().equals("x")){
                            JButton closer = ((JButton)master2.getComponent(y));
                            closer.doClick();
                        }
                                                    
                    }
                    statusTabs.removeAll();
            }
            public void windowClosed(WindowEvent e){
                                           
            }
            public void windowDeactivated(WindowEvent e){
                                            
            }
            public void windowActivated(WindowEvent e){
                                            
            }
            public void windowDeiconified(WindowEvent e){
                                            
            }
            public void windowIconified(WindowEvent e){
                                            
            }
            public void windowOpened(WindowEvent e){
                                            
            }
        });
        addTab(parent, type, which, id, tag);
        this.pack(); 
    }
    
    public void addTab(Component parent, int type, int which, String id){
        addTab(parent, type, which, id, null);
    }
   public void addTab(Component parent, int type, int which, String id, String tag){
        try{
            
            String loc;
            if(type == Constants.DCM_LINEHANDLER){
                java.util.HashMap m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+id);
                String pl = (String)m.get("HOME_LOCATION");
                if(Integer.toString(which).equals(pl))
                    loc = Constants.TAB_SEPARATOR + "H";
                else
                    loc = Constants.TAB_SEPARATOR + "A"; 
            }else if (type == Constants.DSP_BROADCASTER)
            {
                        
                if(which == 1)
                    loc = Constants.TAB_SEPARATOR +"I";
                else
                    loc = Constants.TAB_SEPARATOR +"II";
            }else{
                if(which == 1)
                    loc = Constants.TAB_SEPARATOR +"H"+Constants.TAB_SEPARATOR +tag;
                else
                    loc = Constants.TAB_SEPARATOR +"A"+Constants.TAB_SEPARATOR +tag;
            }
            
            String newID = id + loc;
            int tabCheck = statusTabs.indexOfTab(newID);
                                
                               
            if(tabCheck != -1)
            {
                statusTabs.setSelectedIndex(tabCheck);
                this.toFront();
            }
            else{ 
                FormReturner status_win;
                if(tag == null){
                    status_win = new DistributorStatusForm(type, which, id);
                }
                else{
                    status_win = new ReaderStatusForm(type, which, tag, id);
                }
                    
                          
                statusTabs.addTab(newID, status_win.getForm());
                int index = statusTabs.indexOfTab(newID);
                statusTabs.setSelectedIndex(index);
                JPanel pnlTab = new JPanel();
                pnlTab.setLayout(new BoxLayout(pnlTab, BoxLayout.X_AXIS));
                pnlTab.setOpaque(false);
                JLabel lblTitle = new JLabel(newID);
                JButton btnClose = new JButton("x");
                btnClose.setActionCommand(index+"");
                pnlTab.add(lblTitle);
                pnlTab.add(Box.createHorizontalStrut(25));
                btnClose.setPreferredSize(new Dimension(20,20));
                btnClose.setMargin(new Insets(0,0,0,0));
                btnClose.setHorizontalTextPosition(SwingConstants.CENTER);
                JButton getOther = new JButton();
                ImageIcon icon = IDS_SwingUtils.createImageIcon("cursor_v_split.gif", "");
                getOther.setIcon(icon);
                getOther.setPreferredSize(new Dimension(25,20));
                getOther.setMargin(new Insets(0,0,0,0));
                getOther.setActionCommand(newID);
                getOther.setToolTipText("Toggle Display of Opposite Status");
                getOther.addActionListener(new ActionListener(){
                   public void actionPerformed(ActionEvent evt)
                    {
                        splitHandler(evt);
                    }
                });

                pnlTab.add(getOther);
                pnlTab.add(Box.createHorizontalStrut(5));
                pnlTab.add(btnClose);
                pnlTab.add(Box.createHorizontalGlue());
                btnClose.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent evt) {

                            int index = Integer.parseInt(evt.getActionCommand());
                            Component selected = 
                                    statusTabs.getComponentAt(index);
                            if(selected instanceof JSplitPane)
                            {
                               selected = ((JSplitPane)selected).getLeftComponent();
                               selected = ((JScrollPane)selected).getComponent(0);
                               selected = ((JViewport)selected).getComponent(0);
                            }

                            JPanel master = (JPanel)selected;
                            int buttonFinder;
                            if(master.getName().contains("reader"))
                                buttonFinder = 0;
                            else
                                buttonFinder = 1;
                            JPanel buttonsPan = ((JPanel)master.getComponent(buttonFinder));
                            JButton button = ((JButton)buttonsPan.getComponent(1));
                            button.doClick();
                            if(statusTabs.getComponentAt(index) instanceof JSplitPane){
                                selected = ((JSplitPane)statusTabs.getComponentAt(index)).getRightComponent();
                                selected = ((JScrollPane)selected).getComponent(0);
                                selected = ((JViewport)selected).getComponent(0);
                                JPanel buttonPan = (JPanel)((JPanel)selected).getComponent(buttonFinder);
                                JButton button2 = ((JButton)buttonPan.getComponent(1));
                                button2.doClick();
                            }

                            if (statusTabs.getComponentAt(index) != null){
                                statusTabs.remove(statusTabs.getComponentAt(index));

                                for(int x=0;x<statusTabs.getTabCount();x++)
                                {                                                    
                                    Component tabPan = statusTabs.getTabComponentAt(x);
                                    JPanel master2 = (JPanel)tabPan;
                                    for(int y=0;y<master2.getComponentCount();y++)
                                        if(master2.getComponent(y) instanceof JButton
                                                && ((JButton)master2.getComponent(y)).getText().equals("x")){
                                    JButton closer = ((JButton)master2.getComponent(y));
                                    closer.setActionCommand(x + "");
                                        }            
                                }
                            }
                            if(statusTabs.getTabCount() == 0)
                                statusFrame.dispose();
                }});

                statusTabs.setTabComponentAt(index, pnlTab);
                statusFrame.show();
                statusFrame.revalidate();

                }
    }catch (Utils.DuplicateWindowException dwe) {
        JOptionPane.showMessageDialog(statusFrame, "Status Currently"
        + " Open in Split Tab",
        "Status Already Open", JOptionPane.WARNING_MESSAGE);
        return;
    }catch (Exception e) {
        //System.out.println(e.getMessage());
        Log.getInstance().show_error(parent,"Error",
            e.getMessage(),
            e);
        } 
                        
    }
   
    private void splitHandler(ActionEvent evt){
        splitHelper(evt.getActionCommand());
    }
    private void splitHelper(String evt){
                     
    String id = evt;
    int index = statusTabs.indexOfTab(id);
    Component tab = statusTabs.getTabComponentAt(index);
    JPanel tabPan = (JPanel) tab;
    JLabel ident = (JLabel) tabPan.getComponent(0);
    Component statComp = statusTabs.getComponentAt(index);
    String[] idComps = id.split(Constants.TAB_SEPARATOR);
    if(!(statComp instanceof JSplitPane)){
        //code to split
        String pl = "1";
        try{
            java.util.HashMap
            m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+idComps[0]);
            pl = (String)m.get("HOME_LOCATION");
        }catch(Exception e){
        }
        JSplitPane splitPane;
        int opp;
        String home, away;
        if(pl.equals("1")){
            home = "1";
            away = "2";
        }else{
            home = "2";
            away = "1";
        }
        if(idComps[1].equals("A") || idComps[1].equals("II")){
            opp = Integer.parseInt(home);
        }else
            opp = Integer.parseInt(away);
        FormReturner oppForm;
        // int tryCount = 0;
        /// while(tryCount < 2){
        int type = 6;
        if(title.contains("DCM Line"))
            type = Constants.DCM_LINEHANDLER;
        else if(title.contains("DSP Line"))
            type = Constants.DSP_BROADCASTER;
        else if(title.contains("DCM Read"))
            type = Constants.DCM_READER;
        else if(title.contains("DSP Read"))
            type = Constants.DSP_READER;
        else if(title.contains("Message"))
            type = Constants.MSGMGR;
        try{
            if(type == Constants.DCM_LINEHANDLER || type == Constants.DSP_BROADCASTER)
                oppForm = new DistributorStatusForm(type,opp,idComps[0]);
            else
                oppForm = new ReaderStatusForm(type, opp, idComps[2], idComps[0]);
            JScrollPane left = new JScrollPane(statComp);
            JScrollPane right = new JScrollPane(oppForm.getForm());
            splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,left,right );
            splitPane.setResizeWeight(.5);
            if(statusTabs.getTabCount() != 0 && 
                    index < statusTabs.getTabCount()){
                    
                statusTabs.insertTab(id, null, splitPane, null, index);
                statusTabs.setTabComponentAt(index, tabPan);
            }
            else
            {
                statusTabs.add(id, splitPane);
                statusTabs.setTabComponentAt(statusTabs.getTabCount()-1, tabPan);
            }
            statusTabs.setSelectedIndex(index);
            //tryCount = 5;
            if(idComps.length > 2)
                ident.setText(idComps[0] + Constants.TAB_SEPARATOR + idComps[2]);
            else
                ident.setText(idComps[0] + "   ");
         }catch(Utils.DuplicateWindowException dwe){
                              /*String mess = "The status requested is being"
                                         + "used by another tab. Do you wish"
                                         + "to close that tab?";
                                 String[] options = {"Yes", "No"};
                                 int resp = JOptionPane.showOptionDialog(statusTabs, mess, "Split Confirmation",
                                         JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
                                 if(resp == JOptionPane.YES_OPTION){*/
                                 //JOptionPane.showInputDialog("here");
            if(idComps[1].equals("A"))
                idComps[1] = "H";
            else if(idComps[1].equals("H"))
                idComps[1] = "A";
            else if(idComps[1].equals("I"))
                idComps[1] = "II";
            else if(idComps[1].equals("II"))
                idComps[1] = "I";
                
            JOptionPane.showMessageDialog(statusFrame, "Close tab " + idComps[0]+
                "-"+idComps[1]+" to execute split", 
                "Status Already Open",JOptionPane.WARNING_MESSAGE); 
                                /*int enemyIndex = statusTabs.indexOfTab(idComps[0]+"-"+idComps[1]);
                                 if(enemyIndex < index)
                                     index--;
                                 JPanel grrPan =(JPanel) statusTabs.getTabComponentAt(enemyIndex);
                                 for(int y=0;y<grrPan.getComponentCount();y++)
                                                        if(grrPan.getComponent(y) instanceof JButton
                                                                && ((JButton)grrPan.getComponent(y)).getText().equals("x")){
                                                    JButton closer = ((JButton)grrPan.getComponent(y));
                                                        closer.doClick();
                                                        //splitHelper(evt);
                                                        //return;
                                                        
                                                        tryCount++;
                                                        }
                                /* }
                                else*/
            return;
            }catch(Exception e){
                Log.getInstance().show_error(statComp,"Error",
                    e.getMessage(),
                    e);
                               //  tryCount++;
            }
                           //}
        }else{
            //code to reunify
            ident.setText(id);
            JSplitPane sptPane = (JSplitPane) statComp;

            JScrollPane sclPane = (JScrollPane)sptPane.getLeftComponent();
            JViewport view = sclPane.getViewport();
            JPanel regPane = (JPanel)view.getComponent(0);

            JScrollPane ritPane = (JScrollPane)sptPane.getRightComponent();
            JViewport view2 = ritPane.getViewport();
            JPanel reg2Pane = (JPanel)view2.getComponent(0);
            int buttonFinder = 1;
            if(idComps.length > 2)
                buttonFinder = 0;
            JPanel buttonPan = (JPanel)reg2Pane.getComponent(buttonFinder);
            JButton button = ((JButton)buttonPan.getComponent(1));
            button.doClick();
            if(statusTabs.getTabCount() != 0){
                statusTabs.insertTab(id, null, regPane, null, index);
                statusTabs.setTabComponentAt(index, tabPan);
                statusTabs.remove(index+1);
            }
            else
            {
                statusTabs.add(id, regPane);
                statusTabs.setTabComponentAt(0, tabPan);
            }
            statusTabs.setSelectedIndex(index);
        }
    }
}

/*
**  SCCS Info :  "@(#)TransportPanel.java	1.5    01/10/03"
*/
/*
 * TransportPanel.java
 *
 * Created on March 2, 2001, 5:02 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class TransportPanel extends javax.swing.JPanel {
  private java.util.Vector transportList = null;
  private String transportString = null;
  private javax.swing.JTable tcpHostTable = null;
  private java.awt.Window parentFrame = null;
  
  /** Creates new form TransportPanel */
  public TransportPanel(java.awt.Window parent, String title,java.util.Vector tl, String ts ) {
    parentFrame = parent;
    transportList = tl;
    transportString = ts;

     
    initComponents ();
    myInitComponents (title);
    
    transportChanged(null);
    if (ts!=null)
      populateUI(ts);

    final javax.swing.ListSelectionModel selectionModel
          = tcpHostTable.getSelectionModel();
    
    jButton2.setEnabled(false);
    jButton3.setEnabled(false);
    
     selectionModel.addListSelectionListener(
          new javax.swing.event.ListSelectionListener() {
              public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                boolean enabled = true;
                if (evt.getValueIsAdjusting())
                  return;
                if (selectionModel.isSelectionEmpty())
                  enabled = false;
                jButton2.setEnabled(enabled); //Modify button
                jButton3.setEnabled(enabled); //Delete button
                
              }
            });
            
  }

  public void setTransportConfig(String ts) {
      populateUI(ts);
  }

  public int getTransportConfig(StringBuffer transport, StringBuffer errstr) {
    int err=0;
    
    transport.append(transportString).append(" ");
    
    
    if (transportString.substring(0,3).equals("FIL") ) {
      String fname = fileTextField.getText().trim();
      if (fname.length() == 0) {
        err=1; errstr.append(" Transport: filename \n");
      }
      transport.append(fname);
    }


    if (transportString.substring(0,3).equals("RBP") ) {
      String appid = rbpTextField.getText().trim();
      if (appid.length() == 0) {
        err=1; errstr.append("  Application ID \n");
      }
      transport.append(appid);
    }



    if (transportString.equals("ASYNC")) {
      String h = tcpHostTextField.getText().trim();
      String p = tcpPortTextField.getText().trim();
      if ( (h.length()==0) || (p.length()==0)) {
        err=1; errstr.append(" Transport: Port/Service \n");
      }
      transport.append(h).append(":").append(p);
    }

    if (transportString.substring(0,3).equals("SVC")) {
      String l = svcLinkTextField.getText().trim();
      String d = svcDTETextField.getText().trim();
      if ( (l.length()==0) || (d.length()==0)) {
        err=1; errstr.append(" Transport: Link/Dte \n");
      }
      transport.append(l).append(".").append(d);
    }

    if (transportString.substring(0,3).equals("PVC")){
      String l = pvcLinkTextField.getText();
      if (l.length() == 0) {
        err=1; errstr.append(" Transport: PVC Link \n");
      }
      transport.append(l);
    }

    if (transportString.substring(0,3).equals("TCP")) {
      javax.swing.table.DefaultTableModel model =
      (javax.swing.table.DefaultTableModel)tcpHostTable.getModel();
      int nrows = model.getRowCount();

      if (nrows <= 0) {
        err=1; errstr.append(" Transport: Host/Service \n");
      }

      
      if (transport.length() < 5 ) {
        err=1; errstr.append("TCP type \n");
      }

      //transport.append(" ");
      for ( int i = 0; i < nrows; i++) {
        String h = (String)model.getValueAt(i,0);
        String p = (String)model.getValueAt(i,1);

        if (h!=null && (h.length() > 0))
        transport.append(h).append(":");

        transport.append(p);
        if (i < (nrows-1)) transport.append(",");
      }

    } /* TCPOUT */

    return err;
  }


  private void myInitComponents(String title) {

    setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.TitledBorder(
                  new javax.swing.border.EtchedBorder(), title, 2, 2),
          new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5))));
  


  }

  private void populateUI(String transport) {
    java.util.StringTokenizer st
    = new java.util.StringTokenizer(transport," ");
    String typeStr, addrStr;


    if (st.hasMoreTokens())
    typeStr = st.nextToken();
    else
    return;

    if (st.hasMoreTokens())
    addrStr = st.nextToken();
    else
    return;

    if  (typeStr.substring(0,3).equals("FIL")) {
      fileTextField.setText(addrStr);
    }

    if  (typeStr.substring(0,3).equals("RBP")) {
      rbpTextField.setText(addrStr);
    }



    if (typeStr.equals("ASYNC")) {
      int inx = addrStr.indexOf(':');

      tcpHostTextField.setText(addrStr.substring(0,inx));
      tcpPortTextField.setText(addrStr.substring(inx+1));

    }
    if (typeStr.substring(0,3).equals("SVC")) {
      int inx = addrStr.indexOf('.');
      /* 
      ** For compatibility with previous config
      ** where ':' was used as separator for X.25 address
      */
      if (inx < 0) 
	inx = addrStr.indexOf(':');


      svcLinkTextField.setText(addrStr.substring(0,inx));
      svcDTETextField.setText(addrStr.substring(inx+1));
    }
    if (typeStr.substring(0,3).equals("PVC")) {
      pvcLinkTextField.setText(addrStr);
    }

    

    if (typeStr.substring(0,3).equals("TCP")) {


      javax.swing.table.DefaultTableModel model =
      (javax.swing.table.DefaultTableModel)tcpHostTable.getModel();
	  model.setNumRows(0);
      st = new java.util.StringTokenizer(addrStr,",");
      while (st.hasMoreTokens()) {
        String hp = st.nextToken();
        String [] row = new String[2];
        int inx = hp.indexOf(':');
        if (inx != -1) {
          row[0] = hp.substring(0,inx);
          row[1] = hp.substring(inx+1);
        } else {
          row[0] = "";
          row[1] = hp;
        }
        model.addRow(row);
      }

	  model.fireTableDataChanged();
      //typeStr = new String("TCPOUT");
    }
    java.awt.CardLayout l = (java.awt.CardLayout)transportPanel.getLayout();



    if (typeStr.substring(0,3).equals("TCP") )
    l.show((java.awt.Container)transportPanel,"TransportTCP");
    else if (typeStr.equals("ASYNC"))
    l.show((java.awt.Container)transportPanel,"TransportTCPHost");
    else if (typeStr.substring(0,3).equals("PVC"))
    l.show((java.awt.Container)transportPanel,"TransportPVC");
    else if (typeStr.substring(0,3).equals("SVC"))
    l.show((java.awt.Container)transportPanel,"TransportSVC");
    else if (typeStr.substring(0,3).equals("FIL"))
    l.show((java.awt.Container)transportPanel,"TransportFile");
	else if (typeStr.substring(0,3).equals("RBP"))
    l.show((java.awt.Container)transportPanel,"TransportRBP");
    else
    l.show((java.awt.Container)transportPanel,"TransportBlank");

    transportString = new String(typeStr);
    transportTypeCombo.setSelectedItem(transportString);



	validate();
  }







  /** This method is called from within the constructor to
   * initialize the form.
   * WARNING: Do NOT modify this code. The content of this method is
   * always regenerated by the FormEditor.
   */
  private void initComponents () {//GEN-BEGIN:initComponents
    jPanel1 = new javax.swing.JPanel ();
    jLabel1 = new javax.swing.JLabel ();
    transportTypeCombo = new javax.swing.JComboBox(transportList);
    if (transportList != null)
    transportString = new String((String)transportList.firstElement());

    transportPanel = new javax.swing.JPanel ();
    jPanel3 = new javax.swing.JPanel ();
    jPanel4 = new javax.swing.JPanel ();
    jLabel2 = new javax.swing.JLabel ();
    fileTextField = new javax.swing.JTextField ();
    jPanel5 = new javax.swing.JPanel ();
    jLabel3 = new javax.swing.JLabel ();
    svcLinkTextField = new javax.swing.JTextField ();
    jLabel4 = new javax.swing.JLabel ();
    svcDTETextField = new javax.swing.JTextField ();
    jPanel6 = new javax.swing.JPanel ();
    jLabel5 = new javax.swing.JLabel ();
    pvcLinkTextField = new javax.swing.JTextField ();
    jPanel7 = new javax.swing.JPanel ();
    jLabel6 = new javax.swing.JLabel ();
    tcpHostTextField = new javax.swing.JTextField ();
    jLabel7 = new javax.swing.JLabel ();
    tcpPortTextField = new javax.swing.JTextField ();
    jPanel8 = new javax.swing.JPanel ();
    jPanel10 = new javax.swing.JPanel ();
    jPanel11 = new javax.swing.JPanel ();

    tcpHostTable = new javax.swing.JTable(new javax.swing.table.DefaultTableModel(Constants.TCPColumnNames,0) );
    tcpHostTable.setPreferredScrollableViewportSize(new java.awt.Dimension(50,50));
    jScrollPane1 = new javax.swing.JScrollPane(tcpHostTable);

    jPanel12 = new javax.swing.JPanel ();
    jButton1 = new javax.swing.JButton ();
    jButton2 = new javax.swing.JButton ();
    jButton3 = new javax.swing.JButton ();
    jPanel13 = new javax.swing.JPanel ();
    jLabel8 = new javax.swing.JLabel ();
    rbpTextField = new javax.swing.JTextField ();
    setLayout (new java.awt.BorderLayout ());

    jPanel1.setLayout (new java.awt.FlowLayout (0, 10, 5));
    jPanel1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 5, 2)));

      jLabel1.setText ("Type");
  
      jPanel1.add (jLabel1);
  
      transportTypeCombo.setActionCommand ("transportChanged");
      transportTypeCombo.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) {
          transportChanged (evt);
        }
      }
      );
  
      jPanel1.add (transportTypeCombo);
  

    add (jPanel1, java.awt.BorderLayout.NORTH);

    transportPanel.setLayout (new java.awt.CardLayout ());
    transportPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)));

  
      transportPanel.add (jPanel3, "TransportBlank");
  
      jPanel4.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints1;
  
        jLabel2.setText ("File name");
    
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.insets = new java.awt.Insets (0, 0, 0, 5);
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        jPanel4.add (jLabel2, gridBagConstraints1);
    
    
        gridBagConstraints1 = new java.awt.GridBagConstraints ();
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints1.weightx = 1.0;
        jPanel4.add (fileTextField, gridBagConstraints1);
    
      transportPanel.add (jPanel4, "TransportFile");
  
      jPanel5.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints2;
  
        jLabel3.setText ("Link number");
    
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.insets = new java.awt.Insets (0, 0, 3, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel5.add (jLabel3, gridBagConstraints2);
    
        svcLinkTextField.setColumns (4);
    
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.insets = new java.awt.Insets (0, 0, 3, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel5.add (svcLinkTextField, gridBagConstraints2);
    
        jLabel4.setText ("DTE Address");
    
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.gridx = 0;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.insets = new java.awt.Insets (3, 0, 0, 5);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel5.add (jLabel4, gridBagConstraints2);
    
        svcDTETextField.setColumns (16);
        svcDTETextField.setText ("39990000000100");
    
        gridBagConstraints2 = new java.awt.GridBagConstraints ();
        gridBagConstraints2.gridx = 1;
        gridBagConstraints2.gridy = 1;
        gridBagConstraints2.insets = new java.awt.Insets (3, 0, 0, 0);
        gridBagConstraints2.anchor = java.awt.GridBagConstraints.WEST;
        jPanel5.add (svcDTETextField, gridBagConstraints2);
    
      transportPanel.add (jPanel5, "TransportSVC");
  
      jPanel6.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints3;
  
        jLabel5.setText ("Link number");
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.insets = new java.awt.Insets (0, 0, 0, 5);
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel6.add (jLabel5, gridBagConstraints3);
    
        pvcLinkTextField.setColumns (4);
    
        gridBagConstraints3 = new java.awt.GridBagConstraints ();
        gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
        jPanel6.add (pvcLinkTextField, gridBagConstraints3);
    
      transportPanel.add (jPanel6, "TransportPVC");
  
      jPanel7.setLayout (new java.awt.GridBagLayout ());
      java.awt.GridBagConstraints gridBagConstraints4;
  
        jLabel6.setText ("Host name");
    
        gridBagConstraints4 = new java.awt.GridBagConstraints ();
        gridBagConstraints4.insets = new java.awt.Insets (0, 0, 3, 5);
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
        jPanel7.add (jLabel6, gridBagConstraints4);
    
    
        gridBagConstraints4 = new java.awt.GridBagConstraints ();
        gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints4.insets = new java.awt.Insets (0, 0, 3, 0);
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints4.weightx = 0.5;
        jPanel7.add (tcpHostTextField, gridBagConstraints4);
    
        jLabel7.setText ("Service/Port");
    
        gridBagConstraints4 = new java.awt.GridBagConstraints ();
        gridBagConstraints4.gridx = 0;
        gridBagConstraints4.gridy = 1;
        gridBagConstraints4.insets = new java.awt.Insets (3, 0, 0, 5);
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
        jPanel7.add (jLabel7, gridBagConstraints4);
    
    
        gridBagConstraints4 = new java.awt.GridBagConstraints ();
        gridBagConstraints4.gridx = 1;
        gridBagConstraints4.gridy = 1;
        gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints4.insets = new java.awt.Insets (3, 0, 0, 0);
        gridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints4.weightx = 0.25;
        jPanel7.add (tcpPortTextField, gridBagConstraints4);
    
      transportPanel.add (jPanel7, "TransportTCPHost");
  
      jPanel8.setLayout (new javax.swing.BoxLayout (jPanel8, 0));
  
        jPanel10.setLayout (new javax.swing.BoxLayout (jPanel10, 0));
    
          jPanel11.setLayout (new java.awt.BorderLayout ());
      
        
            jPanel11.add (jScrollPane1, java.awt.BorderLayout.CENTER);
        
        
              jButton1.setText ("Add");
              jButton1.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tcpHostAction (evt);
                }
              }
              );
          
              jPanel12.add (jButton1);
          
              jButton2.setText ("Modify");
              jButton2.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tcpHostAction (evt);
                }
              }
              );
          
              jPanel12.add (jButton2);
          
              jButton3.setText ("Delete");
              jButton3.addActionListener (new java.awt.event.ActionListener () {
                public void actionPerformed (java.awt.event.ActionEvent evt) {
                  tcpHostAction (evt);
                }
              }
              );
          
              jPanel12.add (jButton3);
          
            jPanel11.add (jPanel12, java.awt.BorderLayout.SOUTH);
        
          jPanel10.add (jPanel11);
      
        jPanel8.add (jPanel10);
    
      transportPanel.add (jPanel8, "TransportTCP");
  
  
        jLabel8.setText ("Application ID");
    
        jPanel13.add (jLabel8);
    
        rbpTextField.setColumns (8);
        rbpTextField.setText ("0");
    
        jPanel13.add (rbpTextField);
    
      transportPanel.add (jPanel13, "TransportRBP");
  

    add (transportPanel, java.awt.BorderLayout.CENTER);

  }//GEN-END:initComponents

private void tcpHostAction (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcpHostAction
  // Add your handling code here:

  // Add your handling code here:
  String action = evt.getActionCommand();
  javax.swing.table.DefaultTableModel model =
  (javax.swing.table.DefaultTableModel)tcpHostTable.getModel();
  int nrows = model.getRowCount();
  HostServiceDialog dlg;
  javax.swing.JDialog pdlg = null;
  javax.swing.JFrame pfrm = null;

	if (parentFrame instanceof javax.swing.JDialog)
		pdlg = (javax.swing.JDialog)parentFrame;
	else if (parentFrame instanceof javax.swing.JFrame)
		pfrm = (javax.swing.JFrame)parentFrame;
		
  if (action.equals("Add")) {
    if (nrows == 5) {
      javax.swing.JOptionPane.showMessageDialog(this,
      "Only 5 hosts are allowed","Error",
      javax.swing.JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (nrows > 0) {
      String [] validateList = new String[nrows];
      for (int i=0; i < nrows; i++) {
        StringBuffer s = new StringBuffer();
        String h = (String)model.getValueAt(i,0);
        String p = (String)model.getValueAt(i,1);

        if (h!=null && (h.length()>0))
        s.append(h).append(":");

        s.append(p);
        validateList[i] = s.toString();
      }
		if (pdlg!=null)
      		dlg = new HostServiceDialog(pdlg,true,validateList);
		else
      		dlg = new HostServiceDialog(pfrm,true,validateList);
			
    } else  {
		if (pdlg!=null)
      		dlg = new HostServiceDialog(pdlg,true);
		else
      		dlg = new HostServiceDialog(pfrm,true);
    }

    dlg.show();
    String addr = dlg.getHostAddress();
    if (addr != null) {
      int index = addr.indexOf(":");
      String h = addr.substring(0,index);
      String s = addr.substring(index+1);
      /* Check for duplicate host/service */


      String [] a = new String[2];
      a[0] = h;
      a[1] = s;
      model.addRow(a);
    }
  }

  if (action.equals("Modify")) {
    int srows[] = tcpHostTable.getSelectedRows();
    if (srows.length == 0) return;
    int srow = srows[0];

    StringBuffer hstr = new StringBuffer();
    String h = (String)model.getValueAt(srow,0);
    String p = (String)model.getValueAt(srow,1);

    if (h!=null && (h.length()>0))
    hstr.append(h).append(":");

    hstr.append(p);

    String [] validateList = new String[nrows-1];
    int k=0;


    for (int i=0; i < nrows; i++) {
      if (i == srow) continue;
      StringBuffer s = new StringBuffer();
      h = (String)model.getValueAt(srow,0);
      p = (String)model.getValueAt(srow,1);

      if (h!=null && (h.length() > 0))
      s.append(h).append(":");

      s.append(p);
      validateList[k++] = s.toString();
    }
	if (pdlg!=null)
      	dlg = new HostServiceDialog(pdlg,true,validateList,hstr.toString());
	else
      	dlg = new HostServiceDialog(pfrm,true,validateList,hstr.toString());

    dlg.show();
    String addr = dlg.getHostAddress();
    if (addr != null) {
      int index = addr.indexOf(":");
      String h1 = addr.substring(0,index);
      String s1 = addr.substring(index+1);
      /* Check for duplicate host/service */

      model.setValueAt(h1,srow,0);
      model.setValueAt(s1,srow,1);

    }
  }

  if (action.equals("Delete")) {
    int srows[] = tcpHostTable.getSelectedRows();
    if (srows.length == 0) return;
    
    if (srows.length==1) {
      model.removeRow(srows[0]);
    } else {
      String hosts[] = new String[srows.length];
      String ports[] = new String[srows.length];
      for (int i = 0; i < srows.length; i++) {
        hosts[i] = new String((String)model.getValueAt(srows[i],0));
        ports[i] = new String((String)model.getValueAt(srows[i],1));        
      }
      
      for (int i=0; i< srows.length; i++) {
        for (int r = 0; r < model.getRowCount(); r++) {
          String h = (String)model.getValueAt(r,0);
          String p = (String)model.getValueAt(r,1);
        
          if (h.equals(hosts[i]) && p.equals(ports[i])) {            
            model.removeRow(r);
            //model.fireTableRowsDeleted(r,r);
            break;
          }
        }
      }
      
      
    }
  }




  }//GEN-LAST:event_tcpHostAction

private void transportChanged (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transportChanged
  // Add your handling code here:

  // Add your handling code here:
  java.awt.CardLayout l = (java.awt.CardLayout)transportPanel.getLayout();


  String selectstr = (String)transportTypeCombo.getSelectedItem();
  if (selectstr.substring(0,3).equals("TCP"))
  l.show((java.awt.Container)transportPanel,"TransportTCP");
  else if (selectstr.equals("ASYNC"))
  l.show((java.awt.Container)transportPanel,"TransportTCPHost");
  else if (selectstr.substring(0,3).equals("PVC"))
  l.show((java.awt.Container)transportPanel,"TransportPVC");
  else if (selectstr.substring(0,3).equals("SVC"))
  l.show((java.awt.Container)transportPanel,"TransportSVC");
  else if (selectstr.substring(0,3).equals("FIL"))
  l.show((java.awt.Container)transportPanel,"TransportFile");
  else if (selectstr.substring(0,3).equals("RBP"))
  l.show((java.awt.Container)transportPanel,"TransportRBP");
  else
  l.show((java.awt.Container)transportPanel,"TransportBlank");


  transportString = new String(selectstr);
  //System.out.println("Transport type " + transportString);


  }//GEN-LAST:event_transportChanged


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JPanel jPanel1;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JComboBox transportTypeCombo;
  private javax.swing.JPanel transportPanel;
  private javax.swing.JPanel jPanel3;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JLabel jLabel2;
  private javax.swing.JTextField fileTextField;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JLabel jLabel3;
  private javax.swing.JTextField svcLinkTextField;
  private javax.swing.JLabel jLabel4;
  private javax.swing.JTextField svcDTETextField;
  private javax.swing.JPanel jPanel6;
  private javax.swing.JLabel jLabel5;
  private javax.swing.JTextField pvcLinkTextField;
  private javax.swing.JPanel jPanel7;
  private javax.swing.JLabel jLabel6;
  private javax.swing.JTextField tcpHostTextField;
  private javax.swing.JLabel jLabel7;
  private javax.swing.JTextField tcpPortTextField;
  private javax.swing.JPanel jPanel8;
  private javax.swing.JPanel jPanel10;
  private javax.swing.JPanel jPanel11;
  private javax.swing.JScrollPane jScrollPane1;
  private javax.swing.JPanel jPanel12;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton3;
  private javax.swing.JPanel jPanel13;
  private javax.swing.JLabel jLabel8;
  private javax.swing.JTextField rbpTextField;
  // End of variables declaration//GEN-END:variables

}

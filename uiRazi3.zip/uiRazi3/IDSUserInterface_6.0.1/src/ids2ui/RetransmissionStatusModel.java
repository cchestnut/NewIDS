/*
**  SCCS Info :  "@(#)RetransmissionStatusModel.java	1.9    07/12/14"
*/
/*
 * RetransmissionStatusModel.java
 *
 * Created on November 24, 2000, 2:37 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */



  
public class RetransmissionStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements Utils.UpdateEventModel 
{
    
    
 

    protected int     m_sortCol = 0;
    protected boolean m_sortAsc = true;
    protected java.util.Vector m_vector = null;

    protected int m_columnsCount = Constants.RetransmissionStatusTableColumnNames.length;

    
    String DCMTag = null;
    StringBuffer HostKey1 = null;
    StringBuffer HostKey2 = null;
    String ProgramName = "rtp";
    String ProgramID = "rtp";
  

    /** Creates new RetransmissionStatusModel */
    RetransmissionStatusModel( String dcmTag, 
			      String hostlist1, String hostlist2) 
	throws Exception 
    {
 
	m_vector = new java.util.Vector(50);

	DCMTag = new String(dcmTag);
    
	HostKey1 = new StringBuffer();
	String sep = new String(" ,\t");
	java.util.StringTokenizer st =
	    new java.util.StringTokenizer(hostlist1,sep);
      
	while (st.hasMoreTokens()) {
	    String hostName = st.nextToken();
	    HostKey1.append(hostName).append(" ");
	}

	HostKey2 = new StringBuffer();
	st = new java.util.StringTokenizer(hostlist2,sep);
      
	while (st.hasMoreTokens()) {
	    String hostName = st.nextToken();
	    HostKey2.append(hostName).append(" ");
	}

    

	RetransmissionStatusEvent evt = (RetransmissionStatusEvent)Update();
	int err = evt.getStatus();
	if (err!=0) {
	    throw new Exception(evt.getError()); 
	}
    
    }
      


    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("ReaderStatusModel:Error in update",
					e);
	}
    }
  
    synchronized public String getName() {
	return DCMTag;
    }
  
    public void stop(TaskListener l) {
    }
  
   
    
    synchronized public int getRowCount() {
	return m_vector==null ? 0 : m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int column) {
      	String str = Constants.RetransmissionStatusTableColumnNames[column];
	if (column==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 
    public boolean isCellEditable(int nRow, int nCol) {
	return false;
    }

    synchronized public Object getValueAt(int nRow, int nCol) {
	if (nRow < 0 || nRow>=getRowCount())
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }





    public java.util.EventObject
	Update() 
    {

    
	String statusBuf1, statusBuf2;
	boolean exc1=false, exc2=false;
	String timeStamp = null;
	StringBuffer timeStamp1 = null;
	StringBuffer timeStamp2 = null;
	statusBuf1 = statusBuf2 = null;


	java.util.Vector u_vector = new java.util.Vector(50);

	/* Get Status */


	int nr1,nr2;

	try {
	    statusBuf1 = StatusRequest.getInstance().statusQuery(
					HostKey1.toString().trim(),
					ProgramName, ProgramID);

	    timeStamp1 = new StringBuffer();
	    nr1 = parseRTPStatus(u_vector,statusBuf1,timeStamp1);

	} catch (Exception e) {
	    exc1=true;
	}

	try {
	    statusBuf2 = StatusRequest.getInstance().statusQuery(
					HostKey2.toString().trim(),
					ProgramName, ProgramID);

	    timeStamp2 = new StringBuffer();
	    nr2 = parseRTPStatus(u_vector,statusBuf2,timeStamp2);
	} catch (Exception e) {
	    exc2= true;
	}



	if (exc1&&exc2) {
	    Log.getInstance().log_error("RetransmissionStatusModel:Error "
					+"retrieving"
					+" status: Host: "
					+HostKey1.toString() + " "
					+HostKey2.toString()
					+" Program: "+ProgramName+" ProgID: "
					+ProgramID,null);
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();


	    return new RetransmissionStatusEvent(this,-1,"Error in retrieving status.");
	}

         
      
     

	if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("Status: "+statusBuf1);
      

      
	if (exc1)
	    timeStamp = new String(timeStamp2.toString());
	else
	    timeStamp = new String(timeStamp1.toString());


	Log.getInstance().debug_println("Retrans: timestamp "+timeStamp);


	if (timeStamp==null) {
	    synchronized (this) {
		m_vector.removeAllElements();
	    }
	    fireTableDataChanged();
	    return new RetransmissionStatusEvent(this,-1,"Empty Status Record");
	}

	java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));


	synchronized (this) {
	    if (m_vector!=null) m_vector.clear();
	    m_vector = null;
	    m_vector = u_vector;
	}
	fireTableDataChanged();
	return new RetransmissionStatusEvent(this,DCMTag,timeStamp);
    }




    private int parseRTPStatus(java.util.Vector u_vector,
			       String statusBuf, 
			       StringBuffer timeStamp) 
    {

	String separator = new String(",\0\n");
	String type=null,format=null;
	String host=null,lhost=null, phost=null,hostName=null;
	String prognm,progid;
	String tmStamp = null;


	java.util.StringTokenizer tokenizer 
	    = new java.util.StringTokenizer(statusBuf,separator);
      
	if (tokenizer.hasMoreTokens()) {
	    String t = tokenizer.nextToken();
	    int i = t.indexOf('\t');
	    if (i>0)
		tmStamp = t.substring(0,i);
	    else
		tmStamp = t;
	}
      
	if (tokenizer.hasMoreTokens())
	    type = tokenizer.nextToken();
      
	if (tokenizer.hasMoreTokens())
	    hostName = tokenizer.nextToken();
      
	if (tokenizer.hasMoreTokens())
	    prognm = tokenizer.nextToken();
      
	if (tokenizer.hasMoreTokens())
	    progid = tokenizer.nextToken();
      
 
	if (type.equalsIgnoreCase("error")) {
	    String errorstr=null;
	    if (tokenizer.hasMoreTokens()) {
		errorstr = tokenizer.nextToken();
		Log.getInstance().log_warning("Error in retrieving status: "
					      +ProgramName+","+ProgramID
					      +" :"+errorstr,null);
	    }
	    return 0;	
	}
      
      
      
	java.util.StringTokenizer fldTokenizer = null;

	while (tokenizer.hasMoreTokens()) {

	    String pstatus = tokenizer.nextToken();
	    fldTokenizer = new java.util.StringTokenizer(pstatus,"|");
	  
	    String [] rowData = 
		new String[m_columnsCount];


	    rowData[0] = hostName;
	    if (fldTokenizer.hasMoreTokens())
		rowData[1] = fldTokenizer.nextToken();// did
	    if (fldTokenizer.hasMoreTokens())
		rowData[2] = fldTokenizer.nextToken();//product
	    if (fldTokenizer.hasMoreTokens())
		rowData[3] = fldTokenizer.nextToken();//date
	    if (fldTokenizer.hasMoreTokens())
		rowData[4] = fldTokenizer.nextToken(); //queued
	    if (fldTokenizer.hasMoreTokens())
		rowData[5] = fldTokenizer.nextToken(); //start

	    if (fldTokenizer.hasMoreTokens())
		rowData[6] = fldTokenizer.nextToken(); //end

	    u_vector.add(rowData);

	}      

	timeStamp.append(tmStamp);


	return 0;
    }






    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;

	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock lk) {
	    m_table = table;
	    rwLock = lk;
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;
	    
	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }



	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;

	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }
	    m_table.getTableHeader().repaint();  

	    synchronized (RetransmissionStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, 
							    m_sortAsc));
	    }

	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(RetransmissionStatusModel.this)); 
	    m_table.repaint();
	    
	    rwLock.writeLock().release();

  
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;
	    double d1, d2;
	    switch (m_sortCol) {
	    case 3:    // date
	    case 4:    // queued
	    case 5:    // start
	    case 6:    // end
		try {
		    d1 = Double.parseDouble(s1);
		    d2 = Double.parseDouble(s2);
		    result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
		} catch (NumberFormatException nfe){}
		break;
	    case 0:    // host
	    case 1:    // distr
	    case 2:    // product
	    default:
		result = s1.compareTo(s2);
		break;
	    }

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}


    }
}

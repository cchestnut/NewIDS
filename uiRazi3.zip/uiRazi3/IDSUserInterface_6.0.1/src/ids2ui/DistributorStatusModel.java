/*
 **  SCCS Info :  "%W%    %E%"
 */
/*
 * DistributorStatusModel.java
 *
 * Created on October 16, 2000, 3:37 PM
 */
package ids2ui;

import model.DistributorProductFlagOptions;

/**
 *
 * @author srz
 * @version
 */
public class DistributorStatusModel
        extends javax.swing.table.AbstractTableModel
        implements Utils.UpdateEventModel {

    protected int m_sortCol = 0;
    protected boolean m_sortAsc = true;
    protected java.util.Vector m_vector = null;
    protected int m_columnsCount = 0;
    String ConfigKey = null;
    String NameKey = null;
    String HostKey = null;
    String PHostKey = null;
    String ProgramName = null;
    int Type = -1;
    int DC = -1;

    /**
     * Creates new DistributorStatusModel
     */
    public DistributorStatusModel(int type, int which, String name,
            DistributorStatusEvent evt)
            throws Exception {

        m_vector = new java.util.Vector(50);

        if (name != null) {
            NameKey = new String(name);
        }

        m_columnsCount = Constants.DistributorStatusColumnNames.length;

        if (type == Constants.DSP_BROADCASTER) {
            ProgramName = "dsp_linehand";
            //m_columnsCount--; // DSP line handler does not have filter codes
        } else if (type == Constants.DCM_LINEHANDLER) {
            ProgramName = "dcm_linehand";
        }


        Type = type;
        ConfigKey = Constants.GLB_TAG_DISTR_PREFIX + name;

        DC = which;


        if (which == 1) {
            HostKey = "HOST1";
            PHostKey = "PHOST1";
        } else if (which == 2) {
            HostKey = "HOST2";
            PHostKey = "PHOST2";
        }

        DistributorStatusEvent e = (DistributorStatusEvent) Update();
        if (evt != null) {
            evt.copy(e);
        } else {
            int err = e.getStatus();
            if (err == Constants.KEY_NOT_FOUND) {
                throw new DBException(e.getError(), Constants.KEY_NOT_FOUND);
            } else if (err == -1) {
                throw new Exception(e.getError());
            }
        }



    }

    DistributorStatusModel(int type, int which,
            String name)
            throws Exception {
        this(type, which, name, null);
    }

    public void Refresh() {
        try {
            Update();
        } catch (Exception e) {
            Log.getInstance().log_error("ReaderStatusModel:Error in update",
                    e);
        }
    }

    synchronized public String getName() {
        return NameKey;
    }

    public void stop(TaskListener l) {
    }

    public synchronized int getRowCount() {
        return m_vector == null ? 0 : m_vector.size();
    }

    public int getColumnCount() {
        return m_columnsCount;
    }

    public String getColumnName(int column) {
        String str = Constants.DistributorStatusColumnNames[column];
        if (column == m_sortCol) {
            str += m_sortAsc ? " \273" : " \253";
        }
        return str;
    }

    public boolean isCellEditable(int nRow, int nCol) {
        return false;
    }

    synchronized public Object getValueAt(int nRow, int nCol) {
        if (nRow < 0 || nRow >= getRowCount()) {
            return "";
        }

        return ((String[]) m_vector.get(nRow))[nCol];
    }

    public java.util.EventObject Update() {

        java.util.HashMap map = null;
        String host = null, lhost = null, phost = null, hostName = null;
        String mode = null, timeStamp = null;
        String ckpt = null, ka = null;
        String prot = null, stats = null;
        StringBuffer statusHostKey = new StringBuffer();


        java.util.Vector u_vector = new java.util.Vector(50);

        /*
         * Get Configuration
         */
        try {
            map = ConfigComm.getHashMap(ConfigKey);
            String dcmtag = (String) map.get("TAG");
            map = ConfigComm.getHashMap(dcmtag);

            String primary_location = (String) map.get("HOME_LOCATION");
            if (primary_location != null) {
                if (primary_location.equals("1")) {
                    if (DC == 1) {
                        HostKey = "HOST1";
                        PHostKey = "PHOST1";
                    } else {
                        HostKey = "HOST2";
                        PHostKey = "PHOST2";
                    }
                } else {
                    if (DC == 1) {
                        HostKey = "HOST2";
                        PHostKey = "PHOST2";
                    } else {
                        HostKey = "HOST1";
                        PHostKey = "PHOS12";
                    }
                }
            } else {
                lhost = (String) map.get(HostKey);
                phost = (String) map.get(PHostKey);
            }

            if (phost != null) {
                host = phost;
            } else {
                host = lhost;
            }
            String sep = new String(" ,\t");
            java.util.StringTokenizer st =
                    new java.util.StringTokenizer(host, sep);

            while (st.hasMoreTokens()) {
                hostName = st.nextToken();
                statusHostKey.append(hostName).append(" ");
            }


            if (statusHostKey.length() == 0) {
                synchronized (this) {
                    m_vector.removeAllElements();
                }
                fireTableDataChanged();
                return new DistributorStatusEvent(this, -1,
                        "Error in parsing hosts");
            }


        } catch (DBException dbe) {

            Log.getInstance().log_error("DistributorStatusModel:Error "
                    + "retrieving configuration: ", dbe);

            synchronized (this) {
                m_vector.removeAllElements();
            }
            fireTableDataChanged();

            if (dbe.getErrorNo() == Constants.KEY_NOT_FOUND) {
                return new DistributorStatusEvent(this, Constants.KEY_NOT_FOUND, NameKey
                        + " is not configured.");
            }

            return new DistributorStatusEvent(this, -1, "Error in retrieving "
                    + "configuration");


        } catch (Exception e) {

            Log.getInstance().log_error("DistributorStatusModel:Error "
                    + "retrieving configuration: ", e);
            synchronized (this) {
                m_vector.removeAllElements();
            }
            fireTableDataChanged();
            return new DistributorStatusEvent(this, -1, "Error in retrieving "
                    + "configuration");

        }


        /*
         * Get Status
         */
        String statusBuf = null;

        try {
            statusBuf = StatusRequest.getInstance().statusQuery(statusHostKey.toString().trim(),
                    ProgramName, NameKey);

            if (Constants.DEBUG && Constants.Verbose > 2) {
                System.out.println("Status: " + statusBuf);
            }
        } catch (Exception e) {
            Log.getInstance().log_error("DistributorStatusModel:Update:"
                    + "Error retrieving status: Host: "
                    + host + " Program: " + ProgramName
                    + " ProgID: " + NameKey, e);

            synchronized (this) {
                m_vector.removeAllElements();
            }
            fireTableDataChanged();

            return new DistributorStatusEvent(this, -1, "Error in retrieving "
                    + "status.");
        }



        String separator = new String(",\0\n");
        String type = null, format = null;
        String prognm = null, progid = null;

        java.util.StringTokenizer tokenizer = new java.util.StringTokenizer(statusBuf, separator);

        if (tokenizer.hasMoreTokens()) {
            String t = tokenizer.nextToken();
            int i = t.indexOf('\t');
            if (i > 0) {
                timeStamp = t.substring(0, i);
            } else {
                timeStamp = t;
            }
        }


        if (tokenizer.hasMoreTokens()) {
            type = tokenizer.nextToken();
        }

        if (tokenizer.hasMoreTokens()) {
            hostName = tokenizer.nextToken();
        }

        if (tokenizer.hasMoreTokens()) {
            prognm = tokenizer.nextToken();
        }

        if (tokenizer.hasMoreTokens()) {
            progid = tokenizer.nextToken();
        }


        if (type.equalsIgnoreCase("error")) {
            String errorstr = null;
            if (tokenizer.hasMoreTokens()) {
                errorstr = tokenizer.nextToken();
                if (Constants.DEBUG && Constants.Verbose > 3) {
                    Log.getInstance().log_warning("Error in retrieving status: "
                            + hostName + "," + prognm + ","
                            + progid + " :" + errorstr, null);
                }
            }

            synchronized (this) {
                m_vector.removeAllElements();
            }
            fireTableDataChanged();
            //return new DistributorStatusEvent(this,-2,errorstr);
            return new DistributorStatusEvent(this, progid, hostName,
                    -2, errorstr);
        }


        if (tokenizer.hasMoreTokens()) {
            mode = tokenizer.nextToken();
        }


        /*
         ** The DSP line handler did not originally report the checkpoint
         * status * but now it does.
         */
        if (Constants.checkpointStatusFromDSP
                || (!Constants.checkpointStatusFromDSP
                && (Type == Constants.DCM_LINEHANDLER))) {

            if (tokenizer.hasMoreTokens()) {
                ckpt = tokenizer.nextToken();
            }
        }

        if (tokenizer.hasMoreTokens()) {
            prot = tokenizer.nextToken();
        }

        if (tokenizer.hasMoreTokens()) {
            ka = tokenizer.nextToken();
        }

        if (tokenizer.hasMoreTokens()) {
            stats = tokenizer.nextToken();
        }


        StringBuilder sb = new StringBuilder();
        sb.append("|" /*ConfigComm.CONF_FS*/);
        while (tokenizer.hasMoreTokens()) {
            String pstatus = tokenizer.nextToken();

            java.util.StringTokenizer tokens = new java.util.StringTokenizer(pstatus, sb.toString(), true);

            String[] rowData = new String[m_columnsCount];


            int nc = 0;
            boolean token = false;
            while (tokens.hasMoreTokens()) {
                String tk = tokens.nextToken();

                if (token) {
                    token = false;
                    continue;
                } else {
                    token = true;
                    if (nc == 7) {
                        nc += 2;
                    }
                    if (tk.equals("|")) {
                        rowData[nc] = null;
                    } else {
                        rowData[nc] = tk;
                        if (nc == 6) {
                            try {
                                long i = Long.parseLong(tk);
                                String nc6 = DistributorProductFlagOptions.getFreewheel(i) ? "ON" : "OFF";
                                String nc7 = DistributorProductFlagOptions.getNewsplusOff(i) ? "ON" : "OFF";
                                String nc8 = DistributorProductFlagOptions.getDerivedDataOption(i);
                                String nc81 = "dict";//DistrProductStructure.getDerivedDataDictionary();
                                rowData[6] = nc6;
                                rowData[7] = nc7;
                                rowData[8] = nc8;
                            } catch (NumberFormatException nfe) {
                            }

                        }
                    }
                    nc++;
                }

            }

            u_vector.add(rowData);

        }


        /**
         * *******************************
         */
        if ((timeStamp == null) || (mode == null) || (prot == null) || (ka == null)
                || (stats == null)) {

            synchronized (this) {
                m_vector.removeAllElements();
            }
            fireTableDataChanged();
            //return new DistributorStatusEvent(this,-1,"Empty Status Record");
            return new DistributorStatusEvent(this, progid, hostName,
                    -2, "Empty Status Record");
        }


        java.util.Collections.sort(u_vector, new StatusComparator(m_sortCol, m_sortAsc));

        synchronized (this) {
            if (m_vector != null) {
                m_vector.clear();
            }
            m_vector = null;
            m_vector = u_vector;
        }

        fireTableDataChanged();
        return new DistributorStatusEvent(this, NameKey, hostName, timeStamp, mode, prot, ka, stats, ckpt);
    }

    class ColumnListener extends java.awt.event.MouseAdapter {

        protected javax.swing.JTable m_table;
        private FIFOReadWriteLock rwLock;

        public ColumnListener(javax.swing.JTable table, FIFOReadWriteLock lk) {
            m_table = table;
            rwLock = lk;
        }

        public void mouseClicked(java.awt.event.MouseEvent e) {
            javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
            int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
            int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

            if (modelIndex < 0) {
                return;
            }


            try {
                if (!rwLock.writeLock().attempt(0)) {
                    java.awt.Toolkit.getDefaultToolkit().beep();
                    return;
                }
            } catch (InterruptedException ie) {
                java.awt.Toolkit.getDefaultToolkit().beep();
                return;
            }


            if (m_sortCol == modelIndex) {
                m_sortAsc = !m_sortAsc;
            } else {
                m_sortCol = modelIndex;
            }

            for (int i = 0; i < m_columnsCount; i++) {
                javax.swing.table.TableColumn column = colModel.getColumn(i);
                column.setHeaderValue(getColumnName(column.getModelIndex()));
            }
            m_table.getTableHeader().repaint();

            synchronized (DistributorStatusModel.this) {
                java.util.Collections.sort(m_vector, new StatusComparator(modelIndex, m_sortAsc));
            }

            m_table.tableChanged(
                    new javax.swing.event.TableModelEvent(DistributorStatusModel.this));
            m_table.repaint();

            rwLock.writeLock().release();

        }
    }

    class StatusComparator implements java.util.Comparator {

        protected int m_sortCol;
        protected boolean m_sortAsc;

        public StatusComparator(int sortCol, boolean sortAsc) {
            m_sortCol = sortCol;
            m_sortAsc = sortAsc;
        }

        public int compare(Object o1, Object o2) {
            String[] v1 = (String[]) o1;
            String[] v2 = (String[]) o2;
            String s1 = v1[m_sortCol];
            String s2 = v2[m_sortCol];

            int result = 0;
            double d1, d2;
            switch (m_sortCol) {
                case 2:    // lcn
                case 3:    // sequence
                case 5:    // display time
                    try {
                        d1 = Double.parseDouble(s1);
                        d2 = Double.parseDouble(s2);
                        result = d1 < d2 ? -1 : (d1 > d2 ? 1 : 0);
                    } catch (NumberFormatException nfe) {
                    }
                    break;
                default:
                    result = s1.compareTo(s2);
                    break;
            }

            if (!m_sortAsc) {
                result = -result;
            }
            return result;
        }
    }
}

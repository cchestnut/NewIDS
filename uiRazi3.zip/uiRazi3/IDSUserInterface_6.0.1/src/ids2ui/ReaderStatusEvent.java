/*
**  SCCS Info :  "@(#)ReaderStatusEvent.java	1.3    01/10/03"
*/
/*
 * ReaderStatusEvent.java
 *
 * Created on October 18, 2000, 12:41 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class ReaderStatusEvent extends java.util.EventObject {
  private String name=null;
  private String host=null;
  private String timeStamp=null;
  private String mode=null;
  private int   status;
  private String   error_string;
  
  /** Creates new ReaderStatusEvent */
  public ReaderStatusEvent(Object source) {
    super(source);
  }
  
  public ReaderStatusEvent(Object source, String n,String h, String t, String m) {
    super(source);
    name = new String (n);
    host = new String(h);
    mode = new String(m);
    timeStamp = new String (t);
    status = 0;
  }
  
  public ReaderStatusEvent(Object source, int s, String e) {
    super(source);
    status = s;
    error_string = new String (e);
  }


  public void copy(ReaderStatusEvent e) {
    source = e.getSource();
    name=e.name;
    host=e.host;
    timeStamp=e.timeStamp;
    mode=e.mode;

    status=e.status;
    error_string=e.error_string;
  }


  
  public int getStatus() { return status; }  
  
  public String getError() { return error_string; }
  
  public String getName() { return name; }
  public String getTimeStamp() { return timeStamp; }
  public String getMode() { return mode;}
  public String getHost() { return host; }
  
}

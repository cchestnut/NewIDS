
/*
**  SCCS Info :  "@(#)ActionHandlers.java	1.10    07/09/19"
*/


package ids2ui;

import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import javax.imageio.ImageIO;



public class ActionHandlers 
{
        final static String CMDLINE_DISTR_NORMAL  = " -A  -sNORMAL ";
        final static String CMDLINE_DISTR_HOT     = " -A  -sHOT ";
        final static String CMDLINE_DISTR_COLD    = " -A  -sCOLD ";
        final static String CMDLINE_DISTR_DORMANT = " -D ";
        
        final static String CMDLINE_DISTR_MODE_NORMAL  = ";"+AdminComm.CHANGE_MODE+" 1 NORMAL;";
        final static String CMDLINE_DISTR_MODE_HOT     = ";"+AdminComm.CHANGE_MODE+" 1 HOT;";
        final static String CMDLINE_DISTR_MODE_COLD    = ";"+AdminComm.CHANGE_MODE+" 1 COLD;";
        final static String CMDLINE_DISTR_MODE_DORMANT = ";"+AdminComm.CHANGE_MODE+" 0;";
        
        private static JFrame statusFrame;
        private static JTabbedPane statusTabs;
        private static StatusTabHandler statFrame;
        public static class ActionHandler
                implements ActionListener
        {


                JFrame             frame;
                JTable             table;
                FIFOReadWriteLock  rwLock;
                TaskListener       taskListener;
                Utils.UpdateTimer  updateTimer = null;



                private ActionHandler()
                {}
        

                public ActionHandler(JFrame f, TaskListener tl,
                                     FIFOReadWriteLock lock,
                                     Utils.UpdateTimer timer,
                                     JTable tbl) 
                {
                        frame = f;
                        taskListener = tl;
                        table = tbl;
                        rwLock = lock;
                        updateTimer = timer;
                }
        
                public boolean
                errorCheck() 
                {
                        return true;
                }
        
                        
                public void
                actionPerformed(java.awt.event.ActionEvent evt) 
                {
                        
                        String command = evt.getActionCommand();
                        Object src = evt.getSource();
                        javax.swing.JButton source = null;
                
                        if (!errorCheck())
                                return;
                                        
                
                        if (src instanceof javax.swing.JButton ) {
                                source = (javax.swing.JButton)src;
                                source.setEnabled(false);
                        }
                
                        final Utils.ActionWorker sw
                                = new Utils.ActionWorker(source, command) {
                                public Object construct() {
                                        handler(cmdButton, action);
                                        return null;
                                }
                        };
                
                        sw.start();
                }


        
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {}
        } //ActionHandler


        public static class SelectActionHandler
                extends ActionHandler
        {
                public SelectActionHandler(JFrame f, TaskListener tl,
                                           FIFOReadWriteLock lock,
                                           Utils.UpdateTimer timer,
                                           JTable tbl, String select_msg) 
                {
                        super(f, tl, lock, timer, tbl);
                        if (select_msg != null)
                                select_message = new String(select_msg);
                        else
                                select_message = "Please select a distributor from the table.";
                
                
                }


                public boolean
                errorCheck()
                {
                        selected_rows = table.getSelectedRows();
                
                        if (selected_rows.length==0) {
                                Log.getInstance().show_warning(frame,"Error",
                                                               select_message,
                                                               null);
                                return false;
                        }
                        return super.errorCheck();
                }

                public void handler(javax.swing.JButton cmdButton, String command) 
                {}

                private String select_message;
                int [] selected_rows;
                
        
        } //SelectActionHandler


        public static class ExitHandler
                extends ActionHandler
                implements WindowListener
        {
                boolean isExiting = false;
                
                public ExitHandler(JFrame f, TaskListener tl,
                                     FIFOReadWriteLock lock,
                                     Utils.UpdateTimer timer,
                                     JTable tbl) 
                {
                        super(f, tl, lock, timer, tbl);
                }

                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        exitForm ();
                }

                
                public void windowClosing (java.awt.event.WindowEvent evt) {
                        exitForm ();
                }

                private void exitForm() 
                {
                        if (isExiting) return;

                        isExiting = true;
	
                        if (updateTimer!=null)
                                updateTimer.stop();

                        if (table!=null) {
                                javax.swing.table.AbstractTableModel
                                        model = (javax.swing.table.AbstractTableModel)table.getModel();
                                if (model != null)
                                        model.removeTableModelListener(table);

				if (model instanceof DCMDistributorStatusModel)
					DCMDistributorConfigCache.unsubscribe(model);
                        }
                        
                                
                        final javax.swing.JPanel gpanel = 
                                (javax.swing.JPanel) frame.getGlassPane();
                        
                        gpanel.setLayout(new java.awt.GridBagLayout());
                        
                        
                        final StatusPanel sp = new StatusPanel();
                        sp.setBackground(java.awt.Color.yellow);
                        sp.start("Closing window.\nPlease wait..");
                        
                        gpanel.add(sp);
                        gpanel.validate();
                        gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
                        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
                        gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
                        gpanel.setVisible(true);
                        
                        
                        final SwingWorker exitThread = new SwingWorker() {
                                public Object construct() {
                                        try {
                                                rwLock.writeLock().acquire();
                                                    //model.stop();
                                        } catch (InterruptedException ie ) {}
                                        return null;
                                }
                                
                                public void finished() {
                                        frame.setVisible(false);
                                        sp.stop();
                                        gpanel.removeAll();
                                        gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
                                        gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
                                        frame.dispose();
                                        WindowEventAdapter.getInstance().unregisterWindow(frame);
                                }
                                
                        };
                        
                        exitThread.start();
                        
                }

                public void windowIconified(java.awt.event.WindowEvent evt)
                {}
                
                public void windowClosed(java.awt.event.WindowEvent evt)       
                {}
                
                public void windowActivated(java.awt.event.WindowEvent evt)
                {}
                
                public void windowOpened(java.awt.event.WindowEvent evt)
                {}
                
                public void windowDeactivated(java.awt.event.WindowEvent evt)
                {}
                
                public void windowDeiconified(java.awt.event.WindowEvent evt)
                {}
        }
        

        public static class RetransRequestActionHandler
                extends SelectActionHandler
        {
                public RetransRequestActionHandler(JFrame f, TaskListener tl,
                                                   FIFOReadWriteLock lock,
                                                   Utils.UpdateTimer timer,
                                                   JTable tbl, String select_msg) 
                {
                        super(f, tl, lock, timer, tbl, select_msg);
                }


        

                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        DCMDistributorStatusModel model =
                                (DCMDistributorStatusModel)table.getModel();
                        
                        
                        int row = selected_rows[0];
                        int which = 0;
                        String host1 = model.getHost1(row);
                        String host2 = model.getHost2(row);
                        String phost1 = model.getPHost1(row);
                        String phost2 = model.getPHost2(row);
                        String dcmTag = (String)model.getValueAt(row,1);
                        String distr = (String)model.getValueAt(row,0);
                
                
                
                        String s1 = (String)table.getValueAt(row,3);
                        String s2 = (String)table.getValueAt(row,4);
                
                        if ((s1!=null)&&(s2!=null)
                            &&s1.startsWith("ACTIVE")&&s2.startsWith("ACTIVE"))
                                which = 0;
                        else if ((s1!=null) && s1.startsWith("ACTIVE"))
                                which = 1;
                        else if ((s2!=null) && s2.startsWith("ACTIVE"))
                                which = 2;
                        else {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Cannot do retransmissions.\n"
                                                             +"Line handler not running OR not ACTIVE.", null);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }
                
                        try {
                                DistrRetransRequestDialog dlg 
                                        = new DistrRetransRequestDialog(frame,
                                                                        distr,
                                                                        dcmTag,which,
                                                                        host1,host2);
                                dlg.show();
                        } catch (Exception e) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in displaying retransmission dialog.", e);
                        }
                
                        if (cmdButton!=null) cmdButton.setEnabled(true);
                }
        


        
        } //RetransRequestActionHandler











        public static class RetransStatusActionHandler
                extends SelectActionHandler
        {
                public RetransStatusActionHandler(JFrame f, TaskListener tl,
                                                  FIFOReadWriteLock lock,
                                                  Utils.UpdateTimer timer,
                                                  JTable tbl, String select_msg) 
                {
                        super(f, tl, lock, timer, tbl, select_msg);
                }


        

                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        DCMDistributorStatusModel model =
                                (DCMDistributorStatusModel)table.getModel();
                
                        int row = selected_rows[0];
                        int which = 0;
                        String phost1 = model.getPHost1(row);
                        String phost2 = model.getPHost2(row);
                        String dcmTag = (String)model.getValueAt(row,1);
                        String distr = (String)model.getValueAt(row,0);
                
                        try {
                                DistrRetransStatusForm f = 
                                        new DistrRetransStatusForm(distr,dcmTag,
                                                                   phost1,phost2);
                                f.show();
                        } catch (Utils.DuplicateWindowException dwe) {
                        } catch (Exception e) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in displaying "
                                                             +"retransmission status "
                                                             +"dialog.", e);
                        }
                
                        if (cmdButton!=null) cmdButton.setEnabled(true);
                }
        


        
        } //RetransStatusActionHandler



        public static class X25LinkConfigActionHandler
                extends SelectActionHandler
        {
                public X25LinkConfigActionHandler(JFrame f, TaskListener tl,
                                                  FIFOReadWriteLock lock,
                                                  Utils.UpdateTimer timer,
                                                  JTable tbl, String select_msg) 
                {
                        super(f, tl, lock, timer, tbl, select_msg);
                }




                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                
                        int row = selected_rows[0];
                        String distr = (String)table.getValueAt(row,0);
                        String dcmTag = (String)table.getValueAt(row,1);
                
                        try {
                                java.awt.Window f = null;
                                f = (java.awt.Window)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.X25_LINK_DIALOG_PREFIX+distr);
                                if (f== null)
                                        f = new X25LinkDialog(frame, false,distr,dcmTag,null,null);
                                if (f!=null) f.show();
                        } catch (Utils.DuplicateWindowException dwe) {
                        } catch (Exception e) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in displaying "
                                                             +"X25 Link  "
                                                             +"Menu: \n\t"
                                                             +e.getMessage(), e);
                        }
                        
                        if (cmdButton!=null) cmdButton.setEnabled(true);
                }
        
        } //X25LinkConfigActionHandler





        public static class AddDistributorActionHandler
                extends ActionHandler
        {

                String hostTag = null;
                
                public AddDistributorActionHandler(JFrame f, TaskListener tl,
                                                   FIFOReadWriteLock lock,
                                                   Utils.UpdateTimer timer,
                                                   JTable tbl, String tag) 
                {
                        super(f, tl, lock, timer, tbl);
                        if (tag!=null)
                                hostTag = new String(tag);
                        
                }
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        try {
                                new DistributorConfigurationForm(null, hostTag, false).show();
                                
                        } catch (Exception ex) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in creating distributor window.",
                                                             ex);
                        }
                        if (cmdButton!=null) cmdButton.setEnabled(true);
                        return;  
                }
        } //AddDistributorActionHandler


        

        public static class EditDistributorActionHandler
                extends SelectActionHandler
        {

                boolean copy = false;
                
                public EditDistributorActionHandler(JFrame f, TaskListener tl,
                                                    FIFOReadWriteLock lock,
                                                    Utils.UpdateTimer timer,
                                                    JTable tbl, String msg, boolean c) 
                {
                        super(f, tl, lock, timer, tbl, msg);
                        copy = c;
                }
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        String distrTag = table.getValueAt(selected_rows[0],0).toString();
                        javax.swing.JFrame f = null;
                        if (copy == false) {
                                f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.CONFIGURATION_DISTRIBUTOR_PREFIX+distrTag);
                        }
    
                        
                        if (f == null) {
                                try {
                                        f = new DistributorConfigurationForm(distrTag, null, copy);
                                } catch (Exception e ) {
                                        Log.getInstance().show_error(frame,"Error",
                                                                     "Error in creating distributor window.",e);
                                        
                                }
                        }
                        
                        if (f != null)
                                f.show();
                        
                        if (cmdButton!=null) cmdButton.setEnabled(true);
                        
                        return;   
                }
        } //EditDistributorActionHandler


        
        


        public static class DeleteDistributorActionHandler
                extends SelectActionHandler
        {

                public DeleteDistributorActionHandler(JFrame f, TaskListener tl,
                                                      FIFOReadWriteLock lock,
                                                      Utils.UpdateTimer timer,
                                                      JTable tbl, String msg) 
                {
                        super(f, tl, lock, timer, tbl, msg);
                }
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {


    
                        String distrTag = (String)table.getValueAt(selected_rows[0],0);
                        
                        
                        
                        if (javax.swing.JOptionPane.YES_OPTION !=
                            Log.getInstance().show_confirm(frame,"Confirm delete", 
                                                           "Are you sure you want to "
                                                           +"delete distributor: "+distrTag+" ?.")) {
                                
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }

                        StringBuffer reqbuf = new StringBuffer();
                        int row = selected_rows[0];
                        
                        DCMDistributorStatusModel model = (DCMDistributorStatusModel) table.getModel();
                        String h1 = model.getHost1(row);
                        String h2 = model.getHost2(row);
                        
                        int s1 = Utils.isLineHandlerRunning(h1,distrTag);
                        int s2 = Utils.isLineHandlerRunning(h2,distrTag);
                        
                        
                        
                        if ((s1!=0)||(s2!=0)) {
                                if ((s1==1)||(s2==1)) {
                                        Log.getInstance().show_error(frame,"Error",
                                                                     "Cannot delete configuration while"
                                                                     +" linehandler(s) are running.",
                                                                     null);
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                        return;
                                } else {
                                        if (javax.swing.JOptionPane.YES_OPTION !=
                                            Log.getInstance().show_confirm(frame,"Warning",
                                                                           "Could not verify that line handler(s) "
                                                                           +"are not running.\nAre you sure you "
                                                                           +"want to delete the distributor.?")) {
                                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                                return;
                                        }
                                }
                        }
                        
                        
                        
                        ConfigComm.deleteKeyValue(reqbuf,Constants.GLB_TAG_DISTR_PREFIX+distrTag);
                        
                        try {
                                byte[] b;
                                b = ConfigComm.configRequest(reqbuf);
                                
                                Utils.DeleteDistrCacheThread t1 =
                                        new Utils.DeleteDistrCacheThread(h1,distrTag);
                                
                                Utils.DeleteDistrCacheThread t2 =
                                        new Utils.DeleteDistrCacheThread(h2,distrTag);
                                
                                t1.start();
                                t2.start();
                                
                                Utils.AdminStatus status1 = (Utils.AdminStatus)t1.get();
                                Utils.AdminStatus status2 = (Utils.AdminStatus)t2.get();
                                
                                if ( (status1.status != 0) || (status2.status != 0) ) 
                                {
                                        StringBuffer estr = new StringBuffer();
                                        if (status1.response.length()>0)
                                                estr.append(status1.response)
                                                        .append("\n");
                                        if (status2.response.length()>0)
                                                estr.append(status2.response)
                                                        .append("\n");
                                        
                                        if (estr.length()>0)
                                                Log.getInstance().show_error(frame,"Warning",
                                                                             "Distributor cache could not be deleted:\n "
                                                                             +estr.toString(),
                                                                             null);
                                        
                                }
                                
                                ConfigComm.deleteFromFavorites(distrTag);
                                javax.swing.JFrame f =
                                        (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.CONFIGURATION_DISTRIBUTOR_PREFIX+distrTag);
                                if (f != null) {
                                        f.setVisible(false);
                                        f.dispose();
                                        WindowEventAdapter.getInstance().unregisterWindow(f);
                                }
                                
                                java.util.Vector v = WindowEventAdapter.getInstance()
                                        .findWindows(Constants.STATUS_DISTRIBUTOR_PREFIX
                                                     +distrTag);
                                
                                for (int i = 0; i < v.size(); i++) {
                                        DistributorStatusForm rform = (DistributorStatusForm)v.get(i);
                                        rform.exitForm(null);
                                }
                                v = WindowEventAdapter.getInstance()
                                        .findWindows(Constants.STATUS_DISTR_RETRANSMISSION_PREFIX
                                                     +distrTag);
                                
                                for (int i = 0; i < v.size(); i++) {
                                        RetransmissionStatusForm rform 
                                                = (RetransmissionStatusForm)v.get(i);
                                        rform.exitForm(null);
                                }
                                
                        } catch (Exception e) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in deleting distributor: "
                                                             +distrTag+" configuration: ",e);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }
                        
                        
                        String dcmTag = (String)table.getValueAt(selected_rows[0],1);
                        DCMServicesForm servicesForm 
                                = (DCMServicesForm)WindowEventAdapter.getInstance()
                                .findWindow(Constants.SERVICES_DCM+"_"+dcmTag);
                        if (servicesForm != null)
                                servicesForm.Refresh();
                        
                        model.removeRow(selected_rows[0]);
                        
                } 
        } // DeleteDistributorActionHandler




        public static class SelectAllActionHandler
                implements ActionListener
        {
                JTable             table;
                private SelectAllActionHandler() {}
        
                public SelectAllActionHandler( JTable tbl) 
                {
                        table = tbl;
                }
                        
                public void
                actionPerformed(java.awt.event.ActionEvent evt) 
                {
                        table.selectAll();
                }
        } //SelectAllActionHandler

        public static class ShowFrameActionHandler
                implements ActionListener
        {

                String key = null;
                
                public ShowFrameActionHandler()
                {
                        key = null;
                }
                
                public ShowFrameActionHandler(String k)
                {
                        key = new String(k);
                }
                
                public void
                actionPerformed(java.awt.event.ActionEvent evt) 
                {
                        String action = evt.getActionCommand();
                        if (key == null)
                                key = action;
                        
                        JFrame f = 
                                (JFrame)WindowEventAdapter.getInstance().findWindow(key);
                        
                        if (f == null) {    
                                try {
                                        Class c = Constants.getActionClass(key);
                                        if (c != null) 
                                                f =  (JFrame)c.newInstance();
                                } catch (Exception e) {
                                        Log.getInstance().log_error("Error in "
                                                                    +"creating window:"
                                                                    +key,
                                                                    e);
                                }
                        }
                        
                        if (f != null) {
                                f.show();
                        }
                }
        }


        public static class ShowRunningActionHandler
                extends ActionHandler
        {

                public ShowRunningActionHandler(JFrame f, TaskListener tl,
                                                FIFOReadWriteLock lock,
                                                Utils.UpdateTimer timer,
                                                JTable tbl) 
                {
                        super(f, tl, lock, timer, tbl);
                }

                
                public void
                actionPerformed(java.awt.event.ActionEvent evt) 
                {
                        Object src = evt.getSource();
                        if (!(src instanceof JCheckBox))
                                return;
                        final JCheckBox checkBox = (JCheckBox)src;
                        
                        SwingWorker t = new SwingWorker() {
                                public Object construct() {
                                        try {
                                                rwLock.writeLock().acquire();
                                                if (updateTimer!=null)
                                                        updateTimer.stop();
                                                DCMDistributorStatusModel model
                                                        = (DCMDistributorStatusModel)table.getModel();
                                                taskListener.taskStarted("Please wait.");
                                                model.showRunningOnly(checkBox.isSelected());
                                                model.Refresh();
                                        } catch (InterruptedException ie ) {
                                                ie.printStackTrace();
                                        }
                                        return null;
                                }
                                
                                public void finished() {
                                        taskListener.taskEnded("");
                                        rwLock.writeLock().release();
                                        if (updateTimer!=null)
                                                updateTimer.start();
                                }
                        };
                        t.start();
                }
        }
        


        public static class IDFieldListener
                implements javax.swing.event.DocumentListener 
        {
                JTable distrTable;
                JTextField textField;
                javax.swing.event.ListSelectionListener listener;
                
                private IDFieldListener()  {  }

                public IDFieldListener(javax.swing.event.ListSelectionListener l,
                                       JTable tbl, JTextField tf)
                {
                        distrTable = tbl;
                        textField = tf;
                        listener = l;
                        
                }
                

                
                public void changedUpdate(javax.swing.event.DocumentEvent evt) {
                        processEvent();
                }
                public void insertUpdate(javax.swing.event.DocumentEvent evt) {
                        processEvent();
                }
                public void removeUpdate(javax.swing.event.DocumentEvent evt) {
                        processEvent();
                }
                
                private  void processEvent(){        
                        String id1 = textField.getText();
                        int l1 = id1.length();

                        distrTable.getSelectionModel().removeListSelectionListener(listener);


                        for (int i = 0; i < distrTable.getRowCount(); i++) {
                                String id2
                                        = distrTable.getValueAt(i,0).toString();
                                int l2 = id2.length();	  
                                if (l1<=l2 && l1>0  && (id2.substring(0,l1).equals(id1)))             
                                        distrTable.addRowSelectionInterval(i,i);
                                else
                                        distrTable.removeRowSelectionInterval(i,i);
                        }
                        if (!distrTable.getSelectionModel().isSelectionEmpty()) {
                                int row = distrTable.getSelectionModel().getMinSelectionIndex();
                                java.awt.Rectangle rowRect = distrTable.getCellRect(row, 0, true);
                                if (rowRect!=null) {
                                        rowRect.setSize( Integer.MAX_VALUE, (int)rowRect.getHeight());
                                        distrTable.scrollRectToVisible(rowRect);
                                }
                        }

                        distrTable.getSelectionModel().addListSelectionListener(listener) ;

                }
        }


            /*
**********************************************************************
*/





        public static class DistributorActionHandler
                implements ActionListener
        {
                

                JComboBox          locationComboBox;
                JFrame             frame;
                JTable             distrTable;
                FIFOReadWriteLock  rwLock;
                TaskListener       taskListener;
        
                String             select_err_mesg;
                Utils.UpdateTimer updateTimer = null;
                JRadioButton      dormantRB;
                JRadioButton      normalRB;
                JRadioButton      hotRB;
                JRadioButton      coldRB;


                private DistributorActionHandler()
                {}
        

                public DistributorActionHandler(JFrame f, TaskListener tl,
                                                FIFOReadWriteLock lock,
                                                Utils.UpdateTimer timer,
                                                JTable tbl, JComboBox comboBox,
                                                JRadioButton normal, JRadioButton hot,
                                                JRadioButton cold, JRadioButton dormant) 
                {
                        frame = f;
                        taskListener = tl;
                        distrTable = tbl;
                        rwLock = lock;
                        updateTimer = timer;
                        locationComboBox = comboBox;
                        dormantRB = dormant;
                        normalRB = normal;
                        hotRB = hot;
                        coldRB = cold;
                
                }
        
                
                public void actionPerformed(java.awt.event.ActionEvent evt) 
                {

                
                        String command = evt.getActionCommand();
                        Object src = evt.getSource();
                        javax.swing.JButton source = null;
                
                        int srows[] = distrTable.getSelectedRows();
                
                        if (srows.length==0) {
                                Log.getInstance().show_warning(frame,"Error",
                                                               "Please select distributors from the table.",
                                                               null);
                                return;
                        }
                
                        if (src instanceof javax.swing.JButton ) {
                                source = (javax.swing.JButton)src;
                                source.setEnabled(false);
                        }
                
                        final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
                                public Object construct() {
                                        handler(cmdButton, action);
                                        return null;
                                }
                        };
                
                        sw.start();
                }
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {}
                
        


        } // DistributorActionHandler





        public static class ProcessActionHandler
                extends DistributorActionHandler
        {

                int admin_action = -1;
                JRadioButton noneRB;
        
                public ProcessActionHandler(JFrame f, TaskListener tl,
                                            FIFOReadWriteLock lock,
                                            Utils.UpdateTimer timer,
                                            JTable tbl, JComboBox comboBox,
                                            JRadioButton normal, JRadioButton hot,
                                            JRadioButton cold, JRadioButton dormant,
                                            JRadioButton none, int action) 
                {
                        super(f,tl,lock,timer,tbl,comboBox,normal,hot,cold,dormant);
                        noneRB = none;
                        admin_action = action;
                }
        

                public void handler(javax.swing.JButton cmdButton, String command) 
                {


                        String location = (String)locationComboBox.getSelectedItem();
                        if (location.equals(Constants.PICK_LOCATION)) {
                        
                                Log.getInstance().show_error(frame,
                                                             "Pick a location",
                                                             "Please pick a location from the list.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	
                
                        int [] selectedRows = distrTable.getSelectedRows();
                        if (selectedRows.length==0) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select distributors.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }


                        
                        
                        if (!command.startsWith("START")
                            && !command.startsWith("STOP")
                            && !command.startsWith("MODE")) {
                                Log.getInstance().log_error("Unrecognized command: "
                                                            +command, null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

                        
                        if ( (command.startsWith("START")
                             || command.startsWith("MODE"))
                             && noneRB.isSelected() )
                        {
                                        
                                Log.getInstance().show_error(frame,
                                                             "Error",
                                                       "Please specify mode.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                
                                return;
                        }

	

                       
                           
                        

                
                        String modestr = "ACTIVE";
                        if (dormantRB.isSelected()) 
                                modestr = "DORMANT";
                        boolean needConfirm = false;
                        int option = -1;
                        
                        String lhopt = CMDLINE_DISTR_DORMANT;
                        String ftpopt = " -sHOT ";
                        if (!dormantRB.isSelected()) {
                                if (normalRB.isSelected()) {
                                        lhopt  = CMDLINE_DISTR_NORMAL;
                                        ftpopt = " -sNORMAL ";
                                        modestr = "ACTIVE:NORMAL";
                                }
                                if (hotRB.isSelected()) {
                                        lhopt  = CMDLINE_DISTR_HOT;
                                        ftpopt = " -sHOT ";
                                        needConfirm = true;
                                        modestr = "ACTIVE:HOT";
                                }
                                if (coldRB.isSelected()) {
                                        lhopt  = CMDLINE_DISTR_COLD;
                                        ftpopt = " -sCOLD ";
                                        needConfirm = true;
                                        modestr = "ACTIVE:COLD";
                                }
                        }

                       
                        
                        String msg=null, prompt = null;
                        if (command.startsWith("START")) {
                                msg = "Starting selected line handlers..";
                                prompt = "Are you sure you want to start the selected line handlers in "+modestr+" mode?";
                        } else if (command.startsWith("STOP")) {
                                msg = "Stopping selected line handlers..";
                                prompt = "Are you sure you want to stop the selected line handlers?";
                        } else if (command.startsWith("MODE")) {
                                msg = "Changing mode of line handlers ..";
                                prompt = "Are you sure you want to make the selected line handlers "+modestr+" ?";
                        }
                        
                        
                        if (command.startsWith("START"))
                                option = AdminComm.START_IDS2_PROC;
                        else if (command.startsWith("STOP"))
                        {
                                
                                option = AdminComm.STOP_IDS2_PROC;
                                needConfirm = false;
                        }
                        else if (command.startsWith("MODE")) {
                                option = AdminComm.CHANGE_MODE;
                                if (dormantRB.isSelected()) {
                                        lhopt = CMDLINE_DISTR_MODE_DORMANT;
                                } else if (hotRB.isSelected())
                                        lhopt = CMDLINE_DISTR_MODE_HOT;
                                else if (coldRB.isSelected())
                                        lhopt = CMDLINE_DISTR_MODE_COLD;
                                else
                                        lhopt = CMDLINE_DISTR_MODE_NORMAL;
                        } 
                        noneRB.setSelected(true);
                        
                
                
                        int rv = -1;
                        if (needConfirm)
                        {
                                rv = ConfirmDialog.show_confirm(frame,
                                                       "Confirmation dialog",
                                                       prompt);
                        }
                        else
                        {
                                rv = Log.getInstance().show_confirm(frame,
                                                            "Confirmation dialog",
                                                            prompt);
                        }
                
                
                
                        if (javax.swing.JOptionPane.YES_OPTION
                            != rv) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }
                
                
                
                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().log_error("Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }
                
                
                
                        updateTimer.stop();
                
                
                        taskListener.taskStarted(msg);
                
                        
                        
                        String idsdir1 = Constants.idsdir;
                        if (idsdir1==null)
                                idsdir1="/ids2";
                        idsdir1.trim();
                
                
                        
      

                        DCMDistributorStatusModel model = 
                                (DCMDistributorStatusModel) distrTable.getModel();

                        java.util.HashMap dcmHostMap = new java.util.HashMap(20);
                        java.util.HashMap dcmMap = new java.util.HashMap(20);
                        java.util.HashMap fixedDIDs = new java.util.HashMap(20);
                        
                
                        for (int i = 0; i < selectedRows.length; i++) {
                                int row = selectedRows[i];
                                String did = (String)model.getValueAt(row,0);
                                String dcm = (String)model.getValueAt(row,1);
                        
                                //System.out.println("Processing row "+row+" did "+did);
                        
                                try {
                                        HashMap hostmap = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                                        HashMap m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                                        String host1 = (String)hostmap.get("HOST1");
                                        String host2 = (String)hostmap.get("HOST2");
                                        String location1 = (String)hostmap.get("LOCATION1");
                                        String location2 = (String)hostmap.get("LOCATION2");
                                        String primary_location = (String)m.get("HOME_LOCATION");

                                            //System.out.println("Got location data for "+did);

                                        String did_location = null;
                                        
                                        String host = null;
                                
                                        if (primary_location == null ) {
                                                if (location.equals(Constants.HOME_LOCATION))
                                                        host = host1;
                                                if (location.equals(Constants.AWAY_LOCATION))
                                                        host = host2;
                                                if ((location1 != null) && location.equals(location1))
                                                        host = host1;
                                                if ((location2 != null) && location.equals(location2))
                                                        host = host2;

                                        } else {
                                                if (location.equals(Constants.HOME_LOCATION)) {
                                                        
                                                        did_location = Constants.HOME_LOCATION;
                                                        if (primary_location.equals("1")) 
                                                                host = host1;
                                                        else 
                                                                host = host2;
                                                        
                                                }
                                                else if (location.equals(Constants.AWAY_LOCATION)) {
                                                        
                                                        did_location = Constants.AWAY_LOCATION;
                                                        if (primary_location.equals("1"))
                                                                host = host2;
                                                        else
                                                                host = host1;
                                                }
                                                else if ((location1 != null) && location.equals(location1)) {
                                                        
                                                        host = host1;
                                                        if (primary_location.equals("1"))
                                                                did_location = Constants.HOME_LOCATION;
                                                        else
                                                                did_location = Constants.AWAY_LOCATION;
                                                }
                                                else if ((location2 != null) && location.equals(location2)) {
                                                        
                                                        host = host2;
                                                        if (primary_location.equals("2"))
                                                                did_location = Constants.HOME_LOCATION;
                                                        else
                                                                did_location = Constants.AWAY_LOCATION;
                                                }
                                        }

                                        if (host == null) {
                                                Log.getInstance().log_error("Can't find target("
                                                                            +location+") host for distributor: "+did,
                                                                            null);
                                                continue;
                                        }
                                
                                
                                        java.util.Vector distrList = (java.util.Vector)dcmHostMap.get(host);
                                        if (distrList == null) 
                                                distrList = new java.util.Vector(50);
                                
                                        distrList.add(did);

                                        String activeLoc = (String)ConfigComm.fixedLocationsMap.get(did);
                                        if ((did_location != null) && (activeLoc != null)) {
                                                String cmdline = null;
                                                
                                                if (did_location.equalsIgnoreCase(activeLoc)) {
                                                        if (option == AdminComm.CHANGE_MODE)
                                                                cmdline = CMDLINE_DISTR_MODE_NORMAL;
                                                        else
                                                                cmdline = CMDLINE_DISTR_NORMAL;
                                                }
                                                else {
                                                        if (option == AdminComm.CHANGE_MODE)
                                                                cmdline = CMDLINE_DISTR_MODE_DORMANT;
                                                        else
                                                                cmdline = CMDLINE_DISTR_DORMANT;
                                                }
                                                fixedDIDs.put(did, new String(cmdline));
                                        }
                                        
                                            //System.out.println("Adding1 "+did);
                                
                                        dcmHostMap.put(host,distrList);

                                            //System.out.println("Adding2 "+did);
                                
                                        dcmMap.put(host, Constants.GLB_TAG_DCM_PREFIX+dcm);

                                
                                
                                }
                                catch (Exception e){
                                        e.printStackTrace();
                                }
                        }

                            //System.out.println("Created did list.");
                


                     
                


                        java.util.Iterator iter = dcmHostMap.keySet().iterator();
                        java.util.Vector workers = new java.util.Vector(10);
                        boolean error = false;
                
                        while (iter.hasNext()) {
                        
                                String host = (String)iter.next();


                                //System.out.println("Processing host "+host);

                        
                                java.util.Vector distrList = 
                                        (java.util.Vector) dcmHostMap.get(host);
                        
                                String tag = (String)dcmMap.get(host);
                        
                                java.util.HashMap map = null;
                                try {
                                        map = ConfigComm.getHashMap(tag);
                                } catch (Exception e) {
                                        error = true;
                                        Log.getInstance().log_error(
                                                "Error in retrieving DCM configuration:"+tag,
                                                e);
                                        continue ;
                                }
                        
                                String version = (String)map.get("SOFTWARE_VERSION");
                                boolean  djnews_dcm = Utils.isDJNEWS_DCM((String)map.get("TYPE"));
                        
                        
                                if (version == null)  {
                                        error = true;
                                        Log.getInstance().log_error("Configuration error: "
                                                                    + version + ":"+
                                                                    host, null);
                                        continue;
                                }
                        
                                if (version.equals(Constants.DEFAULT_SW_VERSION))
                                        version = Constants.DEFAULT_SW_VERSION_DIR;
                        
                        
                        
                                String idsdir = idsdir1+"/dcm/"+version;
                                String linehand = "dcm_linehand";
                        
                                StringBuffer reqbuf = new StringBuffer();
                        
                                for (int nlh = 0; nlh < distrList.size(); nlh++) {
                                
                                        String did = (String)distrList.get(nlh);

                                            //System.out.println("Processing did "+did);
                                
                                        if (option==AdminComm.CHANGE_MODE) {
                                                reqbuf.append(ConfigComm.CONF_GS);
                                                String cmdline = lhopt;
                                                String s = (String)fixedDIDs.get(did);
                                                if (s != null) 
                                                        cmdline = s;
                                                
                                                reqbuf.append(did+cmdline);
                                                
                                        } else {
                                                
                                                String cmdline = lhopt;
                                                String s = (String)fixedDIDs.get(did);
                                                if (s != null) 
                                                        cmdline = s;

                                                
                                                
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/"+linehand)
                                                        .append(";-d;-d "+did+cmdline+";");
                                        
                                                if (djnews_dcm) {
                                                        reqbuf.append(ConfigComm.CONF_GS)
                                                                .append(idsdir+"/bin/ftp_handler")
                                                                .append(";-d;-d ")
                                                                .append(did)
                                                                .append(ftpopt)
                                                                .append(";");
                                                }
                                        }
                                }
                        
                        
                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, reqbuf.toString());
                        
                        
                                workers.add(worker);
                                worker.start();
                        
                        }
                
                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }


                
                        if (error) {
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);
                        
                                taskListener.taskEnded("Request completed with errors.");
                        } else {
                                taskListener.taskEnded("Request completed successfully.");
                        }
                
                        rwLock.readLock().release();
                
                        if (cmdButton != null ) 
                                cmdButton.setEnabled(true);
                        
                       
                        updateTimer.start();
                        
                        if(super.frame instanceof DCMServicesForm)
                        {                          
                            ((DCMServicesForm) super.frame).updateUIState(0);                                
                        }
                        
                
                }//end handler
                
        }// end ProcessActionHandler class





        public static class SwitchActionHandler
                extends DistributorActionHandler
        {

        
                public SwitchActionHandler(JFrame f, TaskListener tl,
                                           FIFOReadWriteLock lock,
                                           Utils.UpdateTimer timer,
                                           JTable tbl, JComboBox comboBox,
                                           JRadioButton normal, JRadioButton hot,
                                           JRadioButton cold, JRadioButton dormant) 
                {
                        super(f,tl,lock,timer,tbl,comboBox,normal,hot,cold,dormant);
                }
        
                
            
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                
                        String toLocation = (String)locationComboBox.getSelectedItem();
                        if (toLocation.equals(Constants.PICK_LOCATION)) {
                        
                                Log.getInstance().show_error(frame,
                                                             "Pick a location",
                                                             "Please pick a location from the list.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	
                
                        int [] selectedRows = distrTable.getSelectedRows();
                        if (selectedRows.length==0) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select distributors to be switched.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

                        if (dormantRB.isSelected()
                             || ( !normalRB.isSelected() && !hotRB.isSelected() && !coldRB.isSelected() ) )
                        {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please specify the mode for switching distributor(s).",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }


                        boolean needConfirm = false;

                        if (coldRB.isSelected() || hotRB.isSelected())
                                needConfirm = true;
                        
                        

                        String modestr = "NORMAL";
                        if (hotRB.isSelected())
                                modestr = "HOT";
                        else if (coldRB.isSelected())
                                modestr = "COLD";
                        
                
                        StringBuffer msgb = new StringBuffer("Switching line handlers to ");
                        msgb.append(toLocation);

                        StringBuffer prompt =
                                new StringBuffer("Are you sure you want to switch the selected distributor(s) to '");
        
                        prompt.append(toLocation)
                                .append("' location in ")
                                .append(modestr)
                                .append(" mode ?");
                        
                        String msg=msgb.toString();
                        
                        int rv = -1;

                        if (needConfirm)
                                rv = ConfirmDialog.show_confirm(frame, "Confirmation dialog",
                                                                prompt.toString());

                        else
                                rv = Log.getInstance().show_confirm(frame, "Confirmation dialog",
                                                                    prompt.toString());
                        
                        if (javax.swing.JOptionPane.YES_OPTION != rv) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	

                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().log_error("Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }
                        
                        
                        
                        updateTimer.stop();
                        
                        
                        taskListener.taskStarted(msg);
                        
                        
                        String idsdir1 = Constants.idsdir;
                        if (idsdir1==null)
                                idsdir1="/ids2";
                        idsdir1.trim();
                        
                        
                        
                        HashMap part1CmdActions  = new HashMap();
                        HashMap part2ModeActions = new HashMap();
                        HashMap part2CmdActions  = new HashMap();
                        HashMap part3CmdActions  = new HashMap();
                        
                        
                        java.util.HashMap fixedDIDs = new java.util.HashMap(20);
                        
                        
                        
                        for (int i = 0; i < selectedRows.length; i++) 
                        {
                                int row = selectedRows[i];
                                String did = (String)distrTable.getValueAt(row, 0 );
                                String dcm = (String)distrTable.getValueAt(row, 1 );
                                
                                HashMap m = null, dcmMap = null;
                                try {
                                        
                                        m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                                        dcmMap = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                                }
                                catch (Exception e){
                                        e.printStackTrace();
                                }
                                
                                
                                String host1 = (String)dcmMap.get("HOST1");
                                String host2 = (String)dcmMap.get("HOST2");
                                String home_host = host1;
                                String away_host = host2;
                                String location1 = (String)dcmMap.get("LOCATION1");
                                String location2 = (String)dcmMap.get("LOCATION2");
                                boolean  djnews_dcm = Utils.isDJNEWS_DCM((String)dcmMap.get("TYPE"));
                                String version = (String)dcmMap.get("SOFTWARE_VERSION");
                                if (version.equals(Constants.DEFAULT_SW_VERSION))
                                        version = Constants.DEFAULT_SW_VERSION_DIR;
                                
                                String idsdir = idsdir1+"/dcm/"+version;
                                String linehand = "dcm_linehand";
                                
                                String home_location = (String)m.get("HOME_LOCATION");
                                
                                String hs = null;
                                
                                String as = null;
                                
                                String did_location = null, did_alocation=null;
                                
                                
                                if (toLocation.equals(Constants.HOME_LOCATION)) {
                                /* Switch to Home */
                                        did_location = Constants.HOME_LOCATION;
                                        if (home_location != null) {
                                                if (home_location.equals("1")) {
                                                        home_host = host1;
                                                        away_host = host2;
                                                }
                                                else {
                                                        home_host = host2;
                                                        away_host = host1;
                                                }
                                        }
                                        
                                        hs  = (String)distrTable.getValueAt(row, 3 );
                                        as  = (String)distrTable.getValueAt(row, 4 );
                                }
                                else if (toLocation.equals(Constants.AWAY_LOCATION)) {
                                /* Switch to Away */
                                        did_location = Constants.AWAY_LOCATION;
                                        home_host = host2;
                                        away_host = host1;
                                        if (home_location != null) {
                                                if (home_location.equals("1")) {
                                                        home_host = host2;
                                                        away_host = host1;
                                                }
                                                else {
                                                        home_host = host1;
                                                        away_host = host2;
                                                }
                                        }
                                        hs = (String)distrTable.getValueAt(row, 4 );
                                        as = (String)distrTable.getValueAt(row, 3 );
                                } else {
                                /* Switch to Location */
                                        String location = toLocation;
                                        
                                        if (home_location == null)
                                        {
                                               
                                                Log.getInstance().log_error("Skipping switch "+did
                                                                            +". Location not set in configuration.",
                                                                            null); 
                                                continue;
                                        }
                                        
                                        if (location.equals(location1)) {
                                                home_host = host1;
                                                away_host = host2;
                                                
                                                if (home_location.equals("1")) {
                                                        did_location = Constants.HOME_LOCATION;
                                                        hs  = (String)distrTable.getValueAt(row, 3 );
                                                        as  = (String)distrTable.getValueAt(row, 4 );
                                                }
                                                else {
                                                        did_location = Constants.AWAY_LOCATION;
                                                        hs  = (String)distrTable.getValueAt(row, 4 );
                                                        as  = (String)distrTable.getValueAt(row, 3 );
                                                }
                                                
                                        }
                                        else {
                                                home_host = host2;
                                                away_host = host1;
                                                if (home_location.equals("1")) {
                                                        did_location = Constants.AWAY_LOCATION;
                                                        hs  = (String)distrTable.getValueAt(row, 4 );
                                                        as  = (String)distrTable.getValueAt(row, 3 );
                                                }
                                                else {
                                                        did_location = Constants.HOME_LOCATION;
                                                        hs  = (String)distrTable.getValueAt(row, 3 );
                                                        as  = (String)distrTable.getValueAt(row, 4 );
                                                }
                                        }
                                }
                                
                                
                                
                                /*
                                System.out.println("DID: "+did+"DCM: "+dcm
                                                   +" Home host : "+home_host
                                                   +" Away host : "+away_host
                                                   +" Home status : "+hs
                                                   +" Away status : "+as);
                                
                                */
                                String activeLoc = (String)ConfigComm.fixedLocationsMap.get(did);
                                    /* Switch to Home */
                                if (as.equals("ACTIVE") ) {
                                            /*
                                            ** Part1: Stop ACTIVE
                                            */
                                        
                                        
                                        String ftpopt = " -sHOT ";
                                        String lhopt = " -A ";
                                        
                                        if ((did_location!= null)
                                            && (activeLoc != null)) {

                                                    // If already active in the fixed location
                                                    // ignore
                                                
                                                if (!did_location.equals(activeLoc)) 
                                                        continue;
                                        }
                                        

                                        StringBuffer sb = (StringBuffer)part1CmdActions.get(away_host);
                                        if (sb == null) sb = new StringBuffer();
                                        int option = AdminComm.STOP_IDS2_PROC;
                                        sb.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+linehand)
                                                .append(";-d;-d "+did+lhopt+";");
                                
                                        if (djnews_dcm) {
                                                sb.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/ftp_handler")
                                                        .append(";-d;-d ")
                                                        .append(did)
                                                        .append(ftpopt)
                                                        .append(";");
                                        }
                                        part1CmdActions.put(away_host, sb);
                                
                                }
                        
                            

                                    /*
                                    ** If target's mode is DORMANT, just change the
                                    ** mode to ACTIVE, else start in ACTIVE mode.
                                    */

                        
                                if (hs.equals("DORMANT")) {
                                            /*
                                            ** Part2: Change Mode to ACTIVE OR Start ACTIVE
                                            */

                                        if ((did_location!= null)
                                            && (activeLoc != null)) {

                                                    // If already active in the fixed location
                                                    // ignore
                                                
                                                if (!did_location.equals(activeLoc)) 
                                                        continue;
                                        }

                                        
                                        StringBuffer    sb = (StringBuffer)part2ModeActions.get(home_host);
                                        if (sb == null) sb = new StringBuffer();
                                
                                        int option = AdminComm.CHANGE_MODE;
                                        String lhopt = ";"+AdminComm.CHANGE_MODE+" 1 NORMAL;";
                                
                                        if (hotRB.isSelected())
                                                lhopt = ";"+AdminComm.CHANGE_MODE+" 1 HOT;";
                                        else if (coldRB.isSelected())
                                                lhopt = ";"+AdminComm.CHANGE_MODE+" 1 COLD;";
                                        else
                                                lhopt = ";"+AdminComm.CHANGE_MODE+" 1 NORMAL;";
                                
                                        
                                        sb.append(ConfigComm.CONF_GS)
                                                .append(did)
                                                .append(lhopt);
                                        
                                        part2ModeActions.put(home_host, sb);
                                        
                                } else if (!hs.equals("ACTIVE")) {

                                        if ((did_location!= null)
                                            && (activeLoc != null)) {

                                                    // If already active in the fixed location
                                                    // ignore
                                                
                                                if (!did_location.equals(activeLoc)) 
                                                        continue;
                                        }

                                        
                                /* Start the LH if not running */
                                
                                        String ftpopt = " -sHOT ";
                                        String lhopt = " -A ";
                                
                                
                                        if (hotRB.isSelected()) {
                                                lhopt += " -sHOT ";
                                                ftpopt = " -sHOT ";
                                        }
                                        if (coldRB.isSelected()) {
                                                lhopt += " -sCOLD ";
                                                ftpopt = " -sCOLD ";
                                        } else {
                                                lhopt += " -sNORMAL ";
                                                ftpopt = " -sNORMAL ";
                                        }


                                        
                                        StringBuffer sb = (StringBuffer)part2CmdActions.get(home_host);
                                        if (sb == null) sb = new StringBuffer();
                                        int option = AdminComm.START_IDS2_PROC;
                                
                                        sb.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+linehand)
                                                .append(";-d;-d "+did+lhopt+";");
                                
                                        if (djnews_dcm) {
                                                sb.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/ftp_handler")
                                                        .append(";-d;-d ")
                                                        .append(did)
                                                        .append(ftpopt)
                                                        .append(";");
                                        }
                                        
                                        part2CmdActions.put(home_host, sb);
                                }


                                if ( !as.equals("DORMANT")) {
                                        
                                    /*
                                    ** Part3: Start DORMANT
                                    */
                                        if ((did_location!= null)
                                            && (activeLoc != null)) {

                                                    // If already active in the fixed location
                                                    // ignore
                                                
                                                if (!did_location.equals(activeLoc)) 
                                                        continue;
                                        }
                        
                                        String lhopt = " -D ";
                                        String ftpopt = " -sHOT ";
                                        
                                        StringBuffer sb = (StringBuffer)part3CmdActions.get(away_host);
                                        if (sb == null) sb = new StringBuffer();
                                        int option = AdminComm.STOP_IDS2_PROC;
                                        sb.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+linehand)
                                                .append(";-d;-d "+did+lhopt+";");
                                        
                                        if (djnews_dcm) {
                                                sb.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/ftp_handler")
                                                        .append(";-d;-d ")
                                                        .append(did)
                                                        .append(ftpopt)
                                                        .append(";");
                                        }
                        
                                        part3CmdActions.put(away_host, sb);
                                }
                                
                        
                        } /* For */


                        java.util.Iterator iter = part1CmdActions.keySet().iterator();
                        java.util.Vector workers = new java.util.Vector(10);

                        boolean needs_delay = false;
                        
                
                        while (iter.hasNext()) {
                        
                                String host = (String)iter.next();
                        
                                StringBuffer cmd = (StringBuffer) part1CmdActions.get(host);

                                /*
                                  System.out.println("Part1:STOP Action on host: "+host
                                  +"\n\t->:"+cmd.toString());
                                */


                                int option=AdminComm.STOP_IDS2_PROC;
                        
                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, cmd.toString());
                        
                        
                                workers.add(worker);
                                worker.start();
                                needs_delay = true;
                        }
                
                        boolean error = false;
                        
                        
                        for ( int n = 0; n < workers.size(); n++ ) {
                                
                                
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                
                
                        
                
                
                        iter = part2CmdActions.keySet().iterator();
                        workers = new java.util.Vector(10);
                        while (iter.hasNext()) {
                        
                                String host = (String)iter.next();
                        
                                StringBuffer cmd = (StringBuffer) part2CmdActions.get(host);

                                /*
                                System.out.println("Part2:START Action on host: "+host
                                                   +"\n\t->:"+cmd.toString());
                                */
                        
                                int option=AdminComm.START_IDS2_PROC;
                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, cmd.toString());
                        
                        
                                workers.add(worker);
                                worker.start();
                        
                        }
                
                
                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                



                        
                        
                        
                
                
                        iter = part2ModeActions.keySet().iterator();
                        workers = new java.util.Vector(10);
                        boolean delay_once = true;
                        
                        while (iter.hasNext()) {


                                if (needs_delay && delay_once &&
                                    (Constants.DCM_DISTRIBUTOR_SWITCH_MODE_DELAY>0) ){
                                        delay_once = false;
                                        
                                        try {
                                                Thread.sleep(Constants.DCM_DISTRIBUTOR_SWITCH_MODE_DELAY*1000);
                                        }
                                        catch (InterruptedException e){}
                                }
 
                                
                                String host = (String)iter.next();
                        
                                StringBuffer cmd = (StringBuffer) part2ModeActions.get(host);

                                    /*
                                System.out.println("Part2:Mode on host: "+host
                                                   +"\n\t->:"+cmd.toString());
                                    */

                                
                        
                                int option=AdminComm.CHANGE_MODE;
                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, cmd.toString());
                        
                        
                                workers.add(worker);
                                worker.start();
                        
                        }
                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                

                        if (needs_delay) {
                                try {
                                        Thread.sleep(Constants.DCM_DISTRIBUTOR_DORMANT_START_DELAY*1000);
                                }
                                catch (InterruptedException e){}
                        }
                        
                
                        
                
                        iter = part3CmdActions.keySet().iterator();
                        workers = new java.util.Vector(10);
                        while (iter.hasNext()) {
                        
                                String host = (String)iter.next();
                        
                                StringBuffer cmd = (StringBuffer) part3CmdActions.get(host);

                                /*
                                  System.out.println("Part3:START Action on host: "+host
                                  +"\n\t->:"+cmd.toString());
                                */
                                
                        
                                int option=AdminComm.START_IDS2_PROC;
                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, cmd.toString());
                        
                        
                                workers.add(worker);
                                worker.start();
                        }
                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                

                        if (error) {
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);
                        
                                taskListener.taskEnded("Request completed with errors.");
                        } else {
                                taskListener.taskEnded("Request completed successfully.");
                        }
                
                        rwLock.readLock().release();
                
	
                        if (cmdButton != null ) 
                                cmdButton.setEnabled(true);
                
                        updateTimer.start();
                
                
                
                }
                
        


        }


/*************/
        public static class RestoreStateActionHandler
                extends DistributorActionHandler
        {

        
                public RestoreStateActionHandler(JFrame f, TaskListener tl,
                                                 FIFOReadWriteLock lock,
                                                 Utils.UpdateTimer timer,
                                                 JTable tbl, JComboBox comboBox,
                                                 JRadioButton normal, JRadioButton hot,
                                                 JRadioButton cold, JRadioButton dormant) 
                {
                        super(f,tl,lock,timer,tbl,comboBox,
                              normal,hot,cold,dormant);
                }
        
                private void
                addToList(int inx, String did, String mode,
                          String dcm, HashMap dcmMap) 
                {
                                
                        if ( (mode != null)
                             && ( mode.equals("DORMANT")
                                  || mode.equals("ACTIVE") ) ) {
                                        
                                java.util.HashMap distrList = (java.util.HashMap)dcmMap.get(dcm);
                                if (distrList == null) 
                                        distrList = new java.util.HashMap();
                                
                                String distrModes[] = (String[])distrList.get(did);
                                if (distrModes == null)
                                        distrModes = new String[2];
                                        
                                distrModes[inx] = new String(mode);
                                
                                distrList.put(did, distrModes);
                                
                                dcmMap.put(dcm, distrList);
                        }
                }
                
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {

                        String location = (String)locationComboBox.getSelectedItem();
                        if (location.equals(Constants.PICK_LOCATION)) {
                        
                                Log.getInstance().show_error(frame,
                                                             "Pick a location",
                                                             "Please pick a location from the list.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	
                
                        int [] selectedRows = distrTable.getSelectedRows();
                        if (selectedRows.length==0) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select distributors.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }


                        if (!normalRB.isSelected() && !hotRB.isSelected() && !coldRB.isSelected() )
                        {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select mode of active line handlers.",
                                                             null);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;

                                    
                        }
                            
                        int option = AdminComm.START_IDS2_PROC;

                        
                        String idsdir1 = Constants.idsdir;
                        if (idsdir1==null)
                                idsdir1="/ids2";
                        idsdir1.trim();


                        
                        
                        
                        boolean error = false;
                        
                        String modestr = "NORMAL";
                        if (hotRB.isSelected()) modestr = "HOT";
                        else if (coldRB.isSelected()) modestr  = "COLD";
                        
                        

                        
                        String msg = "Starting selected line handlers..";
                        StringBuffer prompt = new StringBuffer("Are you sure you want to start the active line handlers (if any) in ");
                        prompt.append(modestr).append(" mode ?");
                        
                        
                        
                        if (javax.swing.JOptionPane.YES_OPTION
                            != Log.getInstance().show_confirm(frame,
                                                              "Confirmation dialog",
                                                              prompt.toString())) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }
                        
                        
                        
                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().log_error("Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }
                        
                        
                        
                        
                        
                        
                        taskListener.taskStarted(msg);
                        
                        String activeStr = " -sNORMAL ";
                        if (normalRB.isSelected()) activeStr = " -sNORMAL ";
                        if (hotRB.isSelected()) activeStr = " -sHOT ";
                        if (coldRB.isSelected()) activeStr = " -sCOLD ";
                        
                        
                        String ftpopt = activeStr;
                        
                        DCMDistributorStatusModel model = 
                                (DCMDistributorStatusModel) distrTable.getModel();
                        
                        java.util.HashMap dcmMap = new java.util.HashMap(20);
                        
                        
                        String lhopt = null;
                        boolean flipMode = false;
                        if (command.endsWith("SWITCHED"))
                                flipMode = true;
                        
                        int nselected = 0;


                            /*
                            ** Add LHs running in atleast one loccation
                            ** to the list
                            */
                        
                        for (int i = 0; i < selectedRows.length; i++) {
                                
                                int row = selectedRows[i];
                                String did = (String)model.getValueAt(row,0);
                                String dcm = (String)model.getValueAt(row,1);
                                String mode1 = (String)model.getValueAt(row,3);
                                String mode2 = (String)model.getValueAt(row,4);


                                addToList(0, did, mode1, dcm, dcmMap);
                                addToList(1, did, mode2, dcm, dcmMap);
                                
                        }
                        
                        
                        
                        java.util.Iterator iter = dcmMap.keySet().iterator();
                        java.util.Vector workers = new java.util.Vector(10);

                        
                        while (iter.hasNext()) {
                                
                                String dcm = (String)iter.next();
                                 
                                String tag = Constants.GLB_TAG_DCM_PREFIX+dcm;
                                
                                java.util.HashMap map = null;
                                try {
                                        map = ConfigComm.getHashMap(tag);
                                } catch (Exception e) {
                                        error = true;
                                        Log.getInstance().log_error(
                                                "Error in retrieving DCM configuration:"+dcm,
                                                e);
                                        continue ;
                                }
                                
                                String version = (String)map.get("SOFTWARE_VERSION");
                                
                                if ((version == null) ) {
                                        error = true;
                                        Log.getInstance().log_error("Configuration error: "
                                                                    + version , null);
                                        continue;
                                }
                                
                                
                                if (version.equals(Constants.DEFAULT_SW_VERSION))
                                        version = Constants.DEFAULT_SW_VERSION_DIR;
                                
                                boolean  djnews_dcm = Utils.isDJNEWS_DCM((String)map.get("TYPE"));
                                
                                
                                String host1 = (String)map.get("HOST1");
                                String host2 = (String)map.get("HOST2");
                                String location1 = (String)map.get("LOCATION1");
                                String location2 = (String)map.get("LOCATION2");



                                
                                String idsdir = idsdir1+"/dcm/"+version;
                                String linehand = "dcm_linehand";
                                

                                java.util.HashMap cmdMap = new java.util.HashMap();
                                java.util.HashMap distrList = 
                                        (java.util.HashMap) dcmMap.get(dcm);
                               
                                java.util.Iterator distr_iter = distrList.keySet().iterator();

                                while (distr_iter.hasNext()) {
                                        String did = (String)distr_iter.next();
                                        
                                        String distrModes[]  = (String[])distrList.get(did);
                                        
                                        

                                        String host = null;
                                        String primary_location = null;
                                        
                                        try {
                                                HashMap m =
                                                        ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                                                primary_location = (String)m.get("HOME_LOCATION");
                                        }
                                        catch (Exception e){
                                        }
                                        
                                        
                                        String mode = null;
                                        
                                           
                                        String did_location = null;
                                       
                                        
                                        if (primary_location == null ) {
                                                if (location.equals(Constants.HOME_LOCATION)
                                                    || ((location1 != null)
                                                        && location.equals(location1))) {
                                                        host = host1;
                                                        mode = distrModes[0];
                                                }
                                                
                                                
                                                if (location.equals(Constants.AWAY_LOCATION)
                                                    || ((location2 != null)
                                                        && location.equals(location2)) ) {
                                                        host = host2;
                                                        mode = distrModes[1];
                                                }
                                                

                                        } else {
                                                
                                                if (location.equals(Constants.HOME_LOCATION)) {
                                                        did_location = Constants.HOME_LOCATION;
                                                        mode = distrModes[0];
                                                        if (primary_location.equals("1")) {
                                                                host = host1;
                                                        } else {
                                                                host = host2;
                                                        }
                                                }

                                                
                                                if (location.equals(Constants.AWAY_LOCATION)) {
                                                         did_location = Constants.AWAY_LOCATION;
                                                        mode = distrModes[1];
                                                        if (primary_location.equals("1")) {
                                                                host = host2;
                                                        } else {
                                                                host = host1;
                                                        }
                                                }

                                                
                                                if ((location1 != null)
                                                    && location.equals(location1)) {
                                                        host = host1;
                                                        if (primary_location.equals("1")) {
                                                                did_location = Constants.HOME_LOCATION;
                                                                mode = distrModes[0];
                                                        } else {
                                                                did_location = Constants.AWAY_LOCATION;
                                                                mode = distrModes[1];
                                                        }
                                                }
                                                
                                                if ((location2 != null)
                                                    && location.equals(location2)) {
                                                        host = host2;
                                                        if (primary_location.equals("1")) {
                                                                did_location = Constants.AWAY_LOCATION;
                                                                mode = distrModes[1];
                                                        } else {
                                                                did_location = Constants.HOME_LOCATION;
                                                                mode = distrModes[0];
                                                        }
                                                }
                                                
                                        }

                                        if (host == null) {
                                                Log.getInstance().log_error("Can't find target("
                                                                            +location+") host for distributor: "+did,
                                                                            null);
                                                continue;
                                        }

                                            /*
                                            ** LH was not running before.
                                            */
                                        if (mode == null)
                                                continue;

                                        
                                        String lhcmdline = null;
                                        
                                        if ( (mode.equals("ACTIVE") && !flipMode)
                                             || (mode.equals("DORMANT") && flipMode) ) {
                                                lhcmdline = " -A " + activeStr;
                                        } 
                                        else if ( (mode.equals("DORMANT") && !flipMode)
                                                  || (mode.equals("ACTIVE") && flipMode) ) {
                                                lhcmdline = " -D ";
                                        } else
                                                continue;
                                        
                                        String activeLoc = (String)ConfigComm.fixedLocationsMap.get(did);
                                        if ((did_location != null) && (activeLoc != null)) {
                                                if (did_location.equalsIgnoreCase(activeLoc)) {
                                                        lhcmdline = " -A " + activeStr;
                                                }
                                                else {
                                                        lhcmdline = " -D ";
                                                }
                                                System.out.println("Changed command line: "+lhcmdline);
                                        } 
                                        
                                        StringBuffer reqbuf = (StringBuffer)cmdMap.get(host);
                                        if (reqbuf == null)
                                                reqbuf = new StringBuffer();
                                        
                                
                                        reqbuf.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+linehand)
                                                .append(";-d;-d "+did+lhcmdline+";");
                                        
                                        
                                        if (djnews_dcm) {
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/ftp_handler")
                                                        .append(";-d;-d ")
                                                        .append(did)
                                                        .append(ftpopt)
                                                        .append(";");
                                        }

                                        cmdMap.put(host, reqbuf);
                                        
                                }

                                java.util.Iterator host_iter = cmdMap.keySet().iterator();

                                while (host_iter.hasNext()) {
                                        String host = (String)host_iter.next();
                                        StringBuffer reqbuf = (StringBuffer)cmdMap.get(host);
                                        
                                        Utils.AdminWorker worker =
                                                new Utils.AdminWorker(option, host, reqbuf.toString());
                                
                                        workers.add(worker);
                                        worker.start();
                                }
                                
                                
                        } // iter.hasNext()

                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                        
                        if (error) {
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);
                                
                                taskListener.taskEnded("Request completed with errors.");
                        } else {
                                taskListener.taskEnded("Request completed successfully.");
                        }
                        
                        rwLock.readLock().release();
                        
                        if (cmdButton != null ) 
                                cmdButton.setEnabled(true);
                        
                        



                }
                        


        }
            /***********************/



        public static class StatusActionHandler
                implements ActionListener
        {
                Component  parent;
                int        status_type;
                JTable     table;
        
        
                public StatusActionHandler(Component p, JTable t,
                                           int type) 
                {
                        parent      = p;
                        status_type = type;
                        table       = t;
                
                }
        
                public void actionPerformed(java.awt.event.ActionEvent evt) 
                {
                
                        String command = evt.getActionCommand();
                        Object src = evt.getSource();
                        javax.swing.JButton source = null;
                
                        if (src instanceof javax.swing.JButton ) {
                                source = (javax.swing.JButton)src;
                                source.setEnabled(false);
                        }
                
                

                
                        final Utils.ActionWorker sw
                                = new Utils.ActionWorker(source, command) {
                                public Object construct() {
                                        handler(cmdButton, action);
                                        return null;
                                }
                        };
                
                        sw.start();
                }
        
                public void handler(javax.swing.JButton cmdButton, String command) 
                {             
                }
        }





        public static class DistributorStatusHandler
                extends StatusActionHandler
        {

                int location_index = -1;
                JComboBox locationComboBox ;
        
        
                public DistributorStatusHandler(Component p, JTable t, int type, JComboBox cb) 
                {
                        super(p, t, type);
                        locationComboBox = cb;
                }
        
                public void setLocationIndex(int l) 
                {
                        location_index = l;
                }
        
                public void
                handler(javax.swing.JButton cmdButton, String command) 
                {
                        int [] selectedRows = table.getSelectedRows();
                        if (selectedRows.length==0) {
                                Log.getInstance().show_error(parent,"Error",
                                                             "To view status, please pick atleast one distributor.",
                                                             null);
                        }


                
                        for (int i = 0; i < selectedRows.length; i++) {
                                String id = (String)table.getValueAt(selectedRows[i],0);
                                String location = (String) locationComboBox.getSelectedItem();

                        
                                location_index = -1;
                                if (location.equals(Constants.HOME_LOCATION))
                                        location_index = 1;
                                else if (location.equals(Constants.AWAY_LOCATION))
                                        location_index = 2;
                        
                        
                        
                                try {
                                        java.util.HashMap distrMap = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+id);
                                        String tag = (String)distrMap.get("TAG");
                                
                                        java.util.HashMap hostMap = ConfigComm.getHashMap(tag);
                                        String location1 = (String)hostMap.get("LOCATION1");
                                        String location2 = (String)hostMap.get("LOCATION2");
                                
                                
                                        String primary_location = (String)distrMap.get("HOME_LOCATION");

                                        if (primary_location == null ) {
                                                if (location.equals(Constants.HOME_LOCATION))
                                                        location_index = 1;
                                                else if (location.equals(Constants.AWAY_LOCATION))
                                                        location_index = 2;
                                                else if ((location1 != null)
                                                         && location.equals(location1))
                                                        location_index = 1;
                                                else if ((location2 != null)
                                                         && location.equals(location2))
                                                        location_index = 2;

                                        } else {
                                                if (location.equals(Constants.HOME_LOCATION)) {
                                                        if (primary_location.equals("1"))
                                                                location_index = 1;
                                                        else
                                                                location_index = 2;
                                                }
                                                else if (location.equals(Constants.AWAY_LOCATION)) {
                                                        if (primary_location.equals("1"))
                                                                location_index = 2;
                                                        else
                                                                location_index = 1;
                                                }
                                                else if ((location1 != null)
                                                         && location.equals(location1))
                                                        location_index = 1;
                                                else if ((location2 != null)
                                                         && location.equals(location2))
                                                        location_index = 2;
                                        }
                                }
                                catch (Exception e){
                                }

                                /*
                                System.out.println("Location: "+location+" Index "
                                                   + location_index);
                                */
                        
                        
                                if (location_index <= 0) {
                                        displayDistributorStatus(parent,
                                                                 status_type,
                                                                 1, id);
                                        displayDistributorStatus(parent,
                                                                 status_type,
                                                                 2, id);
                                }
                                else
                                        displayDistributorStatus(parent,
                                                                 status_type,
                                                                 location_index,
                                                                 id);
                        }
                
                
                        if (cmdButton != null ) 
                                cmdButton.setEnabled(true);
                        return;
                }



                public static void
                displayDistributorStatus(Component parent,
                                         int type, int which, String id) 
                {
                    if(statFrame == null)
                        statFrame = new StatusTabHandler("DCM Line Handler Status Tabs",
                                parent, type, which, id);
                    else
                        statFrame.addTab(parent, type, which, id);
                }
                /*                if(type == Constants.DCM_LINEHANDLER && statusFrame == null){
                                    statusFrame = new JFrame("DCM Line Handler Status");
                                    
                                    statusTabs = new JTabbedPane();
                                    statusFrame.add(statusTabs);
                                    statusFrame.addWindowListener(new WindowListener(){
                                        public void windowClosing(WindowEvent e){
                                            
                                            for(int x =statusTabs.getTabCount()-1; x>=0;x--){
                                                Component selected = 
                                                    statusTabs.getTabComponentAt(x);
                                                    
                                                    JPanel master2 = (JPanel)selected;
                                                    for(int y=0;y<master2.getComponentCount();y++)
                                                        if(master2.getComponent(y) instanceof JButton
                                                                && ((JButton)master2.getComponent(y)).getText().equals("x")){
                                                            JButton closer = ((JButton)master2.getComponent(y));
                                                            closer.doClick();
                                                    }
                                                    
                                                }
                                            statusTabs.removeAll();
                                        }
                                        public void windowClosed(WindowEvent e){
                                            
                                        }
                                        public void windowDeactivated(WindowEvent e){
                                            
                                        }
                                        public void windowActivated(WindowEvent e){
                                            
                                        }
                                        public void windowDeiconified(WindowEvent e){
                                            
                                        }
                                        public void windowIconified(WindowEvent e){
                                            
                                        }
                                        public void windowOpened(WindowEvent e){
                                            
                                        }
                                    });
                                    addTab(parent, type, which, id);
                                    statusFrame.pack();
                                }
                                else if(type == Constants.DSP_BROADCASTER){
                                    try {
                                            javax.swing.JFrame status_win
                                                = new DistributorStatusForm(type,
                                                                    which,
                                                                    id);
                                            if (status_win!=null)
                                                status_win.show();
                        
                                        } catch (Utils.DuplicateWindowException dwe) {
                                            return;
                                        } catch (Exception e) {
                                            Log.getInstance().show_error(parent,"Error",
                                                             e.getMessage(),
                                                             e);
                                        } 
                                }
                                else
                                    addTab(parent, type, which, id);
                                
                         
                }
        
                 private static void addTab(Component parent, int type, int which, String id){
                     try{
                         java.util.HashMap
                                        m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+id);
                                
                                String pl = (String)m.get("HOME_LOCATION");
                                String loc;
                                if(Integer.toString(which).equals(pl))
                                    loc = "-H";
                                else
                                    loc = "-A"; 
                                String newID = id + loc;
                                int tabCheck = statusTabs.indexOfTab(newID);
                                
                                
                                if(tabCheck != -1)
                                {
                                    statusTabs.setSelectedIndex(tabCheck);
                                    statusFrame.toFront();
                                }
                                else{
                                DistributorStatusForm status_win
                                        = new DistributorStatusForm(type,
                                                                    which,
                                                                    id);
                                
                                statusTabs.addTab(newID, status_win.getForm());
                                int index = statusTabs.indexOfTab(newID);
                                statusTabs.setSelectedIndex(index);
                                JPanel pnlTab = new JPanel();
                                pnlTab.setLayout(new BoxLayout(pnlTab, BoxLayout.X_AXIS));
                                pnlTab.setOpaque(false);
                                JLabel lblTitle = new JLabel(newID);
                                JButton btnClose = new JButton("x");
                                btnClose.setActionCommand(index+"");
                                pnlTab.add(lblTitle);
                                pnlTab.add(Box.createHorizontalStrut(25));
                                btnClose.setPreferredSize(new Dimension(20,20));
                                btnClose.setMargin(new Insets(0,0,0,0));
                                btnClose.setHorizontalTextPosition(SwingConstants.CENTER);
                                JButton getOther = new JButton();
                                ImageIcon icon = IDS_SwingUtils.createImageIcon("cursor_v_split.gif", "");
                                getOther.setIcon(icon);
                                getOther.setPreferredSize(new Dimension(25,20));
                                getOther.setMargin(new Insets(0,0,0,0));
                                getOther.setActionCommand(newID);
                                getOther.setToolTipText("Toggle Display of Opposite Status");
                                getOther.addActionListener(new ActionListener(){
                                    public void actionPerformed(ActionEvent evt)
                                    {
                                        splitHandler(evt);
                                    }
                                });
                                
                                pnlTab.add(getOther);
                                pnlTab.add(Box.createHorizontalStrut(5));
                                pnlTab.add(btnClose);
                                pnlTab.add(Box.createHorizontalGlue());
                                btnClose.addActionListener(new ActionListener(){
                                    public void actionPerformed(ActionEvent evt) {

                                            int index = Integer.parseInt(evt.getActionCommand());
                                            Component selected = 
                                                    statusTabs.getComponentAt(index);
                                            if(selected instanceof JSplitPane)
                                            {
                                               selected = ((JSplitPane)selected).getLeftComponent();
                                               selected = ((JScrollPane)selected).getComponent(0);
                                               selected = ((JViewport)selected).getComponent(0);
                                            }
                                                    
                                            JPanel master = (JPanel)selected;
                                            JPanel buttonsPan = ((JPanel)master.getComponent(1));
                                            JButton button = ((JButton)buttonsPan.getComponent(1));
                                            button.doClick();
                                            if(statusTabs.getComponentAt(index) instanceof JSplitPane){
                                                selected = ((JSplitPane)statusTabs.getComponentAt(index)).getRightComponent();
                                                selected = ((JScrollPane)selected).getComponent(0);
                                                selected = ((JViewport)selected).getComponent(0);
                                                JPanel buttonPan = (JPanel)((JPanel)selected).getComponent(1);
                                                JButton button2 = ((JButton)buttonPan.getComponent(1));
                                                button2.doClick();
                                            }
                                            
                                            if (statusTabs.getComponentAt(index) != null){
                                                statusTabs.remove(statusTabs.getComponentAt(index));
                                                
                                                for(int x=0;x<statusTabs.getTabCount();x++)
                                                {                                                    
                                                    Component tabPan = statusTabs.getTabComponentAt(x);
                                                    JPanel master2 = (JPanel)tabPan;
                                                    for(int y=0;y<master2.getComponentCount();y++)
                                                        if(master2.getComponent(y) instanceof JButton
                                                                && ((JButton)master2.getComponent(y)).getText().equals("x")){
                                                    JButton closer = ((JButton)master2.getComponent(y));
                                                    closer.setActionCommand(x + "");
                                                        }            
                                                }
                                            }
                                            if(statusTabs.getTabCount() == 0)
                                                statusFrame.dispose();
                                }});
                                
                                statusTabs.setTabComponentAt(index, pnlTab);
                                statusFrame.show();
                                statusFrame.revalidate();
                                
                                }
                     }catch (Utils.DuplicateWindowException dwe) {
                                JOptionPane.showMessageDialog(statusFrame, "Status Currently"
                                        + " Open in Split Tab",
                                        "Status Already Open", JOptionPane.WARNING_MESSAGE);
                                return;
                        }catch (Exception e) {
                                Log.getInstance().show_error(parent,"Error",
                                                             e.getMessage(),
                                                             e);
                        } 
                 }       
                 /*private static void killTab(Component c){
                     JPanel selected;
                     if(c instanceof JScrollPane)
                     {
                         JScrollPane scp = (JScrollPane) c;
                         JViewport v = scp.getViewport();
                         selected
                     }
                 }
                 private static void splitHandler(ActionEvent evt){
                     splitHelper(evt.getActionCommand());
                 }
                 private static void splitHelper(String evt){
                     
                         String id = evt;
                         int index = statusTabs.indexOfTab(id);
                         Component tab = statusTabs.getTabComponentAt(index);
                         JPanel tabPan = (JPanel) tab;
                         JLabel ident = (JLabel) tabPan.getComponent(0);
                         Component statComp = statusTabs.getComponentAt(index);
                         String[] idComps = id.split("-");
                         if(!(statComp instanceof JSplitPane)){
                             //code to split
                             String pl = "1";
                             try{java.util.HashMap
                                m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+idComps[0]);
                                pl = (String)m.get("HOME_LOCATION");
                             }catch(Exception e){
                             }
                             JSplitPane splitPane;
                             int opp;
                             String home, away;
                             if(pl.equals("1")){
                                 home = "1";
                                 away = "2";
                             }else{
                                 home = "2";
                                 away = "1";
                             }
                             if(idComps[1].equals("A")){
                                     opp = Integer.parseInt(home);
                             }else
                                 opp = Integer.parseInt(away);
                             DistributorStatusForm oppForm;
                             // int tryCount = 0;
                            /// while(tryCount < 2){
                             try{
                                 oppForm = new DistributorStatusForm(6,opp,idComps[0]);
                                 JScrollPane left = new JScrollPane(statComp);
                                 JScrollPane right = new JScrollPane(oppForm.getForm());
                                 splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,left,right );
                                 splitPane.setResizeWeight(.5);
                                 if(statusTabs.getTabCount() != 0 &&
                                         index < statusTabs.getTabCount()){
                                 statusTabs.insertTab(id, null, splitPane, null, index);
                                 statusTabs.setTabComponentAt(index, tabPan);}
                                 else
                                 {
                                     statusTabs.add(id, splitPane);
                                     statusTabs.setTabComponentAt(statusTabs.getTabCount()-1, tabPan);
                                 }
                                 statusTabs.setSelectedIndex(index);
                                 //tryCount = 5;
                                 ident.setText(id.substring(0, id.length()-2) + "   ");
                             }catch(Utils.DuplicateWindowException dwe){
                                 /*String mess = "The status requested is being"
                                         + "used by another tab. Do you wish"
                                         + "to close that tab?";
                                 String[] options = {"Yes", "No"};
                                 int resp = JOptionPane.showOptionDialog(statusTabs, mess, "Split Confirmation",
                                         JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
                                 if(resp == JOptionPane.YES_OPTION){
                                 //JOptionPane.showInputDialog("here");
                                if(idComps[1].equals("A"))
                                     idComps[1] = "H";
                                 else
                                    idComps[1] = "A";     
                                
                                 JOptionPane.showMessageDialog(statusFrame, "Close tab " + idComps[0]+
                                         "-"+idComps[1]+" to execute split", 
                                         "Status Already Open",JOptionPane.WARNING_MESSAGE); 
                                /*int enemyIndex = statusTabs.indexOfTab(idComps[0]+"-"+idComps[1]);
                                 if(enemyIndex < index)
                                     index--;
                                 JPanel grrPan =(JPanel) statusTabs.getTabComponentAt(enemyIndex);
                                 for(int y=0;y<grrPan.getComponentCount();y++)
                                                        if(grrPan.getComponent(y) instanceof JButton
                                                                && ((JButton)grrPan.getComponent(y)).getText().equals("x")){
                                                    JButton closer = ((JButton)grrPan.getComponent(y));
                                                        closer.doClick();
                                                        //splitHelper(evt);
                                                        //return;
                                                        
                                                        tryCount++;
                                                        }
                                /* }
                                 else
                                 return;
                             }catch(Exception e){
                                 Log.getInstance().show_error(statComp,"Error",
                                                             e.getMessage(),
                                                             e);
                               //  tryCount++;
                             }
                             //}
                         }else{
                             //code to reunify
                             ident.setText(id);
                             JSplitPane sptPane = (JSplitPane) statComp;
                             
                             JScrollPane sclPane = (JScrollPane)sptPane.getLeftComponent();
                             JViewport view = sclPane.getViewport();
                             JPanel regPane = (JPanel)view.getComponent(0);
                             
                             JScrollPane ritPane = (JScrollPane)sptPane.getRightComponent();
                             JViewport view2 = ritPane.getViewport();
                             JPanel reg2Pane = (JPanel)view2.getComponent(0);
                             JPanel buttonPan = (JPanel)reg2Pane.getComponent(1);
                             JButton button = ((JButton)buttonPan.getComponent(1));
                             button.doClick();
                             if(statusTabs.getTabCount() != 0){
                                 statusTabs.insertTab(id, null, regPane, null, index);
                                 statusTabs.setTabComponentAt(index, tabPan);
                                 statusTabs.remove(index+1);
                             }
                                 else
                                 {
                                     statusTabs.add(id, regPane);
                                     statusTabs.setTabComponentAt(0, tabPan);
                                 }
                            statusTabs.setSelectedIndex(index);
                         }
                 }*/
        
        }



        public static class DCMDataServicesHandler
                extends SelectActionHandler
        {

                private javax.swing.JTable dataServicesTable;
                private String       dcmName;
                private String       idsdir;
                private DCMDataServicesStatusModel dataServicesModel;
                private int location_index = -1;

                public DCMDataServicesHandler(JFrame f, TaskListener tl,
                                              FIFOReadWriteLock lock,
                                              Utils.UpdateTimer timer,
                                              JTable tbl,String msg,
                                              String dcm) 
                {
                        super(f, tl, lock, timer, tbl,
                              "Please select services from the table.");
                        
                        dataServicesTable = table;
                        dcmName = new String(dcm);
                        
                }



                private void processReaders(Vector ifVector, String productList,
                                            int option, StringBuffer reqbuf) 
                {
                        String reader = Constants.DCMServicesTable[0][1];
                        
                        for (int i = 0; i < selected_rows.length; i++) {
                                int row = selected_rows[i];
                                String prg = (String)dataServicesTable.getValueAt(row,0);
                                
                                
                                if (!prg.startsWith("Reader"))
                                        continue;
                                
                                int inx = prg.indexOf(":")+1;
                                String reader_name = prg.substring(inx);
                                        
                                for (int r = 0; r < ifVector.size() ; r++) {
                                        Object [] rowData = (Object[]) ifVector.get(r);
                                        
                                        if (!reader_name.equals((String)rowData[0]))
                                                continue;
                                                        
                                        StringBuffer cmdline = new StringBuffer();
                                        String fmt = (String)rowData[1];
                                        String protocol = (String) rowData[2];
                                        
                                        cmdline.append(" -n ").append(reader_name)
                                                .append(" -f ")
                                                .append(fmt.substring(0,Constants.MSGFMTSZ))
                                                .append(" -p ")
                                                .append(protocol);
                                        
                                        String transport = (String) rowData[3];
                                        String address = (String) rowData[4];
                                        
                                        if (address != null) {
                                                cmdline.append(" -t ").append(transport);
                                                if (transport.startsWith("TCP"))
                                                        cmdline.append(" -a *:").append(address);
                                                else
                                                        cmdline.append(" -a ").append(address);
                                        } else {
                                                cmdline.append(" -t ").append(transport);
                                                cmdline.append(" -a ").append(" 0 ");
                                        }
                                        
                                        
                                        cmdline.append(" ").append(productList);
                                        
                                        reqbuf.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+reader)
                                                .append(";-n;"+cmdline);
                                        
                                        if (option == AdminComm.START_IDS2_PROC)
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append("DELAY;")
                                                        .append(Integer.toString(Constants.DCM_READER_MSGMGR_DELAY))
                                                        .append(";;");
                                        
                                        
                                } /* for r = 0 */
                                        
                        }  /* for selected_rows = 0 */
                        
                }

                
                private void processMessageManagers(Vector ifVector, String productList,
                                                    int option, StringBuffer reqbuf)
                {
                            //String msgmgr = Constants.DCMServicesTable[1][1];
                        String msgmgr = "msgmgr";


                        boolean needs_multi2uni_delay = false;
                        
                        for (int i = 0; i < selected_rows.length; i++) {
                                int row = selected_rows[i];
                                String prg = (String)dataServicesTable.getValueAt(row,0);
                                
                                
                                if (!prg.startsWith("Message"))
                                        continue;
                                
                                        
                                        
                                int inx = prg.indexOf(":")+1;
                                String mgr_name = prg.substring(inx);
                                StringBuffer msgmgr_cl = new StringBuffer();
                                String fmt = null;
                                
                                if (dataServicesModel.isDJNEWS_DCM()) {
                                        fmt = Constants.GLB_IDS_FORMAT;
                                        msgmgr_cl.append(" -n ").append(mgr_name)
                                                .append(" -i ").append(fmt)
                                                .append(" -x ");
                                } else {
                                        inx = mgr_name.indexOf("-")+1;
                                        String mgrfmts = mgr_name.substring(inx);
                                        mgrfmts = mgrfmts.replace('_',',');
                                        
                                        msgmgr_cl.append(" -n ").append(mgr_name)
                                                .append(" -i ");
                                        
                                        fmt = mgr_name.substring(0,inx);
                                        msgmgr_cl.append(fmt.substring(0,Constants.MSGFMTSZ));
                                        
                                        if (!mgrfmts.equals(fmt.substring(0,Constants.MSGFMTSZ)))
                                                msgmgr_cl.append(" -o ")
                                                        .append(mgrfmts);
                                }
                                
                                
                                String products = dataServicesModel.getMgrProducts(mgr_name,location_index);
                                if (products != null)  {
                                        msgmgr_cl.append(" ").append(products);
                                } else {
                                        msgmgr_cl.append(" ").append(productList);
                                }
                                
                                if (!fmt.startsWith(Constants.GLB_IDS_FORMAT)
                                    && (option == AdminComm.START_IDS2_PROC) ) {
                                        needs_multi2uni_delay = true;
                                        continue;
                                }
                                
                                
                                reqbuf.append(ConfigComm.CONF_GS)
                                        .append(idsdir+"/bin/"+msgmgr)
                                        .append(";-n;"+msgmgr_cl.toString());
                                
                                
                        } /* for selected_rows = 0 */
                        
                        
                        if ( needs_multi2uni_delay ) {
                                
                                
                                reqbuf.append(ConfigComm.CONF_GS)
                                        .append("DELAY;")
                                        .append(Integer.toString(Constants.DCM_MSGMGR_MULTI2UNI_DELAY))
                                        .append(";;");
                                
                                
                                
                                for (int i = 0; i < selected_rows.length; i++) {
                                        int row = selected_rows[i];
                                        String prg = (String)dataServicesTable.getValueAt(row,0);
                                        
                                        
                                        if (!prg.startsWith("Message"))
                                                continue;
                                        
                                                
                                        int inx = prg.indexOf(":")+1;
                                        String mgr_name = prg.substring(inx);
                                        inx = mgr_name.indexOf("-")+1;
					int inx2 =  mgr_name.lastIndexOf("-");
                                        String mgrfmts = mgr_name.substring(inx);
					if (inx != (inx2+1))
						mgrfmts = mgr_name.substring(inx2+1);


                                        
                                        mgrfmts = mgrfmts.replace('_',',');
                                        
                                        StringBuffer msgmgr_cl = new StringBuffer();
                                        
                                        msgmgr_cl.append(" -n ").append(mgr_name)
                                                .append(" -i ");
                                        
                                        String fmt = mgr_name.substring(0,inx);
                                        if (inx != (inx2+1))
						fmt = mgr_name.substring(inx, inx2);


                                        msgmgr_cl.append(fmt.substring(0,Constants.MSGFMTSZ));
                                        
                                        if (!mgrfmts.equals(fmt.substring(0,Constants.MSGFMTSZ)))
                                                msgmgr_cl.append(" -o ")
                                                        .append(mgrfmts);
                                        
                                        
                                        
                                        String products = dataServicesModel.getMgrProducts(mgr_name,location_index);
                                        if (products != null)  {
                                                msgmgr_cl.append(" ").append(products);
                                        } else {
                                                msgmgr_cl.append(" ").append(productList);
                                        }
                                        
                                        if (!fmt.startsWith(Constants.GLB_IDS_FORMAT)
                                            && (option == AdminComm.START_IDS2_PROC) ) {
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/"+msgmgr)
                                                        .append(";-n;"+msgmgr_cl.toString());
                                        }
                                        
                                        
                                } /* for selected_rows = 0 */
                        }
                        
                }
        


                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        
	
                        String msg=null, prompt = null;
                        if (command.startsWith("START")) {
                                msg = "Starting selected services..";
                                prompt = "Are you sure you want to start the selected services?";
                        } else if (command.startsWith("STOP")) {
                                msg = "Stopping selected services..";
                                prompt = "Are you sure you want to stop the selected services?";
                        } 

                        if (javax.swing.JOptionPane.YES_OPTION
                            != ConfirmDialog.show_confirm(frame, "Confirmation dialog",
                                                              prompt)) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	

                        int option = -1;
                        if (command.startsWith("START"))
                                option = AdminComm.START_IDS2_PROC;
                        else if (command.startsWith("STOP"))
                                option = AdminComm.STOP_IDS2_PROC;
                        else {
                                Log.getInstance().log_error("Invalid option passed",null);
                                if (cmdButton != null ) cmdButton.setEnabled(true);
                                return;
                        }


                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	

                        updateTimer.stop();
                        taskListener.taskStarted(msg);


                        boolean config_err = false;
                        dataServicesModel
                                = (DCMDataServicesStatusModel) dataServicesTable.getModel();

                        String hostList1 = dataServicesModel.getDC1Host();
                        String hostList2 = dataServicesModel.getDC2Host();
                        if ((hostList1==null)||(hostList2==null)) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in retrieving DCM host names:"
                                                             +dcmName,null);
                                config_err = true;
                        }

                        java.util.Vector ifVector1 = dataServicesModel.getDC1InputFeed();
                        java.util.Vector ifVector2 = dataServicesModel.getDC2InputFeed();
                        if ((ifVector1==null)||(ifVector2==null)) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in retrieving DCM input "
                                                             +"configuration:"
                                                             +dcmName,null);
                                config_err = true;
                        }

                        String version = dataServicesModel.getSWVersion();
                        if (version==null) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in retrieving DCM software version "
                                                             +"configuration:"
                                                             +dcmName,null);
                                config_err = true;
                        }

                        if (version.equals(Constants.DEFAULT_SW_VERSION))
                                version = Constants.DEFAULT_SW_VERSION_DIR;

	
                        if (config_err) {
                                rwLock.readLock().release();
                                updateTimer.start();
                                taskListener.taskEnded("");
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }

	
                        String host = null;
                        java.util.Vector ifVector=ifVector1;
                        

                        if (command.endsWith("1")) {
                                host = hostList1;
                                location_index = 1;
                        }

                        if (command.endsWith("2")) {
                                host = hostList2;
                                location_index = 2;
                                ifVector = ifVector2;
                        }

                        String productList = dataServicesModel.getDCMProducts(location_index);

                        
                          

                        idsdir = Constants.idsdir;
                        if (idsdir==null)
                                idsdir="/ids2";
                        idsdir.trim();
                        idsdir = idsdir+"/dcm/"+version; 


                            /*
                            ** Create command  for adminserver in reqbuf
                            */
                        StringBuffer reqbuf = new StringBuffer();

                            /*
                            **Start the readers first 
                            */
                        
                        
                        processReaders(ifVector, productList, option, reqbuf);
                        
                        processMessageManagers(ifVector, productList, option, reqbuf);
                        
                        
                        
                        if (Constants.DEBUG && Constants.Verbose>2)
                                System.out.println("Command Line: "+reqbuf.toString());
                        

                
                
                        if (Constants.DEBUG && Constants.Verbose>2)
                                System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n"+
                                                   "HOST: "+host+"\n"+reqbuf.toString()
                                                   +"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
                        
                        
                        Utils.AdminWorker worker =
                                new Utils.AdminWorker(option, host, reqbuf.toString());
                        
                            // Start the worker thread
                        worker.start();
                        
                        
                            // Wait for the thread to finish
                        Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                        if (status.status != 0) {
                                
                                if (status.response.length()>0)
                                        Log.getInstance().log_error("Error :"
                                                                    +status.response.toString(),
                                                                    null);
                                
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);
                                
                        }
                        
                        
                        
                        taskListener.taskEnded("");
                
                
                        rwLock.readLock().release();
                        
                        if (cmdButton != null ) 
                                cmdButton.setEnabled(true);
                        
                        updateTimer.start();
                        
                }

        }


        
        

        public static class DCMDataStatusHandler
                extends SelectActionHandler
        {

                private javax.swing.JTable dataServicesTable;
                private String       dcmName;
                

                public DCMDataStatusHandler(JFrame f, TaskListener tl,
                                            FIFOReadWriteLock lock,
                                            Utils.UpdateTimer timer,
                                            JTable tbl,String msg,
                                            String dcm) 
                {
                        super(f, tl, lock, timer, tbl,
                              "Please select a server to view status.");
                        
                        dataServicesTable = table;
                        dcmName = new String(dcm);
                }

                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                        int which=0,type=-1;
                        String serverList=null;
                        String progname = null;
                        String name = null;
                        
                        DCMDataServicesStatusModel dataServicesModel
                                = (DCMDataServicesStatusModel) dataServicesTable.getModel();

                        
                        
                        String hostList1 = dataServicesModel.getDC1PHost();
                        String hostList2 = dataServicesModel.getDC2PHost();
                        if ((hostList1==null)||(hostList2==null)) {
                                Log.getInstance().show_warning(frame,"Error",
                                                               "Error in retrieving DCM host names:"
                                                               +dcmName,null);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }

                           
                        
                        if (command.endsWith("1") ) {
                                which = 1;
                                serverList = hostList1;
                        } else {
                                which = 2;
                                serverList = hostList2;
                        }
                        
                                
                        int selected_row = selected_rows[0];
                        String value = (String)dataServicesTable.getValueAt(selected_row,0);
                        if (value.startsWith("Reader")) {
                                type = Constants.DCM_READER;
                                int inx = value.indexOf(":");
                                progname = value.substring(0,inx-1);
                                name     = value .substring(inx+1);
                        } 
                        
                        
                        if (type != -1) {
                                
                                StatusHandler statushandler = StatusHandler.getInstance();
                                
                                try{
                                        statushandler.displayStatus(frame,type,which, serverList,
                                                                    dcmName,name);
                                }
                                catch (Exception e)
                                {
                                }
                                       
                        }
                        
                        if (cmdButton != null) cmdButton.setEnabled(true);
                        
                }
        }

        public static class DCMRetransStatusHandler
                extends SelectActionHandler
        {

                private javax.swing.JTable systemServicesTable;
                private String       dcmName;
                private DCMDataServicesStatusModel dataServicesModel;
                

                public DCMRetransStatusHandler(JFrame f, TaskListener tl,
                                               FIFOReadWriteLock lock,
                                               Utils.UpdateTimer timer,
                                               JTable tbl,String msg,
                                               String dcm,
                                               DCMDataServicesStatusModel m) 
                {
                        super(f, tl, lock, timer, tbl,
                              "Please select a server to view status.");
                        
                        systemServicesTable = table;
                        dcmName = new String(dcm);

                        dataServicesModel = m;
                        
                }

                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
                       

                        
                        String hostList1 = dataServicesModel.getDC1PHost();
                        String hostList2 = dataServicesModel.getDC2PHost();
                        if ((hostList1==null)||(hostList2==null)) {
                                Log.getInstance().show_warning(frame,"Error",
                                                               "Error in retrieving DCM host names:"
                                                               +dcmName,null);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }

                        try {
                                RetransmissionStatusForm f
                                        = new RetransmissionStatusForm(dcmName,
                                                                       null, 
                                                                       hostList1,
                                                                       hostList2);
                                f.show();
                        } catch (Utils.DuplicateWindowException dwe) {
                        } catch (Exception exc) {
                                Log.getInstance().log_error("Error in displaying "
                                                            +"retransmission status "
                                                            +"dialog:"
                                                            +dcmName, null);
                        }       
                        
                        if (cmdButton != null) cmdButton.setEnabled(true);
                }
        }



        public static class DCMDistributorStatusAdapter
                extends java.awt.event.MouseAdapter
        {

                private javax.swing.JFrame frame;
                private javax.swing.JTable distrTable;

                private DCMDistributorStatusAdapter() 
                {}

                public DCMDistributorStatusAdapter(javax.swing.JFrame f,
                                                   JTable table) 
                {
                        super();
                        frame = f;
                        distrTable = table;
                }
                
                public void mouseClicked(java.awt.event.MouseEvent evt)
                {
                        if (evt.getClickCount() != 2)
                                return;
                        
                        int row = distrTable.getSelectedRow();
                        int col = distrTable.getSelectedColumn();
                        if ( (col <= 2) ||  (col > 4) ) return;
                        
                        String value = (String)distrTable.getValueAt(row,col);
                        if ((value==null) || value.equals("Not Running")
                            || value.startsWith("No Status")
                            || value.startsWith("Error")
                            || value.startsWith("????"))  return ;
                        
                        
                        String id = (String)distrTable.getValueAt(row,0);
                        
                        int location_index = col-2;
                        
                        try {
                                java.util.HashMap
                                        m = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+id);
                                
                                String pl = (String)m.get("HOME_LOCATION");
                                if (pl!=null && !pl.equals("1")) {
                                        if (col==3) 
                                                location_index = 2;
                                        
                                        if (col==4) 
                                                location_index = 1;
                                }
                        }
                        catch (Exception e){
                        }
                                
                        DistributorStatusHandler.displayDistributorStatus(frame,
                                                                          Constants.DCM_LINEHANDLER,
                                                                          location_index, id);
                        
                        
                        
                }
                
                
        }
        

        public static class DeleteDCMActionHandler
                extends SelectActionHandler
        {
                StringBuffer DataServicesList ;
                public  DeleteDCMActionHandler(JFrame f, TaskListener tl,
                                               FIFOReadWriteLock lock,
                                               Utils.UpdateTimer timer,
                                               JTable tbl, String select_msg, StringBuffer sb)
                {super(f, tl, lock, timer, tbl,select_msg);
                DataServicesList = sb;
                
                }
                

                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {                      
                        javax.swing.JFrame f = null;

                        int row = selected_rows[0]; 
                        String dcmTag = (String)table.getValueAt(row,0);
		
                        StringBuffer reqbuf = new StringBuffer();
	  
		
		
                        if (javax.swing.JOptionPane.YES_OPTION !=
                            Log.getInstance().show_confirm(frame,"Confirm delete", 
                                                           "Are you sure you want to delete DCM: "
                                                           +dcmTag+" ?.")) {
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }
		
                            /*
                            ** Check if any distributors are configured on the DCM
                            */
                        ConfigComm.getServKey(reqbuf,
                                              ConfigComm.GET_DCM_DIST_ALL_INFO,
                                              dcmTag);

                        boolean err= true,inuse = false;

                        try { 
                                byte[] b = ConfigComm.configRequest(reqbuf);
                                err=false;
                                inuse = true;
                        } catch (Exception e ) {
                                err = true;
                                if (e instanceof DBException) {
                                        if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND) {
                                                inuse = false;                   
                                                err = false;
                                        }
                                }
                        }

                        if (!err && inuse) {
                                Log.getInstance().show_error(frame,"Error", 
                                                             "Cannot delete dcm configuration.\n"
                                                             +"It is in use by distributors.  ", 
                                                             null);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }
		

                        if (err) {
                                Log.getInstance().show_error(frame,"Error", 
                                                             "Cannot delete dcm configuration.\n"
                                                             +"Error in checking distributors.  ", 
                                                             null);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }

                        DCMStatusDataModel dcmlist_model 
                                = (DCMStatusDataModel)table.getModel();
                            /* 
                            ** Check if any processes are running on the DCM
                            */
	    
                        String h1 = (String)dcmlist_model.getHost1(row);
                        String h2 = (String)dcmlist_model.getHost2(row);
				
                        int i1 = AdminComm.checkProcesses(frame,h1,DataServicesList.toString());
                        int i2 = AdminComm.checkProcesses(frame,h2,DataServicesList.toString());

                        if ((i1!=0) || (i2!=0)) {
                                StringBuffer errstr = new StringBuffer();


                                if ((i1==1)||(i2==1)) {
                                        Log.getInstance().show_error(frame,"Error",
                                                                     "Cannot delete DCM configuration while "
                                                                     +"services are running.",
                                                                     null);
                                        if (cmdButton!=null) cmdButton.setEnabled(true);
                                        return;
                                }

                                if ((i1==-1)||(i2==-1)) {
                                        if (javax.swing.JOptionPane.YES_OPTION !=
                                            Log.getInstance().show_confirm(frame,"Warning",
                                                                           "Could not verify that services are "
                                                                           +"not running.\n"
                                                                           +"Are you sure you want to delete "
                                                                           +"the DCM configiration?.")) {
                                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                                return;
                                        }
                                }
                        }



                            /* 
                            ** Send request to delete DCM
                            */

                        reqbuf.setLength(0);
                        ConfigComm.deleteKeyValue(reqbuf,Constants.GLB_TAG_DCM_PREFIX+dcmTag);
		
                        try {
                                byte[] b;
                                b = ConfigComm.configRequest(reqbuf);

                                    /*
                                    ** If the DCM configuration window is currenlty displayed, close it
                                    */
                                f =
                                        (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.CONFIGURATION_DCM_PREFIX+dcmTag);
                                if (f != null) {
                                        f.setVisible(false);
                                        f.dispose();
                                        WindowEventAdapter.getInstance().unregisterWindow(f);
                                }

                                    /*
                                    ** Close the DCM services window
                                    */
                                f = (javax.swing.JFrame)WindowEventAdapter.getInstance()
                                        .findWindow(Constants.SERVICES_DCM+"_"+dcmTag);
                                if (f != null) {
                                        if (f instanceof DCMServicesForm)  {
                                              java.awt.event.WindowEvent we = new java.awt.event.WindowEvent(f,
                                                              java.awt.event.WindowEvent.WINDOW_CLOSING);
                                              f.dispatchEvent(we);
                                                //((DCMServicesForm)f).exitForm(null);
                                        } else {
                                                f.setVisible(false);
                                                f.dispose();
                                        }
                                        WindowEventAdapter.getInstance().unregisterWindow(f);
                                }

                                    /*
                                    ** Close any DCM reader status windows
                                    */
                                java.util.Vector v = WindowEventAdapter.getInstance()
                                        .findWindows(Constants.STATUS_READER_PREFIX
                                                     +dcmTag);
				
                                for (int i = 0; i < v.size(); i++) {
                                        ReaderStatusForm rform = (ReaderStatusForm)v.get(i);
                                        rform.exitForm(null);
                                }

                                    /* 
                                    ** Close retransmission status windows
                                    */
                                v = WindowEventAdapter.getInstance()
                                        .findWindows(Constants.STATUS_RETRANSMISSION_PREFIX
                                                     +dcmTag);
			
                                for (int i = 0; i < v.size(); i++) {
                                        RetransmissionStatusForm rform 
                                                = (RetransmissionStatusForm)v.get(i);
                                        rform.exitForm(null);
                                }


                        } catch (Exception e) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Error in deleting DCM: "
                                                             +dcmTag+" configuration: ",e);
                                if (cmdButton!=null) cmdButton.setEnabled(true);
                                return;
                        }
		
                        dcmlist_model.removeRow(row);
			

                        if (cmdButton!=null) cmdButton.setEnabled(true);     
                }
        } //DeleteDCMActionHandler
        

        public static class DCMDataServicesActionHandler
                extends DistributorActionHandler
        {
                
                int admin_action = -1;
                JRadioButton noneRB;
                
                public DCMDataServicesActionHandler(JFrame f, TaskListener tl,
                                                FIFOReadWriteLock lock,
                                                Utils.UpdateTimer timer,
                                                JTable tbl, JComboBox comboBox,
                                                JRadioButton normal, JRadioButton hot,
                                                JRadioButton cold, JRadioButton dormant,
                                                JRadioButton none, int action) 
                {
                        super(f,tl,lock,timer,tbl,comboBox,normal,hot,cold,dormant);


                        noneRB = none;
                        admin_action = action;
                }
                
                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
	

	
                        int [] selected_rows = distrTable.getSelectedRows();
                        if (selected_rows.length<=0) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select a DCM from the list",
                                                             null);
                                if (cmdButton != null )
                                        cmdButton.setEnabled(true);
                                return;
                        }


	


                        int option = -1;
    
                        if (command.startsWith("START"))
                                option = AdminComm.START_IDS2_PROC;
                        else if (command.startsWith("STOP"))
                                option = AdminComm.STOP_IDS2_PROC;
                        else {
                                Log.getInstance().log_error("Invalid option passed: "
                                                            +option,null);
                                if (cmdButton != null )
                                        cmdButton.setEnabled(true);
                                return;
                        }
	
                        

                        String msg=null, prompt = null;
                        if (command.startsWith("START_IS")) {
                                msg = "Starting data services on selected DCM(s)..";
                                prompt = "Are you sure you want to START data services\n on the selected DCM(s).?";
                        } else if (command.startsWith("STOP_IS")) {
                                msg = "Stopping data services on selected DCM(s)..";
                                prompt = "Are you sure you want to STOP data services\n on the selected DCM(s).?";
                        } 


                        if (javax.swing.JOptionPane.YES_OPTION
                            != ConfirmDialog.show_confirm(frame, "Confirmation dialog",
                                                              prompt)) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	
                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().log_error("Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

                        String location = (String)locationComboBox.getSelectedItem();


                        updateTimer.stop();

	
                        taskListener.taskStarted(msg);


                        DCMStatusDataModel dcmModel 
                                = (DCMStatusDataModel)distrTable.getModel();

                        boolean error = false;

                        java.util.Vector workers = new java.util.Vector(selected_rows.length);
        
                       
            
                        



                        for (int r = 0; r < selected_rows.length; r++)
                        {

                                String dcmkey = (String)distrTable.getValueAt(selected_rows[r],0);
                                

                                DCMDataServicesStatusModel dataServicesModel
                                        = new DCMDataServicesStatusModel(Constants.DCMServicesTable,
                                                                         Constants.GLB_TAG_DCM_PREFIX+dcmkey);
	  

                                try {
                                        dataServicesModel.Update();
                                } catch (Exception e) {
                                        continue;
                                }
	      
          


                                String host = null;
                                int dc = -1;

                                String location1 = dataServicesModel.getDC1Location();
                                String location2 = dataServicesModel.getDC2Location();
 

                                if (location.equals(Constants.DC1_LOCATION)
                                    || (location1!=null && location.equals(location1)) ) {
                                        host = dataServicesModel.getDC1Host();
                                        dc = 1;
                                }
                                if (location.equals(Constants.DC2_LOCATION)
                                    || (location2!=null && location.equals(location2)) ) {
                                        host = dataServicesModel.getDC2Host();
                                        dc = 2;
                                }

                                
                                if (host == null) {
                                        Log.getInstance().log_error("Can't find target("
                                                                    +location+") host for DCM: "+dcmkey,
                                                                    null);
                                        continue;
                                }

                                String version =  dataServicesModel.getSWVersion();
                                if (version.equals(Constants.DEFAULT_SW_VERSION))
                                        version = Constants.DEFAULT_SW_VERSION_DIR;

                                
                                
                                boolean isDJNEWS_DCM = dataServicesModel.isDJNEWS_DCM();

                                StringBuffer reqbuf = new StringBuffer();

         

                                String idsdir = Constants.idsdir;
                                if (idsdir==null)
                                        idsdir="/ids2";
                                idsdir.trim();
                                idsdir = idsdir+"/dcm/"+version;

                                int inx = command.indexOf('_');


	  

                                    /* BEGIN Data Services */

                                if (command.startsWith("START")) {

                                        String products = dataServicesModel.getDCMProducts(dc);
                                        
                                        String name = Constants.GLB_DCM_INPUT_NAME;
                                        String format = Constants.GLB_IDS_FORMAT.substring(0,Constants.MSGFMTSZ);
                                        String prodList[] = ConfigComm.getCSCProductsModel().getProductsWithoutAD();  
                                        
                                        reqbuf.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+"dcm_reader")
                                                .append(";-n;")
                                                .append(" -n ").append(name)
                                                .append(" -f ").append(format)
                                                .append(" -p ").append(Constants.GLB_IDS_PROTOCOL);
                                        

                                        reqbuf.append(" -t ").append(Constants.GLB_IDS_TRANSPORT);
                                        if(Constants.GLB_IDS_TRANSPORT.startsWith("TCP"))
                                                reqbuf.append(" -a *:").append(Constants.GLB_IDS_TRANSPORT_ADDRESS);
                                        else
                                                reqbuf.append(" -a ").append(Constants.GLB_IDS_TRANSPORT_ADDRESS);


                                        reqbuf.append(" ").append(products);

                                        if (option == AdminComm.START_IDS2_PROC)
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append("DELAY;")
                                                        .append(Integer.toString(Constants.DCM_READER_MSGMGR_DELAY))
                                                        .append(";;");


                                        boolean msgmgr_delay = false;

                                        if (isDJNEWS_DCM) {
                                                String mgr_name = Constants.GLB_DJNEWS_DCM_MSGMGR_NAME;
                                                String fmt = Constants.GLB_IDS_FORMAT;
                                                reqbuf.append(ConfigComm.CONF_GS)
                                                        .append(idsdir+"/bin/"+"msgmgr")
                                                        .append(";-n;")
                                                        .append(" -n ").append(mgr_name)
                                                        .append(" -i ").append(fmt.substring(0,Constants.MSGFMTSZ))
                                                        .append(" -x ");

		  

                                                String djnews_products = dataServicesModel.getMgrProducts(mgr_name,dc);
                                                if (djnews_products != null)  {
                                                        reqbuf.append(" ").append(djnews_products);
                                                } else {
                                                        reqbuf.append(" ").append(prodList);
                                                }
                                        } else {

                                                java.util.HashMap prodConvMap
                                                        = ConfigComm.getCSCSparseMatrixModel().getMsgMgrs();
		  
                                                java.util.Iterator iter = prodConvMap.keySet().iterator();
		  
		  
                                                while (iter.hasNext()) {
		      
                                                        String key = (String)iter.next();
                                                        int inx1 = key.indexOf("-")+1;
                                                        String mgrfmts = key.substring(inx1);
		      
                                                        mgrfmts = mgrfmts.replace('_',',');
		      
                                                        String ifmt = key.substring(0,inx1);
		      
                                                        if (!ifmt.startsWith(Constants.GLB_IDS_FORMAT)
                                                            && (option == AdminComm.START_IDS2_PROC) ) {
                                                                msgmgr_delay = true;
                                                                continue;
                                                        }
		      
		      
                                                        reqbuf.append(ConfigComm.CONF_GS)
                                                                .append(idsdir+"/bin/"+"msgmgr")
                                                                .append(";-n;")
                                                                .append(" -n ").append(key)
                                                                .append(" -i ").append(ifmt.substring(0,Constants.MSGFMTSZ));
		      
                                                        if (!mgrfmts.equals(ifmt.substring(0,Constants.MSGFMTSZ)))
                                                                reqbuf.append(" -o ").append(mgrfmts);
		      
                                                        StringBuffer mgrprods = (StringBuffer)prodConvMap.get(key);
		      
                                                        if (mgrprods != null)  {
                                                                reqbuf.append(" ").append(mgrprods.toString());
                                                        } else {
                                                                reqbuf.append(" ").append(prodList);
                                                        }
                                                }
		  
	      




                                                if ( msgmgr_delay ) {

	
                                                        reqbuf.append(ConfigComm.CONF_GS)
                                                                .append("DELAY;")
                                                                .append(Integer.toString(Constants.DCM_MSGMGR_MULTI2UNI_DELAY))
                                                                .append(";;");
		

                                                        iter = prodConvMap.keySet().iterator();
      
                                                        while (iter.hasNext()) {
		
                                                                String mgr_name = (String)iter.next();
                                                                
                                                                int inx1 = mgr_name.indexOf("-")+1;
                                                                int inx2 =  mgr_name.lastIndexOf("-");
                                                                String mgrfmts = mgr_name.substring(inx1);
                                                                if (inx1 != (inx2+1))
                                                                    mgrfmts = mgr_name.substring(inx2+1);

                                                                

		    
                                                                mgrfmts = mgrfmts.replace('_',',');

                                                                

                                                                String ifmt = mgr_name.substring(0,inx1);
                                                                if (inx1 != (inx2+1))
                                                                    ifmt = mgr_name.substring(inx1, inx2);

                                                                
                    
                                                                if (!ifmt.startsWith(Constants.GLB_IDS_FORMAT)
                                                                    && (option == AdminComm.START_IDS2_PROC) ) {
			
                                                                        reqbuf.append(ConfigComm.CONF_GS)
                                                                                .append(idsdir+"/bin/"+"msgmgr")
                                                                                .append(";-n;")
                                                                                .append(" -n ").append(mgr_name)
                                                                                .append(" -i ").append(ifmt.substring(0,Constants.MSGFMTSZ));
			
                                                                        if (!mgrfmts.equals(ifmt.substring(0,Constants.MSGFMTSZ)))
                                                                                reqbuf.append(" -o ").append(mgrfmts);
			
                                                                        StringBuffer mgrprods = (StringBuffer)prodConvMap.get(mgr_name);
			
                                                                        if (mgrprods != null)  {
                                                                                reqbuf.append(" ").append(mgrprods.toString());
                                                                        } else {
                                                                                reqbuf.append(" ").append(prodList);
                                                                        }
                                                                }
                                                        } // while iter.hasBext()
                                                } // if msgmgr_delay

                                        }


                                        if (Constants.DEBUG && Constants.Verbose>2)
                                                System.out.println("Command Line: "+reqbuf.toString());


                                        int l = reqbuf.length();
                                        if (reqbuf.toString().endsWith(","))
                                                reqbuf.setLength(l-1);



                                } else {

                                        reqbuf.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+"dcm_reader")
                                                .append(";*;;");
                                        
                                        reqbuf.append(ConfigComm.CONF_GS)
                                                .append(idsdir+"/bin/"+"msgmgr")
                                                .append(";*;;");
                                        
                                }
                                
                                
                                    /* END Data Services */
                                
                                   
                                
                                if (Constants.DEBUG && Constants.Verbose>2)
                                        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n"+
                                                           "HOST: "+host+"\n"+reqbuf.toString()
                                                           +"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");

                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, reqbuf.toString());
                                
                                
                                workers.add(worker);
                                worker.start();


                        } // for r < selected_rows.length



                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                    //System.out.println("Retrieving cstatus from thread :"+n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                    //System.out.println("Retrieved cstatus from thread :"+n);
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }
                        
                        
                        
                        if (error) {
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);

                                taskListener.taskEnded("Request completed with errors.");
                        } else {
                                taskListener.taskEnded("Request completed successfully.");
                        }
                
                        rwLock.readLock().release();
                
                        if (cmdButton != null )
                                cmdButton.setEnabled(true);
                
                        updateTimer.start();
                }
        
        } //DCMDataServicesActionHandler



        public class ReturnActionHandler implements ActionListener{
            JButton test2;
            
            public ReturnActionHandler(ActionHandler evt){
                
            }
            
            public ReturnActionHandler(){
                
            }
            
            public void actionPerformed(ActionEvent evt){
                Object test1 = evt.getSource();
                if(test1 instanceof JButton)
                    test2 = (JButton) test1;
                JOptionPane.showInputDialog(test2.getActionListeners().length);
            }
            
        }





        
        public static class DCMDistrServicesActionHandler
                extends DistributorActionHandler
        {
                
                int admin_action = -1;
                JRadioButton noneRB;
                
                public DCMDistrServicesActionHandler(JFrame f, TaskListener tl,
                                                FIFOReadWriteLock lock,
                                                Utils.UpdateTimer timer,
                                                JTable tbl, JComboBox comboBox,
                                                JRadioButton normal, JRadioButton hot,
                                                JRadioButton cold, JRadioButton dormant,
                                                JRadioButton none, int action) 
                {
                        super(f,tl,lock,timer,tbl,comboBox,normal,hot,cold,dormant);


                        noneRB = none;
                        admin_action = action;
                }
                
                
                public void handler(javax.swing.JButton cmdButton, String command) 
                {
	

	
                        int [] selected_rows = distrTable.getSelectedRows();
                        if (selected_rows.length<=0) {
                                Log.getInstance().show_error(frame,"Error",
                                                             "Please select a DCM from the list",
                                                             null);
                                if (cmdButton != null )
                                        cmdButton.setEnabled(true);
                                return;
                        }


	


                        int option = -1;
    
                        if (command.startsWith("START"))
                                option = AdminComm.START_IDS2_PROC;
                        else if (command.startsWith("STOP"))
                                option = AdminComm.STOP_IDS2_PROC;
                        else if (command.startsWith("MODE"))
                                option = AdminComm.CHANGE_MODE;
                        else {
                                Log.getInstance().log_error("Invalid option passed: "
                                                            +option,null);
                                if (cmdButton != null )
                                        cmdButton.setEnabled(true);
                                return;
                        }
	
                        if ((command.startsWith("START_LH")
                             || command.startsWith("MODE_LH"))
                            && noneRB.isSelected()) {

                                Log.getInstance().show_error(frame,"Error",
                                                             "Please specify mode.",null);
                                if (cmdButton != null )
                                        cmdButton.setEnabled(true);
                                return; 
                        }


                        String lhopt = null;
                        String ftpopt = " -sHOT ";
                        String modestr = "";
                        
                        if (option==AdminComm.CHANGE_MODE) {
                                if (dormantRB.isSelected())
                                {
                                        modestr = "DORMANT";
                                        lhopt = ";"+AdminComm.CHANGE_MODE+" 0;";
                                }
                                else if (hotRB.isSelected())
                                {
                                        modestr = "HOT";
                                        lhopt = ";"+AdminComm.CHANGE_MODE+" 1 HOT;";
                                }
                                else if (coldRB.isSelected())
                                {
                                        modestr = "COLD";
                                        lhopt = ";"+AdminComm.CHANGE_MODE+" 1 COLD;";
                                }
                                else
                                {
                                        modestr = "NORMAL";
                                        lhopt = ";"+AdminComm.CHANGE_MODE+" 1 NORMAL;";
                                }
                                
                        }
                        else
                        {
                                lhopt = " -D ";
                                if (!dormantRB.isSelected()) {
                                        lhopt = " -A ";
                                        if (normalRB.isSelected())
                                        {
                                                modestr = "NORMAL";
                                                lhopt += " -sNORMAL ";
                                                ftpopt = " -sNORMAL ";
                                        }
                                        else if (hotRB.isSelected())
                                        {
                                                modestr = "HOT";
                                                lhopt += " -sHOT ";
                                                ftpopt = " -sHOT ";
                                        }
                                        else if (coldRB.isSelected())
                                        {
                                                modestr = "COLD";
                                                lhopt += " -sCOLD ";
                                                ftpopt = " -sCOLD ";
                                        }
                                }
                                else
                                        modestr = "DORMANT";
                                
                        }
                        
                        String msg=null;
                        StringBuffer prompt = new StringBuffer("Are you sure you want");
                        if (command.startsWith("START_LH"))
                        {
                                msg = "Starting all line handlers on selected DCM(s)..";
                                prompt.append(" to start all line handlers in ")
                                        .append(modestr)
                                        .append(" mode \non the selected DCM(s).?");
                        }
                        else if (command.startsWith("STOP_LH"))
                        {
                                msg = "Stopping ALL line handlers on selected DCM(s)..";
                                prompt.append(" to stop all line handlers \non the selected DCM(s) ?");
                        }
                        else
                        {
                                msg = "Changing mode of ALL line handlers on selected DCM(s) ..";
                                prompt.append(" to change mode to ")
                                        .append(modestr)
                                        .append(" \non the selected DCM(s).?");
                        }


                        if (javax.swing.JOptionPane.YES_OPTION
                            != ConfirmDialog.show_confirm(frame, "Confirmation dialog",
                                                              prompt.toString())) {
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	
                        try {
                                rwLock.readLock().acquire();
                        } catch (InterruptedException ie ) {
                                Log.getInstance().log_error("Service handler interrupted",ie);
                                if (cmdButton != null ) 
                                        cmdButton.setEnabled(true);
                                return;
                        }

	

                        updateTimer.stop();

	
                        taskListener.taskStarted(msg);


                        DCMStatusDataModel dcmModel 
                                = (DCMStatusDataModel)distrTable.getModel();

                        boolean error = false;

                        
        
                        

                        java.util.HashMap dcmHostMap = new java.util.HashMap(20);
                        String location = (String)locationComboBox.getSelectedItem();
                        
                        for (int r = 0; r < selected_rows.length; r++) {

                                String dcmkey = (String)distrTable.getValueAt(selected_rows[r],0);


                                DCMDataServicesStatusModel dataServicesModel
                                        = new DCMDataServicesStatusModel(Constants.DCMServicesTable,
                                                                         Constants.GLB_TAG_DCM_PREFIX+dcmkey);
	  

                                try {
                                        dataServicesModel.Update();
                                } catch (Exception e) {
                                        continue;
                                }
	      
          


                                

                                String version =  dataServicesModel.getSWVersion();
                                if (version.equals(Constants.DEFAULT_SW_VERSION))
                                        version = Constants.DEFAULT_SW_VERSION_DIR;

                                String host1 = dataServicesModel.getDC1Host();
                                String host2 = dataServicesModel.getDC2Host();
                                String location1 = dataServicesModel.getDC1Location();
                                String location2 = dataServicesModel.getDC2Location();

                                
                                boolean isDJNEWS_DCM = dataServicesModel.isDJNEWS_DCM();

                                

         

                                String idsdir = Constants.idsdir;
                                if (idsdir==null)
                                        idsdir="/ids2";
                                idsdir.trim();
                                idsdir = idsdir+"/dcm/"+version;

                                int inx = command.indexOf('_');



                                    /* BEGIN Line handler servies */

                                java.util.StringTokenizer rowTokenizer, colTokenizer;

                                try {
                                           
                                        StringBuffer distrreqbuf = new StringBuffer();
                                        ConfigComm.getServKey(distrreqbuf,ConfigComm.GET_DCM_DIST_ALL_INFO,
                                                              dcmkey);
                                        byte[] b = ConfigComm.configRequest(distrreqbuf);
                                        String respbuf = new String(b);
                                        int indx = respbuf.indexOf(ConfigComm.CONF_STX) + 1;

                                        String databuf = respbuf.substring(indx);

                                        StringBuffer rowSeparator, colSeparator;
                                        rowSeparator = new StringBuffer();
                                        colSeparator = new StringBuffer();

                                        rowSeparator.append(ConfigComm.CONF_STX).
                                                append(ConfigComm.CONF_ETX).
                                                append(ConfigComm.CONF_FS);

                                        colSeparator.append(ConfigComm.CONF_ETX).
                                                append(ConfigComm.CONF_RS);

                                        rowTokenizer = new
                                                java.util.StringTokenizer(databuf,rowSeparator.toString());

                                        
                                                                                
                                                
                                        
                                        while (rowTokenizer.hasMoreTokens()) {
                                                rowTokenizer.nextToken(); // Skip "key"
                                                String fstr = rowTokenizer.nextToken();
                                                colTokenizer = new
                                                        java.util.StringTokenizer(fstr, colSeparator.toString());

                                                String did = colTokenizer.nextToken();
                                                String dcmtag =  colTokenizer.nextToken();
                                                String desc =  colTokenizer.nextToken();
                                                String h1 = colTokenizer.nextToken();
                                                String h2 =  colTokenizer.nextToken();
                                                String ph1 = colTokenizer.nextToken();
                                                String ph2 =  colTokenizer.nextToken();
                                                
                                                String l1,l2;
                                                if (colTokenizer.hasMoreTokens())
                                                        l1 =  colTokenizer.nextToken();
                                                    
                                                if (colTokenizer.hasMoreTokens())
                                                        l2 =  colTokenizer.nextToken();

                                                String primary_location = null;
                                                
                                                if (colTokenizer.hasMoreTokens())
                                                    primary_location = colTokenizer.nextToken();


                                                if (primary_location == null) 
                                                {
                                                        try {
                                                                HashMap m =
                                                                        ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                                                                
                                                                primary_location = (String)m.get("HOME_LOCATION");
                                                        } catch (Exception de) {
                                                        }
                                                }
                                                else
                                                        System.out.println("Location already loaded.");
                                                
                                                String host = null;
                                                String did_location = null;
                                                
                                                if (primary_location == null ) {
                                                    
                                                        if (location.equals(Constants.HOME_LOCATION))
                                                                host = host1;
                                                        if (location.equals(Constants.AWAY_LOCATION))
                                                                host = host2;
                                                        if ((location1 != null) && location.equals(location1))
                                                                host = host1;
                                                        if ((location2 != null) && location.equals(location2))
                                                                host = host2;

                                                } else {
                                                    
                                                        if (location.equals(Constants.HOME_LOCATION)) {
                                                                did_location = Constants.HOME_LOCATION;
                                                                if (primary_location.equals("1"))
                                                                        host = host1;
                                                                else
                                                                        host = host2;
                                                        }
                                                        if (location.equals(Constants.AWAY_LOCATION)) {
                                                                did_location = Constants.AWAY_LOCATION;
                                                                if (primary_location.equals("1"))
                                                                        host = host2;
                                                                else
                                                                        host = host1;
                                                        }
                                                        if (location.equals(Constants.DC1_LOCATION) ||
                                                                ((location1 != null) && location.equals(location1))) {
                                                            
                                                                host = host1;
                                                                if (primary_location.equals("1"))
                                                                        did_location = Constants.HOME_LOCATION;
                                                                else
                                                                        did_location = Constants.AWAY_LOCATION;
                                                        }
                                                        
                                                        if (location.equals(Constants.DC2_LOCATION) ||
                                                                ((location2 != null) && location.equals(location2))) {
                                                              
                                                            host = host2;
                                                                if (primary_location.equals("2"))
                                                                        did_location = Constants.HOME_LOCATION;
                                                                else
                                                                        did_location = Constants.AWAY_LOCATION;
                                                        }
                                                        
                                                }
                                                if (host == null) {
                                                        Log.getInstance().log_error("Can't find target("
                                                                                    +location+") host for distributor: "+did,
                                                                                    null);
                                                        continue;
                                                }



                                                StringBuffer reqbuf
                                                        = (StringBuffer)dcmHostMap.get(host);
                                                if (reqbuf == null) 
                                                        reqbuf = new StringBuffer();
                                                String cmdline = lhopt;
                                                String activeLoc = (String)ConfigComm.fixedLocationsMap.get(did);
                                                if ((did_location != null) && (activeLoc != null)) {
                                                
                                                        if (did_location.equalsIgnoreCase(activeLoc)) {
                                                                if (option == AdminComm.CHANGE_MODE)
                                                                        cmdline = CMDLINE_DISTR_MODE_NORMAL;
                                                                else
                                                                        cmdline = CMDLINE_DISTR_NORMAL;
                                                        }
                                                        else {
                                                                if (option == AdminComm.CHANGE_MODE)
                                                                        cmdline = CMDLINE_DISTR_MODE_DORMANT;
                                                                else
                                                                        cmdline = CMDLINE_DISTR_DORMANT;
                                                        }
                                                        System.out.println("DID: "+did+" CMDLINE: "+cmdline);
                                                }

                                                
                                                if (option==AdminComm.CHANGE_MODE) {
                                                        reqbuf.append(ConfigComm.CONF_GS);
                                                        reqbuf.append(did+cmdline);
                                                } else {
                                                        reqbuf.append(ConfigComm.CONF_GS)
                                                                .append(idsdir+"/bin/"+"dcm_linehand")
                                                                .append(";-d;-d "+did+cmdline+";");
                                                        if (isDJNEWS_DCM)  {
                                                                reqbuf.append(ConfigComm.CONF_GS)
                                                                        .append(idsdir+"/bin/ftp_handler")
                                                                        .append(";-d;-d ")
                                                                        .append(did)
                                                                        .append(ftpopt)
                                                                        .append(";");
                                                        }
                                                }
                                                
                                                dcmHostMap.put(host, reqbuf);
                                                
                                        }
                                } catch (DBException dbex) {
                                        int errno = dbex.getErrorNo();

                                        if (errno==Constants.KEY_NOT_FOUND)
                                                continue;

                                        error = true;
                                        switch (errno) {
                                            case Constants.MODE_ERR:
                                                    Log.getInstance().log_error(
                                                            "Could not retrieve distributor list for DCM: "
                                                            +dcmkey+"\nConfiguration server(s) not in primary mode.",
                                                            dbex);
                                                    break ;
                                            case Constants.SYNC_ERR:
                                                    Log.getInstance().log_error(
                                                            "Could not retrieve distributor list for DCM: "
                                                            +dcmkey+"\nConfiguration servers are currently syncing.\n",
                                                            dbex);
                                                    break ;
                                            case Constants.COMM_ERR:
                                                    Log.getInstance().log_error(
                                                            "Could not retrieve distributor list for DCM: "
                                                            +dcmkey+"\nCould not connect to configuration server.",
                                                            dbex);
                                                    break ;
                                            default:
                                                    Log.getInstance().log_error(
                                                            "Could not retrieve distributor list for DCM: "
                                                            +dcmkey,
                                                            dbex);
                                                    break ;
                                        }
                                        continue;
                                } catch (Exception e) {
                                        error = true;
                                        Log.getInstance().log_warning("Could not get line handler configuration for DCM: "
                                                                      +dcmkey,e);
                                        continue;
                                }

                                
                                

                                    /* End Line handler services */

                                


                        } // for r < selected_rows.length

                        java.util.Iterator iter = dcmHostMap.keySet().iterator();
                        java.util.Vector workers = new java.util.Vector(selected_rows.length);
                
                        while (iter.hasNext()) {
                                String host = (String)iter.next();
                                StringBuffer reqbuf = (StringBuffer)dcmHostMap.get(host);
                        
                        
                                if (Constants.DEBUG && Constants.Verbose>2)
                                        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n"+
                                                           "HOST: "+host+"\n"+reqbuf.toString()
                                                           +"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");

                                Utils.AdminWorker worker =
                                        new Utils.AdminWorker(option, host, reqbuf.toString());


                                workers.add(worker);
                                worker.start();
                        }
                        

                                
                        noneRB.setSelected(true);

                        for ( int n = 0; n < workers.size(); n++ ) {
                                Utils.AdminWorker worker = (Utils.AdminWorker)workers.get(n);
                                    //System.out.println("Retrieving cstatus from thread :"+n);
                                Utils.AdminStatus status = (Utils.AdminStatus)worker.get();
                                    //System.out.println("Retrieved cstatus from thread :"+n);
                                if (status.status != 0) {
                                        error = true;
                                        if (status.response.length()>0)
                                                Log.getInstance().log_error("Error :"
                                                                            +status.response.toString(),
                                                                            null);
                                }
                        }



                        if (error) {
                                Log.getInstance().show_error(frame, "Error",
                                                             "Please check log for "
                                                             +"error messages",null);

                                taskListener.taskEnded("Request completed with errors.");
                        } else {
                                taskListener.taskEnded("Request completed successfully.");
                        }

                        rwLock.readLock().release();

                        if (cmdButton != null )
                                cmdButton.setEnabled(true);

                        updateTimer.start();


                }
        }
        
        
        
}

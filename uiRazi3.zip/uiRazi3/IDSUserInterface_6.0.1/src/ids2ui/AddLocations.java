/*
**  SCCS Info :  "@(#)AddLocations.java	1.2    04/04/02"
*/

package ids2ui;
import java.util.*;


public class AddLocations {
        


        static public void
        saveDSP(int dbreq, HashMap configMap)
                throws Exception
        {
                StringBuffer reqbuf = new StringBuffer();
                
                ConfigComm.convertHashMap(reqbuf,
                                          Constants.GLB_TAG_DSP,
                                          dbreq, configMap,
                                          null, true);
                
                    /*
                      System.out.println("SAVE BUF ("
                                   + reqbuf.length()
                                   + "): " + reqbuf.toString());
                    */


                ConfigComm.configRequest(reqbuf);
        }
        
        
        
        
        
        static public void
        saveDCM(int dbreq, String id, HashMap configMap)
                throws Exception
        {
                
                StringBuffer reqbuf = new StringBuffer();
                
                ConfigComm.convertHashMap(reqbuf,
                                          Constants.GLB_TAG_DCM_PREFIX+id,
                                          dbreq, configMap,
                                          null, true);
                
                    /*
                      System.out.println("SAVE BUF ("
                                   + reqbuf.length()
                                   + "): " + reqbuf.toString());
                    */
                
                ConfigComm.configRequest(reqbuf);

        }
        



        static public void
        saveDistributor(int dbreq, String id, HashMap configMap)
                throws Exception
        {
        
                StringBuffer reqbuf = new StringBuffer();
                
                ConfigComm.convertHashMap(reqbuf,
                                          Constants.GLB_TAG_DISTR_PREFIX+id,
                                          dbreq, configMap,
                                          null, true);
                
                    /*
                      System.out.println("SAVE BUF ("
                                   + reqbuf.length()
                                   + "): " + reqbuf.toString());
                    */

                ConfigComm.configRequest(reqbuf);
        }


        static private void
        addLocations(HashMap map, String l1, String l2)
        {
                map.put(Constants.LOCATION1, l1);
                map.put(Constants.LOCATION2, l2);
        }


        static private String
        getHomeIndex(String dcm) 
        {
                int i = 1;
                if (dcm.startsWith("DCMN")) {
                        
                        String s = dcm.substring("DCMN".length(), dcm.length());
                        try {
                                i = (Integer.parseInt(s) % 2 == 0) ? 2 : 1;
                        }
                        catch (NumberFormatException nfe){
                        }
                }
                
                return Integer.toString(i);
        }
        
                        


                        
        public static void main(String[] args)
                throws Exception
        {



                StringBuffer userName = new StringBuffer();
                StringBuffer hostList = new StringBuffer();
                StringBuffer idsDir   = new StringBuffer();



                if (args.length > 1) {
			System.out.println("Usage: java -jar AddLocations.java.jar  dsp_host_list");
			System.exit(1);
                }
                
                
                
                if (args.length > 0) {
			userName.append("ids2adm");
			idsDir.append("/ids2");
			hostList.append(args[0]);
                } 
                else {
			UILoginDialog dlg
                                = new UILoginDialog(new javax.swing.JFrame(),
                                                    true);
			dlg.show();
			if (!dlg.getLoginParams(userName,hostList,idsDir)) 
                                System.exit(1);
                }



                System.out.println("Configuration host list: "
                                   +hostList.toString());
                
                ConfigComm.initLoginLite(userName.toString(),
                                         hostList.toString(),
                                         idsDir.toString());
                
                



                
                
                
                    //Add GLB_LOCATION_LIST
                StringBuffer reqbuf = new StringBuffer();
                
                ConfigComm.saveKeyValue(reqbuf,"GLB_LOCATION_LIST",
                                        "South Brunswick	Secaucus	London: AP House(P1)	London: AP House(P2)");
                ConfigComm.configRequest(reqbuf);

                reqbuf.setLength(0);
                ConfigComm.saveKeyValue(reqbuf,"GLB_ALWAYS_ACTIVE_LOCATION_LIST",
                                        "DC:HOME,DD:HOME");
                ConfigComm.configRequest(reqbuf);




                java.util.HashMap map = null;


                System.out.println("Updating DSP configuration..");
                
                map = ConfigComm.getHashMap(Constants.GLB_TAG_DSP);
                addLocations(map,"South Brunswick", "Secaucus");
                saveDSP(ConfigComm.SAVE_DSP_KEY, map);

                DSPDistributorStatusModel dspDistrModel
                        = new DSPDistributorStatusModel();
                dspDistrModel.Update();
                System.out.println("Updating DSP LH configuration..");
                int nd = dspDistrModel.getRowCount();
                for (int j = 0; j < nd; j++) {
                        String did = (String)dspDistrModel.getValueAt(j, 0);
                        map = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                        map.put("HOME_LOCATION", "1");
                        
                        saveDistributor(ConfigComm.SAVE_DISTRIBUTOR_KEY,
                                  did,map);
                }
                

                DCMStatusDataModel dcmModel = new DCMStatusDataModel();

                dcmModel.Update();
                int numDcms = dcmModel.getRowCount();
                
                System.out.println("Updating DCM onfiguration..");
                
                for (int i = 0; i< numDcms; i++) {
                        String dcm = (String)dcmModel.getValueAt(i, 0);
                        System.out.println("DCM -> "+dcm+" ["+(i+1)+" of "+numDcms+" ]");
                        

                        map = ConfigComm.getHashMap(Constants.GLB_TAG_DCM_PREFIX+dcm);
                        if (dcm.equals("DCMN9"))
                                addLocations(map,"London: AP House(P1)", "London: AP House(P2)");
                        else 
                                addLocations(map,"South Brunswick", "Secaucus");

                        saveDCM(ConfigComm.SAVE_DCM_KEY, dcm, map);

                        DCMDistributorStatusModel distrModel
                                = new DCMDistributorStatusModel(dcm);

                        distrModel.Update();

                        int numDistr = distrModel.getRowCount();

                        String home = getHomeIndex(dcm);
                        
                        System.out.println("Updating DCM LH configuration.."
                                           +" ("+numDistr+")");     
                        for (int j = 0; j < numDistr; j++) {
                                String did = (String)distrModel.getValueAt(j, 0);
                                map = ConfigComm.getHashMap(Constants.GLB_TAG_DISTR_PREFIX+did);
                                if (did.equals("DC"))
                                        map.put("HOME_LOCATION", "1");
                                else if (did.equals("DD"))
                                        map.put("HOME_LOCATION", "2");
                                else
                                        map.put("HOME_LOCATION", home);

                                saveDistributor(ConfigComm.SAVE_DISTRIBUTOR_KEY,
                                           did,map);
                        }
                }

                System.out.println("Configuration updated.");
                
                System.exit(0);
        
        }

 
}

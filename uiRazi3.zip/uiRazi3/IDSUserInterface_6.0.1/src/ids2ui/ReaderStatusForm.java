/*
**  SCCS Info :  "@(#)ReaderStatusForm.java	1.9    08/12/05"
*/
/*
 * ReaderStatusForm.java
 *
 * Created on October 16, 2000, 3:21 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class ReaderStatusForm 
    extends javax.swing.JFrame
    implements TaskListener, FormReturner
{

    ReaderStatusModel statusModel = null;
    javax.swing.JTable statusTable = null;
    javax.swing.JFrame myFrame;


    private Utils.UpdateTimer updateTimer = null;
    private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();

    private volatile boolean isExiting = false;

  
    /** Creates new form ReaderStatusForm */
    public ReaderStatusForm(int type, int which, String tag, String name) 
	throws Exception 
    {	

	if ((type!=Constants.DSP_READER)
	    && (type!=Constants.DCM_READER)
	    && (type!=Constants.MSGMGR)) {
	    setVisible(false);
	    dispose();
	    throw new Exception("Status request for invalid Reader type"
				+type);
	}
    
	myFrame = this;
            
	StringBuffer key = new StringBuffer(Constants.STATUS_READER_PREFIX);
	
	if (type==Constants.DSP_READER) {
	    setTitle("DSP Reader status");
	    key.append(Constants.GLB_TAG_DSP);
	} else if (type==Constants.DCM_READER) {
	    setTitle("DCM Reader status");
	    key.append(tag);
	} else if (type==Constants.MSGMGR) {
	    setTitle("Message Manager status");
	    key.append(tag);
	}
    
	key.append("_");
	if (name!=null) 
	    key.append(name);
    
	key.append("_").append(which);



	javax.swing.JFrame f 
	    = (javax.swing.JFrame)WindowEventAdapter.getInstance()
	    .findWindow(key.toString());


	if (f!=null) {
	    /*f.show();
	    setVisible(false);
	    dispose();*/
	    throw new Utils.DuplicateWindowException();
	}



    	
    
	initComponents ();
	myInitComponents(type,which,tag, name);
	
	if (type==Constants.DSP_READER) {
	    setTitle("DSP Reader status");
	} else if (type==Constants.DCM_READER) {
	    setTitle("DCM Reader status");
	} else if (type==Constants.MSGMGR) {
	    setTitle("Message Manager status");
	}
	pack ();

	WindowEventAdapter.getInstance().registerWindow(key.toString(),this);

	updateTimer.start();


    }






    public void Refresh () 
    {

	if (statusModel==null) return;

	taskStarted(new java.util.EventObject(this));
	try {
	    rwLock.writeLock().acquire();
	} catch (Exception e){
		taskEnded();
		return;
	}
	statusModel.Refresh();

   	rwLock.writeLock().release();     
	taskEnded();

    }//GEN-LAST:event_refresh




    public void taskStarted(java.util.EventObject evt) {
	taskStarted("Updating status...");
    }

    public void taskStarted() {
	taskStarted((String)null);	
    }

    public void taskStarted(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskStarted(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else { 
	    if (s==null)
		statusPanel.start();
	    else
		statusPanel.start(s);
	}

    }




    public void taskEnded() {
	taskEnded((String)null);
    }

    public void taskEnded(final String s) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(s);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {
	    statusPanel.stop();

	    if (s!=null)
		statusPanel.showStatus(s);
	    else
		statusPanel.clear();

	    repaint();
	}


    }



    public void taskEnded(final java.util.EventObject evt) {

	if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
	    Runnable callMe = new Runnable() {
		public void run() {
		    taskEnded(evt);
		}
	    };	
	    javax.swing.SwingUtilities.invokeLater(callMe);

	} else {

	    if (evt instanceof ReaderStatusEvent ) {
		ReaderStatusEvent e = (ReaderStatusEvent)evt;
		if (e.getStatus()==0) {
		    nameLabel.setText(e.getName());
		    hostLabel.setText(e.getHost());
		    timeLabel.setText(e.getTimeStamp());
		    modeLabel.setText(e.getMode());
		    taskEnded("Status updated @ "+new java.util.Date().toString());
		} else {
		    timeLabel.setText("");
		    modeLabel.setText("");
		    taskEnded(e.getError());
		}
	    } else {
		taskEnded("Status updated.");
	    }
	}

    }




    private void myInitComponents(int type, int which, String tag, String name) 
	throws Exception
    {

	try {
	    statusModel = new ReaderStatusModel(type,which,tag, name);
      
	} catch (Exception e) { 
	    //Log.getInstance().show_error(this,"Error",e.getMessage(),e);
	    Log.getInstance().log_error(e.getMessage(),e);
	    setVisible(false);
	    dispose();
	    throw e;
	}


	statusTable = new javax.swing.JTable(statusModel);

	    

	javax.swing.JScrollPane jScrollPane1 = 
	    new javax.swing.JScrollPane(statusTable);
	jPanel2.add (jScrollPane1, java.awt.BorderLayout.CENTER);



	javax.swing.table.JTableHeader header = statusTable.getTableHeader();
	header.addMouseListener(statusModel.new ColumnListener(statusTable,
							       rwLock));
	
    
	
	nameLabel.setForeground(statusTable.getForeground());
	modeLabel.setForeground(statusTable.getForeground());
	hostLabel.setForeground(statusTable.getForeground());
	timeLabel.setForeground(statusTable.getForeground());
    

	Utils.UpdateEventListener updater 
	    = new Utils.UpdateEventListener(rwLock, this,
					    statusModel);

	updateTimer = 
	    new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, 
				  updater);
	

    }




    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the FormEditor.
     */
    private void initComponents () {//GEN-BEGIN:initComponents
	jPanel1 = new javax.swing.JPanel ();
	jButton1 = new javax.swing.JButton ();
	jButton2 = new javax.swing.JButton ();
	jPanel2 = new javax.swing.JPanel ();
	jPanel4 = new javax.swing.JPanel ();
	jLabel1 = new javax.swing.JLabel ();
	nameLabel = new javax.swing.JLabel ();
	jLabel3 = new javax.swing.JLabel ();
	modeLabel = new javax.swing.JLabel ();
	jLabel5 = new javax.swing.JLabel ();
	hostLabel = new javax.swing.JLabel ();
	jLabel7 = new javax.swing.JLabel ();
	timeLabel = new javax.swing.JLabel ();
	statusPanel = new ids2ui.StatusPanel ();
        masterPanel = new javax.swing.JPanel();
	masterPanel.setLayout (new java.awt.GridBagLayout ());
	java.awt.GridBagConstraints gridBagConstraints1;
	setTitle ("Reader Status");
	addWindowListener (new java.awt.event.WindowAdapter () {
	    public void windowClosing (java.awt.event.WindowEvent evt) {
		exitForm (evt);
	    }
	}
			   );

	jPanel1.setLayout (new java.awt.FlowLayout (1, 25, 5));

        jButton1.setText ("Refresh");
        jButton1.addActionListener (new java.awt.event.ActionListener () {
	    public void actionPerformed (java.awt.event.ActionEvent evt) {
		refresh (evt);
	    }
        }
				    );
  
        jPanel1.add (jButton1);
  
        jButton2.setText ("Close");
        jButton2.addActionListener (new java.awt.event.ActionListener () {
	    public void actionPerformed (java.awt.event.ActionEvent evt) {
		closeForm (evt);
	    }
        }
				    );
  
        jPanel1.add (jButton2);
        jButton2.setVisible(false);

	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.gridx = 0;
	gridBagConstraints1.gridy = 1;
	gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints1.weightx = 1.0;
	masterPanel.add (jPanel1, gridBagConstraints1);

	jPanel2.setLayout (new java.awt.BorderLayout ());
	jPanel2.setBorder (new javax.swing.border.TitledBorder(""));

        jPanel4.setLayout (new java.awt.GridBagLayout ());
        java.awt.GridBagConstraints gridBagConstraints2;
        jPanel4.setBorder (new javax.swing.border.TitledBorder(""));
  
	jLabel1.setText ("Name:");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
	jPanel4.add (jLabel1, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.weightx = 0.5;
	jPanel4.add (nameLabel, gridBagConstraints2);
    
	jLabel3.setText ("Mode:");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 0;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
	jPanel4.add (jLabel3, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 1;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.weightx = 0.5;
	jPanel4.add (modeLabel, gridBagConstraints2);
    
	jLabel5.setText ("Host:");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
	jPanel4.add (jLabel5, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.weightx = 0.5;
	jPanel4.add (hostLabel, gridBagConstraints2);
    
	jLabel7.setText ("Time:");
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 2;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.insets = new java.awt.Insets (5, 5, 5, 10);
	jPanel4.add (jLabel7, gridBagConstraints2);
    
    
	gridBagConstraints2 = new java.awt.GridBagConstraints ();
	gridBagConstraints2.gridx = 3;
	gridBagConstraints2.gridy = 1;
	gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints2.weightx = 0.5;
	jPanel4.add (timeLabel, gridBagConstraints2);
    
        jPanel2.add (jPanel4, java.awt.BorderLayout.NORTH);
  

	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.gridx = 0;
	gridBagConstraints1.gridy = 0;
	gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
	gridBagConstraints1.weightx = 1.0;
	gridBagConstraints1.weighty = 1.0;
	masterPanel.add (jPanel2, gridBagConstraints1);



	gridBagConstraints1 = new java.awt.GridBagConstraints ();
	gridBagConstraints1.gridx = 0;
	gridBagConstraints1.gridy = 2;
	gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gridBagConstraints1.weightx = 1.0;
	masterPanel.add (statusPanel, gridBagConstraints1);
        masterPanel.setName("reader panel");
    }//GEN-END:initComponents

    private void refresh (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;


	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, command) {
	    public Object construct() {
		Refresh();
		return null;
	    }

	    public void finished(){
		if (cmdButton!=null) cmdButton.setEnabled(true);
	    }
	};

	sw.start();
	
    }//GEN-LAST:event_refresh

    public javax.swing.JPanel getForm(){
        return masterPanel;
    }


    private void closeForm (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeForm
	// Add your handling code here:
	exitForm(null);
    }//GEN-LAST:event_closeForm

    /** Exit the Application */
    public void 
	exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm

	if (isExiting) return;
	
	isExiting = true;
	
	if (updateTimer!=null)
	    updateTimer.stop();

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final ReaderStatusForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    rwLock.writeLock().acquire();
		    if (updateTimer!=null)
			updateTimer.stop();
		    //model.stop();
		} catch (InterruptedException ie ) {}
		return null;
	    }

	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();
    }//GEN-LAST:event_exitForm

 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel modeLabel;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel hostLabel;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel timeLabel;
    private ids2ui.StatusPanel statusPanel;
    private javax.swing.JPanel masterPanel;
    // End of variables declaration//GEN-END:variables

}

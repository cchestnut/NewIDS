/*
**  SCCS Info :  "@(#)DistrStatusDataModel.java	1.12    07/12/14"
*/
/*
 * DistrStatusDataModel.java
 *
 * Created on May 24, 2000, 5:08 PM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */

public class DistrStatusDataModel 
	extends javax.swing.table.AbstractTableModel 
    implements Runnable 
{
  

    private Thread updater = null;
    private int _count = 0;
    private String dcmlist = null;

	private java.util.HashMap distrData = null;


    private javax.swing.event.EventListenerList listenerList;
    private int lhtype = -1;
    static private DistrStatusDataModel dcm_instance = null;
    static private DistrStatusDataModel dsp_instance = null;

 	protected int     m_sortCol = 0;
  	protected boolean m_sortAsc = true;
  	protected java.util.Vector m_vector = null;
  	protected int m_columnsCount = Constants.DistributorStatusTableColumnNames.length;







    
    public static DistrStatusDataModel getInstance(int option) {
	switch (option ) {
	case ConfigComm.GET_DCM_DIST_ALL_INFO:
	    if (dcm_instance == null) {
		synchronized(DistrStatusDataModel.class) {
		    if (dcm_instance == null) {
			dcm_instance = new DistrStatusDataModel(option);
		    }
		}
	    }
	    //System.out.println("Returning dcm instance");
	    return dcm_instance;
	    
	case ConfigComm.GET_DSP_DIST_ALL_INFO:
	    if (dsp_instance == null) {
		synchronized(DistrStatusDataModel.class) {
		    if (dsp_instance == null) {
			dsp_instance = new DistrStatusDataModel(option);
		    }
		}
	    }
	    //System.out.println("Returning dsp instance");
	    return dsp_instance;
	}
	
	return null;
    }
    

  public DistrStatusDataModel(int option)
  {
    lhtype = option;
    if (option == ConfigComm.GET_DSP_DIST_ALL_INFO)
      m_columnsCount--;
    
	m_vector = new java.util.Vector(50);
    _initialize();

  }

  
  public void _initialize() {
          _count = 0;
		  distrData  = new java.util.HashMap(100);
          listenerList = new javax.swing.event.EventListenerList();
  }





  public  void attach(TaskListener l) {
    synchronized (listenerList) {

      listenerList.add(TaskListener.class, l);

      _count++;
      if (updater == null) {
        updater = new Thread(this);
        updater.start();
      }
    }
    if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("DistrStatusDataModel: returning instance: "+_count);
  }

  public  void deattach(TaskListener l) {

    synchronized (listenerList) {

      _count--;

      if (_count <= 0) {
        updater.interrupt();
        try {
          updater.join(Constants.ServiceStatusUpdateMilliSecs);
        } catch (InterruptedException e) {
        }
        updater=null;
        dcmlist=null;
      }

      listenerList.remove(TaskListener.class, l);
    }
  }

   protected void fireTaskStarted(java.util.EventObject e) {
    // Guaranteed to return a non-null array
    Object[] listeners = listenerList.getListenerList();
    // Process the listeners last to first, notifying
    // those that are interested in this event
    for (int i = listeners.length-2; i>=0; i-=2) {
      if (listeners[i]==TaskListener.class) {
        TaskListener lis =
        (TaskListener) listeners[i+1];
        try {
          lis.taskStarted(e);
        }
        catch (Exception ex) {
          // Warning: Unresponsive listeners will be removed!
          System.err.println("Callback failed: "+ex);
          System.err.println("Removing "+lis);
          listenerList.remove(TaskListener.class,lis);
        }
      }
    }
  }
   protected void fireTaskEnded(java.util.EventObject e) {
    // Guaranteed to return a non-null array
    Object[] listeners = listenerList.getListenerList();
    // Process the listeners last to first, notifying
    // those that are interested in this event
    for (int i = listeners.length-2; i>=0; i-=2) {
      if (listeners[i]==TaskListener.class) {
        TaskListener lis =
        (TaskListener) listeners[i+1];
        try {
          lis.taskEnded(e);
        }
        catch (Exception ex) {
          // Warning: Unresponsive listeners will be removed!
          System.err.println("Callback failed: "+ex);
          System.err.println("Removing "+lis);
          listenerList.remove(TaskListener.class,lis);
        }
      }
    }
  }


  public void run() {

    while (!Constants.isExiting && _count>0) {
	
	synchronized (listenerList) {
	    fireTaskStarted(new java.util.EventObject(this));
	    Update();
	    fireTaskEnded(new java.util.EventObject(this));
	}
	try {
	    Thread.sleep(Constants.ServiceStatusUpdateMilliSecs);
	} catch (InterruptedException e) {
	    continue;
	}
    }
  }
    



  synchronized public void loadConfig(String dlist) {
    //dcmlist = dlist;
    if (updater!=null)
    updater.interrupt();
    if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("Load Config called");
  }



  public boolean isCellEditable(int r, int c) {
    //if (c <= 3) return false;
    /*String value = (String) getValueAt(r,c);
    if (value==null) return false;
    if (value.startsWith("Running") 
		|| value.startsWith("ACTIVE")
		|| value.startsWith("DORMANT")) 
		return true;
	*/
    return false;
  }


  public String getHost1(int r) {
	 String id = (String)getValueAt(r,0);
	 if (id!=null) {
		 String data[] = (String[])distrData.get(id);
		 return data[0];
	 }
	 return null;
  }

  public String getHost2(int r) {
	 String id = (String)getValueAt(r,0);
	 if (id!=null) {
		 String data[] = (String[])distrData.get(id);
		 return data[1];
	 }
	 return null;
  }



    private Object getRunningListFromHost(final String host) {

      
      final SwingWorker worker = new SwingWorker() {
	  
	public Object construct() {
	    String distList = null;
	    
	    try {
		
		if (Constants.DEBUG && Constants.Verbose>2)
		    System.out.println("Retrieving status  from: "+host);
		
		byte[] respb = AdminComm.serviceRequest(host,
					AdminComm.EXEC_COMMAND,
					AdminComm.LIST_IDS2_PROC_BY_KEY,
					"dsp_linehand,dcm_linehand   -d ");

		distList = new String(respb);
		int inx = distList.indexOf(ConfigComm.CONF_STX)+1;
		
		if (inx <= 0)
		    distList = null;
		else
		    distList = distList.substring(inx);
		
		
	    } catch (Exception e) {
		distList = null;
	    }
	    
	    return distList;
	}
	  
	  //Runs on the event-dispatching thread.
	  public void finished() {
	      
	  }	
	  
      };  // new SwingWorker */
      
      // Start the thread 
      worker.start();
      
      return worker.get();


    }





  private void Update() {




	if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("DistrStatusDataModel: Updating..");

    try {

      StringBuffer reqbuf = new StringBuffer();
      String          respbuf, databuf;
      byte[] b;
      java.util.StringTokenizer rowTokenizer, colTokenizer;
      StringBuffer statusQuery = new StringBuffer();
      StringBuffer hostQuery = new StringBuffer();

      ConfigComm.getServKey(reqbuf,lhtype,dcmlist);
      b = ConfigComm.configRequest(reqbuf);
      respbuf = new String(b);
      int index = respbuf.indexOf(ConfigComm.CONF_STX) + 1;
      

      databuf = respbuf.substring(index);

      StringBuffer rowSeparator, colSeparator;
      rowSeparator = new StringBuffer();
      colSeparator = new StringBuffer();

      rowSeparator.append(ConfigComm.CONF_STX).
      append(ConfigComm.CONF_ETX).
      append(ConfigComm.CONF_FS);

      colSeparator.append(ConfigComm.CONF_ETX).
      append(ConfigComm.CONF_RS);

      
      
      rowTokenizer = new
      java.util.StringTokenizer(databuf,rowSeparator.toString());

      int numRows = 0;
      int oldRows = m_vector.size();
      int sColumn = 2;
      if (lhtype == ConfigComm.GET_DSP_DIST_ALL_INFO)
        sColumn--;
      java.util.HashMap hostmap = new java.util.HashMap(20);

      while (rowTokenizer.hasMoreTokens()) {
      	String [] rowData = new String [m_columnsCount];
        String [] hostData = new String[4];

        rowTokenizer.nextToken(); // Skip "key"
        String fstr = rowTokenizer.nextToken();
        colTokenizer = new
        java.util.StringTokenizer(fstr, colSeparator.toString());

        rowData[0] = colTokenizer.nextToken();
        String tag = (String) colTokenizer.nextToken();

        
	
        //rowData[1] = s;

        if (colTokenizer.hasMoreTokens())
        rowData[sColumn] = colTokenizer.nextToken();
        else
        rowData[sColumn] = null;

        String host1 = (String)colTokenizer.nextToken();
        String host2 = (String)colTokenizer.nextToken();
        String k = null;
        if (lhtype != ConfigComm.GET_DSP_DIST_ALL_INFO) {
	    rowData[1] = tag.substring(Constants.GLB_TAG_DCM_PREFIX.length()); 
	    k = (String)rowData[1];
	} else {
        String phost1 = (String)colTokenizer.nextToken();
        String phost2 = (String)colTokenizer.nextToken();
		
        hostData[2] = phost1;
        hostData[3] = phost2;

	    k = Constants.GLB_TAG_DSP;
	}
	
        hostData[0] = host1;
        hostData[1] = host2;
        if (!hostmap.containsKey(k))
          hostmap.put((String)rowData[1],hostData);
      
			String []data = new String[2];

				data[0] = host1;
				data[1] = host2;
			distrData.put((String)rowData[0] , data);
	statusQuery.append((String)rowData[0]).append(" ");
        if (numRows >= oldRows) {
          m_vector.add(rowData);
        } else {
		  m_vector.setElementAt(rowData,numRows);
        }
        numRows++;

      }
      m_vector.setSize(numRows);



      /*******************/
      if (Constants.DEBUG && Constants.Verbose>2)
	  System.out.println("DistrStatusDataModel: Num rows: "+numRows);

      java.util.Iterator iter = hostmap.keySet().iterator();

      String distList1 = null, distList2 = null;
      boolean e1 = false, e2 = false;

      
      while (iter.hasNext()) {

        String [] hostData;
        e1 = false;
        e2 = false;
        String k1 = (String)iter.next();
        hostData = (String[]) hostmap.get(k1);
	
    if (lhtype != ConfigComm.GET_DSP_DIST_ALL_INFO) {
		hostQuery.append(hostData[0])
                    .append(" ").append(hostData[1]);
	} else {
		/* 
		** To get status of dsp linehandlers, use the
		** physical hostnames in the query
		*/
		hostQuery.append(hostData[0])
			.append(" ").append(hostData[2])
	    	.append(" ").append(hostData[1])
                    .append(" ").append(hostData[3]);
                
	}

    
    Utils.ServiceWorker work1 
	= new Utils.ServiceWorker(hostData[0], 
					"dsp_linehand,dcm_linehand   -d ",
					AdminComm.LIST_IDS2_PROC_BY_KEY);
    Utils.ServiceWorker work2 
	= new Utils.ServiceWorker(hostData[1], 
					"dsp_linehand,dcm_linehand   -d ",
					 AdminComm.LIST_IDS2_PROC_BY_KEY);


    work1.start();
    work2.start();
    
    Object data1[] = (Object[])work1.get();
    Object data2[] = (Object[])work2.get();

    distList1 = (String)data1[0];
    distList2 = (String)data2[0];
    
    
        if (Constants.DEBUG && Constants.Verbose>2)
	    System.out.println("NumRows: "+numRows+" 1: "+distList1+" 2: "+distList2);

        for (int r = 0; r < numRows; r++) {
          String id = (String)getValueAt(r,0);
          String dcm = (String)getValueAt(r,1);

          //System.out.println("ID: "+id+" DCM: "+dcm+" K1: "+k1+" "+e1+" "+e2);

          if ((lhtype == ConfigComm.GET_DSP_DIST_ALL_INFO) 
                || ( (lhtype != ConfigComm.GET_DSP_DIST_ALL_INFO)
                   && dcm.equals(k1)) )  {
	      if (distList1!=null) {
		  if (Constants.matchPattern(distList1.trim(),",",id)) {
		      _setValueAt("Running",r,sColumn+1);
		  } else{
		      _setValueAt("Not Running",r,sColumn+1);
		  }
	      } else {
		  _setValueAt("????????",r,sColumn+1);
	      }
	      if (distList2!=null) {
		  if (Constants.matchPattern(distList2.trim(),",",id)){
		      _setValueAt("Running",r,sColumn+2);
		  } else {
		      _setValueAt("Not Running",r,sColumn+2);
		  }
	      } else {
		  _setValueAt("????????",r,sColumn+2); 
	      }
          }
        }



      }




      /*******************/
      
	  if ((hostQuery.length()==0) 
			|| (statusQuery.length()==0)) {
		m_vector.removeAllElements();
        fireTableDataChanged();
		return;
     }	

      try {
	  //statusQuery.trim();
	  StringBuffer query = new StringBuffer();
	  
	  for (int i = 0; i < hostQuery.length(); i++) 
	      if (hostQuery.charAt(i)==',')
		  hostQuery.setCharAt(i,' ');

	  if (lhtype==ConfigComm.GET_DSP_DIST_ALL_INFO)
	      query.append("#4 ").append(hostQuery).append(",dsp_linehand,");
	      //statusQuery.insert(0,"#4 $,dsp_linehand, allof(");
	  else
	      query.append("#4 ").append(hostQuery).append(",dcm_linehand,");
	      //statusQuery.insert(0,"#4 $,dcm_linehand, allof(");
	  query.append(statusQuery);
	  query.append('\0');

	  String statusBuffer = StatusRequest.getInstance().statusQuery(query.toString());
	  java.util.StringTokenizer recordTokenizer 
	      = new java.util.StringTokenizer(statusBuffer,"\n");
	  int numRecords = recordTokenizer.countTokens();

	  /*for (int i = 0; i< numRows; i++) {
	      setValueAt("NO STATUS",i,sColumn+1);
	      setValueAt("NO STATUS",i,sColumn+2);
	      }*/
	  for (int n = 0; n < numRecords; n++) {
	      String record = recordTokenizer.nextToken();
	      java.util.StringTokenizer fieldTokenizer 
		  = new java.util.StringTokenizer(record,",");
	      if (fieldTokenizer.countTokens()>=6) {
		  String ts = fieldTokenizer.nextToken();
		  String st = fieldTokenizer.nextToken();
		  String host = fieldTokenizer.nextToken();
		  String name = fieldTokenizer.nextToken();
		  String id = fieldTokenizer.nextToken();
		  if (st.equals("status")) {
		      String mode = fieldTokenizer.nextToken();
		      for (int i = 0; i< numRows; i++) {
			  String did = (String)getValueAt(i,0);
			  String host1 = (String)getHost1(i);
			  String host2 = (String)getHost2(i);
			  if (did.equals(id)) {
			      if (Constants.findPattern(host1,host)) {
				  String s = (String)getValueAt(i,sColumn+1);
				  if ((s!=null)&&s.startsWith("Running"))
				      _setValueAt(mode,i,sColumn+1);
			      } else if (Constants.findPattern(host2,host)) {
				  String s = (String)getValueAt(i,sColumn+2);
				  if ((s!=null)&&s.startsWith("Running"))
				      _setValueAt(mode,i,sColumn+2);
			      }
			  }
		      }
		  } else {
		      String es = fieldTokenizer.nextToken();
		  }
	      }
	  }
	  
	  	//System.out.println("Status Response: "+statusBuffer);
      } catch (Exception e) {

      }



    java.util.Collections.sort(m_vector, new
                StatusComparator(m_sortCol, m_sortAsc));


    fireTableDataChanged();

    } catch (Exception e) {
		m_vector.removeAllElements();
        fireTableDataChanged();
      if (e instanceof DBException) {
        if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND)
        return;
      }
      Log.getInstance().log_error(
      "Error in retrieving DCM list",e);


    }

    if (Constants.DEBUG && Constants.Verbose>2)
	System.out.println("DistrStatusDataModel: Update done.");


  }


  synchronized public void Refresh() {
    if (updater!=null)
	updater.interrupt();

  }


    
	public int getRowCount() {
		return m_vector==null ? 0 : m_vector.size();
	}

	public int getColumnCount() { 
		return m_columnsCount;
	}


	public String getColumnName(int col) {
		int column = col;
      if ((lhtype == ConfigComm.GET_DSP_DIST_ALL_INFO)
              && (col>=1)) column++;

      	String str = Constants.DistributorStatusTableColumnNames[column];
		if (col==m_sortCol)
			str += m_sortAsc ? " \273" : " \253";
		return str;
	}
 

  public Object getValueAt(int nRow, int nCol) {
    if (nRow < 0 || nRow>=getRowCount())
      return "";

	return ((String[])m_vector.get(nRow))[nCol];
  }


	private void _setValueAt(Object o, int r, int c) {

		Object[] s = (Object[])m_vector.get(r);

		s[c] = o;
		m_vector.setElementAt(s,r);
		
	}


	public void setValueAt(Object o, int r, int c) {

		Object[] s = (Object[])m_vector.get(r);

		s[c] = o;
		m_vector.setElementAt(s,r);
		

    java.util.Collections.sort(m_vector, new
                StatusComparator(m_sortCol, m_sortAsc));


   fireTableDataChanged();


	}

	public void addRow(Object[] o) {
		m_vector.add(o);

    java.util.Collections.sort(m_vector, new
                StatusComparator(m_sortCol, m_sortAsc));


   fireTableDataChanged();

	}
	
	public void removeRow(int r) {
		m_vector.remove(r);

   fireTableDataChanged();

	}

	public java.util.Vector getDataVector(){
		return m_vector;
	}

  class ColumnListener extends java.awt.event.MouseAdapter
  {
    protected javax.swing.JTable m_table;

    public ColumnListener(javax.swing.JTable table) {
      m_table = table;
    }

    public void mouseClicked(java.awt.event.MouseEvent e) {
      javax.swing.table.TableColumnModel colModel = m_table.getColumnModel();
      int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
      int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

      if (modelIndex < 0)
        return;
      if (m_sortCol==modelIndex)
        m_sortAsc = !m_sortAsc;
      else
        m_sortCol = modelIndex;


	  //System.out.println("SORTING COLUMN : "+m_sortCol);

      for (int i=0; i < m_columnsCount; i++) {
        javax.swing.table.TableColumn column = colModel.getColumn(i);
        column.setHeaderValue(getColumnName(column.getModelIndex()));    
      }
      m_table.getTableHeader().repaint();  


      java.util.Collections.sort(m_vector, new 
        StatusComparator(modelIndex, m_sortAsc));

	  
      m_table.tableChanged(
        new javax.swing.event.TableModelEvent(DistrStatusDataModel.this)); 
      m_table.repaint();  
	  
    }
  }


class StatusComparator implements java.util.Comparator
{
  protected int     m_sortCol;
  protected boolean m_sortAsc;

  public StatusComparator(int sortCol, boolean sortAsc) {
    m_sortCol = sortCol;
    m_sortAsc = sortAsc;
  }

  public int compare(Object o1, Object o2) {
    String[] v1 = (String[])o1;
    String[] v2 = (String[])o2;
	String s1 = v1[m_sortCol];
	String s2 = v2[m_sortCol];

    int result = 0;

	if (s1==null)
		result = +1000;
	else if (s2==null)
		result = -1000;
	else
		result = s1.compareTo(s2);

    if (!m_sortAsc)
      result = -result;
    return result;
  }

  public boolean equals(Object obj) {
    return false;
  }
}



}



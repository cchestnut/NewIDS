/*
**  SCCS Info :  "@(#)DCMDataServicesStatusModel.java	1.10    05/05/03"
*/
/*
 * DataServicesStatusModel.java
 *
 * Created on June 29, 2000, 9:43 AM
 */
 
package ids2ui;
import javax.swing.event.*;

/** 
 *
 * @author  srz
 * @version 
 */
public class DCMDataServicesStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements	Utils.UpdateModel
{
    private java.util.HashMap prodConvMap = null;

    private String 		   	m_hostTag = null;
    private String		   	m_progList = null;


    protected int     		m_sortCol = 0;
    protected boolean 		m_sortAsc = true;
    protected java.util.Vector 	m_vector = null;
    protected java.util.Vector	m_dc1InputFeed = null;
    protected java.util.Vector	m_dc2InputFeed = null;
    protected String			m_dc1PHost = null;
    protected String			m_dc2PHost = null;
    protected String			m_dc1Host = null;
    protected String			m_dc2Host = null;

    protected String			m_swVersion = null;

    protected String			m_dc1ProductList = null;
    protected String			m_dc2ProductList = null;

    protected boolean         isDJNEWS_DCM = false;

    protected int 			m_columnsCount = 
	Constants.SystemServicesTableColumnNames.length;

    protected int 			m_rowsCount = 0;

    private String[][]		m_serverDesc = null;
        private final String dc1status = "DC-I Status";
        private final String dc2status = "DC-II Status";
        private String m_location1 = dc1status;
        private String m_location2 = dc2status;
        

    public DCMDataServicesStatusModel(String[][] tableDesc, String hTag)
    {

	m_serverDesc = tableDesc;

	int nservers  = m_serverDesc.length;

	m_vector = new java.util.Vector(nservers*2);
	m_hostTag = hTag;

	StringBuffer progList = new StringBuffer();
	for ( int i = 0; i < nservers; i++)  {
	    progList.append(m_serverDesc[i][1]);
	    /*if (i < (nservers-1))
	      progList.append(",");*/
	}
	progList.append("msgmgr");
	
	m_progList = progList.toString();

        try {
                java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
                m_location1 = (String)map.get("LOCATION1");
                m_location2 = (String)map.get("LOCATION2");
        }
        catch (Exception e)
        {
        }
        
    }




    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }


    synchronized public java.util.Vector getDC1InputFeed() {
	return m_dc1InputFeed;
    }

    synchronized public java.util.Vector getDC2InputFeed() {
	return m_dc2InputFeed;
    }

    synchronized public String getDC1PHost() {
	return m_dc1PHost;
    }

    synchronized public String getDC2PHost() {
	return m_dc2PHost;
    }

    synchronized public String getDC1Host() {
	return m_dc1Host;
    }

    synchronized public String getDC2Host() {
	return m_dc2Host;
    }

    synchronized public String getSWVersion() {
	return m_swVersion;
    }

    synchronized public boolean isDJNEWS_DCM() {
	return isDJNEWS_DCM;
    }

    synchronized public String getDC1Location() {
	return (m_location1 == null
                || m_location1.equals(dc1status))?null:m_location1;
    }

    synchronized public String getDC2Location() {
	return (m_location2 == null
                || m_location2.equals(dc2status))?null:m_location2;
    }

        
    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    synchronized public int getRowCount() {
	return m_vector.size();
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int col) {
	int column = col;
      	String str = Constants.SystemServicesTableColumnNames[column];

        if (column == 1 && m_location1 != null) str = m_location1;
        if (column == 2 && m_location2 != null) str = m_location2;
        
	if (col==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 

    synchronized public Object getValueAt(int nRow, int nCol) {
	
	if (nRow < 0 || nRow>=m_rowsCount)
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }

    synchronized public java.util.Vector getDataVector(){
	return m_vector;
    }

    synchronized public void stop() {
	//threadPool.waitForAll(true);
	m_vector.clear();
	m_vector = null;

    }


    synchronized public String getMgrProducts(String mgrname, int dc) 
    {
	if (isDJNEWS_DCM) {
	    if (dc==1) return m_dc1ProductList;
	    if (dc==2) return m_dc2ProductList;
	} else if (prodConvMap!=null) {
	    StringBuffer s = (StringBuffer)prodConvMap.get(mgrname);
	    return s.toString();
	}
	return null;
    }


    synchronized public String getDCMProducts(int dc)
    {

	if (isDJNEWS_DCM) {
	    if (dc==1) return m_dc1ProductList;
	    if (dc==2) return m_dc2ProductList;
	} else {
	    String prodList[] = ConfigComm.getCSCProductsModel().getProductsWithoutAD();
	    return (Utils.productArrayToString(prodList));
	}
	return null;
    }



    public void Update() 
	throws Exception 
    {


	/* Retrieve DCM configuration ;
	   fill all fields and select current items in lists */
	try {

	    java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
		
	    String serverList1 = new String((String)map.get("HOST1"));
	    String serverList2 = new String((String)map.get("HOST2"));
	    String phost1= new String((String)map.get("PHOST1"));
	    String phost2 = new String((String)map.get("PHOST2"));
            
            String s = (String)map.get("LOCATION1");
            
            if (s != null)
                    m_location1 = new String(s);
            else
                    m_location1 = null;

            s = (String)map.get("LOCATION2");
            if (s != null)
                    m_location2 = new String(s);
            else
                    m_location2 = null;
            


           
            
	    String ver = (String) map.get("SOFTWARE_VERSION");

	    isDJNEWS_DCM = Utils.isDJNEWS_DCM((String) map.get("TYPE"));
	    /*
            ** Retrieve the list of running system programs from server
            ** and update status fields
            */
               

            String statusBuf1 = null;
            String statusBuf2 = null;
            boolean exc1=false, exc2=false;
            try
            {
                    statusBuf1 =
                            Utils.getProgramStatus((String)map.get("PHOST1"),
                                                   Constants.ADMINSERVER,
                                                   Constants.ADMINSERVER);
                    
            }
            catch (Exception ignore)
            {
                    exc1= true;
                    ignore.printStackTrace();
            }


            
            try
            {
                    statusBuf2
                            = Utils.getProgramStatus((String)map.get("PHOST2"),
                                                     Constants.ADMINSERVER,
                                                     Constants.ADMINSERVER);
            }
            catch (Exception ignore)
            {
                    exc2 = true;
                    ignore.printStackTrace();
            }

            
            

	    java.util.Vector ifVector1 = new java.util.Vector(5);
	    java.util.Vector ifVector2 = new java.util.Vector(5);


	    String [] rowData1 = new String[5];
	    String [] rowData2 = new String[5];

	    rowData1[0]=Constants.GLB_DCM_INPUT_NAME;
	    rowData1[1]=Constants.GLB_IDS_FORMAT;
	    rowData1[2]=Constants.GLB_IDS_PROTOCOL;
	    rowData1[3]=Constants.GLB_IDS_TRANSPORT;
	    rowData1[4]=Constants.GLB_IDS_TRANSPORT_ADDRESS;

	    rowData2[0]=Constants.GLB_DCM_INPUT_NAME;
	    rowData2[1]=Constants.GLB_IDS_FORMAT;
	    rowData2[2]=Constants.GLB_IDS_PROTOCOL;
	    rowData2[3]=Constants.GLB_IDS_TRANSPORT;
	    rowData2[4]=Constants.GLB_IDS_TRANSPORT_ADDRESS;

	    ifVector1.add(rowData1);
	    ifVector2.add(rowData2);



	    java.util.Vector u_vector = new java.util.Vector(m_vector.size());

	    boolean found;

	    /* 
	    ** Update the Data services table with all possible reader 
	    **
	    */
	    for ( int i = 0; i < m_serverDesc.length; i++) {

		if  ( m_serverDesc[i][0].equals("Reader") ) {
			
		    for (int r = 0; r < ifVector1.size() ; r++) {
			String [] rowData = new String[m_columnsCount];

			rowData[1] = Constants.NO_STATUS;
			rowData[2] = Constants.NO_STATUS;


          		String [] row = (String[]) ifVector1.get(r);
          		String name = row[0];
			String id = m_serverDesc[i][0]+":"+name;
			found = false;
			
			for (int r2 = 0; r2 < ifVector2.size() ; r2++) {
			    String [] row2 = (String[]) ifVector2.get(r2);
			    String name2 = row2[0];
			    if (name.equals(name2)) {
				found = true;
				break;
			    }
			}
			if (!found) 
			    rowData[2] = Constants.NOT_CONFIGURED;
			
			rowData[0] = id;

			u_vector.add(rowData);
		    }
		    
		    for (int r2 = 0; r2 < ifVector2.size() ; r2++) {
          		String [] row2 = (String[]) ifVector2.get(r2);
          		String name2 = row2[0];
			found = false;			
			for (int r = 0; r < ifVector1.size() ; r++) {
			    String [] row1 = (String[]) ifVector1.get(r);
			    String name1 = row1[0];
			    if (name1.equals(name2)) {
				found = true;
				break;
			    }
			}
			if (!found) {
			    String [] rowData = new String[m_columnsCount];

			    rowData[1] = Constants.NO_STATUS;
			    rowData[2] = Constants.NO_STATUS;


			    String id = m_serverDesc[i][0]+":"
				+name2;
			    rowData[0] = id;
			    rowData[1] = Constants.NOT_CONFIGURED;
			    
			    u_vector.add(rowData);
			}
		    }
		} else {
		    String [] rowData = new String[m_columnsCount];
		    rowData[0] = m_serverDesc[i][0];
		    rowData[1] = Constants.NO_STATUS;
		    rowData[2] = Constants.NO_STATUS;
		    u_vector.add(rowData);
		}

	    }


	    /*
	    ** Update the Data services table with all possible 
	    ** Message Manager entries
	    */
	    Object proddata1[] = null,proddata2[] = null;

	    if (isDJNEWS_DCM) {
		String id = m_hostTag.substring(Constants.GLB_TAG_DCM_PREFIX.length());
		ProductWorker pw1 = new ProductWorker(id,"1");
		ProductWorker pw2 = new ProductWorker(id,"2");

		pw1.start();
		pw2.start();
		
		proddata1 = (Object[])pw1.get();
		proddata2 = (Object[])pw2.get();
		
		
		if (proddata1[1] != null) {
		    String prodList[] = ConfigComm.getCSCProductsModel().getContainerProducts();
		    proddata1[0] = Utils.productArrayToString(prodList);
		    //throw (Exception)proddata1[1];
		}
		
		
		if (proddata2[1] != null) {
		    String prodList[] = ConfigComm.getCSCProductsModel().getContainerProducts();
		    proddata2[0] = Utils.productArrayToString(prodList);
		    //throw (Exception)proddata2[1];
		}
		


		String [] rowData = new String[m_columnsCount];
		rowData[0] = "Message Manager:"+Constants.GLB_DJNEWS_DCM_MSGMGR_NAME;
		rowData[1] = Constants.NO_STATUS;
		rowData[2] = Constants.NO_STATUS;
		u_vector.add(rowData);
		

	    } else {
		prodConvMap = ConfigComm.getCSCSparseMatrixModel().getMsgMgrs();
		java.util.Iterator iter = prodConvMap.keySet().iterator();
		
		while (iter.hasNext()) {
		    
		    String key = (String)iter.next();
		    StringBuffer value = (StringBuffer)prodConvMap.get(key);
		    
		    if (Constants.DEBUG && (Constants.Verbose>2))
			System.out.println("KEY: "+key
					   +"\n\tProducts: "+value.toString());
		    
		    String [] rowData = new String[m_columnsCount];
		    rowData[0] = "Message Manager:"+key;
		    rowData[1] = Constants.NO_STATUS;
		    rowData[2] = Constants.NO_STATUS;
		    u_vector.add(rowData);
		}
	    }



	    
	    if (exc1) {
		for (int r = 0; r < m_rowsCount; r++) 
		    setValueAt(u_vector,Constants.NO_STATUS,r,1);
	    } else {
		updateStatus(u_vector,statusBuf1, 1);
	    }
	    if (exc2) {
		for (int r = 0; r < m_rowsCount; r++) 
		    setValueAt(u_vector,Constants.NO_STATUS,r,2);
	    } else {
		updateStatus(u_vector,statusBuf2, 2);
	    }
	    

	    java.util.Collections.sort(u_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));	    
            int oldRows = 0, newRows = 0;
            
	    synchronized (this) {
		if (m_vector!=null) {
                        oldRows = m_vector.size();
                        m_vector.clear();
                }
                
		m_vector = null;
		m_vector = u_vector;
		m_rowsCount = m_vector.size();

		if (m_dc1InputFeed!=null) m_dc1InputFeed.clear();
		if (m_dc2InputFeed!=null) m_dc2InputFeed.clear();
		m_dc1InputFeed=null;
		m_dc2InputFeed=null;
		m_dc1InputFeed = ifVector1;
		m_dc2InputFeed = ifVector2;
		m_dc1Host      = serverList1;
		m_dc2Host      = serverList2;
		m_dc1PHost      = phost1;
		m_dc2PHost      = phost2;
		if (proddata1!=null)
		    m_dc1ProductList = (String)proddata1[0];
		else
		    m_dc1ProductList = null;
		if (proddata2!=null)
		    m_dc2ProductList = (String)proddata2[0];
		else
		    m_dc2ProductList = null;
		m_swVersion    = ver;

                newRows = m_vector.size();
                
	    }

	    IDS_SwingUtils.fireTableChanged(this, oldRows, newRows);

	} catch (Exception e) {

	    synchronized (this) {
		for (int r = 0; r < m_rowsCount; r++) {
		    setValueAt(Constants.NO_STATUS,r,1);
		    setValueAt(Constants.NO_STATUS,r,2);
		}
		/*
		**    Reuse old config ??
		if (m_dc1InputFeed!=null) m_dc1InputFeed.clear();
		if (m_dc2InputFeed!=null) m_dc2InputFeed.clear();
		m_dc1InputFeed=null;
		m_dc2InputFeed=null;
		m_dc1Host=null;
		m_dc2Host=null;
		m_dc1PHost=null;
		m_dc2PHost=null;
		m_swVersion    = null;
		**
		*/
		java.util.Collections.sort(m_vector, new
					   StatusComparator(m_sortCol, m_sortAsc));	
	    }
	    fireTableDataChanged();
	    
	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo() == Constants.KEY_NOT_FOUND) {
		    Log.getInstance().log_error(
				  "DataServicesStatusModel:Configuration does not exist."
				  +m_hostTag,e);          
		    
		    return;
		}
	    }
	    Log.getInstance().log_error("Error in retrieving configuration"
					+m_hostTag,e);
	    throw (e);
	}




    }



    private void setValueAt(java.util.Vector v, String s, int row, int col) 
    {
	String[] rowData = (String[])v.get(row);
	rowData[col] = s;
	v.set(row,rowData);
    }
   
   
    private void updateStatus(java.util.Vector v, String datastr, int column)
    {
	
	for (int r = 0; r < v.size(); r++) {
	    String rdata[] = (String[])v.get(r);
	    if (rdata.length > column ) {
		String vc = rdata[column];
		if (vc.equals(Constants.NOT_CONFIGURED))
		    continue;
	    }
	    setValueAt(v,Constants.NOT_RUNNING, r, column);
	}
	

	if ((datastr==null) || datastr.trim().length()==0) 
	    return;



	java.util.StringTokenizer st
	    = new java.util.StringTokenizer(datastr.trim(),
					    "\n");

        boolean first_record = true;
        
	while (st.hasMoreTokens()){
	    int kindex=-1;

            String s = st.nextToken();
            if (first_record)
            {
                    String separator = new String(",\0\n");
                    java.util.StringTokenizer tokenizer 
                            = new java.util.StringTokenizer(s,separator);
                    
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    
                    if (tokenizer.hasMoreTokens())
                            s = tokenizer.nextToken();

                    first_record = false;
            }
            
            
            
	    	
	    String sep1 = new String(" \t");
	    java.util.StringTokenizer st1 = 
		new java.util.StringTokenizer(s.trim(),sep1);
	    String progname = null;
	    if (st1.hasMoreTokens())
		progname = st1.nextToken();	
	    else
		continue;
            
            

	    if (progname.equals("msgmgr")) {
		String pattern = null;

		int inx = s.indexOf("-n");
		String ss = s.substring(inx+2);
		java.util.StringTokenizer st2 = 
			new java.util.StringTokenizer(ss,sep1);
		String n1 = (String)st2.nextToken();
		pattern="Message Manager"+":"+n1;
		
		int numRows = v.size();
		for ( int i = 0; i < numRows; i++) {
		    String[] data = (String[])v.get(i);
		    
		    if (pattern.equals(data[0])) {
			String o1 = data[column];
			if ((o1!=null) && o1.equals(Constants.NOT_CONFIGURED))
			    setValueAt(v,Constants.NOT_CONFIGURED+" (?Running?)",
				       i,column);
			else
			    setValueAt(v,"Running",i,column);
			break;
		    } 
		}
		continue;
	    }

	    for ( int k = 0; k < m_serverDesc.length; k++) {
		if (m_serverDesc[k][1].equals(progname)){
		    kindex = k;
		    break;
		}
	    }

	    if (kindex <0) 
		continue;

	    String pattern = m_serverDesc[kindex][0];
	    if (kindex < 2 ) {
		int inx = s.indexOf("-n");
		String ss = s.substring(inx+2);
		java.util.StringTokenizer st2 = 
		    new java.util.StringTokenizer(ss,sep1);
		String n1 = (String)st2.nextToken();
		pattern=pattern+":"+n1;
	    }

	    int numRows = v.size();
	    for ( int i = 0; i < numRows; i++) {
		String[] data = (String[])v.get(i);

		if (pattern.equals(data[0])) {
		    String o1 = data[column];
		    if ((o1!=null) && o1.equals(Constants.NOT_CONFIGURED))
			setValueAt(v,Constants.NOT_CONFIGURED+" (?Running?)",
				   i,column);
		    else
			setValueAt(v,"Running",i,column);
		}
	    }

	} /* st.hasMoreTokens() */
	
    }









    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;
	
	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock lk) {
	    m_table = table;
	    rwLock = lk;
	}	
	
	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel 
		= m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }

	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;


		
	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }

	    m_table.getTableHeader().repaint();  

	    synchronized (DCMDataServicesStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, m_sortAsc));
	    }

	  
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(DCMDataServicesStatusModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release();
	    
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;

	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }



    private class ProductWorker extends SwingWorker {

	ProductWorker(String dcm, String s) {
	    dcmName = dcm;
	    dc = s;
	    data[0] = data[1] = null;
	}

	Object data[] = new Object[2];
	String dc = null;
	String dcmName = null;
	public Object construct() {
	    try {
		data[0]=Utils.getDCMProducts(dcmName,dc);
	    } catch (DBException dbe) {
		dbe.printStackTrace();
		data[1] = dbe;
		if (dbe.getErrorNo()==Constants.KEY_NOT_FOUND) {
		    data[0]=null;
		    data[1]=null;
		}	
			
	    } catch (Exception e) {
		e.printStackTrace();
		Log.getInstance().log_error("Error in retrieving product list for DCM:"
					    +dcmName+" "+dc,e);
		data[1] = e;
	    }
			
	    return data;
	}

    }
	    




}  // End of class DataServicesStatusModel

/*
**  SCCS Info :  "@(#)DistrServicesForm.java	1.27    04/12/08"
*/
/*
 * DistrServicesScreen.java
 *
 * Created on April 7, 2000, 11:17 AM
 */
 
package ids2ui;
import java.util.*;
import javax.swing.table.*;
import javax.swing.*;

/** 
 *
 * @author  srz
 * @version 
 */
public class DistrServicesForm extends javax.swing.JFrame 
        implements TaskListener, javax.swing.event.ListSelectionListener 
{

        private javax.swing.JTable distrTable;
        private DistrServicesForm myFrame;
        private javax.swing.table.TableCellRenderer serviceCellRenderer=null;
        private javax.swing.JRadioButton noneRB=null;
        private Utils.UpdateTimer updateTimer = null;
        private FIFOReadWriteLock rwLock = new FIFOReadWriteLock();
        private volatile boolean isExiting = false;
        private volatile boolean SaveStateMode = false;
        javax.swing.event.DocumentListener docListener = null;

        

            /** Creates new form DistrServicesScreen */
        public DistrServicesForm() {

                
                
                try {
                        serviceCellRenderer
                                = new IDS_SwingUtils.IDS_CellRenderer(IDS_SwingUtils.DefaultServiceCellColorMap);
                } catch (Exception e) {
                        Log.getInstance().log_error("DistrServicesForm:Error in "
                                                    +"creating cell renderer.",e);
                }
                
                setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
                myFrame = this;
                
                initComponents ();
                myInitComponents ();
                
                pack ();
                
                WindowEventAdapter.getInstance().registerWindow(
			Constants.SERVICES_DISTRIBUTORS_DETAILED,this);
                updateTimer.start();
        }





        public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                if (evt.getValueIsAdjusting()) return;
                updateUIState(0);

                int srows[] = distrTable.getSelectedRows();

                idTextF.getDocument().removeDocumentListener( docListener);

                if (srows.length!=1)
                        idTextF.setText("");
                else
                        idTextF.setText((String)distrTable.getValueAt(srows[0],0));

                idTextF.getDocument().addDocumentListener( docListener);
		
        }


        public void Refresh() {
                try {
                        DCMDistributorStatusModel mdl
                                = (DCMDistributorStatusModel)distrTable.getModel();
                        mdl.Refresh();
                } catch (Exception e){}
        }




        public void taskStarted(java.util.EventObject evt) {
                taskStarted("Updating status...");
        }

        public void taskStarted() {
                taskStarted((String)null);	
        }

        public void taskStarted(final String s) {

                if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                        Runnable callMe = new Runnable() {
                                public void run() {
                                        taskStarted(s);
                                }
                        };	
                        javax.swing.SwingUtilities.invokeLater(callMe);

                } else { 

                        if (s==null)
                                statusPanel.start();
                        else
                                statusPanel.start(s);
                }

        }


        public void taskEnded() {
                taskEnded((String)null);
        }

        public void taskEnded(java.util.EventObject evt) {
                taskEnded("Status updated @ "+new java.util.Date().toString());
        }

        public void taskEnded(final String s) {


                if ( !javax.swing.SwingUtilities.isEventDispatchThread() ) {
                        Runnable callMe = new Runnable() {
                                public void run() {
                                        taskEnded(s);
                                }
                        };	
                        javax.swing.SwingUtilities.invokeLater(callMe);

                } else {
                        statusPanel.stop();

                        if (s!=null)
                                statusPanel.showStatus(s);

                        updateUIState(0);
                            //repaint();
                }
        }





        public void updateUIState(int flags) {
                
                boolean enable1,enable2;
	    
                statusButton.setEnabled(false);
                retransRequestButton.setEnabled(false);
                retransStatusButton.setEnabled(false);
                x25LinkButton.setEnabled(false);

                String location = (String)locationComboBox.getSelectedItem();

                    /*
                if (location==null)
                        System.out.println("Location is null");
                    */
                
	    
                if (distrTable.getSelectionModel().isSelectionEmpty()) {
                        startButton.setEnabled(false);
                        modeButton.setEnabled(false);
                        stopButton.setEnabled(false);
                        switchButton.setEnabled(false);
                        copyButton.setEnabled(false);
                        modifyButton.setEnabled(false);
                        deleteButton.setEnabled(false);
                        if (flags != 1)
                                Utils.loadDCMLocationList(locationComboBox, null);
                        return;
                        
                }

                int srows[] = distrTable.getSelectedRows();


                
                if (flags != 1) {
                        String dcms[] = new String[srows.length];
                        for (int i = 0; i < srows.length; i++) 
                                dcms[i] = (String)distrTable.getValueAt(srows[i], 1);
                        
                        
                        Utils.loadDCMLocationList(locationComboBox, Arrays.asList(dcms) );
                }
                
                boolean validLocation = true;
                if ((location==null)
                    || location.equals(Constants.PICK_LOCATION))
                        validLocation = false;

                if (srows.length > 1) {
                        retransRequestButton.setEnabled(false);
                        retransStatusButton.setEnabled(false);
                        x25LinkButton.setEnabled(false);
                        statusButton.setEnabled(false);


                        if (validLocation && AccessLevel.MENU_ACCESS_LEVEL < 2) {
                                modeButton.setEnabled(true);
                                startButton.setEnabled(true);
                                switchButton.setEnabled(true);
                                stopButton.setEnabled(true);
                        }

                        modifyButton.setEnabled(false);
                        copyButton.setEnabled(false);
                        deleteButton.setEnabled(false);
                        x25LinkButton.setEnabled(false);
                } else {
	    
                        
                        if (AccessLevel.MENU_ACCESS_LEVEL == 0) {
                                modifyButton.setEnabled(true);
                                copyButton.setEnabled(true);
                                deleteButton.setEnabled(true);
                                x25LinkButton.setEnabled(true);
                        }

                        

                        String value1 = (String)distrTable.getValueAt(srows[0],3);
                        String value2 = (String)distrTable.getValueAt(srows[0],4);

                        
                        if ( (value1 != null && value1.startsWith("ACTIVE") )
                             || (value2 != null && value2.startsWith("ACTIVE")) ) {
                                if (AccessLevel.MENU_ACCESS_LEVEL < 2) 
                                        retransRequestButton.setEnabled(true);
                        
                                retransStatusButton.setEnabled(true);
                        }
                        

            
                        if (validLocation && AccessLevel.MENU_ACCESS_LEVEL < 2) {
                                startButton.setEnabled(true);
                                switchButton.setEnabled(true);
                                modeButton.setEnabled(true);
                                stopButton.setEnabled(true);
                                
                        }
        
                        statusButton.setEnabled(true);
	    

                } /* srows.length == 1*/


        } /* updateUIState() */



        
        private void myInitComponents()
        {

                javax.swing.ButtonGroup group;
     
                noneRB = new javax.swing.JRadioButton();

    
                group = new javax.swing.ButtonGroup();
                group.add(normalRB);
                group.add(hotRB);
                group.add(coldRB);
                group.add(dormantRB);
                group.add(noneRB);
                noneRB.setSelected(true);

                if (AccessLevel.MENU_ACCESS_LEVEL != 0)
                        jButton4.setEnabled(false);
        

                Utils.loadLocationList(locationComboBox);
                locationComboBox.setRenderer( new IDS_SwingUtils.LocationComboBoxRenderer());
       
        

                DCMDistributorStatusModel distrModel 
                = new DCMDistributorStatusModel();

                distrTable = new javax.swing.JTable( distrModel){
                        public javax.swing.table.TableCellRenderer 
                        getCellRenderer(int row,int column) {

                                if ((serviceCellRenderer!=null)
                                    && ((column==3)||(column==4)))
                                        return serviceCellRenderer;
                                return super.getCellRenderer(row,column);

                        }

                            /*
                              public java.awt.Component prepareRenderer(TableCellRenderer renderer,
                              int row, int column) 
                              {
                              java.awt.Component c = super.prepareRenderer(renderer,
                              row, column);
                              if (SaveStateMode)
                              c.setBackground(java.awt.Color.yellow);
                              else
                              c.setBackground(getBackground());
                              return c;
                              }
                            */
                };

	
                distrTable.setPreferredScrollableViewportSize(new java.awt.Dimension(300,100));

                docListener = new ActionHandlers.IDFieldListener(this, distrTable, idTextF);

                javax.swing.table.JTableHeader header = distrTable.getTableHeader();
                header.addMouseListener(
                        distrModel.new ColumnListener(distrTable,rwLock));

                distrTable.getSelectionModel().addListSelectionListener(this);

                distrTable.addMouseListener( new ActionHandlers.DCMDistributorStatusAdapter(this, distrTable) );


                Utils.UpdateListener updater = new Utils.UpdateListener(rwLock, this,
                                                                        distrModel);

                updateTimer = new Utils.UpdateTimer(Constants.ServiceStatusUpdateMilliSecs, updater);
	


                javax.swing.JScrollPane tableScrollPane = new javax.swing.JScrollPane(distrTable);
                tablePanel.add (tableScrollPane, java.awt.BorderLayout.CENTER);
        



                idTextF.getDocument().addDocumentListener( docListener );

                if (AccessLevel.MENU_ACCESS_LEVEL != 0) {
                        addButton.setEnabled(false); //Add
                        copyButton.setEnabled(false); //Copy
                        modifyButton.setEnabled(false); //Modify
                        deleteButton.setEnabled(false); // Delete
                        x25LinkButton.setEnabled(false);
                }


                ActionHandlers.SwitchActionHandler switchHandler
                = new ActionHandlers.SwitchActionHandler(this, this,
                                          rwLock, updateTimer,
                                          distrTable, locationComboBox,
                                          normalRB, hotRB, coldRB, dormantRB);
                switchButton.addActionListener(switchHandler);
        
                ActionHandlers.ProcessActionHandler serviceHandler
                = new ActionHandlers.ProcessActionHandler(this, this,
                                           rwLock, updateTimer,
                                           distrTable, locationComboBox,
                                           normalRB, hotRB, coldRB, dormantRB,
                                           noneRB, -1);
        
                startButton.addActionListener(serviceHandler);
                stopButton.addActionListener(serviceHandler);
                modeButton.addActionListener(serviceHandler);
        

                ActionHandlers.DistributorStatusHandler statusHandler
                = new ActionHandlers.DistributorStatusHandler(this,
                                               distrTable,
                                               Constants.DCM_LINEHANDLER,
                                               locationComboBox);
                statusButton.addActionListener(statusHandler);
        
        
                retransRequestButton.addActionListener( new ActionHandlers.RetransRequestActionHandler(this, this, rwLock, updateTimer, distrTable, null));
        
       
                retransStatusButton.addActionListener( new ActionHandlers.RetransStatusActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                x25LinkButton.addActionListener( new ActionHandlers.X25LinkConfigActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                addButton.addActionListener( new ActionHandlers.AddDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                modifyButton.addActionListener( new ActionHandlers.EditDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null, false));


                copyButton.addActionListener( new ActionHandlers.EditDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null, true));


                deleteButton.addActionListener( new ActionHandlers.DeleteDistributorActionHandler(this, this, rwLock, updateTimer, distrTable, null));

                jButton1.addActionListener( new ActionHandlers.SelectAllActionHandler(distrTable));

                jButton4.addActionListener( new ActionHandlers.ShowFrameActionHandler());
        
                jCheckBox1.addActionListener( new ActionHandlers.ShowRunningActionHandler(this, this, rwLock, updateTimer, distrTable));
        


                locationComboBox.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) 
                        {  updateUIState(1); }
                }
                                                   );
                        
                                                  ActionHandlers.ExitHandler exitHandler =
                                                          new ActionHandlers.ExitHandler(this,this, rwLock, 
                                                                                         updateTimer, distrTable);
                                                  
                closeButton.addActionListener(exitHandler);
                addWindowListener(exitHandler);
                
        } // End of myInitComponents() 



   


            /** This method is called from within the constructor to
             * initialize the form.
             * WARNING: Do NOT modify this code. The content of this method is
             * always regenerated by the FormEditor.
             */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel8 = new javax.swing.JPanel ();
          tablePanel = new javax.swing.JPanel ();
          jPanel4 = new javax.swing.JPanel ();
          jPanel5 = new javax.swing.JPanel ();
          idLabel = new javax.swing.JLabel ();
          idTextF = new ids2ui.UCTextField ();
          jPanel1 = new javax.swing.JPanel ();
          jButton4 = new javax.swing.JButton ();
          jButton1 = new javax.swing.JButton ();
          jCheckBox1 = new javax.swing.JCheckBox ();
          jTabbedPane1 = new javax.swing.JTabbedPane ();
          jPanel2 = new javax.swing.JPanel ();
          jPanel10 = new javax.swing.JPanel ();
          switchButton = new javax.swing.JButton ();
          locationComboBox = new javax.swing.JComboBox ();
          startButton = new javax.swing.JButton ();
          stopButton = new javax.swing.JButton ();
          modeButton = new javax.swing.JButton ();
          statusButton = new javax.swing.JButton ();
          jLabel1 = new javax.swing.JLabel ();
          optionPanel1 = new javax.swing.JPanel ();
          dormantRB = new javax.swing.JRadioButton ();
          normalRB = new javax.swing.JRadioButton ();
          hotRB = new javax.swing.JRadioButton ();
          coldRB = new javax.swing.JRadioButton ();
          jLabel2 = new javax.swing.JLabel ();
          jPanel6 = new javax.swing.JPanel ();
          retransStatusButton = new javax.swing.JButton ();
          retransRequestButton = new javax.swing.JButton ();
          jPanel7 = new javax.swing.JPanel ();
          addButton = new javax.swing.JButton ();
          copyButton = new javax.swing.JButton ();
          modifyButton = new javax.swing.JButton ();
          deleteButton = new javax.swing.JButton ();
          x25LinkButton = new javax.swing.JButton ();
          jPanel3 = new javax.swing.JPanel ();
          closeButton = new javax.swing.JButton ();
          statusPanel = new ids2ui.StatusPanel ();
          getContentPane ().setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints1;
          setTitle ("Distributor Main Screen");

          jPanel8.setLayout (new java.awt.GridBagLayout ());
          java.awt.GridBagConstraints gridBagConstraints2;
          jPanel8.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));

            tablePanel.setLayout (new java.awt.BorderLayout ());
            tablePanel.setBorder (new javax.swing.border.CompoundBorder(
            new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)),
            new javax.swing.border.LineBorder(java.awt.Color.black)));
  
              jPanel4.setLayout (new java.awt.BorderLayout (4, 4));
              jPanel4.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)));
    
      
                  idLabel.setText ("ID");
        
                  jPanel5.add (idLabel);
        
                  idTextF.setColumns (5);
        
                  jPanel5.add (idTextF);
        
                jPanel4.add (jPanel5, java.awt.BorderLayout.WEST);
      
                jPanel1.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints3;
      
                  jButton4.setText ("Save State");
                  jButton4.setActionCommand (Constants.DCM_DISTRIBUTOR_SAVE_STATE);
        
                  gridBagConstraints3 = new java.awt.GridBagConstraints ();
                  gridBagConstraints3.insets = new java.awt.Insets (0, 0, 0, 10);
                  gridBagConstraints3.anchor = java.awt.GridBagConstraints.WEST;
                  jPanel1.add (jButton4, gridBagConstraints3);
        
                  jButton1.setMargin (new java.awt.Insets(2, 7, 2, 7));
                  jButton1.setText ("Select all");
        
                  gridBagConstraints3 = new java.awt.GridBagConstraints ();
                  gridBagConstraints3.anchor = java.awt.GridBagConstraints.EAST;
                  jPanel1.add (jButton1, gridBagConstraints3);
        
                  jCheckBox1.setText ("View running programs only ");
        
                  gridBagConstraints3 = new java.awt.GridBagConstraints ();
                  gridBagConstraints3.insets = new java.awt.Insets (0, 10, 0, 5);
                  gridBagConstraints3.anchor = java.awt.GridBagConstraints.EAST;
                  jPanel1.add (jCheckBox1, gridBagConstraints3);
        
                jPanel4.add (jPanel1, java.awt.BorderLayout.EAST);
      
              tablePanel.add (jPanel4, java.awt.BorderLayout.SOUTH);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 0;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.weightx = 1.0;
            gridBagConstraints2.weighty = 1.0;
            jPanel8.add (tablePanel, gridBagConstraints2);
  
  
              jPanel2.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints4;
              jPanel2.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(5, 5, 5, 5)));
    
                jPanel10.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints5;
                jPanel10.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));
      
                  switchButton.setText ("Switch");
                  switchButton.setForeground (java.awt.Color.red);
                  switchButton.setActionCommand ("SWITCH");
                  switchButton.setLabel ("SWITCH");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 4;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel10.add (switchButton, gridBagConstraints5);
        
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 1;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (0, 5, 0, 15);
                  jPanel10.add (locationComboBox, gridBagConstraints5);
        
                  startButton.setText ("Start");
                  startButton.setForeground (new java.awt.Color (0, 150, 50));
                  startButton.setActionCommand ("START");
                  startButton.setLabel ("START");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 2;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel10.add (startButton, gridBagConstraints5);
        
                  stopButton.setText ("Stop");
                  stopButton.setForeground (java.awt.Color.red);
                  stopButton.setActionCommand ("STOP");
                  stopButton.setLabel ("STOP");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 3;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel10.add (stopButton, gridBagConstraints5);
        
                  modeButton.setText ("Set Mode");
                  modeButton.setForeground (java.awt.Color.red);
                  modeButton.setActionCommand ("MODE");
                  modeButton.setLabel ("SET MODE");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 5;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel10.add (modeButton, gridBagConstraints5);
        
                  statusButton.setText ("Status");
                  statusButton.setForeground (java.awt.Color.blue);
                  statusButton.setActionCommand ("STATUS");
                  statusButton.setLabel ("STATUS");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 6;
                  gridBagConstraints5.gridy = 0;
                  gridBagConstraints5.insets = new java.awt.Insets (5, 5, 5, 5);
                  jPanel10.add (statusButton, gridBagConstraints5);
        
                  jLabel1.setText ("Location");
        
                  gridBagConstraints5 = new java.awt.GridBagConstraints ();
                  gridBagConstraints5.gridx = 0;
                  gridBagConstraints5.gridy = 0;
                  jPanel10.add (jLabel1, gridBagConstraints5);
        
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.gridx = 0;
                gridBagConstraints4.gridy = 1;
                gridBagConstraints4.fill = java.awt.GridBagConstraints.BOTH;
                gridBagConstraints4.insets = new java.awt.Insets (10, 0, 5, 0);
                jPanel2.add (jPanel10, gridBagConstraints4);
      
                optionPanel1.setLayout (new java.awt.GridBagLayout ());
                java.awt.GridBagConstraints gridBagConstraints6;
      
                  dormantRB.setText ("Dormant");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 4;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 10, 0, 5);
                  gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
                  optionPanel1.add (dormantRB, gridBagConstraints6);
        
                  normalRB.setText ("Normal");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 1;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 5, 0, 5);
                  gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
                  optionPanel1.add (normalRB, gridBagConstraints6);
        
                  hotRB.setText ("Hot");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 2;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 5, 0, 5);
                  gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
                  optionPanel1.add (hotRB, gridBagConstraints6);
        
                  coldRB.setText ("Cold");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 3;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 5, 0, 5);
                  gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
                  optionPanel1.add (coldRB, gridBagConstraints6);
        
                  jLabel2.setText ("Start/Switch modes");
        
                  gridBagConstraints6 = new java.awt.GridBagConstraints ();
                  gridBagConstraints6.gridx = 0;
                  gridBagConstraints6.gridy = 0;
                  gridBagConstraints6.insets = new java.awt.Insets (0, 0, 0, 10);
                  gridBagConstraints6.anchor = java.awt.GridBagConstraints.WEST;
                  optionPanel1.add (jLabel2, gridBagConstraints6);
        
                gridBagConstraints4 = new java.awt.GridBagConstraints ();
                gridBagConstraints4.fill = java.awt.GridBagConstraints.HORIZONTAL;
                gridBagConstraints4.insets = new java.awt.Insets (2, 0, 0, 0);
                gridBagConstraints4.anchor = java.awt.GridBagConstraints.SOUTH;
                gridBagConstraints4.weightx = 1.0;
                jPanel2.add (optionPanel1, gridBagConstraints4);
      
              jTabbedPane1.addTab ("Services", jPanel2);
    
              jPanel6.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints7;
              jPanel6.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 5, 5, 5)));
    
                retransStatusButton.setText ("Retransmission Status");
                retransStatusButton.setActionCommand ("RTP_STATUS");
      
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.gridx = 1;
                gridBagConstraints7.gridy = 0;
                gridBagConstraints7.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints7.anchor = java.awt.GridBagConstraints.NORTHWEST;
                gridBagConstraints7.weightx = 0.5;
                gridBagConstraints7.weighty = 0.8;
                jPanel6.add (retransStatusButton, gridBagConstraints7);
      
                retransRequestButton.setText ("Retransmission request");
                retransRequestButton.setActionCommand ("RTP_REQUEST");
      
                gridBagConstraints7 = new java.awt.GridBagConstraints ();
                gridBagConstraints7.gridx = 0;
                gridBagConstraints7.gridy = 0;
                gridBagConstraints7.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints7.anchor = java.awt.GridBagConstraints.NORTHEAST;
                gridBagConstraints7.weightx = 0.5;
                gridBagConstraints7.weighty = 0.8;
                jPanel6.add (retransRequestButton, gridBagConstraints7);
      
              jTabbedPane1.addTab ("Retransmission", jPanel6);
    
              jPanel7.setLayout (new java.awt.GridBagLayout ());
              java.awt.GridBagConstraints gridBagConstraints8;
              jPanel7.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(10, 5, 5, 5)));
    
                addButton.setToolTipText ("Add a new distributor ");
                addButton.setText ("Add ");
                addButton.setActionCommand ("ADD");
      
                gridBagConstraints8 = new java.awt.GridBagConstraints ();
                gridBagConstraints8.gridx = 0;
                gridBagConstraints8.gridy = 0;
                gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
                gridBagConstraints8.weighty = 0.8;
                jPanel7.add (addButton, gridBagConstraints8);
      
                copyButton.setToolTipText ("Copy distributor's configuration to create new");
                copyButton.setText ("Copy");
                copyButton.setActionCommand ("COPY");
      
                gridBagConstraints8 = new java.awt.GridBagConstraints ();
                gridBagConstraints8.gridx = 1;
                gridBagConstraints8.gridy = 0;
                gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
                gridBagConstraints8.weighty = 0.8;
                jPanel7.add (copyButton, gridBagConstraints8);
      
                modifyButton.setToolTipText ("Modify distributor's configuration");
                modifyButton.setText ("Modify");
                modifyButton.setActionCommand ("MODIFY");
      
                gridBagConstraints8 = new java.awt.GridBagConstraints ();
                gridBagConstraints8.gridx = 2;
                gridBagConstraints8.gridy = 0;
                gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
                gridBagConstraints8.weighty = 0.8;
                jPanel7.add (modifyButton, gridBagConstraints8);
      
                deleteButton.setToolTipText ("Delete distributor from database");
                deleteButton.setText ("Delete");
                deleteButton.setActionCommand ("DELETE");
      
                gridBagConstraints8 = new java.awt.GridBagConstraints ();
                gridBagConstraints8.gridx = 3;
                gridBagConstraints8.gridy = 0;
                gridBagConstraints8.insets = new java.awt.Insets (5, 5, 5, 5);
                gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
                gridBagConstraints8.weighty = 0.8;
                jPanel7.add (deleteButton, gridBagConstraints8);
      
                x25LinkButton.setText ("X.25 Link Menu");
                x25LinkButton.setActionCommand ("X25_LINK_MENU");
      
                gridBagConstraints8 = new java.awt.GridBagConstraints ();
                gridBagConstraints8.gridx = 4;
                gridBagConstraints8.gridy = 0;
                gridBagConstraints8.insets = new java.awt.Insets (5, 10, 5, 5);
                gridBagConstraints8.anchor = java.awt.GridBagConstraints.NORTH;
                gridBagConstraints8.weighty = 0.8;
                jPanel7.add (x25LinkButton, gridBagConstraints8);
      
              jTabbedPane1.addTab ("Configuration", jPanel7);
    
            gridBagConstraints2 = new java.awt.GridBagConstraints ();
            gridBagConstraints2.gridx = 0;
            gridBagConstraints2.gridy = 1;
            gridBagConstraints2.fill = java.awt.GridBagConstraints.BOTH;
            gridBagConstraints2.weightx = 1.0;
            jPanel8.add (jTabbedPane1, gridBagConstraints2);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.fill = java.awt.GridBagConstraints.BOTH;
          gridBagConstraints1.weightx = 1.0;
          gridBagConstraints1.weighty = 1.0;
          getContentPane ().add (jPanel8, gridBagConstraints1);

          jPanel3.setLayout (new java.awt.FlowLayout (1, 25, 5));
          jPanel3.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(2, 2, 2, 2)));

            closeButton.setText ("Close");
  
            jPanel3.add (closeButton);
  

          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 1;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (jPanel3, gridBagConstraints1);

          statusPanel.setBorder (new javax.swing.border.CompoundBorder(
          new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)),
          new javax.swing.border.EtchedBorder()));


          gridBagConstraints1 = new java.awt.GridBagConstraints ();
          gridBagConstraints1.gridx = 0;
          gridBagConstraints1.gridy = 2;
          gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
          gridBagConstraints1.weightx = 1.0;
          getContentPane ().add (statusPanel, gridBagConstraints1);

        }//GEN-END:initComponents


 
       








 

 

            /** Exit the Application */
	

            /**
             * @param args the command line arguments
             */
        public static void main (String args[]) {
                new DistrServicesForm ().show ();
        }


        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JPanel jPanel8;
        private javax.swing.JPanel tablePanel;
        private javax.swing.JPanel jPanel4;
        private javax.swing.JPanel jPanel5;
        private javax.swing.JLabel idLabel;
        private ids2ui.UCTextField idTextF;
        private javax.swing.JPanel jPanel1;
        private javax.swing.JButton jButton4;
        private javax.swing.JButton jButton1;
        private javax.swing.JCheckBox jCheckBox1;
        private javax.swing.JTabbedPane jTabbedPane1;
        private javax.swing.JPanel jPanel2;
        private javax.swing.JPanel jPanel10;
        private javax.swing.JButton switchButton;
        private javax.swing.JComboBox locationComboBox;
        private javax.swing.JButton startButton;
        private javax.swing.JButton stopButton;
        private javax.swing.JButton modeButton;
        private javax.swing.JButton statusButton;
        private javax.swing.JLabel jLabel1;
        private javax.swing.JPanel optionPanel1;
        private javax.swing.JRadioButton dormantRB;
        private javax.swing.JRadioButton normalRB;
        private javax.swing.JRadioButton hotRB;
        private javax.swing.JRadioButton coldRB;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JPanel jPanel6;
        private javax.swing.JButton retransStatusButton;
        private javax.swing.JButton retransRequestButton;
        private javax.swing.JPanel jPanel7;
        private javax.swing.JButton addButton;
        private javax.swing.JButton copyButton;
        private javax.swing.JButton modifyButton;
        private javax.swing.JButton deleteButton;
        private javax.swing.JButton x25LinkButton;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JButton closeButton;
        private ids2ui.StatusPanel statusPanel;
        // End of variables declaration//GEN-END:variables

 

}

/*
 **  SCCS Info :  "%W%    %E%"
 */
/*
 * DistrProductStructure.java
 *
 * Created on March 22, 2000, 3:18 PM
 */
package ids2ui;

/**
 *
 * @author srz
 * @version
 */
public class DistrProductStructure {

    public String product;
    public String format;
    public int delay;
    public boolean freewheel;
    public boolean newsplus_off;
    public String permTemplate;
    public int derived_data;
    public String derived_data_dictionary;
    public String language;
    public String encoding;
    public String premium_filter;
    public boolean sigabout;

    public boolean equals(DistrProductStructure other) {

        if (check_str(product, other.product)
                && compareAttributes(other)) {
            return true;
        }

        return false;
    }

    public boolean compareAttributes(DistrProductStructure other)
    {
        if (check_str(format, other.format)
                && (delay == other.delay)
                && (freewheel == other.freewheel)
                && (newsplus_off == other.newsplus_off)
                && check_str(permTemplate, other.permTemplate)
                && (derived_data == other.derived_data)
                && check_str(derived_data_dictionary, other.derived_data_dictionary)
                && check_str(language, other.language)
                && check_str(encoding, other.encoding)
                && check_str(premium_filter, other.premium_filter)
                && (sigabout == other.sigabout)) {
            return true;
        }

        return false;
    }
    
    
    
    /**
     * Creates new DistrProductStructure
     */
    public DistrProductStructure() {
        product = null;
        format = null;
        delay = 0;
        freewheel = false;
        newsplus_off = false;
        derived_data = 0;
        permTemplate = null;
        derived_data_dictionary = null;
        language = null;
        encoding = null;
        premium_filter = null;
        sigabout = false;
    }

    public DistrProductStructure(String p, String f, int d, boolean b,
            boolean nb, int dd, String dict, String t, String l,
            String e, String pf, boolean sig) {
        product = p;
        format = f;
        delay = d;
        freewheel = b;
        newsplus_off = nb;
        derived_data = dd;
        if (derived_data > 0) {
            derived_data_dictionary = dict;
        } else {
            derived_data_dictionary = "NONE";
        }
        permTemplate = t;
        language = "Default";
        encoding = "Default";
        if (l != null) {
            language = l;
        }
        if (e != null) {
            encoding = e;
        }
        if (pf != null) {
            premium_filter = pf;
        }
        sigabout = sig;
    }

    
    private boolean check_str(String s1, String s2) {
        if ((s1 == null && s2 == null)
                || (s1 != null && s2 != null && s1.equals(s2))) {
            return true;
        }
        return false;
    }
}

/*
**  SCCS Info :  "@(#)ServiceWorker.java	1.1    01/05/08"
*/
/*
 * ServiceWorker.java
 *
 * Created on April 4, 2001, 2:47 PM
 */
 
package ids2ui;

public class ServiceWorker extends SwingWorker {
    Object[] data = new Object[2];
    String serverList, progList;
    int type = AdminComm.LIST_IDS2_PROC_BY_NAME;

    ServiceWorker(String srvrlist, String proglist) {
	serverList = srvrlist;
	progList   = proglist;
	data[0] = data[1] = null;
    }

    ServiceWorker(String srvrlist, String proglist, int t) {
	serverList = srvrlist;
	progList   = proglist;
	type = t;
	data[0] = data[1] = null;
    }


    public Object construct() {
	try {
	    String response;
	    int index;

	    byte[] respb = AdminComm.serviceRequest(serverList,
					    AdminComm.EXEC_COMMAND,
					    type,
					    progList);
		
	    response = new String(respb);
		
	    index = response.indexOf(ConfigComm.CONF_STX)+1;
		
	    if (index>0) 
		data[0] =  response.substring(index);
		
	} catch (Exception e) {
	    Log.getInstance().log_error("Error in retrieving process list from: "+serverList,e);
	    data[1] = e;
	}
	return data;
    }

}

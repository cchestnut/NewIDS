/*
**  SCCS Info :  "@(#)IntDocument.java	1.2    01/03/26"
*/
/*
 * IntDocument.java
 *
 * Created on July 7, 2000, 5:12 PM
 */
 
package ids2ui;
import javax.swing.*;
import javax.swing.text.*;

/** 
 *
 * @author  srz
 * @version 
 */


public class IntDocument extends javax.swing.text.PlainDocument {
	int numChars = 1024;
	public IntDocument(int max) {
		super();
		numChars = max;
	}

    public void insertString(int offs, String str, javax.swing.text.AttributeSet a) 
      throws javax.swing.text.BadLocationException {

      if (str == null) 
        return;
      char[] upper = str.toCharArray();
      char[] upper1;
	  if ((str.length() > numChars )
		|| (offs >= numChars) ) {
          java.awt.Toolkit.getDefaultToolkit().beep();
		  return;
	  }
		
      int l=0;
      for (int i = 0; i < upper.length; i++) {
        if (Character.isDigit(upper[i]))
          upper[l++] = Character.toUpperCase(upper[i]);
        else 
          java.awt.Toolkit.getDefaultToolkit().beep();
        
      }
      upper1 = new char [l];
      System.arraycopy(upper, 0, upper1, 0, l);
      super.insertString(offs, new String(upper1), a);
    }
}
  

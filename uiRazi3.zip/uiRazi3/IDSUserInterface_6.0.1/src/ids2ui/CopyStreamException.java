
/*
**  SCCS Info :  "@(#)CopyStreamException.java	1.1    03/09/16"
*/
  package ids2ui;
  import java.io.IOException;

  public class CopyStreamException extends IOException
  {
      private long totalBytesTransferred;
      private IOException ioException;
  
      /***
       * Creates a new CopyStreamException instance.
       * @param message  A message describing the error.
       * @param bytesTransferred  The total number of bytes transferred before
       *        an exception was thrown in a copy operation.
       * @param exception  The IOException thrown during a copy operation.
       */
      public CopyStreamException(String message,
                                 long bytesTransferred,
                                 IOException exception)
      {
          super(message);
          totalBytesTransferred = bytesTransferred;
          ioException = exception;
      }
  
      /***
       * Returns the total number of bytes confirmed to have
       * been transferred by a failed copy operation.
       * @return The total number of bytes confirmed to have
       * been transferred by a failed copy operation.
       */
      public long getTotalBytesTransferred()
      {
          return totalBytesTransferred;
      }
  
     /***
      * Returns the IOException responsible for the failure of a copy operation.
      * @return The IOException responsible for the failure of a copy operation.
      */
     public IOException getIOException()
     {
         return ioException;
     }
 }





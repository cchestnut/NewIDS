
/*
 * RadioOptionsDialog.java
 *
 * Created on March 4, 2004, 1:35 PM
 */
 
/*
**  SCCS Info :  "@(#)RadioOptionsDialog.java	1.1    04/04/01"
*/
package ids2ui;


/** 
 *
 * @author  srz
 * @version 
 */
public class RadioOptionsDialog
        extends javax.swing.JDialog {

        private int selected_index = -1;
        Object Options[] = null;
        RadioOptionsDialog me;
  
            /** Creates new form StatusLocationDialog */
        public RadioOptionsDialog(java.awt.Frame parent,boolean modal,Object message,String title,Object[] options,Object default_option) {
                super (parent, modal);
                me = this;
                
                        

        
                initComponents ();
                myInitComponents(message, title, options, default_option);
     
    
                pack ();
                if (parent!=null) {
                            //setLocationRelativeTo(parent);
                        int X  = parent.getX();
                        int Y = parent.getY();
                        int W  = parent.getWidth();
                        int H = parent.getHeight();
                        int w = getWidth();
                        int h = getHeight();
                        setLocation(X+W/2-w/2,Y+H/2-h/2);
                }
        }

        public static Object showRadioOptionsDialog(java.awt.Frame parent,boolean modal,
                                                    Object message,String title,Object[] options,Object default_option)
        {
    
                RadioOptionsDialog dlg = new RadioOptionsDialog(parent, modal,
                                                                message, title, options,
                                                                default_option);
                dlg.show();
    
                return dlg.getSelection();
        }
  
  
        public Object getSelection() {
    
                if (   (selected_index >= 0)
                       && (selected_index <= Options.length))
                        return Options[selected_index];
                return null;
    
        }
  
        private java.awt.event.ActionListener listener = 
        new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                        try {
                                selected_index = Integer.parseInt(evt.getActionCommand());
                        } catch (Exception e) {}
                }
        };
  
  
        private void myInitComponents(Object message, String title,
                                      Object []options, Object default_option) {



          
                Options = options;
                if (title!=null) setTitle(title);
                else setTitle("Options Dialog");
                if (message!=null)messageText.setText(message.toString());
                else messageText.setText("Please choose one");
    
                int num_options = options.length;
    
                buttonPanel.setLayout (new java.awt.GridLayout (num_options, 1, 0, 2));
    
                javax.swing.ButtonGroup group = new javax.swing.ButtonGroup();
    
                for (int i = 0; i< num_options; i++) {
                        javax.swing.JRadioButton btn = new javax.swing.JRadioButton();
                        btn.setText(options[i].toString());
                        btn.setActionCommand(Integer.toString(i));
                        btn.addActionListener(listener);
                        group.add(btn);
                        buttonPanel.add(btn);
                        if (options[i] == default_option) {
                                selected_index = i;
                                btn.setSelected(true);
                        }
                      
                }
    
                okButton.addActionListener( new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                if (selected_index == -1) {
                                        javax.swing.JOptionPane.showMessageDialog(me, "Please select an option or select \"Cancel\"");
                                        return;
                                }
                                                                                           
                                setVisible(false);
                                dispose();          
                        }
                });
    
                cancelButton.addActionListener( new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                selected_index = -1;
                                setVisible(false);
                                dispose();          
                        }
                });
    
                messageText.setBackground(buttonPanel.getBackground());
        }
  
  
  
  
            /** This method is called from within the constructor to
             * initialize the form.
             * WARNING: Do NOT modify this code. The content of this method is
             * always regenerated by the FormEditor.
             */
        private void initComponents () {//GEN-BEGIN:initComponents
          jPanel1 = new javax.swing.JPanel ();
          messageText = new javax.swing.JTextArea ();
          buttonPanel = new javax.swing.JPanel ();
          jPanel3 = new javax.swing.JPanel ();
          okButton = new javax.swing.JButton ();
          cancelButton = new javax.swing.JButton ();
          addWindowListener (new java.awt.event.WindowAdapter () {
            public void windowClosing (java.awt.event.WindowEvent evt) {
              closeDialog (evt);
            }
          }
          );

          jPanel1.setLayout (new javax.swing.BoxLayout (jPanel1, 0));
          jPanel1.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 4, 4, 4)));

            messageText.setBackground (java.awt.Color.lightGray);
            messageText.setEditable (false);
            messageText.setFont (new java.awt.Font ("dialog.bold", 0, 11));
  
            jPanel1.add (messageText);
  

          getContentPane ().add (jPanel1, java.awt.BorderLayout.NORTH);

          buttonPanel.setBorder (new javax.swing.border.EmptyBorder(new java.awt.Insets(4, 25, 4, 4)));


          getContentPane ().add (buttonPanel, java.awt.BorderLayout.CENTER);

          jPanel3.setLayout (new java.awt.FlowLayout (1, 10, 5));

            okButton.setText ("OK");
  
            jPanel3.add (okButton);
  
            cancelButton.setText ("Cancel");
  
            jPanel3.add (cancelButton);
  

          getContentPane ().add (jPanel3, java.awt.BorderLayout.SOUTH);

        }//GEN-END:initComponents

            /** Closes the dialog */
        private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
                setVisible (false);
                dispose ();
        }//GEN-LAST:event_closeDialog

            /**
             * @param args the command line arguments
             */
        public static void main (String args[]) {
                Object[] possibleValues = { "Both",
                                            "Home Status ", 
					    "Away Status "
		};
                Object s = RadioOptionsDialog.showRadioOptionsDialog (new javax.swing.JFrame (), true, 
                                                                      "Please choose one", "Distributor Status", possibleValues, null);
    
                System.out.println("Selection = "+s.toString());
        }


        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JPanel jPanel1;
        private javax.swing.JTextArea messageText;
        private javax.swing.JPanel buttonPanel;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JButton okButton;
        private javax.swing.JButton cancelButton;
        // End of variables declaration//GEN-END:variables

}

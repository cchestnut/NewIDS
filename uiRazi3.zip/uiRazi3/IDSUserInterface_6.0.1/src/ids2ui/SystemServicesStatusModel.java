/*
**  SCCS Info :  "@(#)SystemServicesStatusModel.java	1.8    05/05/03"
*/
/*
 * SystemServicesStatusModel.java
 *
 * Created on June 29, 2000, 9:43 AM
 */
 
package ids2ui;

/** 
 *
 * @author  srz
 * @version 
 */
public class SystemServicesStatusModel 
    extends javax.swing.table.AbstractTableModel 
    implements	Utils.UpdateModel
{
  
    private String 		   	m_hostTag = null;
    private String		   	m_progList = null;


    protected int     		m_sortCol = 0;
    protected boolean 		m_sortAsc = true;
    protected java.util.Vector 	m_vector = null;

    protected int 			m_columnsCount = 
	Constants.SystemServicesTableColumnNames.length;

    protected int 			m_rowsCount = 0;

    private String[][]		m_serverDesc = null;

        private String m_location1 = "DC-I Status";
        private String m_location2 = "DC-II Status";
        
    
    public SystemServicesStatusModel(String[][] tableDesc, String hTag)
    {

	m_serverDesc = tableDesc;

	m_rowsCount = m_serverDesc.length;

	m_vector = new java.util.Vector(m_rowsCount);
	m_hostTag = hTag;



	StringBuffer progList = new StringBuffer();
	for ( int i = 0; i < m_rowsCount; i++)  {
	    progList.append(m_serverDesc[i][1]);
	    if (i < (m_rowsCount-1))
		progList.append(",");
	    String rowData[] = new String[m_columnsCount];
	    rowData[0] = m_serverDesc[i][0];
	    rowData[1] = Constants.NO_STATUS;
	    rowData[2] = Constants.NO_STATUS;
	    m_vector.add(rowData);
	}
	    
	m_progList = progList.toString();

        try {
                java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
                m_location1 = (String)map.get("LOCATION1");
                m_location2 = (String)map.get("LOCATION2");
        }
        catch (Exception e)
        {
        }
        
    }



    public void Refresh() {
	try {
	    Update();
	} catch (Exception e){	
	    Log.getInstance().log_error("Error in update",e);
	}
    }

  
    public boolean isCellEditable(int r, int c) {
	return false;
    }

    
    synchronized public int getRowCount() {
	return m_rowsCount;
    }

    public int getColumnCount() { 
	return m_columnsCount;
    }


    public String getColumnName(int col) {
	int column = col;
      	String str = Constants.SystemServicesTableColumnNames[column];

        if (column == 1 && m_location1 != null)  str = m_location1;
        if (column == 2 && m_location2 != null)  str = m_location2;
        
	if (col==m_sortCol)
	    str += m_sortAsc ? " \273" : " \253";
	return str;
    }
 

    synchronized public Object getValueAt(int nRow, int nCol) {
	
	if (nRow < 0 || nRow>=m_rowsCount)
	    return "";

	return ((String[])m_vector.get(nRow))[nCol];
    }

    synchronized public java.util.Vector getDataVector(){
	return m_vector;
    }

    synchronized public void stop() {
	//threadPool.waitForAll(true);
	m_vector.clear();
	m_vector = null;

    }
   



    public void Update() 
    throws Exception 
    {


	/* Retrieve DCM configuration ;
	   fill all fields and select current items in lists */
	try {

	    java.util.HashMap map = ConfigComm.getHashMap(m_hostTag);
		
            String s = (String)map.get("LOCATION1");
            
            if (s != null)
                    m_location1 = new String(s);
            else
                    m_location1 = null;

            s = (String)map.get("LOCATION2");
            if (s != null)
                    m_location2 = new String(s);
            else
                    m_location2 = null;



            /*
            ** Retrieve the list of running system programs from adminserver
            ** and update status fields
            */
            
            String statusBuf1 = null;
            String statusBuf2 = null;
            boolean exc1=false, exc2=false;
            try
            {
                    statusBuf1 =
                            Utils.getProgramStatus((String)map.get("PHOST1"),
                                                   Constants.ADMINSERVER,
                                                   Constants.ADMINSERVER);
                    
            }
            catch (Exception ignore)
            {
                    exc1= true;
                    ignore.printStackTrace();
            }


            
            try {
                    statusBuf2
                            = Utils.getProgramStatus((String)map.get("PHOST2"),
                                                     Constants.ADMINSERVER,
                                                     Constants.ADMINSERVER);
                    
            }
            catch (Exception ignore)
            {
                    exc2 = true;
                    ignore.printStackTrace();
            }

            
	    
	    
	  

	    
	    
            
	    synchronized (this) {
		if (exc1) {
		    for (int r = 0; r < m_rowsCount; r++) 
			setValueAt(Constants.NO_STATUS,r,1);
		} else {
		    updateStatus(statusBuf1, 1);
		}
		if (exc2) {
		    for (int r = 0; r < m_rowsCount; r++) 
			setValueAt(Constants.NO_STATUS,r,2);
		} else {
		    updateStatus(statusBuf2, 2);
		}

		java.util.Collections.sort(m_vector, new
				   StatusComparator(m_sortCol, m_sortAsc));
	    }

	    IDS_SwingUtils.fireTableChanged(this, m_rowsCount, m_rowsCount);
		
	} catch (Exception e) {

	    synchronized (this) {
		for (int r = 0; r < m_rowsCount; r++) {
		    setValueAt(Constants.NO_STATUS,r,1);
		    setValueAt(Constants.NO_STATUS,r,2);
		}
		java.util.Collections.sort(m_vector, new
					   StatusComparator(m_sortCol, m_sortAsc));	
	    }
	    fireTableDataChanged();

	    if (e instanceof DBException) {
		if (((DBException)e).getErrorNo()
                    == Constants.KEY_NOT_FOUND) {
		    Log.getInstance().log_error(
                            "SystemServicesStatusModel:Configuration does not exist."
                            +m_hostTag,e);          
		    
		    return;
		}
	    }
	    Log.getInstance().log_error("Error in retrieving configuration"
						 +m_hostTag,e);
	    throw (e);
		
	}
	    
    } /* End of Update() */
    




    private void setValueAt(String s, int row, int col) 
    {
	String[] rowData = (String[])m_vector.get(row);
	rowData[col] = s;
	m_vector.set(row,rowData);
    }
   
    private void updateStatus(String datastr, int column)
    {
        for (int r = 0; r < m_rowsCount; r++) {
		setValueAt(Constants.NOT_RUNNING, r, column);
	}

	java.util.StringTokenizer st
	    = new java.util.StringTokenizer(datastr.trim(),
				   "\n");
	if ((datastr==null) || datastr.trim().length()==0) {
	    return;
	}
        boolean first_record = true;
 
	while (st.hasMoreTokens()){
	    int kindex=-1;

            String s = st.nextToken();
            if (first_record)
            {
                    String separator = new String(",\0\n");
                    java.util.StringTokenizer tokenizer 
                            = new java.util.StringTokenizer(s,separator);
                    
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    if (tokenizer.hasMoreTokens())
                            tokenizer.nextToken();
                    
                    if (tokenizer.hasMoreTokens())
                            s = tokenizer.nextToken();

                    first_record = false;
            }
            
	    	

	    String sep1 = new String(" \t");

	    java.util.StringTokenizer st1 = 
		new java.util.StringTokenizer(s.trim(),sep1);


	    String progname = null;
	    if (st1.hasMoreTokens())
		progname = st1.nextToken();	
	    else
		continue;

	    for (int r = 0; r < m_rowsCount; r++) {
		if (progname.equals(m_serverDesc[r][1])) {
	    		for (int r1 = 0; r1 < m_rowsCount; r1++) {
				if (m_serverDesc[r][0].equals((String)getValueAt(r1,0))) {
		    			setValueAt(Constants.RUNNING,r1,column);
		    			break;
				}
			}
			break;
		}
	    }
	}
    }

    class ColumnListener extends java.awt.event.MouseAdapter
    {
	protected javax.swing.JTable m_table;
	private FIFOReadWriteLock	rwLock;
	
	public ColumnListener(javax.swing.JTable table,FIFOReadWriteLock  lk) {
	    m_table = table;
	    rwLock = lk;
	}	
	
	public void mouseClicked(java.awt.event.MouseEvent e) {
	    javax.swing.table.TableColumnModel colModel 
		= m_table.getColumnModel();
	    int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
	    int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

	    if (modelIndex < 0)
		return;

	    try {
		if (!rwLock.writeLock().attempt(0)) {
		    java.awt.Toolkit.getDefaultToolkit().beep();
		    return;
		}
	    } catch (InterruptedException ie) {
		java.awt.Toolkit.getDefaultToolkit().beep();
		return;
	    }

	    if (m_sortCol==modelIndex)
		m_sortAsc = !m_sortAsc;
	    else
		m_sortCol = modelIndex;


		
	    for (int i=0; i < m_columnsCount; i++) {
		javax.swing.table.TableColumn column = colModel.getColumn(i);
		column.setHeaderValue(getColumnName(column.getModelIndex()));    
	    }

	    m_table.getTableHeader().repaint();  

	    synchronized (SystemServicesStatusModel.this ) {
		java.util.Collections.sort(m_vector, new 
					   StatusComparator(modelIndex, m_sortAsc));
	    }

	  
	    m_table.tableChanged(
				 new javax.swing.event.TableModelEvent(SystemServicesStatusModel.this)); 
	    m_table.repaint();  

	    rwLock.writeLock().release();
	    
	}
    }


    class StatusComparator implements java.util.Comparator
    {
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StatusComparator(int sortCol, boolean sortAsc) {
	    m_sortCol = sortCol;
	    m_sortAsc = sortAsc;
	}

	public int compare(Object o1, Object o2) {
	    String[] v1 = (String[])o1;
	    String[] v2 = (String[])o2;
	    String s1 = v1[m_sortCol];
	    String s2 = v2[m_sortCol];

	    int result = 0;

	    if (s1==null)
		result = +1000;
	    else if (s2==null)
		result = -1000;
	    else
		result = s1.compareTo(s2);

	    if (!m_sortAsc)
		result = -result;
	    return result;
	}

    }



}

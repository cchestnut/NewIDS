/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package refactor.ui.forms;

import ids2ui.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellEditor;
import model.PremiumCodesList;
import refactor.ui.model.PremiumCodesListTableModel;
import refactor.ui.model.ValidatingCellEditor;

/**
 *
 * @author srz
 */
public class PremiumCodesForm extends javax.swing.JFrame {

    PremiumCodesListTableModel pcltm;
    /**
     * Creates new form PremiumCodesForm
     */
    public PremiumCodesForm() {
        
        WindowEventAdapter.getInstance()
                .registerWindow(Constants.CONFIGURATION_PREMIUMCODES,this);
        
	setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	
        initComponents();
        statusPanel = new ids2ui.StatusPanel ();
        jPanel4.add(statusPanel);
        
        boolean readOnly = false;
        if ( AccessLevel.MENU_ACCESS_LEVEL != 0 ) {
                readOnly = true;
                jPanel3.remove(saveButton);                
        }
        
        PremiumCodesList premiumCodesList = ConfigComm.getPremiumCodesList();
        pcltm = new PremiumCodesListTableModel(premiumCodesList,
                readOnly);
        
        final ValidatingCellEditor uce = new ValidatingCellEditor(pcltm);
        javax.swing.JTable codeTable = new javax.swing.JTable() {
            @Override
            public TableCellEditor getCellEditor(int r, int c)
            {                
                if (convertColumnIndexToModel(c) == 0)
                    return uce;
                else
                    return super.getCellEditor(r, c);
            }
        };
        
        PremiumCodesPanel pcp = new PremiumCodesPanel(codeTable);
        final javax.swing.JButton deleteButton = pcp.getDeleteButton();
        final javax.swing.JTable table = pcp.getTable();
        table.setModel(pcltm);
        deleteButton.setEnabled(false);
        if (!readOnly) {
            saveButton.addActionListener(new java.awt.event.ActionListener() {

                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    screenActionHandler(evt);
                }
            });
            closeButton.addActionListener(new java.awt.event.ActionListener() {

                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    screenActionHandler(evt);
                }
            });
            
            deleteButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    int[] srows = table.getSelectedRows();
                    if (srows.length == 0) {
                        return;
                    }
                    pcltm.removeRows(srows);
                }
            });


            table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

                public void valueChanged(ListSelectionEvent e) {
                    int[] srows = table.getSelectedRows();
                    boolean state = true;
                    if (srows.length == 0) {
                        state = false;
                    }
                    deleteButton.setEnabled(state);
                }
            });
        }
        
        jPanel2.add(pcp);
        
        
        addWindowListener(new java.awt.event.WindowAdapter() {

            @Override
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        pack();
    }

    
    
    private void screenActionHandler (java.awt.event.ActionEvent evt) {//GEN-FIRST:event_screenActionHandler
	// Add your handling code here:
	String command = evt.getActionCommand();
	Object src = evt.getSource();
        javax.swing.JButton source = null;

	

	if (src instanceof javax.swing.JButton ) {
	    source = (javax.swing.JButton)src;
	    source.setEnabled(false);
	}

	final Utils.ActionWorker sw = new Utils.ActionWorker(source, 
							     command) {
	    public Object construct() {
		_screenActionHandler(cmdButton, action);
		return null;
	    }
	};

	sw.start();

    }//GEN-LAST:event_screenActionHandler



    private void _screenActionHandler(javax.swing.JButton cmdButton, 
				    String command)
    {

	boolean exit_form = false;

    codeblock:
	if (command.equals("Close")) {
	    exit_form = closeForm();
	} else if (command.equals("Save")) {

	    try {
		mLock.acquire();
	    } catch (InterruptedException ie) {
		Log.getInstance().log_error("Service handler interrupted",ie);
		break codeblock;
	    }

	    statusPanel.start("Saving configuration. Please wait ...");

	    exit_form = saveConfig();

	    statusPanel.stop();
	    statusPanel.clear();

	    mLock.release();
	}

	if (exit_form) exitForm(null);
	if (cmdButton != null ) cmdButton.setEnabled(true);

    }

    private boolean closeForm() {

        if (AccessLevel.MENU_ACCESS_LEVEL != 0) {
            return true;
        }

        if (pcltm.isEdited()) {
            if (javax.swing.JOptionPane.YES_OPTION
                    != Log.getInstance().show_confirm(this, "Please confirm",
                    "Any unsaved changes will be "
                    + "lost.\nAre you sure you want"
                    + " to close window?.")) {


                return false;
            }
        }

            return true;
    }


    private boolean saveConfig()
    {

	int err=0;
	int i;

        String s = pcltm.toString();
        PremiumCodesList pcl = PremiumCodesList.parse(s);
	
	String errstr = "Please enter valid information :\n";


	if (s.length() == 0)
	    {err=1;errstr += "Premium Codes are empty \n";}

	

	if (err==1) {
	    javax.swing.JOptionPane.showMessageDialog(this,
					errstr, "Error",
					javax.swing.JOptionPane.ERROR_MESSAGE);
	    return false;
	}


	

	try {
	    StringBuffer buf = new StringBuffer();
	    
	    statusPanel.showStatus("Saving configuration ...");
            
            ConfigComm.saveKeyValue(buf,
                    Constants.GLB_TAG_PREMIUM_FILTER_CODES,s);
	    
	    byte [] b = ConfigComm.configRequest(buf);

            ConfigComm.setPremiumCodesList(pcl);
	} catch (Exception e) {
	    	    
	    Log.getInstance().show_error(this,"Error",
					 "Error in saving configuration",e);
	    return false;
	}

	return true;
    }




    /** Exit the Application */
    public void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm


	if (isExiting) return;

	isExiting = true;

	final javax.swing.JPanel gpanel = 
		(javax.swing.JPanel) getGlassPane();

	gpanel.setLayout(new java.awt.GridBagLayout());

	
	final StatusPanel sp = new StatusPanel();
	sp.setBackground(java.awt.Color.yellow);
	sp.start("Closing window.\nPlease wait..");
	
	gpanel.add(sp);
	gpanel.validate();
	gpanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR));
        gpanel.addMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
	gpanel.addMouseListener(Constants.MOUSE_ADAPTER);
	gpanel.setVisible(true);


	final PremiumCodesForm This = this;

	final SwingWorker exitThread = new SwingWorker() {
	    public Object construct() {
		try {
		    mLock.acquire();
		} catch (InterruptedException ie ) {}
		return null;
	    }

            @Override
	    public void finished() {
		This.setVisible(false);
		sp.stop();
		gpanel.removeAll();
        	gpanel.removeMouseMotionListener(Constants.MOUSE_MOTION_ADAPTER);
		gpanel.removeMouseListener(Constants.MOUSE_ADAPTER);
		This.dispose();
		WindowEventAdapter.getInstance().unregisterWindow(This);
	    }

	};

	exitThread.start();

		



    }//GEN-LAST:event_exitForm

    private StatusPanel statusPanel;
    private MutexLock   mLock = new MutexLock();
    private volatile boolean isExiting = false;
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        saveButton = new javax.swing.JButton();
        closeButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jPanel1.setLayout(new java.awt.BorderLayout());

        saveButton.setText("Save");
        jPanel3.add(saveButton);

        closeButton.setText("Close");
        jPanel3.add(closeButton);

        jPanel1.add(jPanel3, java.awt.BorderLayout.NORTH);

        jPanel4.setLayout(new javax.swing.BoxLayout(jPanel4, javax.swing.BoxLayout.LINE_AXIS));
        jPanel1.add(jPanel4, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);

        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));
        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PremiumCodesForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PremiumCodesForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PremiumCodesForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PremiumCodesForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new PremiumCodesForm().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closeButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JButton saveButton;
    // End of variables declaration//GEN-END:variables
}

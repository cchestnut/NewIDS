/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package refactor.ui.model;

/**
 * SVN  Info :  "$Id$"
 * SCCS Info :  "%W%    %E%"
 * @author srz
 */
public interface CellKeyValidator {
    public boolean isValid(int row, String value);
}

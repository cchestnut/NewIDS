/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package refactor.ui.model;

import java.util.*;
import javax.swing.table.AbstractTableModel;
import model.PremiumCodesList;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class PremiumCodesListTableModel
        extends AbstractTableModel implements CellKeyValidator{

    public void removeRows(int[] srows) {
        if (srows.length == 0)
            return;
        Arrays.sort(srows);
        int rcount = 0;
        for (int i = srows.length-1; i >=0; i--)            
        {
            if (srows[i] < tableData.size())
            {
                ++rcount;            
                tableData.remove(srows[i]);
            }
        }
        
        if (rcount > 0)
        {
            isEdited = true;
            fireTableDataChanged();
        }
    }

    public boolean isValid(int rowIndex, String value) {
        if (value==null)
            return false;
        int size = tableData.size();
        for (int r = 0; r < size; r++)
        { 
            if (r == rowIndex) continue;
            Row row = tableData.get(r);                
            if (row.code.equalsIgnoreCase(value))
                return false;
        }
        return true;
    }

    private class Row {
        String code;
        String description;
    }
    private static int EXTRA_ROW = 1;
    private static String columns[] = {"Premium Code", "Description"};
    private List<Row> tableData = new ArrayList<Row>();
    boolean[] canEdit = new boolean[]{true, true};
    private static Class[] types = {java.lang.String.class,
        java.lang.String.class
    };
    
    boolean isEdited = false;
    boolean readOnly = false;
    
    public PremiumCodesListTableModel(PremiumCodesList _codesList, boolean ro) {
        if (_codesList != null) {
            load(_codesList);
        }
        this.readOnly = ro;
    }
    
    public PremiumCodesListTableModel() {
        this(null, false);        
    }

    private void load(PremiumCodesList _codesList) {
        Set<Map.Entry<String, String>> entries = _codesList.getEntries();

        for (Map.Entry entry : entries) {
            Row r = new Row();
            r.code = entry.getKey().toString();
            r.description = entry.getValue().toString();
            tableData.add(r);
        }
    }

    public int getRowCount() {
        return tableData.size()+((readOnly)?0:EXTRA_ROW);
    }

    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (readOnly) return false;
        if (columnIndex == 1)
        {
            String s = getValueAt(rowIndex, 0).toString();
            if (s.trim().length()==0)
                return false;
        }
        return canEdit[columnIndex];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return types[columnIndex];
    }

    @Override
    public String getColumnName(int columnIndex) {
        return columns[columnIndex];
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex >= tableData.size())
            return "";
        
        Row r = tableData.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return r.code;
            case 1:
                return r.description;
        }
        return "";
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
        boolean new_row = false;
        if (rowIndex >= tableData.size())
        {           
            if (value.toString().trim().length() == 0)
                return;
            tableData.add(rowIndex, new Row());    
            new_row = true;
        }
        
        String oldValue=null;
        Row r = tableData.get(rowIndex);
        switch (columnIndex) {
            case 0:
                oldValue = r.code;
                r.code = value.toString().toUpperCase();
                break;
            case 1:
                oldValue = r.description;
                r.description = value.toString();
                break;
        }

        if ((oldValue == null) || !(oldValue.equals(value)))
        {
            isEdited = true;        
            fireTableCellUpdated(rowIndex, columnIndex);
        }
        if (new_row)
        {
            isEdited = true;
            int nrow = tableData.size()+EXTRA_ROW-1;        
            fireTableRowsInserted(nrow, nrow);
        }

    }
    
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        
        for (Row r:tableData)
        {
            if (r.code.trim().length() > 0 )
                sb.append("<")
                    .append(r.code)
                    .append(",")
                    .append((r.description!=null)?r.description:"")
                    .append(">");
        }
        return sb.toString();
    }
    
    public boolean isEdited()
    {
        return isEdited;
    }
}

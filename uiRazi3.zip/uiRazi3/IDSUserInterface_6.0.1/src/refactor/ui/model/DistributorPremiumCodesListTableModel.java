/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package refactor.ui.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.swing.table.AbstractTableModel;
import model.PremiumCodesList;

/**
 * SVN Info : "$Id$" SCCS Info : "%W% %E%"
 *
 * @author srz
 */
public class DistributorPremiumCodesListTableModel 
extends AbstractTableModel {

    private static String columns[] = {"Pr. Code", "Content", "Enabled"};
    boolean[] canEdit = new boolean [] {false, false, true };
    private static Class[] types = {java.lang.String.class,
        java.lang.String.class,
        java.lang.Boolean.class
    };
    private PremiumCodesList codesList;
    private List<Row> tableData = new ArrayList<Row>();
    
    private class Row {
        String code;
        String content;
        Boolean enabled;
    }
    
    private void addRows(boolean b, String ... codes)
    {
        for (String code : codes) {
            if (code.trim().length() == 0)
                continue;
            Row r = new Row();
            r.code = code.trim();
            r.content = codesList.lookup(r.code);
            r.enabled = b;
            tableData.add(r);
        }
    }

    public DistributorPremiumCodesListTableModel(PremiumCodesList list, 
            String dbvalue) 
    {
    
        this.codesList = list;
        String[] codes = new String[0];
        
        
        
        Set<String> dbcodes = list.getTokens();
        codes = dbcodes.toArray(codes);        
        addRows(Boolean.FALSE, codes);
        
        if ((dbvalue != null) 
                && (dbvalue.trim().length() > 0)
                && (!dbvalue.equals("NONE"))) {
            
            String[] ecodes = dbvalue.split("[(| )]");
            for (String ecode:ecodes)
            {
                ecode = ecode.trim();
                if ((ecode.length() == 0)
                    || (ecode.equals("NONE")))
                    continue;
                
                if (dbcodes.contains(ecode))
                {
                    int sz = tableData.size();
                    for (int i = 0; i < sz; i++)
                    {
                        Row r = tableData.get(i);
                        if (r.code.equals(ecode))
                        {
                            r.enabled = Boolean.TRUE;
                            break;
                        }
                    }
                }
                else
                {
                    Row r = new Row();
                    r.code = ecode;
                    r.content = "";
                    r.enabled = Boolean.TRUE;
                    tableData.add(r);
                }
            }
            
        }
    }

    public int getRowCount() {
        return tableData.size();
    }

    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return types[columnIndex];
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return columns[columnIndex];
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        Row r = tableData.get(rowIndex);
        
        switch (columnIndex)
        {
            case 0:
                return r.code;                
            case 1:
                return r.content;
            case 2:
                return r.enabled;                
        }
        return r;
    }
    
    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
        if (columnIndex == 2) {
            Row r = tableData.get(rowIndex);
            r.enabled = ((Boolean) value).booleanValue();
            fireTableCellUpdated(rowIndex, columnIndex);
            
            System.out.println("MODEL UPDATED:"+this.toString());
        }
    }
    
    @Override
    public String toString()
    {
       StringBuilder sb = new StringBuilder();
       int count = 0;
       int nitems = tableData.size();
       
       for (int i = 0; i < nitems; i++)
       {
           Row r = tableData.get(i);
           if (r.enabled)
           {
               count++;
               if (count > 1)
                   sb.append(" | ");
               
               sb.append(r.code);
           }
       }
          
       if (count > 0 )
       {
           sb.insert(0, "( ");
           sb.append(" )");
       }
       else
           sb.setLength(0);
       
       return sb.toString();
    }
}

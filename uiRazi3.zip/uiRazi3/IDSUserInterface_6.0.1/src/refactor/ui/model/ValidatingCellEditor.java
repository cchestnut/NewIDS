package refactor.ui.model;

import java.awt.Component;
import java.awt.Toolkit;
import javax.swing.*;
import javax.swing.text.DefaultFormatterFactory;

public class ValidatingCellEditor extends DefaultCellEditor {

    protected JFormattedTextField editorField;
    protected int editRow = -1, editCol = -1;
    private CellKeyValidator validator;

    public ValidatingCellEditor(CellKeyValidator v) {
        super(new JFormattedTextField());

        validator = v;

        editorField = (JFormattedTextField) getComponent();
        editorField.setFormatterFactory(new DefaultFormatterFactory());
        editorField.setFocusLostBehavior(JFormattedTextField.PERSIST);

    }

    @Override
    public Component getTableCellEditorComponent(JTable table,
            Object value, boolean isSelected,
            int row, int column) {
        JFormattedTextField ftf =
                (JFormattedTextField) super.getTableCellEditorComponent(
                table, value, isSelected, row, column);
        ftf.setValue(value);
        editRow = row;
        editCol = column;
        return ftf;
    }

    @Override
    public Object getCellEditorValue() {

        Object o = editorField.getValue();
        String s = editorField.getText();
        if (validator.isValid(editRow, s)) {
            return s;
        } else {
            return o;
        }
    }

    @Override
    public boolean stopCellEditing() {

        String s = editorField.getText();
        if (validator.isValid(editRow, s)) {
            try {
                editorField.commitEdit();
            } catch (java.text.ParseException exc) {
            }
        } else {
            if (!showWarning()) {
                return false;
            }
        }
        return super.stopCellEditing();
    }

    protected boolean showWarning() {
        Toolkit.getDefaultToolkit().beep();
        editorField.selectAll();
        Object[] options = {"Edit",
            "Cancel"};
        int answer = JOptionPane.showOptionDialog(
                SwingUtilities.getWindowAncestor(editorField),
                "Premium code exists already.",
                "Invalid code Entered",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.ERROR_MESSAGE,
                null,
                options,
                options[1]);

        if (answer == 1) {
            editorField.setValue(editorField.getValue());
            return true;
        }
        return false;
    }
}
